import {projectConfig} from './vitest.shared.mts';
import {defineConfig} from './vitest.shared.mts';
export default projectConfig('zz-scan', defineConfig({test:{include:['zz-scan/owner-mobile-scan.integration.ts'],fileParallelism:false,testTimeout:2400000,passWithNoTests:false}}));
