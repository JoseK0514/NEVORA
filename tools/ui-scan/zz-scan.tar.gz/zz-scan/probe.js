() => {
  const page = document.querySelector('.page-frame :is(.c-page, .q-page)'); if (!page) return null;
  const textLeft = e => { const w = document.createTreeWalker(e, NodeFilter.SHOW_TEXT); let n; while ((n = w.nextNode())) { if (!n.textContent.trim()) continue; const p = n.parentElement; const cs = getComputedStyle(p); if (cs.display === 'none' || cs.visibility === 'hidden' || p.closest('.c-sr, .q-sr, .sr-only, [hidden]')) continue; const r = document.createRange(); r.selectNodeContents(n); const rr = r.getClientRects()[0]; if (rr && rr.width > 0) return Math.round(rr.left * 2) / 2; } return null; };
  const nm = e => (e.tagName.toLowerCase() + '.' + [...e.classList].slice(0, 3).join('.')).slice(0, 48);
  const row = page.querySelector(':is(.c-card, .q-list) :is(.c-row__title, .q-rt b, .b-row__tt)');
  const rowLeft = row ? textLeft(row) : null;
  const hero = [...page.children].filter(c => c.matches('.c-nav--phone, .q-nav, .c-phone-sub, .q-hd, .c-seg, .q-seg, .c-shift__head, .c-formhead') && getComputedStyle(c).display !== 'none');
  const heroBottom = hero.length ? Math.round(Math.max(...hero.map(h => h.getBoundingClientRect().bottom))) : null;
  const firstContent = [...page.children].find(c => !hero.includes(c) && getComputedStyle(c).display !== 'none' && getComputedStyle(c).position !== 'absolute' && c.getBoundingClientRect().height > 2);
  const out = { rowLeft, heroBottom, first: firstContent ? [nm(firstContent), Math.round(firstContent.getBoundingClientRect().top)] : null, labels: [], dividers: [] };
  // text blocks outside cards (labels, notes) and non-row text inside cards
  const seen = new Set();
  for (const e of page.querySelectorAll('h2, h3, p, label, .c-section__label, .c-sec-label, .q-grp, .q-sec, .wc-foot, .wc-intro, .c-note, .q-help, .c-field__label, .q-fl__label, .c-empty__title, .c-empty__body, .wc-cardhead, .c-card__head, .c-card__body > *, .q-empty, .c-error-card > *')) {
    if (e.closest('.b-screen, .c-nav, .q-nav, .q-hd, .c-shift__head, .c-formhead, .c-phone-sub, [hidden]') || seen.has(e)) continue;
    const x = textLeft(e); if (x === null) continue; seen.add(e);
    const inCard = !!e.closest('.c-card, .q-list, .wc-card');
    const chain = []; for (let n = e; n && n !== page; n = n.parentElement) { const cs = getComputedStyle(n); const ml = parseFloat(cs.marginLeft), pl = parseFloat(cs.paddingLeft); if (ml || pl) chain.push(`${nm(n)}:m${ml}p${pl}`); }
    out.labels.push([inCard ? 'in' : 'out', nm(e), (e.textContent || '').trim().slice(0, 22), x, chain.slice(0, 4).join(' < ')]);
  }
  // dividers between rows: what draws them
  for (const li of page.querySelectorAll(':is(.c-rows, .q-list) > li + li, .c-card > .c-row + .c-row, .c-card__head + *')) {
    const cs = getComputedStyle(li); const kid = li.firstElementChild; const kcs = kid ? getComputedStyle(kid) : null; const ka = kid ? getComputedStyle(kid, '::after') : null; const kb = kid ? getComputedStyle(kid, '::before') : null;
    out.dividers.push([nm(li), (li.textContent || '').trim().slice(0, 16), 'bg:' + cs.backgroundImage.slice(0, 30), 'bt:' + cs.borderTopWidth, 'sh:' + cs.boxShadow.slice(0, 30), kid ? 'kid:' + nm(kid) + ' bt:' + kcs.borderTopWidth + ' sh:' + kcs.boxShadow.slice(0, 26) + ' after:' + ka.content + '/' + ka.height + ' before:' + kb.content + '/' + kb.height : '']);
    if (out.dividers.length > 6) break;
  }
  out.labels = out.labels.slice(0, 18);
  return out;
}
