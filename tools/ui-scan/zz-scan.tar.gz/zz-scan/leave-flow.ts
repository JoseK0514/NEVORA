// Leave and staffing (Nov 9, 2026): fictional leave over published shifts, the approval conflict, a repair, draft vs
// published, privacy and the X-Nevora-Failure negatives. Local Postgres only; no provider calls; nothing real is sent.
/* eslint-disable @typescript-eslint/no-explicit-any */
type Q=(text:string,values?:unknown[])=>Promise<any>;
const rows=(r:any)=>Array.isArray(r)?r:r?.rows??[];
export type LeaveSeed={week:string;maria?:{id:string;date:string;shiftId:string};james?:{id:string;date:string};ana?:{id:string;date:string}};

/** Pending full day for Maria (the flow approves it in the browser), pending part day for James (stays waiting) and an
 * older approval with no reviewer for Ana (a repair that needs an Owner), each over a published shift later this week. */
export async function seedLeave(q:Q,actors:string[],week:string,today:string,log:unknown[]):Promise<LeaveSeed>{
 const seed:LeaveSeed={week};
 const next=async(employee:string)=>rows(await q(`SELECT sh.date::text AS date,to_char(sh.start_time,'HH24:MI') AS s,to_char(sh.end_time,'HH24:MI') AS e,sh.source_shift_id AS shift FROM schedule_publication_revision_shifts sh
   JOIN schedule_publication_revisions p ON p.id=sh.revision_id WHERE p.week_start=$1 AND sh.employee_id=$2 AND sh.date>$3::date
   AND p.revision_number=(SELECT max(revision_number) FROM schedule_publication_revisions WHERE week_start=$1) ORDER BY sh.date,sh.start_time LIMIT 1`,[week,employee,today]))[0];
 const m=await next(actors[0]),j=await next(actors[1]),a=await next(actors[2]);
 log.push({leaveShifts:{m,j,a}});
 if(m){await q(`INSERT INTO time_off_requests(id,employee_id,start_date,end_date,reason,status,created_at) VALUES('scan-leave-maria',$1,$2,$2,'Family visit','PENDING',now()-interval '3 hours')`,[actors[0],m.date]);seed.maria={id:'scan-leave-maria',date:m.date,shiftId:m.shift};}
 if(j){await q(`INSERT INTO time_off_requests(id,employee_id,start_date,end_date,start_time,end_time,reason,status,created_at) VALUES('scan-leave-james',$1,$2,$2,'13:00','17:00','Dentist','PENDING',now()-interval '1 hour')`,[actors[1],j.date]);seed.james={id:'scan-leave-james',date:j.date};}
 if(a){await q(`INSERT INTO time_off_requests(id,employee_id,start_date,end_date,reason,status,reviewed_by,reviewed_at,created_at) VALUES('scan-leave-ana',$1,$2,$2,'Appointment','APPROVED',NULL,now()-interval '2 days',now()-interval '3 days')`,[actors[2],a.date]);seed.ana={id:'scan-leave-ana',date:a.date};}
 return seed;
}

const settle=async(page:any,ms=2500)=>{await page.waitForLoadState('networkidle').catch(()=>{});await page.waitForTimeout(ms);};
const size=async(page:any,w:number)=>{await page.setViewportSize({width:w,height:w>1000?900:w>=768?1024:844});await page.waitForTimeout(500);};
const active=(page:any)=>page.evaluate(()=>{const e=document.activeElement as HTMLElement|null;return e?(e.tagName.toLowerCase()+'#'+e.id+'.'+[...e.classList].slice(0,2).join('.')+' "'+(e.textContent||'').trim().replace(/\s+/g,' ').slice(0,50)+'"'):null;});
const attr=(page:any,sel:string,name:string)=>page.evaluate(([s,n]:string[])=>[...document.querySelectorAll(s)].filter(e=>(e as HTMLElement).getClientRects().length).map(e=>e.getAttribute(n)),[sel,name]);
const text=(page:any,sel:string)=>page.evaluate((s:string)=>[...document.querySelectorAll(s)].filter(e=>(e as HTMLElement).getClientRects().length).map(e=>(e.textContent||'').replace(/\s+/g,' ').trim().slice(0,300)),sel);

/** Every negative check: the staffing reads answer with the contract's status and X-Nevora-Failure. */
export async function staffingProbe(page:any,app:string,label:string,body:Record<string,unknown>,headers:Record<string,string>,path:string,origin?:string){
 if(origin){const r=await page.request.post(app+path,{headers:{'content-type':'application/json',origin,...headers},data:body,failOnStatusCode:false});return {label,status:r.status(),failure:r.headers()['x-nevora-failure']??null};}
 return page.evaluate(async([p,b,h,l]:[string,unknown,Record<string,string>,string])=>{const r=await fetch(p,{method:'POST',credentials:'same-origin',headers:{'content-type':'application/json',...h},body:JSON.stringify(b)});const t=await r.text();
  let items:unknown=null;try{const j=JSON.parse(t);items=Array.isArray(j.items)?j.items.map((i:any)=>({id:i.id,state:i.state,employee:i.employeeName,location:i.locationName,owner:i.ownerEmployeeId,overlap:i.overlapMinutes})):j.state;}catch{items=t.slice(0,80);}
  return {label:l,status:r.status,failure:r.headers.get('x-nevora-failure'),items};},[path,body,headers,label]);
}

/** The Owner's path: the conflict before Approve, Approve, the repair everywhere, the schedule, draft vs published. */
export async function runLeaveFlow(page:any,app:string,evidence:string,log:unknown[],seed:LeaveSeed,deps:{q:Q;publish:(week:string)=>Promise<unknown>;actorId:string;view:()=>Promise<string|null>}){
 const widths=(process.env.NEVORA_SCAN_LEAVE_W??'390,900,1440').split(',').map(Number);
 const shoot=async(name:string,url:string|null,ws=widths,wait=3500)=>{if(url){await page.goto(app+url);await settle(page,wait);}for(const w of ws){await size(page,w);await page.waitForTimeout(700);await page.screenshot({path:`${evidence}/leave-${name}-${w}.png`,fullPage:true});}};
 if(!seed.maria){log.push('leave: no Maria shift to seed');return;}
 const review=`/app/requests?tab=pending&requestId=${seed.maria.id}`;
 // 1. The request's page: the published shift before Approve.
 await page.goto(app+review);await settle(page,4000);
 log.push({leave:'review',check:await attr(page,'[data-check]','data-check'),text:await text(page,'.ls-check')});
 await shoot('review',null);
 // 1b. The check's other states, forced in the browser only: unavailable (the read fails) and expired (a short lifetime).
 await page.route('**/api/manager/time-off-staffing',(r:any)=>r.fulfill({status:503,contentType:'application/json',headers:{'x-nevora-failure':'source_unavailable'},body:JSON.stringify({state:'unavailable'})}));
 await page.goto(app+review);await settle(page,3500);log.push({leave:'review-unavailable',check:await attr(page,'[data-check]','data-check')});
 for(const w of [390,1440]){await size(page,w);await page.screenshot({path:`${evidence}/leave-review-unavailable-${w}.png`,fullPage:true});}
 await page.unroute('**/api/manager/time-off-staffing');
 let first=true;await page.route('**/api/manager/time-off-staffing',async(r:any)=>{if(!first){await new Promise(done=>setTimeout(done,6000));return r.fulfill({status:503,contentType:'application/json',body:'{"state":"unavailable"}'}).catch(()=>{});}first=false;const res=await r.fetch();const j=await res.json();j.validForMs=1500;return r.fulfill({response:res,body:JSON.stringify(j)});});
 await page.goto(app+review);await settle(page,800);await page.waitForTimeout(2500);log.push({leave:'review-expired',check:await attr(page,'[data-check]','data-check')});
 for(const w of [390]){await size(page,w);await page.screenshot({path:`${evidence}/leave-review-expired-${w}.png`,fullPage:true});}
 await page.unroute('**/api/manager/time-off-staffing');
 // 2. Things to do (phone): Maria and James waiting; Approve only for a request with no overlap.
 await shoot('todo-pending','/app/inbox',[390]);
 log.push({leave:'todo-pending',notes:await text(page,'.b-leave-note'),approve:await text(page,'.b-screen .b-decide')});
 // 3. Approve on the request's page (the existing form and handler).
 await size(page,1440);await page.goto(app+review);await settle(page,4000);
 const approve=page.getByRole('button',{name:/^Approve time off for /}).first();
 await approve.click();await settle(page,4000);
 log.push({leave:'approved',url:page.url().replace(app,''),db:rows(await deps.q("SELECT status,reviewed_by FROM time_off_requests WHERE id=$1",[seed.maria.id]))[0]});
 // 4. The repair: Things to do, Home, the Tasks list.
 await shoot('todo-repair','/app/inbox',widths,4500);
 log.push({leave:'todo-repair',rows:await text(page,'#b-todo-repair, #todo-repair')});
 await shoot('home','/app',[390,1440],4500);
 log.push({leave:'home',needs:await text(page,'#b-home-needs, #home-needs-you'),coverage:await text(page,'.cov')});
 const href=await page.evaluate(()=>{const a=[...document.querySelectorAll('a[href*="leaveRepair="]')] as HTMLAnchorElement[];return a[0]?.getAttribute('href')??null;});
 const repairHref=href??(await page.goto(app+'/app/inbox').then(()=>settle(page,4000)).then(()=>page.evaluate(()=>([...document.querySelectorAll('a[href*="leaveRepair="]')] as HTMLAnchorElement[])[0]?.getAttribute('href')??null)));
 log.push({leave:'repairHref',href:repairHref});
 if(!repairHref)return;
 // 5. The schedule opened from the task: the note takes focus, the person's shift is marked.
 for(const w of widths){await size(page,w);await page.goto(app+repairHref);await settle(page,4500);
  log.push({leave:'schedule',width:w,state:await attr(page,'.ls-repair','data-repair'),focus:await active(page),marked:await text(page,'.b-screen .b-chip'),desk:await attr(page,'tr[data-leave-repair]','id'),cov:await text(page,'.cov')});
  await page.screenshot({path:`${evidence}/leave-schedule-${w}.png`,fullPage:true});await page.screenshot({path:`${evidence}/leave-schedule-${w}-fold.png`,fullPage:false});}
 // Keyboard: from the note, Tab reaches Open the shift with a visible focus ring.
 await size(page,1440);await page.goto(app+repairHref);await settle(page,4500);await page.keyboard.press('Tab');await page.waitForTimeout(200);
 log.push({leave:'keyboard',after:await active(page),outline:await page.evaluate(()=>{const e=document.activeElement as HTMLElement|null;return e?getComputedStyle(e).outlineStyle+' '+getComputedStyle(e).outlineWidth:null;})});
 await page.screenshot({path:`${evidence}/leave-schedule-keyboard-1440.png`,fullPage:false});
 // 6. Draft vs published: deleting the shift in the draft keeps the repair; publishing the change clears it.
 await deps.q('DELETE FROM shifts WHERE id=$1',[seed.maria.shiftId]).catch((e:unknown)=>log.push('draft delete: '+String(e)));
 await shoot('schedule-draft',repairHref,[390,1440],4500);
 log.push({leave:'draft',state:await attr(page,'.ls-repair','data-repair'),api:await staffingProbe(page,app,'after draft',{weekStart:seed.week},{'x-nevora-leave-staffing':'1','x-nevora-actor':deps.actorId,'x-nevora-employee-view':(await deps.view())??''},'/api/manager/time-off-staffing')});
 await deps.publish(seed.week).then(r=>log.push({leave:'published',result:JSON.stringify(r).slice(0,160)})).catch((e:unknown)=>log.push('publish: '+String(e).slice(0,300)));
 log.push({leave:'after-publish',latest:rows(await deps.q(`SELECT p.revision_number AS n,(SELECT count(*)::int FROM schedule_publication_revision_shifts sh WHERE sh.revision_id=p.id AND sh.source_shift_id=$2) AS has FROM schedule_publication_revisions p WHERE p.week_start=$1 ORDER BY p.revision_number DESC LIMIT 2`,[seed.week,seed.maria.shiftId])),pending:rows(await deps.q(`SELECT l.short_name AS loc,s.status FROM schedules s JOIN locations l ON l.id=s.location_id WHERE s.week_start=$1`,[seed.week]))});
 await shoot('schedule-published',repairHref,[390,1440],4500);
 log.push({leave:'published-state',state:await attr(page,'.ls-repair','data-repair'),todo:await page.goto(app+'/app/inbox').then(()=>settle(page,4000)).then(()=>text(page,'#b-todo-repair, #todo-repair'))});
}

/** The negatives, as the signed-in person: wrong actor, stale view, missing intent, foreign origin, the other role's
 * endpoint, a colleague (employees), then revocation (the page's notice). */
export async function runLeaveNegatives(page:any,app:string,evidence:string,log:unknown[],input:{scope:'management'|'employee';actorId:string;view:string|null;colleague?:string;week:string;q:Q;revoke:boolean}){
 const path=input.scope==='management'?'/api/manager/time-off-staffing':'/api/employee/time-off-staffing',other=input.scope==='management'?'/api/employee/time-off-staffing':'/api/manager/time-off-staffing';
 const ok={'x-nevora-leave-staffing':'1','x-nevora-actor':input.actorId,'x-nevora-employee-view':input.view??''};
 const results=[
  await staffingProbe(page,app,'own scope, current',{weekStart:input.week},ok,path),
  await staffingProbe(page,app,'wrong actor',{weekStart:input.week},{...ok,'x-nevora-actor':'someone-else'},path),
  await staffingProbe(page,app,'stale view',{weekStart:input.week},{...ok,'x-nevora-employee-view':'stale'},path),
  await staffingProbe(page,app,'no intent header',{weekStart:input.week},{'x-nevora-actor':input.actorId,'x-nevora-employee-view':input.view??''},path),
  await staffingProbe(page,app,'foreign origin',{weekStart:input.week},ok,path,'https://not-nevora.example'),
  await staffingProbe(page,app,'other role endpoint',{weekStart:input.week},ok,other),
  await staffingProbe(page,app,'not a Monday',{weekStart:'2026-11-10'},ok,path),
  ...(input.colleague?[await staffingProbe(page,app,'a colleague',{weekStart:input.week,employeeId:input.colleague},ok,path)]:[]),
 ];
 log.push({leaveNegatives:input.scope,results});
 if(!input.revoke)return;
 // Revocation: the session ends while a protected page is open; the next read clears it and the page says why.
 await size(page,390);
 await input.q('DELETE FROM employee_sessions').catch((e:unknown)=>log.push('revoke: '+String(e)));
 await page.evaluate(()=>window.dispatchEvent(new Event('focus')));await page.waitForTimeout(3500);
 log.push({leave:'revoked',notice:await text(page,'.ls-failure'),focus:await active(page),probe:await staffingProbe(page,app,'after revocation',{weekStart:input.week},ok,path)});
 for(const w of [390,1440]){await size(page,w);await page.screenshot({path:`${evidence}/leave-revoked-${w}.png`,fullPage:false});}
}

/** A complete correction approval: the original recorded punches stay exactly as they were (CLAUDE-CONTRACT.md). */
export async function runCorrectionFlow(page:any,app:string,evidence:string,log:unknown[],q:Q){
 const punches=async()=>JSON.stringify(rows(await q("SELECT to_jsonb(t) AS row FROM time_entries t ORDER BY id")));
 await size(page,1440);await page.goto(app+'/app/timecards/corrections');await settle(page,4500);
 await page.screenshot({path:`${evidence}/correction-before-1440.png`,fullPage:true});
 const before=await punches(),events=rows(await q("SELECT count(*)::int AS n FROM time_correction_events"))[0]?.n;
 const button=page.locator('button[aria-label^="Approve correction for"]').filter({visible:true}).first();
 log.push({correction:'buttons',count:await button.count()});
 if(!await button.count()){await size(page,390);await page.screenshot({path:`${evidence}/correction-none-390.png`,fullPage:true});return;}
 const who=await button.getAttribute('aria-label');await button.click();await settle(page,4500);
 const after=await punches(),eventsAfter=rows(await q("SELECT count(*)::int AS n FROM time_correction_events"))[0]?.n;
 log.push({correction:'approved',who,punchesUnchanged:before===after,events:[events,eventsAfter],status:await text(page,'[role="status"]')});
 await page.screenshot({path:`${evidence}/correction-after-1440.png`,fullPage:true});
 await size(page,390);await page.screenshot({path:`${evidence}/correction-after-390.png`,fullPage:true});
}
