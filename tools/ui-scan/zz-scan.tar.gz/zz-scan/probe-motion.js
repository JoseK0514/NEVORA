() => {
  // Reduced-motion probe (Phase 2 gap closure): with prefers-reduced-motion: reduce, list every element (and its ::before
  // and ::after) whose computed animation or transition still has a real duration, and every animation still running.
  // "motion" = a property that moves or resizes something; colour, opacity and shadow fades are listed apart.
  const secs = v => v.split(',').map(s => s.trim()).map(s => s.endsWith('ms') ? parseFloat(s) / 1000 : parseFloat(s) || 0);
  const MOTION = /^(all|transform|translate|scale|rotate|top|left|right|bottom|inset|width|height|max-height|max-width|min-height|margin.*|padding.*|grid-template.*|flex.*|offset.*|clip-path|background-position|stroke-dash.*)$/;
  const name = e => (e.tagName.toLowerCase() + (e.id ? '#' + e.id : '') + '.' + [...e.classList].slice(0, 3).join('.')).slice(0, 70);
  const vis = e => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
  const motion = new Map(), fades = new Map(), anims = new Map();
  for (const e of document.querySelectorAll('body *')) {
    if (!vis(e)) continue;
    for (const pseudo of [null, '::before', '::after']) {
      const cs = getComputedStyle(e, pseudo);
      if (pseudo && (cs.content === 'none' || cs.content === 'normal')) continue;
      const key = name(e) + (pseudo || '');
      const an = cs.animationName.split(',').map(s => s.trim()), ad = secs(cs.animationDuration), ic = cs.animationIterationCount.split(',').map(s => s.trim());
      an.forEach((n, i) => { if (n !== 'none' && (ad[i] ?? ad[0]) > 0.02) anims.set(key, `${n} ${(ad[i] ?? ad[0])}s x${ic[i] ?? ic[0]}`); });
      const tp = cs.transitionProperty.split(',').map(s => s.trim()), td = secs(cs.transitionDuration);
      tp.forEach((p, i) => { const d = td[i] ?? td[0]; if (p === 'none' || d <= 0.02) return; (MOTION.test(p) ? motion : fades).set(key + ' ' + p, d); });
    }
  }
  const running = document.getAnimations().filter(a => a.playState === 'running').map(a => { const t = a.effect && a.effect.target; return (a.animationName || a.transitionProperty || a.constructor.name) + ' @ ' + (t ? name(t) : '?'); });
  const pick = m => [...m].slice(0, 40).map(([k, v]) => k + ' ' + v);
  return { animations: pick(anims), motionTransitions: pick(motion), fadeCount: fades.size, fades: pick(fades).slice(0, 12), running: running.slice(0, 20), reduce: matchMedia('(prefers-reduced-motion: reduce)').matches };
}
