() => {
  const root = document.querySelector('main.page-frame :is(.c-page, .q-page)'); if (!root) return null;
  const out = [];
  const d = (e, depth) => { const r = e.getBoundingClientRect(); const cs = getComputedStyle(e); if (cs.display === 'none') return;
    out.push('  '.repeat(depth) + (e.tagName.toLowerCase() + '.' + [...e.classList].slice(0, 3).join('.')).slice(0, 50) + ' [' + (e.childElementCount ? '' : (e.textContent || '').trim().slice(0, 24)) + '] ' + [Math.round(r.left), Math.round(r.top), Math.round(r.width), Math.round(r.height)].join(',') + ' pad=' + cs.padding + ' m=' + cs.margin + ' f=' + cs.fontSize + '/' + cs.fontWeight + ' bg=' + cs.backgroundColor + ' bi=' + cs.backgroundImage.slice(0, 60) + ' bt=' + cs.borderTopWidth + ' bb=' + cs.borderBottomWidth + ' sh=' + cs.boxShadow.slice(0, 50) + (getComputedStyle(e, '::after').content !== 'none' ? ' AFTER[' + getComputedStyle(e, '::after').left + ',' + getComputedStyle(e, '::after').height + ',' + getComputedStyle(e, '::after').backgroundColor + ']' : '') + (getComputedStyle(e, '::before').content !== 'none' ? ' BEFORE[' + getComputedStyle(e, '::before').left + ',' + getComputedStyle(e, '::before').height + ']' : ''));
    if (depth < 3) for (const c of e.children) d(c, depth + 1); };
  d(root, 0); return out.slice(0, 40);
}
