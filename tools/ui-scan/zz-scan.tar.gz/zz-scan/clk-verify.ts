// SCRATCH (not committed to the app): verification of the Owner's "Clock in at" row and sheet (NEVORA_SCAN_CLK=1). Fictional
// people and locations only, the throwaway database, the owned https origin. Per docs/design/ui-implementation-guide.md §13:
// 320, 390, 768 and 1440 at 100% and 200% text; axe; 44px reach by elementFromPoint ±21.5px; the focus walk and focus
// return; reduced motion; Spanish; a real save round trip; a stale save from two contexts; and every save state.
/* eslint-disable @typescript-eslint/no-explicit-any */
import {createRequire} from 'node:module';
import {TEST_PASSWORD} from '../src/test/integration/owned-app-fixture';
export const CLK_SEED=[
 "INSERT INTO locations(id,name,short_name,workspace_id,clocker_key) SELECT 'loc-3','Northside Old San Juan','Old San Juan',workspace_id,'scan-kiosk-osj' FROM locations WHERE id='loc-1' ON CONFLICT (id) DO NOTHING",
 "UPDATE locations SET short_name=CASE id WHEN 'loc-1' THEN 'Main Office' WHEN 'loc-2' THEN 'West Office' ELSE short_name END WHERE id IN ('loc-1','loc-2')",
 "UPDATE employees SET first_name='Daniel',last_name='Reyes',primary_location_id='loc-1' WHERE id='QA-SCAN-A'",
 "UPDATE employees SET first_name='Carmen',last_name='Ortiz',primary_location_id='loc-1' WHERE id='QA-SCAN-B'",
 "INSERT INTO employee_location_eligibility(employee_id,location_id) VALUES('QA-SCAN-A','loc-1'),('QA-SCAN-A','loc-2'),('QA-SCAN-B','loc-1'),('QA-SCAN-B','loc-2'),('QA-SCAN-B','loc-3') ON CONFLICT DO NOTHING",
 "UPDATE employees SET clocker_location_mode='SELECTED',clocker_location_ids='{loc-2,loc-3}' WHERE id='QA-SCAN-B'",
 "UPDATE employees SET role='MANAGER' WHERE id='QA-SCAN-C'",
];
export async function runClkVerify(browser:any,front:string,net:Record<string,unknown>,q:(t:string,v?:unknown[])=>Promise<any>,evidence:string,log:unknown[]){
 const axePath=createRequire(import.meta.url).resolve('axe-core/axe.min.js');
 const D='/app/employees/QA-SCAN-A',C='/app/employees/QA-SCAN-B';
 const owner=async(opts:any={})=>{const ctx=await browser.newContext({...net,viewport:{width:390,height:844},deviceScaleFactor:1,reducedMotion:'reduce',serviceWorkers:'block',...opts});const page=await ctx.newPage();page.setDefaultTimeout(20000);
  page.on('pageerror',(e:Error)=>log.push('clk pageerror '+e.message.slice(0,200)));
  await page.goto(front+'/login');await page.getByLabel('Employee ID',{exact:true}).fill('QAOWNER');await page.getByLabel('Password',{exact:true}).fill(TEST_PASSWORD);await page.getByRole('button',{name:'Sign in',exact:true}).click();
  await page.waitForURL((u:URL)=>u.pathname.startsWith('/app'));return {ctx,page};};
 const settle=async(page:any)=>{await page.waitForLoadState('networkidle').catch(()=>{});await page.waitForTimeout(600);};
 const step=async(name:string,fn:()=>Promise<void>)=>{try{await fn();}catch(e){log.push({clkError:name,e:String((e as Error)?.message??e).slice(0,400)});}};
 const probe=(page:any)=>page.evaluate(()=>{
  const root=(document.querySelector('.clk')||document.getElementById('clock-in-at')) as HTMLElement|null;
  const over=document.documentElement.scrollWidth-innerWidth;
  const clipped=root?[...root.querySelectorAll('*')].filter(e=>e.children.length===0&&(e.textContent||'').trim()&&(e.scrollWidth>e.clientWidth+1||e.scrollHeight>e.clientHeight+1)&&getComputedStyle(e).overflow!=='visible').map(e=>(e.textContent||'').trim().slice(0,30)):[];
  const controls=root?[...root.querySelectorAll('a[href],button,input,label.clk-choice')].filter(e=>{const r=e.getBoundingClientRect();return r.width>0&&r.height>0;}):[];
  const reach=controls.map(e=>{e.scrollIntoView({block:'center'});const r=e.getBoundingClientRect(),cx=r.left+r.width/2,cy=r.top+r.height/2;
   const hit=(x:number,y:number)=>{const t=document.elementFromPoint(x,y);return !!t&&(t===e||e.contains(t)||(e.tagName==='INPUT'&&t===e.closest('label'))||(e.tagName==='INPUT'&&!!e.closest('label')?.contains(t)));};
   const ok=[[cx-21.5,cy],[cx+21.5,cy],[cx,cy-21.5],[cx,cy+21.5]].every(([x,y])=>hit(x,y));
   return {c:(e.getAttribute('aria-label')||e.textContent||(e as HTMLInputElement).value||e.tagName).trim().slice(0,30),ok,w:Math.round(r.width),h:Math.round(r.height)};});
  // An input sits inside its label: the label (44px row) is the target, so a bare input is judged through it.
  return {over,clipped:clipped.filter(c=>c!=='Clock in at'&&c!=='Puede marcar en').slice(0,6),reachFail:reach.filter(r=>!r.ok&&!/^(ASSIGNED|SELECTED|ALL|loc-\d)$/.test(r.c)).slice(0,8),controls:reach.length};});
 const axe=async(page:any)=>{await page.addScriptTag({path:axePath});return page.evaluate(async()=>{const r=await (window as any).axe.run(document,{runOnly:{type:'tag',values:['wcag2a','wcag2aa','wcag21a','wcag21aa','wcag22aa']}});return r.violations.map((v:any)=>({id:v.id,n:v.nodes.length,t:v.nodes.slice(0,3).map((n:any)=>String(n.target)).join(' | ')}));});};
 const shot=async(page:any,name:string,w:number,big:boolean,full=false)=>{await page.setViewportSize({width:w,height:w>1000?900:w>=768?1024:844});
  await page.evaluate((b:boolean)=>{document.documentElement.style.fontSize=b?'32px':'';},big);await page.waitForTimeout(350);
  const p=await probe(page);
  if(w<1000&&!full){await page.evaluate(()=>{(document.querySelector('.clk')||document.getElementById('clock-in-at'))?.scrollIntoView({block:'center'});});await page.waitForTimeout(200);}
  const tag=`${w}${big?'-text200':''}`;await page.screenshot({path:`${evidence}/clk-${name}-${tag}.png`,fullPage:full||w>=1000});
  log.push({clk:name,size:tag,...p});await page.evaluate(()=>{document.documentElement.style.fontSize='';});};

 // 1. Every view at every size, Chromium (WebKit isn't installed in this container).
 await step('views',async()=>{const {ctx,page}=await owner();
  for(const [name,path] of [['row-daniel',D],['row-carmen',C],['sheet-daniel',D+'?edit=clocker'],['sheet-carmen',C+'?edit=clocker']] as const){
   await page.goto(front+path);await settle(page);
   for(const w of [320,390,768,1440])for(const big of [false,true])await shot(page,name,w,big);
   await page.setViewportSize({width:390,height:844});log.push({clkAxe:name,w:390,v:await axe(page)});
   await page.setViewportSize({width:1440,height:900});await page.reload();await settle(page);log.push({clkAxe:name,w:1440,v:await axe(page)});}
  await ctx.close();});

 // 2. Focus: the walk through the sheet, and the return to the row when it closes.
 await step('focus',async()=>{const {ctx,page}=await owner();await page.goto(front+C+'?edit=clocker');await settle(page);
  const walk:unknown[]=[];await page.locator('body').click({position:{x:2,y:300}}).catch(()=>{});
  for(let i=0;i<10;i++){await page.keyboard.press('Tab');await page.waitForTimeout(80);walk.push(await page.evaluate(()=>{const e=document.activeElement as HTMLElement|null;if(!e)return null;const cs=getComputedStyle(e);return (e.tagName+' '+((e as HTMLInputElement).type||'')+' '+(e.getAttribute('aria-label')||(e.closest('label')?.textContent)||e.textContent||'').trim().slice(0,30)+' | '+cs.outlineStyle+' '+cs.outlineWidth);}));}
  log.push({clkFocusWalk:walk});
  await page.getByRole('link',{name:'Cancel',exact:true}).click();await page.waitForURL((u:URL)=>u.hash==='#clock-in-at');await settle(page);
  log.push({clkFocusReturn:await page.evaluate(()=>{const e=document.activeElement as HTMLElement|null;return e?(e.closest('#clock-in-at')?'row link: ':'elsewhere: ')+(e.textContent||'').trim().slice(0,40):null;})});
  await page.screenshot({path:`${evidence}/clk-focus-return-390.png`});await ctx.close();});

 // 3. Reduced motion: nothing moves when a choice changes.
 await step('motion',async()=>{const {ctx,page}=await owner();await page.goto(front+D+'?edit=clocker');await settle(page);
  await page.getByRole('radio',{name:/^Only these locations/}).check();await page.waitForTimeout(40);
  log.push({clkMotion:await page.evaluate(()=>document.getAnimations().filter(a=>a.playState==='running').map(a=>{const t=(a.effect as any)?.target as Element|undefined;const k=(a.effect as any)?.getKeyframes?.()??[];return ((a as any).transitionProperty||(a as any).animationName)+' @ '+(t?t.className.toString().slice(0,40):'?')+' '+JSON.stringify(k.map((f:any)=>f[(a as any).transitionProperty]??''));}))});await ctx.close();});

 // 4. Spanish.
 await step('spanish',async()=>{const {ctx,page}=await owner();await ctx.addCookies([{name:'nv-lang',value:'es',url:front}]);
  for(const [name,path] of [['row-carmen-es',C],['sheet-carmen-es',C+'?edit=clocker']] as const){await page.goto(front+path);await settle(page);await shot(page,name,390,false);await shot(page,name,390,true);}
  await page.goto(front+C+'?edit=clocker');await settle(page);log.push({clkAxe:'sheet-carmen-es',w:390,v:await axe(page)});await ctx.close();});

 // 5. States on Carmen's sheet: a change, nothing ticked, saving (the reply held), couldn't confirm (no reply), saved.
 await step('states',async()=>{const {ctx,page}=await owner();
  await page.goto(front+C+'?edit=clocker');await settle(page);
  await page.getByRole('checkbox',{name:/^Main Office/}).check();await shot(page,'state-changed',390,false);
  await page.getByRole('checkbox',{name:/^Main Office/}).uncheck();await page.getByRole('checkbox',{name:/^West Office/}).uncheck();await page.getByRole('checkbox',{name:/^Old San Juan/}).uncheck();await shot(page,'state-nothing-ticked',390,false);await shot(page,'state-nothing-ticked',390,true);
  await page.reload();await settle(page);await page.getByRole('checkbox',{name:/^Main Office/}).check();
  await page.route(front+C+'?edit=clocker',async(r:any)=>{if(r.request().method()==='POST'){await new Promise(res=>setTimeout(res,5000));await r.abort().catch(()=>{});}else await r.continue();});
  await page.getByRole('button',{name:'Save',exact:true}).click();await page.waitForTimeout(600);await shot(page,'state-saving',390,false);await shot(page,'state-saving',1440,false);
  await page.locator('.clk-result [role=alert]').waitFor({timeout:15000});await page.waitForTimeout(300);
  log.push({clkUnconfirmedFocus:await page.evaluate(()=>document.activeElement?.className)});
  await shot(page,'state-unconfirmed',390,false);await shot(page,'state-unconfirmed',390,true);await shot(page,'state-unconfirmed',1440,false);
  await page.unroute(front+C+'?edit=clocker');
  await page.getByRole('button',{name:'Reload profile'}).click();await settle(page);
  log.push({clkAfterReload:await page.evaluate(()=>[...document.querySelectorAll('.clk input:checked')].map(e=>(e as HTMLInputElement).value))});
  await ctx.close();});

 // 6. The real round trip: Daniel to "Only these locations" (Main and West), reload, then "Every location", reload.
 await step('round trip',async()=>{const {ctx,page}=await owner();
  const db=async()=>{const r=await q("SELECT clocker_location_mode AS mode,clocker_location_ids AS ids FROM employees WHERE id='QA-SCAN-A'");return (Array.isArray(r)?r[0]:r?.rows?.[0])??null;};
  log.push({clkDbBefore:await db()});
  await page.goto(front+D+'?edit=clocker');await settle(page);
  await page.getByRole('radio',{name:/^Only these locations/}).check();await page.getByRole('checkbox',{name:/^Main Office/}).uncheck();
  await page.getByRole('button',{name:'Save',exact:true}).click();await page.locator('.clk-result [role=status]').waitFor({timeout:20000});await page.waitForTimeout(300);
  log.push({clkSavedFocus:await page.evaluate(()=>document.activeElement?.className),clkSavedSave:await page.getByRole('button',{name:'Save',exact:true}).isDisabled()});
  await shot(page,'state-saved',390,false);await shot(page,'state-saved',390,true);
  await page.reload();await settle(page);
  log.push({clkReloadSelected:await page.evaluate(()=>[...document.querySelectorAll('.clk input:checked')].map(e=>(e as HTMLInputElement).value)),clkDbSelected:await db()});
  await page.getByRole('radio',{name:/^Every location/}).check();await page.getByRole('button',{name:'Save',exact:true}).click();await page.locator('.clk-result [role=status]').waitFor({timeout:20000});
  await page.reload();await settle(page);
  log.push({clkReloadAll:await page.evaluate(()=>[...document.querySelectorAll('.clk input:checked')].map(e=>(e as HTMLInputElement).value)),clkDbAll:await db()});
  await page.goto(front+D);await settle(page);log.push({clkRowAfter:await page.locator('#clock-in-at').innerText()});await shot(page,'row-daniel-after-all',390,false);
  await ctx.close();});

 // 7. A stale save: two Owners open Carmen's sheet; the first saves, the second's save is refused as changed.
 await step('stale',async()=>{const A=await owner(),B=await owner();
  for(const s of [A,B]){await s.page.goto(front+C+'?edit=clocker');await settle(s.page);}
  await A.page.getByRole('checkbox',{name:/^Main Office/}).check();await A.page.getByRole('button',{name:'Save',exact:true}).click();await A.page.locator('.clk-result [role=status]').waitFor({timeout:20000});
  await B.page.getByRole('radio',{name:/^Every location/}).check();await B.page.getByRole('button',{name:'Save',exact:true}).click();await B.page.locator('.clk-result [role=alert]').waitFor({timeout:20000});await B.page.waitForTimeout(300);
  log.push({clkStale:await B.page.locator('.clk-result').innerText(),clkStaleFocus:await B.page.evaluate(()=>document.activeElement?.className),clkStaleLocked:await B.page.getByRole('button',{name:'Save',exact:true}).isDisabled()});
  await shot(B.page,'state-stale',390,false);await shot(B.page,'state-stale',390,true);await shot(B.page,'state-stale',1440,false);
  await B.page.getByRole('button',{name:'Reload profile'}).click();await settle(B.page);
  log.push({clkStaleAfterReload:await B.page.evaluate(()=>[...document.querySelectorAll('.clk input:checked')].map(e=>(e as HTMLInputElement).value))});
  await A.ctx.close();await B.ctx.close();});

 // 8. A Manager: no row, and the sheet address goes back to the person page.
 await step('manager',async()=>{const ctx=await browser.newContext({...net,viewport:{width:390,height:844},reducedMotion:'reduce',serviceWorkers:'block'});const page=await ctx.newPage();
  await page.goto(front+'/login');await page.getByLabel('Employee ID',{exact:true}).fill('QA-SCAN-C');await page.getByLabel('Password',{exact:true}).fill(TEST_PASSWORD);await page.getByRole('button',{name:'Sign in',exact:true}).click();await page.waitForURL((u:URL)=>u.pathname.startsWith('/app'));
  await page.goto(front+D);await settle(page);const row=await page.locator('#clock-in-at').count();
  await page.goto(front+D+'?edit=clocker');await settle(page);
  log.push({clkManager:{row,sheetUrl:new URL(page.url()).pathname+new URL(page.url()).search,sheet:await page.locator('.clk').count()}});
  await page.goto(front+D);await settle(page);await page.screenshot({path:`${evidence}/clk-manager-person-390.png`,fullPage:true});await ctx.close();});
}
