// SCRATCH (not committed): Employee desktop states (NEVORA_SCAN_STATES_DESK=1). Fictional data, disposable database.
/* eslint-disable @typescript-eslint/no-explicit-any */
export async function runDeskStates(browser:any,main:any,appUrl:string,evidence:string,log:unknown[]){
 const storage=await main.storageState();
 const mk=async(width:number,motion:'reduce'|'no-preference'='reduce')=>{const ctx=await browser.newContext({storageState:storage,reducedMotion:motion,serviceWorkers:'block',viewport:{width,height:900},deviceScaleFactor:1});const page=await ctx.newPage();page.setDefaultTimeout(20000);
  page.on('pageerror',(e:Error)=>log.push('desk pageerror '+e.message.slice(0,300)));return {ctx,page};};
 const step=async(name:string,fn:()=>Promise<unknown>)=>{try{const r=await fn();log.push({desk:name,ok:true,...(r&&typeof r==='object'?r:{info:r})});}catch(e){log.push({desk:name,ok:false,error:String((e as Error)?.message??e).slice(0,400)});}};
 const settle=async(page:any,ms=1800)=>{await page.waitForLoadState('networkidle',{timeout:8000}).catch(()=>{});await page.waitForTimeout(ms);};
 const active=(page:any)=>page.evaluate(()=>{const e=document.activeElement as HTMLElement|null;if(!e||e===document.body)return null;const cs=getComputedStyle(e);return (e.tagName.toLowerCase()+'.'+[...e.classList].slice(0,2).join('.')+' "'+(e.getAttribute('aria-label')||e.textContent||'').trim().replace(/\s+/g,' ').slice(0,36)+'" '+cs.outlineStyle+' '+cs.outlineColor);});
 for(const width of [1440,1280]){
  const {ctx,page}=await mk(width);
  // Shift panel by keyboard: focus the agenda row, Enter, Tab through, Escape, focus back.
  await step(`panel-keys-${width}`,async()=>{await page.goto(appUrl+'/app/schedule');await settle(page);
   const row=page.locator('.b-screen a.b-row[aria-haspopup="dialog"]').first();await row.focus();const before=await active(page);await page.keyboard.press('Enter');await page.waitForTimeout(900);
   const open=await page.evaluate(()=>!!document.querySelector('dialog.q-sheet[open]'));const inside:unknown[]=[await active(page)];
   for(let i=0;i<5;i++){await page.keyboard.press('Tab');await page.waitForTimeout(150);inside.push(await active(page));if(i===1)await page.screenshot({path:`${evidence}/desk-panel-focus-${width}.png`});}
   await page.keyboard.press('Escape');await page.waitForTimeout(700);const closed=await page.evaluate(()=>!document.querySelector('dialog.q-sheet[open]'));
   return {before,open,inside,closed,after:await active(page)};});
  // Loading: the first frames of a page whose screen loads on the client.
  for(const route of ['/app/requests/hub','/app/notifications']){const slug=route.replace(/^\/app\/?/,'').replace(/[^a-z0-9]+/gi,'-');
   await step(`loading-${slug}-${width}`,async()=>{await page.goto(appUrl+route,{waitUntil:'domcontentloaded'});await page.waitForTimeout(60);await page.screenshot({path:`${evidence}/desk-loading-${slug}-${width}.png`});await settle(page);return {};});}
  // Errors: the private reads fail (500); the server-rendered page stays.
  for(const route of ['/app/requests/hub','/app/notifications','/app/exchange','/app/my-time','/app/my-pay','/app/profile']){const slug=route.replace(/^\/app\/?/,'').replace(/[^a-z0-9]+/gi,'-');
   await step(`error-${slug}-${width}`,async()=>{await page.route(/\/api\/(?!auth)/,(r:any)=>r.request().resourceType()==='fetch'||r.request().resourceType()==='xhr'?r.fulfill({status:500,body:'{}',contentType:'application/json'}):r.continue());
    await page.goto(appUrl+route);await settle(page,2500);await page.screenshot({path:`${evidence}/desk-error-${slug}-${width}.png`});
    const text=await page.evaluate(()=>[...document.querySelectorAll('.b-screen [role="status"], .b-screen [role="alert"], .b-screen .b-state')].map(e=>(e.textContent||'').trim()).filter(Boolean).slice(0,4));
    await page.unroute(/\/api\/(?!auth)/);return {text,overflow:await page.evaluate(()=>document.documentElement.scrollWidth-innerWidth)};});}
  // Offline after load.
  await step(`offline-my-pay-${width}`,async()=>{await page.goto(appUrl+'/app/my-pay');await settle(page);await ctx.setOffline(true);await page.evaluate(()=>{window.dispatchEvent(new Event('offline'));window.dispatchEvent(new Event('focus'));document.dispatchEvent(new Event('visibilitychange'));});await page.waitForTimeout(3000);
   await page.screenshot({path:`${evidence}/desk-offline-my-pay-${width}.png`});await ctx.setOffline(false);return {};});
  // Search (Employee finder).
  await step(`finder-${width}`,async()=>{await page.goto(appUrl+'/app');await settle(page);await page.locator('.command-finder-trigger').first().click();await page.waitForTimeout(500);await page.screenshot({path:`${evidence}/desk-finder-${width}.png`});
   const items=await page.evaluate(()=>[...document.querySelectorAll('dialog[open] [role="option"]')].map(e=>(e.textContent||'').trim()));await page.keyboard.type('pay');await page.waitForTimeout(300);
   const typed=await page.evaluate(()=>[...document.querySelectorAll('dialog[open] [role="option"]')].map(e=>(e.textContent||'').trim()));await page.screenshot({path:`${evidence}/desk-finder-pay-${width}.png`});await page.keyboard.press('Escape');await page.waitForTimeout(300);return {items,typed,after:await active(page)};});
  await ctx.close();
 }
 // Reduced motion: card animations with and without the preference.
 for(const motion of ['reduce','no-preference'] as const){const {ctx,page}=await mk(1440,motion);
  await step(`motion-${motion}`,async()=>{await page.goto(appUrl+'/app');await page.waitForTimeout(80);
   const anim=await page.evaluate(()=>[...document.querySelectorAll('.b-screen .b-stack > *, .b-screen .b-hero > .b-title')].slice(0,4).map(e=>{const cs=getComputedStyle(e);return cs.animationName+' '+cs.animationDuration;}));
   await page.screenshot({path:`${evidence}/desk-motion-${motion}.png`});return {anim};});await ctx.close();}
}
