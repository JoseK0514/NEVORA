// SCRATCH (not committed): public pages (NEVORA_SCAN_PUBLIC=1), signed out. Fictional data only; no email or SMS is sent.
/* eslint-disable @typescript-eslint/no-explicit-any */
export async function runPublic(browser:any,appUrl:string,evidence:string,log:unknown[],extra:{clocker?:string}){
 const widths=(process.env.NEVORA_SCAN_PUBLIC_W??'320,390,768,1024,1440').split(',').map(Number);
 const langs=(process.env.NEVORA_SCAN_PUBLIC_LANGS??'en,es').split(',');
 const only=(process.env.NEVORA_SCAN_PUBLIC_ONLY??'').split(',').filter(Boolean);
 const pages:[string,string,((p:any)=>Promise<void>)|null][]=[
  ['signin','/login',null],
  ['signin-err','/login',async p=>{await p.locator('#login-employee-id').fill('NOPE-1');await p.locator('#login-password').fill('wrong-password-123');await p.getByRole('button',{name:/^(Sign in|Iniciar sesión|Entrar)$/}).first().click();await p.waitForTimeout(1500);}],
  ['signin-empty','/login',async p=>{await p.getByRole('button',{name:/^(Sign in|Iniciar sesión|Entrar)$/}).first().click();await p.waitForTimeout(600);}],
  ['forgot','/forgot-access',null],
  ['reset-bad','/reset-access?token=expired-or-invalid',null],
  ['reset','/reset-access',null],
  ['activate','/activate',null],
  ['activate-bad','/activate?token=not-a-real-token',null],
  ['privacy','/privacy',null],['terms','/terms',null],['support','/support',null],['delete','/account-deletion',null],
  ['404','/no-such-page-here',null],
  ['welcome','/welcome',null],['access-help','/access-help',null],['access-help-id','/access-help/id?from=login',null],
  ...(extra.clocker?[['clocker','/clocker/'+extra.clocker,null] as [string,string,null]]:[]),
 ];
 for(const lang of langs){
  const ctx=await browser.newContext({viewport:{width:1440,height:900},deviceScaleFactor:1,reducedMotion:'reduce',serviceWorkers:'block'});
  await ctx.addCookies([{name:'nv-lang',value:lang,url:appUrl}]);
  const page=await ctx.newPage();page.setDefaultTimeout(15000);
  page.on('pageerror',(e:Error)=>log.push('public pageerror '+e.message.slice(0,200)));
  for(const [name,route,act] of pages){
   if(only.length&&!only.includes(name))continue;
   const sizes=name==='clocker'&&process.env.NEVORA_SCAN_CLOCKER_SIZES?process.env.NEVORA_SCAN_CLOCKER_SIZES.split(',').map(v=>v.split('x').map(Number)):widths.map(w=>[w,w>1000?900:w>=768?1024:844]);
   for(const [width,height] of sizes){
    try{
     await page.setViewportSize({width,height});
     // The kiosk shows the time: one fixed fictional moment so before and after compare pixel for pixel.
     if(name==='clocker')await page.clock.setFixedTime(new Date('2026-11-05T15:30:00Z'));
     await page.goto(appUrl+route);await page.waitForLoadState('networkidle',{timeout:8000}).catch(()=>{});await page.waitForTimeout(700);
     if(act)await act(page);
     const info=await page.evaluate(()=>({overflow:document.documentElement.scrollWidth-innerWidth,h1:[...document.querySelectorAll('h1')].map(e=>(e.textContent||'').trim()).slice(0,2)}));
     log.push({pub:name,lang,width,...info});
     if(process.env.NEVORA_SCAN_PUBLIC_PROBE==='1')log.push({probe:name,width,d:await page.evaluate(()=>{const pick=(x:number,y:number)=>{const e=document.elementFromPoint(x,y);if(!e)return null;const cs=getComputedStyle(e);return e.tagName+'.'+(e.className||'').toString().slice(0,40)+' bi='+cs.borderImageSource.slice(0,30)+' bg='+cs.backgroundImage.slice(0,30)};const hd=document.querySelector('.q-auth .q-hd');const top=document.querySelector('.q-auth__top');return {at:[pick(1100,300),pick(1300,320),pick(100,10),pick(30,30)],hd:hd?getComputedStyle(hd).borderImageSource.slice(0,40)+' '+getComputedStyle(hd).borderImageOutset:null,hdParent:hd?.parentElement?.className,top:top?getComputedStyle(top).position+' '+top.getBoundingClientRect().top+' '+getComputedStyle(top).borderImageOutset:null};})});
     await page.screenshot({path:`${evidence}/pub-${name}-${lang}-${name==='clocker'?width+'x'+height:width}.png`,fullPage:name!=='clocker'});
    }catch(e){log.push({pub:name,lang,width,error:String((e as Error).message).slice(0,200)});}
   }
  }
  if(process.env.NEVORA_SCAN_PUBLIC_TOC==='1'){await page.setViewportSize({width:1440,height:900});await page.goto(appUrl+'/privacy');await page.waitForLoadState('networkidle').catch(()=>{});await page.waitForTimeout(500);
   const steps:unknown[]=[];for(let i=1;i<=6;i++){await page.keyboard.press('Tab');await page.waitForTimeout(100);steps.push(await page.evaluate(()=>{const e=document.activeElement as HTMLElement|null;if(!e||e===document.body)return null;const cs=getComputedStyle(e);return e.tagName+' "'+(e.textContent||'').trim().slice(0,30)+'" '+cs.outlineStyle+' '+cs.outlineColor;}));}
   await page.screenshot({path:`${evidence}/pub-toc-focus-${lang}-1440.png`});
   const link=page.locator('.q-doc__toc a').nth(4);let jumped:unknown=null;if(await link.count()){const href=await link.getAttribute('href');await link.focus();await page.keyboard.press('Enter');await page.waitForTimeout(800);
    jumped=await page.evaluate((h:string|null)=>{const t=h?document.getElementById(h.slice(1)):null;const d=t?.closest('details');return {href:h,hash:location.hash,open:!!d?.open,top:t?Math.round(t.getBoundingClientRect().top):null,scrollY:Math.round(scrollY)};},href);
    await page.screenshot({path:`${evidence}/pub-toc-jump-${lang}-1440.png`});}
   log.push({toc:lang,steps,jumped});}
  // Keyboard focus on sign in (desktop and phone).
  for(const width of [1440,390]){
   await page.setViewportSize({width,height:width>1000?900:844});await page.goto(appUrl+'/login');await page.waitForLoadState('networkidle').catch(()=>{});await page.waitForTimeout(500);
   const steps:unknown[]=[];for(let i=1;i<=9;i++){await page.keyboard.press('Tab');await page.waitForTimeout(120);
    steps.push(await page.evaluate(()=>{const e=document.activeElement as HTMLElement|null;if(!e||e===document.body)return null;const cs=getComputedStyle(e);return (e.tagName+'.'+(e.className||'').toString().slice(0,30)+' "'+(e.getAttribute('aria-label')||e.textContent||(e as HTMLInputElement).name||'').trim().slice(0,26)+'" '+cs.outlineStyle+' '+cs.outlineColor+' '+cs.boxShadow.slice(0,40));}));
    if(i===3)await page.screenshot({path:`${evidence}/pub-focus-${lang}-${width}.png`});}
   log.push({pubFocus:width,lang,steps});
  }
  await ctx.close();
 }
}
