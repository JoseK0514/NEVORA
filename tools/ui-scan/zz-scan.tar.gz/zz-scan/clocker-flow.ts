// SCRATCH (not committed): the Clocker kiosk, every reachable state, for the Direction B build (NEVORA_SCAN_CLOCKER_FLOW).
// Fictional employees, fictional tablets and owned loopback PostgreSQL only. Outages are simulated in the browser
// (Playwright routes and init scripts), never by changing app code.
//   NEVORA_SCAN_CLOCKER_SIZES  e.g. 1024x768,768x1024 (default those two)
//   NEVORA_SCAN_CLOCKER_LOCALE en | es (es: the tablet remembers Spanish before the first visit)
//   NEVORA_SCAN_CLOCKER_EXTRA  1: also the simulated states (photo, review current, reconnect, clear failed, storage) and
//                              the keyboard, motion-sequence and reduced-motion captures
/* eslint-disable @typescript-eslint/no-explicit-any */
import {registerClockerDevice} from '../src/lib/clocker/devices.server';
import {setEmployeeClockerPin} from '../src/lib/clocker/pins.server';
import {saveBreakType} from '../src/lib/clocker/break-types.server';
import {fixtureProof} from '../src/test/integration/shift-change-api';
import {clockerText} from '../src/components/clocker-copy';

export async function runClockerFlow(browser:any,appUrl:string,ex:any,actors:string[],evidence:string,log:unknown[],mode='full'){
 const q=(text:string,values:unknown[]=[])=>ex.query({text,values});
 const ownerSession=await fixtureProof(ex,'QAOWNER');const owner={employeeId:'QAOWNER',sessionTokenHash:ownerSession.sessionTokenHash};
 const key=Buffer.from('ab'.repeat(32),'hex');
 const locale=process.env.NEVORA_SCAN_CLOCKER_LOCALE==='es'?'es':'en',extra=process.env.NEVORA_SCAN_CLOCKER_EXTRA==='1';
 const N=(en:string,params?:Record<string,string|number>)=>locale==='es'?clockerText('es',en,params):clockerText('en',en,params);
 await q("UPDATE locations SET clocker_key='scan-kiosk-main' WHERE id='loc-1'");
 await q("UPDATE locations SET clocker_key='scan-kiosk-west' WHERE id='loc-2'");
 const [james,ana]=[actors[1],actors[2]];
 for(const [id,pin] of [[james,'2468'],[ana,'1357']])await setEmployeeClockerPin(owner,{employeeId:id,pin,expectedVersion:0},key,ex).catch((e:unknown)=>log.push('pin '+id+' '+String(e)));
 await q("INSERT INTO employee_location_eligibility(employee_id,location_id) VALUES($1,'loc-2') ON CONFLICT DO NOTHING",[ana]).catch((e:unknown)=>log.push('elig '+String(e)));
 const sizes:[number,number][]=(process.env.NEVORA_SCAN_CLOCKER_SIZES??'1024x768,768x1024').split(',').map(v=>v.split('x').map(Number) as [number,number]);
 let n=0;
 const shot=async(page:any,name:string,all=true)=>{n++;const tag=String(n).padStart(2,'0')+'-'+name;
  for(const [w,h] of all?sizes:sizes.slice(0,1)){await page.setViewportSize({width:w,height:h});await page.waitForTimeout(300);await page.screenshot({path:`${evidence}/ck-${tag}-${w}x${h}.png`});}
  await page.setViewportSize({width:sizes[0][0],height:sizes[0][1]});
  const info=await page.evaluate(()=>{const over=document.documentElement.scrollWidth-innerWidth;
   // Small targets and clipped text on screen (premium pass).
   const small=[...document.querySelectorAll('main button, main a, main summary')].filter(e=>{const r=e.getBoundingClientRect();return r.width>0&&r.height>0&&(r.height<44||r.width<44);}).map(e=>(e.getAttribute('aria-label')||e.textContent||'').trim().slice(0,30));
   const clipped=[...document.querySelectorAll('main *')].filter(e=>e.children.length===0&&(e.textContent||'').trim()&&e.scrollWidth>e.clientWidth+1&&getComputedStyle(e).overflow!=='visible').map(e=>(e.textContent||'').trim().slice(0,30));
   return {over,small:small.slice(0,8),clipped:clipped.slice(0,8)};});
  log.push({ck:tag,h1:await page.locator('h1').allInnerTexts().catch(()=>[]),alerts:await page.locator('[role=alert],[role=status]').allInnerTexts().catch(()=>[]),...info});};
 const seq=async(page:any,name:string,times:number[])=>{const t0=Date.now();for(const t of times){const wait=t-(Date.now()-t0);if(wait>0)await page.waitForTimeout(wait);await page.screenshot({path:`${evidence}/seq-${name}-${String(t).padStart(4,'0')}ms.png`});}};
 const step=async(name:string,fn:()=>Promise<void>)=>{try{await fn();}catch(e){log.push({ckError:name,e:String((e as Error).message).slice(0,300)});}};
 const fresh=async(opts:any={})=>{const ctx=await browser.newContext({viewport:{width:sizes[0][0],height:sizes[0][1]},deviceScaleFactor:1,reducedMotion:'no-preference',serviceWorkers:'block',...opts});
  if(locale==='es')await ctx.addInitScript(()=>{try{localStorage.setItem('nevora.clocker.locale','es');}catch{/* blocked */}});
  const page=await ctx.newPage();page.setDefaultTimeout(15000);page.on('pageerror',(e:Error)=>log.push('ck pageerror '+e.message.slice(0,200)));
  page.on('console',(m:any)=>{if(m.type()==='error')log.push('ck console '+m.text().slice(0,200));});return {ctx,page};};
 const settle=(page:any)=>page.waitForLoadState('networkidle',{timeout:8000}).catch(()=>{});
 const enroll=async(page:any,locationId:string,locationKey:string,name:string)=>{
  const pending=await registerClockerDevice(owner,{name,locationId},ex);
  await page.goto(`${appUrl}/clocker/${locationKey}`);await settle(page);await page.waitForTimeout(800);
  await page.locator('textarea[name="enrollmentToken"]').fill(pending.enrollmentToken);
  await page.locator('form button[type="submit"]').click();
  await page.locator('[data-clocker-pin="entry"]').waitFor({timeout:20000});
 };
 const idle=(page:any)=>page.waitForFunction(()=>!document.querySelector('[aria-busy="true"]'),{timeout:15000}).catch(()=>{});
 const pinKey=async(page:any,digits:string)=>{for(const d of digits)await page.locator('[data-clocker-keypad] button[data-key="digit"]').filter({hasText:new RegExp('^'+d+'$')}).click();};
 const enterPin=async(page:any,pin:string)=>{await page.locator('[data-clocker-pin="entry"]').waitFor({timeout:20000});await idle(page);await page.waitForTimeout(200);await pinKey(page,pin);await page.locator('[data-clocker-pin="entry"] button[type="submit"]').click();};
 const ready=(page:any)=>page.locator('[data-clocker-state="ready"]').waitFor({timeout:20000});
 const success=(page:any)=>page.locator('[data-clocker-state="success"]').waitFor({timeout:20000});
 const btn=(page:any,en:string)=>page.getByRole('button',{name:N(en),exact:true});
 const doneToPin=async(page:any)=>{const done=btn(page,'Done').first();if(await done.count())await done.click();await page.locator('[data-clocker-pin="entry"]').waitFor({timeout:20000});};

 // Other configurations: PINs off (a registered tablet only) or punches off (a PIN check only).
 if(mode==='connected'||mode==='preview'){
  const X=await fresh();
  await step(mode,async()=>{const pending=await registerClockerDevice(owner,{name:'Front counter tablet',locationId:'loc-1'},ex);
   await X.page.goto(`${appUrl}/clocker/scan-kiosk-main`);await settle(X.page);await X.page.waitForTimeout(800);
   await X.page.locator('textarea[name="enrollmentToken"]').fill(pending.enrollmentToken);await X.page.locator('form button[type="submit"]').click();
   if(mode==='connected'){await X.page.getByRole('heading',{name:N('Tablet connected')}).waitFor({timeout:20000});await X.page.waitForTimeout(800);await shot(X.page,'tablet-connected-pins-off');}
   else{await enterPin(X.page,'2468');await X.page.getByText(N('Time punches are not enabled yet.')).waitFor({timeout:20000});await X.page.waitForTimeout(800);await shot(X.page,'pin-verified-punches-off');}});
  await X.ctx.close();return;
 }
 // ---- Invalid key and the unregistered tablet ----
 const A=await fresh();
 await step('invalid key',async()=>{await A.page.goto(`${appUrl}/clocker/not-a-real-key`);await settle(A.page);await A.page.waitForTimeout(600);await shot(A.page,'invalid-key');});
 await step('checking setup',async()=>{
  await A.page.route('**/api/clocker/*/setup',async(r:any)=>{await new Promise(res=>setTimeout(res,6000));await r.continue().catch(()=>{});});
  await A.page.goto(`${appUrl}/clocker/scan-kiosk-main`);await A.page.waitForTimeout(1200);await shot(A.page,'setup-checking');
  await A.page.unroute('**/api/clocker/*/setup');await A.page.waitForTimeout(5000);});
 await step('setup',async()=>{await A.page.goto(`${appUrl}/clocker/scan-kiosk-main`);await settle(A.page);await A.page.waitForTimeout(900);await shot(A.page,'setup');});
 await step('setup bad code',async()=>{await A.page.locator('textarea[name="enrollmentToken"]').fill('nev_enr_not-complete');await A.page.locator('form button[type="submit"]').click();await A.page.waitForTimeout(600);await shot(A.page,'setup-bad-code');});
 await step('setup uncertain',async()=>{
  await A.page.route('**/api/clocker/*/setup',(r:any)=>r.abort());
  await A.page.goto(`${appUrl}/clocker/scan-kiosk-main`);await A.page.waitForTimeout(2500);await shot(A.page,'setup-uncertain');
  await A.page.unroute('**/api/clocker/*/setup');});
 await A.ctx.close();

 // ---- The registered tablet at Main Office ----
 const B=await fresh();const p=B.page;
 await step('enroll',async()=>{await enroll(p,'loc-1','scan-kiosk-main','Front counter tablet');await idle(p);await p.waitForTimeout(800);await shot(p,'pin-empty');});
 if(locale==='en')await step('spanish',async()=>{
  await p.getByRole('button',{name:'Switch language to Spanish'}).click();await p.waitForTimeout(400);await shot(p,'pin-espanol');
  await enterPin(p,'2468');await ready(p);await p.waitForTimeout(700);await shot(p,'ready-off-clock-espanol');
  await p.getByRole('button',{name:'Listo',exact:true}).first().click();await p.locator('[data-clocker-pin="entry"]').waitFor();await idle(p);
  await p.getByRole('button',{name:'Cambiar idioma a inglés'}).click();await p.waitForTimeout(400);});
 await step('pin partial',async()=>{await pinKey(p,'2');
  // Mid-press: the pointer is down on 4 (the key's pressed tint) after one digit is in.
  const k=p.locator('[data-clocker-keypad] button[data-key="digit"]').filter({hasText:/^4$/});const box=await k.boundingBox();
  await p.mouse.move(box.x+box.width/2,box.y+box.height/2);await p.mouse.down();await p.waitForTimeout(150);
  await p.screenshot({path:`${evidence}/ck-pin-mid-press-${sizes[0][0]}x${sizes[0][1]}.png`});await p.mouse.up();await p.waitForTimeout(200);
  await shot(p,'pin-two-digits');await p.getByRole('button',{name:N('Clear PIN')}).click();});
 await step('pin wrong',async()=>{await enterPin(p,'9090');await p.locator('[role=alert]').first().waitFor({timeout:15000});
  if(extra)await seq(p,'wrong-pin-shake',[0,40,80,120,160,220,400]);await p.waitForTimeout(500);await shot(p,'pin-not-recognized');});
 await step('pin checking',async()=>{
  await p.route('**/api/clocker/*/pin',async(r:any)=>{const body=r.request().postData()??'';if(body.includes('"verify"'))await new Promise(res=>setTimeout(res,4000));await r.continue().catch(()=>{});});
  await pinKey(p,'2468');await p.locator('[data-clocker-pin="entry"] button[type="submit"]').click();await p.waitForTimeout(700);await shot(p,'pin-checking',false);
  await p.unroute('**/api/clocker/*/pin');});
 await step('ready off',async()=>{await ready(p);await p.waitForTimeout(700);await shot(p,'ready-off-clock');});
 await step('clock in',async()=>{await btn(p,'Clock In').click();await success(p);if(extra)await seq(p,'check-draw',[0,60,140,220,320,480,700]);await p.waitForTimeout(500);await shot(p,'receipt-clock-in');
  await btn(p,'Done').click();});
 await step('ready on no breaks',async()=>{await enterPin(p,'2468');await ready(p);await p.waitForTimeout(700);await shot(p,'ready-clocked-in-no-break-types');});
 await step('privacy warning',async()=>{await p.waitForTimeout(21500);await shot(p,'privacy-warning');await p.getByRole('button',{name:N('Continue securely')}).click().catch(()=>{});await p.waitForTimeout(1500);});
 await step('break types',async()=>{
  await saveBreakType(owner,{name:'Meal break',category:'MEAL',targetMinutes:30,active:true,expectedVersion:0},ex);
  await saveBreakType(owner,{name:'Rest break',category:'REST',targetMinutes:10,active:true,expectedVersion:0},ex);});
 await step('ready on',async()=>{await doneToPin(p);await enterPin(p,'2468');await ready(p);await p.waitForTimeout(700);await shot(p,'ready-clocked-in');});
 await step('select break',async()=>{await btn(p,'Start Break').click();await p.waitForTimeout(600);await shot(p,'choose-break');});
 await step('start break',async()=>{await p.getByRole('button',{name:N('Start {name}',{name:'Rest break'})}).click();await success(p);await p.waitForTimeout(500);await shot(p,'receipt-break-start');await btn(p,'Done').click();});
 await step('ready break',async()=>{await enterPin(p,'2468');await ready(p);await p.waitForTimeout(700);await shot(p,'ready-on-break');});
 await step('confirm out on break',async()=>{await btn(p,'Clock Out').click();await p.waitForTimeout(600);await shot(p,'confirm-clock-out-on-break');await btn(p,'Stay on break').click();await p.waitForTimeout(400);});
 await step('end break',async()=>{await btn(p,'End Break').click();await success(p);await p.waitForTimeout(500);await shot(p,'receipt-break-end');await btn(p,'Done').click();});
 await step('state unavailable',async()=>{
  await p.route('**/api/clocker/*/punch',(r:any)=>r.abort());
  await enterPin(p,'2468');await p.locator('[data-clocker-state="unavailable"]').waitFor({timeout:20000});await p.waitForTimeout(500);await shot(p,'clock-state-unavailable');
  await p.unroute('**/api/clocker/*/punch');await btn(p,'Return to PIN').click();});
 await step('auth changed',async()=>{
  await p.route('**/api/clocker/*/punch',(r:any)=>r.fulfill({status:401,contentType:'application/json',body:JSON.stringify({code:'AUTH_REQUIRED',error:'Verification required.'})}));
  await enterPin(p,'2468');await p.locator('[data-clocker-state="auth"]').waitFor({timeout:20000});await p.waitForTimeout(500);await shot(p,'verify-pin-again');
  await p.unroute('**/api/clocker/*/punch');await btn(p,'Return to PIN').click();});
 await step('sending + recovery',async()=>{
  await enterPin(p,'2468');await ready(p);
  await p.route('**/api/clocker/*/punch',async(r:any)=>{const body=r.request().postData()??'';if(body.includes('"execute"')){await new Promise(res=>setTimeout(res,3000));await r.abort().catch(()=>{});}else await r.continue().catch(()=>{});});
  await btn(p,'Clock Out').click();await p.waitForTimeout(500);await shot(p,'confirm-clock-out');
  await btn(p,'Confirm Clock Out').click();await p.waitForTimeout(300);if(extra)await seq(p,'progress',[0,200,400,600,800]);await shot(p,'sending',false);
  await p.locator('[data-clocker-state="recovery"]').waitFor({timeout:20000});await p.waitForTimeout(500);await shot(p,'check-last-action');
  await btn(p,'Help with a saved action').click();await p.waitForTimeout(400);await shot(p,'saved-action-help');
  await p.unroute('**/api/clocker/*/punch');
  await btn(p,'Check Action Status').click();await p.locator('[data-clocker-state="retry"],[data-clocker-state="success"],[data-clocker-state="review-current"]').first().waitFor({timeout:20000});await p.waitForTimeout(500);await shot(p,'retry-same-action');
  const retry=btn(p,'Retry Same Action');if(await retry.count()){await retry.click();await success(p);await p.waitForTimeout(500);await shot(p,'receipt-clock-out');await btn(p,'Done').click();}
 });
 if(extra)await step('review current',async()=>{
  // An aborted Clock In on this tablet, then James clocks in on another Main Office tablet: the saved request is obsolete.
  await enterPin(p,'2468');await ready(p);
  await p.route('**/api/clocker/*/punch',async(r:any)=>{const body=r.request().postData()??'';if(body.includes('"execute"'))await r.abort().catch(()=>{});else await r.continue().catch(()=>{});});
  await btn(p,'Clock In').click();await p.locator('[data-clocker-state="recovery"]').waitFor({timeout:20000});await p.unroute('**/api/clocker/*/punch');
  const C=await fresh();await enroll(C.page,'loc-1','scan-kiosk-main','Back office tablet');await enterPin(C.page,'2468');await ready(C.page);await C.page.getByRole('button',{name:N('Clock In'),exact:true}).click();await success(C.page);await C.ctx.close();
  await btn(p,'Check Action Status').click();await p.locator('[data-clocker-state="review-current"]').waitFor({timeout:20000});await p.waitForTimeout(500);await shot(p,'review-current-status');
  await p.getByRole('button',{name:N('Review current status'),exact:true}).click();await ready(p);await p.waitForTimeout(600);await shot(p,'ready-after-review');
  await btn(p,'Done').click();});
 await step('other location',async()=>{
  const C=await fresh();await enroll(C.page,'loc-2','scan-kiosk-west','West Office tablet');await enterPin(C.page,'1357');await ready(C.page);
  await C.page.getByRole('button',{name:N('Clock In'),exact:true}).click();await success(C.page);await C.ctx.close();
  await p.locator('[data-clocker-pin="entry"]').waitFor();await enterPin(p,'1357');await ready(p);await p.waitForTimeout(700);await shot(p,'ready-other-location');await btn(p,'Done').click();});
 if(extra)await step('photo',async()=>{
  // The company photo policy, simulated the way scripts/clocker-ipad-ui-qa.mjs does (no camera or image storage is used).
  const policy={version:1,enabled:true,events:['CLOCK_OUT'],retentionDays:30,failureBehavior:'ALLOW_WITH_EXCEPTION',captureMaxBytes:524288,captureMaxDimension:640,uploadWindowSeconds:300};
  const notice={policyVersion:1,profileVersion:1,companyName:'Northside QA Workforce',retentionDays:30,assistanceContact:'Front desk (fictional)',assistanceInstructions:'Ask the front desk for an assisted clock action.',cleanupDisclosure:'Fictional cleanup schedule.',backupDisclosure:'Fictional backup retention.'};
  await p.route('**/api/clocker/*/punch',async(r:any)=>{if(r.request().postDataJSON()?.operation==='state'){const response=await r.fetch();const body=await response.json();await r.fulfill({response,json:{...body,photoCaptureAvailable:true}});}else await r.continue();});
  await p.route('**/api/clocker/*/photos',async(r:any)=>{const body=r.request().postDataJSON();if(body.operation==='policy')await r.fulfill({json:{policy,notice}});else await r.fulfill({json:{commandId:body.command?.commandId,state:'missing'}});});
  await p.locator('[data-clocker-pin="entry"]').waitFor();await enterPin(p,'2468');await ready(p);await btn(p,'Clock Out').click();await btn(p,'Confirm Clock Out').click();
  await btn(p,'Continue without photo').waitFor({timeout:20000});await p.waitForTimeout(600);await shot(p,'photo-for-clock-out');
  await btn(p,'Continue without photo').click();await p.getByRole('heading',{name:N('Clock Out Recorded'),exact:true}).waitFor({timeout:20000});await p.waitForTimeout(600);await shot(p,'photo-time-recorded');
  await p.unroute('**/api/clocker/*/punch');await p.unroute('**/api/clocker/*/photos');await btn(p,'Done').click().catch(()=>{});await p.locator('[data-clocker-pin="entry"]').waitFor();});
 if(extra)await step('keyboard',async()=>{
  await p.locator('[data-clocker-pin="entry"]').waitFor();await idle(p);await p.reload();await settle(p);await p.locator('[data-clocker-pin="entry"]').waitFor();await idle(p);await p.waitForTimeout(600);
  const focus=()=>p.evaluate(()=>{const e=document.activeElement as HTMLElement|null;return e?(e.tagName.toLowerCase()+(e.id?'#'+e.id:'')+' '+(e.getAttribute('aria-label')||e.textContent||'').trim().slice(0,28)):null;});
  const order:unknown[]=[await focus()];await p.keyboard.press('Shift+Tab');await p.keyboard.press('Shift+Tab');await p.waitForTimeout(150);order.push(await focus());await p.screenshot({path:`${evidence}/kbd-skip-${sizes[0][0]}x${sizes[0][1]}.png`});
  for(let i=0;i<17;i++){await p.keyboard.press('Tab');await p.waitForTimeout(80);order.push(await focus());if(i===6)await p.screenshot({path:`${evidence}/kbd-key-${sizes[0][0]}x${sizes[0][1]}.png`});}
  log.push({keyboardOrder:order});
  await p.locator('#clocker-pin').focus();await p.keyboard.type('24');await p.waitForTimeout(200);await p.screenshot({path:`${evidence}/kbd-typed-${sizes[0][0]}x${sizes[0][1]}.png`});
  await p.keyboard.press('Escape');await idle(p);await p.waitForTimeout(400);log.push({afterEscape:await p.evaluate(()=>(document.querySelector('#clocker-pin') as HTMLInputElement|null)?.value.length),focus:await focus()});
  await p.keyboard.type('2468');await p.keyboard.press('Enter');await ready(p);await p.waitForTimeout(500);
  for(let i=0;i<3;i++){await p.keyboard.press('Tab');await p.waitForTimeout(80);}
  log.push({readyFocus:await focus()});await p.screenshot({path:`${evidence}/kbd-ready-${sizes[0][0]}x${sizes[0][1]}.png`});await btn(p,'Done').click();});
 // PIN service outage: no connection at all (the browser's own failure), then the server's unavailable reply.
 await step('pin offline',async()=>{
  await p.locator('[data-clocker-pin="entry"]').waitFor();
  await p.route('**/api/clocker/*/pin',async(r:any)=>{const body=r.request().postData()??'';if(body.includes('"verify"'))await r.abort();else await r.continue();});
  await enterPin(p,'2468');await p.waitForTimeout(1500);await shot(p,'pin-offline');await p.unroute('**/api/clocker/*/pin');
  await btn(p,'Check Connection').click();await idle(p);await p.waitForTimeout(800);});
 await step('pin unavailable',async()=>{
  await p.route('**/api/clocker/*/pin',async(r:any)=>{const body=r.request().postData()??'';if(body.includes('"verify"'))await r.fulfill({status:503,contentType:'application/json',body:JSON.stringify({state:'unavailable',error:'PIN verification is unavailable. Check the connection and try again.'})});else await r.continue();});
  await enterPin(p,'2468');await p.waitForTimeout(1500);await shot(p,'pin-unavailable');await p.unroute('**/api/clocker/*/pin');
  await btn(p,'Check Connection').click();await idle(p);await p.waitForTimeout(800);});
 if(extra)await step('clear failed',async()=>{
  await p.route('**/api/clocker/*/pin',async(r:any)=>{const body=r.request().postData()??'';if(body.includes('"clear"'))await r.abort();else await r.continue();});
  await p.keyboard.press('Escape');await p.waitForTimeout(1500);await shot(p,'pin-clear-failed');await p.unroute('**/api/clocker/*/pin');await btn(p,'Check Connection').click();await idle(p);await p.waitForTimeout(600);});
 if(extra)await step('reconnect',async()=>{
  // The tablet's credential is gone (cookies cleared) while the PIN screen is open: the server asks to reconnect.
  await B.ctx.clearCookies();await enterPin(p,'2468');await p.waitForTimeout(1500);await shot(p,'pin-reconnect-tablet');});
 if(extra)await step('band late hour',async()=>{
  const C=await fresh();const q2=C.page;await q2.clock.install({time:new Date()});await enroll(q2,'loc-1','scan-kiosk-main','Clock test tablet');
  const read=async()=>{await q2.waitForTimeout(1300);return q2.evaluate(()=>{const c=document.querySelector('[data-clocker-kiosk] time') as HTMLElement|null,b=c?.closest('aside') as HTMLElement|null;if(!c||!b)return null;
   const cs=getComputedStyle(b),right=b.getBoundingClientRect().right-parseFloat(cs.paddingRight),last=c.lastElementChild?.getBoundingClientRect().right??c.getBoundingClientRect().right;
   return {label:c.getAttribute('aria-label'),fontSize:getComputedStyle(c).fontSize,clockRight:Math.round(last),bandContentRight:Math.round(right),fits:last<=right+0.5};});};
  const now=await read();const m=/^(\d+):(\d+)\s*([ap])/i.exec(String(now?.label??''));
  if(m){const shown=(Number(m[1])%12)+(m[3].toLowerCase()==='p'?12:0),utc=new Date().getUTCHours(),offset=(shown-utc+24)%24;
   const target=new Date();target.setUTCHours((22-offset+24)%24,58,0,0);await q2.clock.setFixedTime(target);}
  for(const [w,h] of sizes){await q2.setViewportSize({width:w,height:h});log.push({bandClock:w+'x'+h,...(await read())});}
  await q2.setViewportSize({width:sizes[0][0],height:sizes[0][1]});await shot(q2,'band-late-hour');await C.ctx.close();});
 await B.ctx.close();
 // The lockout, on its own tablet (it holds that tablet for a few minutes).
 await step('lockout',async()=>{const L=await fresh();await enroll(L.page,'loc-1','scan-kiosk-main','Back room tablet');
  for(let i=0;i<6;i++){await idle(L.page);if(await L.page.getByText(N('Too many attempts. Wait a few minutes before trying again.')).count()||await L.page.locator('[data-clocker-blocked="wait"]').count())break;await enterPin(L.page,'90'+String(10+i));await L.page.waitForTimeout(1300);}
  await shot(L.page,'pin-too-many-attempts');await L.ctx.close();});
 if(extra)await step('storage',async()=>{
  // This browser can't open its recovery storage (IndexedDB refused).
  const S=await fresh();await S.ctx.addInitScript(()=>{try{Object.defineProperty(window,'indexedDB',{value:{open(){const r:any={};setTimeout(()=>{r.error=new DOMException('blocked','UnknownError');r.onerror?.(new Event('error'));},10);return r;}},configurable:true});}catch{/* ignore */}});
  await enroll(S.page,'loc-1','scan-kiosk-main','Storage test tablet');await enterPin(S.page,'2468');await S.page.locator('[data-clocker-state="storage"]').waitFor({timeout:20000});await S.page.waitForTimeout(600);await shot(S.page,'browser-storage-needed');await S.ctx.close();});
 if(extra)await step('reduced motion',async()=>{
  const R=await fresh({reducedMotion:'reduce'});await enroll(R.page,'loc-1','scan-kiosk-main','Reduced motion tablet');
  await enterPin(R.page,'9191');await R.page.locator('[role=alert]').first().waitFor({timeout:15000});await seq(R.page,'rm-wrong-pin',[0,100,220]);
  await enterPin(R.page,'2468');await ready(R.page);
  if(await btn(R.page,'Clock In').count()){await btn(R.page,'Clock In').click();}else{await btn(R.page,'Clock Out').click();await btn(R.page,'Confirm Clock Out').click();}
  await success(R.page);await seq(R.page,'rm-check',[0,100,220,480]);
  log.push({reducedMotion:await R.page.evaluate(()=>{const c=document.querySelector('[data-clocker-state=success] span');return c?getComputedStyle(c).animationName:null;})});await R.ctx.close();});
}
