() => {
  const pick = (el) => { if (!el) return null; const cs = getComputedStyle(el); const r = el.getBoundingClientRect();
    return {tag: el.tagName.toLowerCase(), cls: String(el.className).slice(0, 60), top: Math.round(r.top + scrollY), h: Math.round(r.height), w: Math.round(r.width),
      mt: cs.marginTop, mb: cs.marginBottom, pt: cs.paddingTop, pb: cs.paddingBottom, fs: cs.fontSize, lh: cs.lineHeight, minh: cs.minHeight}; };
  const chain = (el) => { const out = []; for (let e = el; e && e !== document.body; e = e.parentElement) { const cs = getComputedStyle(e); const r = e.getBoundingClientRect();
    if (parseFloat(cs.marginTop) || parseFloat(cs.paddingTop) || r.top + scrollY > 0.5) out.push([e.tagName.toLowerCase() + '.' + String(e.className).split(' ').slice(0, 2).join('.'), Math.round(r.top + scrollY), cs.marginTop, cs.paddingTop]); if (out.length > 9) break; } return out; };
  const scr = document.querySelector('.b-screen');
  const shown = scr && scr.getClientRects().length ? scr : null;
  const hero = shown?.querySelector('.b-hero');
  const links = shown ? [...shown.querySelectorAll('a')].filter(a => a.closest('.eb-read, .eb-doc__links, p')).slice(0, 4).map(a => [a.textContent.slice(0, 20), getComputedStyle(a).fontSize]) : [];
  return {hero: pick(hero), heroChain: chain(hero), h1: pick(shown?.querySelector('.b-title h1')), sub: pick(shown?.querySelector('.b-sub')), title: pick(shown?.querySelector('.b-title')),
    links, lseg: pick(shown?.querySelector('.eb-lseg button')), note: pick(shown?.querySelector('.b-note')), confirmBtn: pick(shown?.querySelector('.es-confirm__act button')),
    stackEnd: shown ? Math.round(shown.querySelector('.b-stack')?.getBoundingClientRect().bottom + scrollY) : null, docH: document.documentElement.scrollHeight,
    stackPb: shown ? getComputedStyle(shown.querySelector('.b-stack') || shown).paddingBottom : null, mainPb: getComputedStyle(document.querySelector('.app-main') || document.body).paddingBottom,
    framePb: getComputedStyle(document.querySelector('.page-frame') || document.body).paddingBottom};
}
