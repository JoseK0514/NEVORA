// SCRATCH (not committed): Owner / Manager interaction states (NEVORA_SCAN_STATES_OWNER=1). Fictional data, disposable database.
// Every state is fold first, then full page, on a fresh page (a full-page shot drops touch emulation in this browser build).
// Nothing irreversible is submitted: forms are filled and left unsent; the only commit is approving one fictional timecard.
/* eslint-disable @typescript-eslint/no-explicit-any */
type Log=unknown[];

export async function runOwnerStates(browser:any,main:any,appUrl:string,evidence:string,log:Log,info:{lastWeek:string;only?:string[]}){
 const storage=await main.storageState();
 const shots:string[]=[];
 const want=(name:string)=>!info.only?.length||info.only.some(o=>name===o||name.startsWith(o));
 const phone={viewport:{width:390,height:844},deviceScaleFactor:2,isMobile:true,hasTouch:true};
 const desk={viewport:{width:1440,height:900},deviceScaleFactor:1};
 const contexts:any[]=[];
 const mkctx=async(opts:Record<string,unknown>)=>{const ctx=await browser.newContext({storageState:storage,reducedMotion:'reduce',serviceWorkers:'block',...opts});contexts.push(ctx);return ctx;};
 const ctxPhone=await mkctx(phone),ctxDesk=await mkctx(desk);
 const ctxFor=(w:number)=>w<1000?ctxPhone:ctxDesk;
 const newPage=async(ctx:any)=>{const page=await ctx.newPage();page.setDefaultTimeout(12000);
  page.on('pageerror',(e:Error)=>log.push('ostate pageerror '+e.message.slice(0,300)));
  page.on('console',(m:{type():string;text():string})=>{if(m.type()==='error')log.push('ostate console '+m.text().slice(0,300));});return page;};
 const settle=async(page:any,ms=1200)=>{await page.waitForLoadState('networkidle',{timeout:8000}).catch(()=>{});await page.waitForTimeout(ms);};
 const go=async(page:any,route:string)=>{await page.goto(appUrl+route);await settle(page,1800);};
 const snap=async(page:any,name:string,w:number|string)=>{await page.screenshot({path:`${evidence}/state-${name}-${w}-fold.png`,fullPage:false});await page.screenshot({path:`${evidence}/state-${name}-${w}.png`,fullPage:true});shots.push(`state-${name}-${w}`);};
 const inventory=async(page:any)=>page.evaluate(()=>[...document.querySelectorAll('main a, main button, main summary, main input, main textarea, main select, [role="dialog"] button')].filter(e=>(e as HTMLElement).getClientRects().length).map(e=>{const el=e as HTMLElement;return `${el.tagName.toLowerCase()}${el.getAttribute('type')?'['+el.getAttribute('type')+']':''}:${(el.getAttribute('aria-label')||el.textContent||el.getAttribute('name')||'').trim().replace(/\s+/g,' ').slice(0,40)}${el.getAttribute('href')?' →'+el.getAttribute('href')?.slice(0,60):''}`;}).slice(0,40)).catch(()=>[]);
 const step=async(name:string,w:number|string,fn:(page:any)=>Promise<unknown>,ctx?:any)=>{
  if(!want(name))return;
  const page=await newPage(ctx??ctxFor(Number(w)||1440));
  try{const r=await fn(page);log.push({ostate:`${name}-${w}`,ok:true,...(r&&typeof r==='object'?r:r!==undefined?{info:r}:{})});}
  catch(e){log.push({ostate:`${name}-${w}`,ok:false,error:String((e as Error)?.message??e).slice(0,400),url:page.url().replace(appUrl,''),inventory:await inventory(page)});await page.screenshot({path:`${evidence}/state-${name}-${w}-failed.png`,fullPage:false}).catch(()=>{});}
  finally{await page.close().catch(()=>{});}
 };
 const firstVisible=async(locator:any)=>{const n=await locator.count();for(let i=0;i<n;i++){const l=locator.nth(i);if(await l.isVisible().catch(()=>false))return l;}return null;};
 const scope=(page:any)=>page.locator('main').first();
 const focusInfo=(page:any)=>page.evaluate(()=>{const e=document.activeElement as HTMLElement|null;if(!e||e===document.body)return null;const cs=getComputedStyle(e);const r=e.getBoundingClientRect();
  return {tag:e.tagName.toLowerCase(),cls:[...e.classList].slice(0,3).join('.'),text:(e.getAttribute('aria-label')||e.textContent||'').trim().replace(/\s+/g,' ').slice(0,50),rect:[Math.round(r.left),Math.round(r.top),Math.round(r.width),Math.round(r.height)],outline:`${cs.outlineStyle} ${cs.outlineWidth} ${cs.outlineColor} offset ${cs.outlineOffset}`,shadow:cs.boxShadow.slice(0,90)};});
 const slugOf=(route:string)=>route.replace(/^\/app\/?/,'').replace(/[^a-z0-9]+/gi,'-').replace(/-$/,'')||'home';

 // ---------- Keyboard focus after 3 and 8 Tabs (a fresh load per count, so each shot is a clean fold-then-full) ----------
 for(const route of ['/app','/app/inbox','/app/schedule','/app/timecards'])for(const w of [390,1440])for(const n of [3,8]){
  await step(`focus-${slugOf(route)}-${n}`,w,async page=>{await go(page,route);await page.evaluate(()=>{(document.activeElement as HTMLElement|null)?.blur?.();window.scrollTo(0,0);});
   const steps:unknown[]=[];for(let i=1;i<=n;i++){await page.keyboard.press('Tab');await page.waitForTimeout(150);steps.push(await focusInfo(page));}
   await snap(page,`focus-${slugOf(route)}-${n}`,w);return {focus:steps};});
 }

 // ---------- Timecards: open one, the approve step, an approval (fictional), and one with issues ----------
 const lw=`/app/timecards?start=${info.lastWeek}&end=${addDays(info.lastWeek,6)}`;
 const openCard=async(page:any,prefer?:RegExp)=>{const rows=page.locator('main button').filter({hasText:/Colon|Ortiz|Rivera|Ruiz|Torres|Santos|Díaz|Méndez|Vega|Cruz|Reyes/});const n=await rows.count();const tried:string[]=[];
  for(let i=0;i<n;i++){const r=rows.nth(i);if(!(await r.isVisible().catch(()=>false)))continue;const label=((await r.getAttribute('aria-label'))||(await r.innerText())).replace(/\s+/g,' ');tried.push(label.slice(0,50));if(prefer&&!prefer.test(label))continue;
   await r.scrollIntoViewIfNeeded();await r.click();await page.waitForTimeout(900);
   const ok=await firstVisible(page.getByRole('button',{name:'Approve timecard',exact:true}));
   if(prefer||ok&&await ok.isEnabled())return {label,approve:ok};
   await page.keyboard.press('Escape');await page.waitForTimeout(400);}
  throw Error('no timecard row fit; rows: '+tried.join(' | '));};
 for(const w of [390,1440]){
  await step('timecard-open',w,async page=>{await go(page,lw);const {label,approve}=await openCard(page);await snap(page,'timecard-open',w);
   if(approve){await approve.scrollIntoViewIfNeeded();await page.waitForTimeout(300);await snap(page,'timecard-approve-step',w);}
   if(w===1440&&approve){await approve.click();await page.waitForTimeout(400);await page.screenshot({path:`${evidence}/state-timecard-approving-${w}-fold.png`,fullPage:false});shots.push(`state-timecard-approving-${w}-fold`);await settle(page,1800);await snap(page,'timecard-approved',w);}
   return {opened:label,status:await page.locator('[role="status"],[role="alert"]').allInnerTexts().then((t:string[])=>t.map(x=>x.replace(/\s+/g,' ').slice(0,120)).filter(Boolean).slice(0,4))};});
  await step('timecard-issue',w,async page=>{await go(page,lw);const {label}=await openCard(page,/Valeria|Luis|Miguel/);await snap(page,'timecard-issue',w);
   const more=await firstVisible(page.locator('summary').filter({hasText:/Clock-ins and fixes/}));if(more){await more.click();await page.waitForTimeout(500);await snap(page,'timecard-issue-details',w);}return {opened:label};});
 }

 // ---------- Schedule: the shift editor ----------
 for(const w of [390,1440])await step('schedule-shift-edit',w,async page=>{await go(page,'/app/schedule');const l=await firstVisible(page.locator('a[href*="/app/schedule/edit"]'));if(!l)throw Error('no shift edit link');
  const label=(await l.getAttribute('aria-label'))??(await l.innerText());await l.scrollIntoViewIfNeeded();await l.click();await settle(page,1500);await snap(page,'schedule-shift-edit',w);return {row:label.slice(0,80),url:page.url().replace(appUrl,'')};});

 // ---------- Time off: a waiting request opened, with Approve / Decline ----------
 for(const w of [390,1440])await step('timeoff-open',w,async page=>{await go(page,'/app/requests?tab=pending');const l=await firstVisible(page.locator('main a[href*="requestId="]'));if(!l)throw Error('no waiting time-off row');
  await l.click();await settle(page,1500);await snap(page,'timeoff-open',w);
  return {url:page.url().replace(appUrl,''),decision:await page.locator('main button').allInnerTexts().then((t:string[])=>t.map(x=>x.trim()).filter(x=>/Approve|Decline/.test(x)))};});

 // ---------- Shift requests: a swap opened, a callout opened ----------
 for(const w of [390,1440]){
  await step('swap-open',w,async page=>{await go(page,'/app/exchange?tab=pending');const s=await firstVisible(page.locator('main summary').filter({hasText:/swap/i}))??await firstVisible(page.locator('main summary'));if(!s)throw Error('no waiting shift request');
   const label=(await s.getAttribute('aria-label'))??(await s.innerText());await s.click();await page.waitForTimeout(700);await snap(page,'swap-open',w);
   return {opened:label.replace(/\s+/g,' ').slice(0,100),decision:await page.locator('main button').filter({hasText:/^(Approve|Decline)$/}).count().then((n:number)=>n+' Approve/Decline buttons'),_x:await page.locator('main details[open] button').allInnerTexts().then((t:string[])=>t.map(x=>x.trim()))};});
  await step('callout-open',w,async page=>{await go(page,'/app/exchange?tab=pending');const s=await firstVisible(page.locator('main summary').filter({hasText:/Can.t work/i}));if(!s)throw Error('no waiting callout');
   await s.click();await page.waitForTimeout(700);await snap(page,'callout-open',w);return {decision:await page.locator('main button').filter({hasText:/^(Approve|Decline)$/}).count().then((n:number)=>n+' Approve/Decline buttons'),_x:await page.locator('main details[open] button').allInnerTexts().then((t:string[])=>t.map(x=>x.trim()))};});
 }

 // ---------- Add employee: empty submit (validation) and filled (not submitted) ----------
 const submitOf=async(page:any)=>{const b=await firstVisible(scope(page).locator('button[type="submit"]'))??await firstVisible(page.getByRole('button',{name:/^(Add|Save|Create|Continue|Invite|Next)\b/}));if(!b)throw Error('no submit button');return b;};
 for(const w of [390,1440]){
  await step('employee-new-empty',w,async page=>{await go(page,'/app/employees/new');const b=await submitOf(page);const label=(await b.innerText()).trim();await b.scrollIntoViewIfNeeded();await b.click();await settle(page,1200);
   await snap(page,'employee-new-empty',w);return {pressed:label,url:page.url().replace(appUrl,''),invalid:await page.locator('[aria-invalid="true"]').count(),errors:await page.locator('[role="alert"], .c-field__error, .c-error').allInnerTexts().then((t:string[])=>t.map(x=>x.replace(/\s+/g,' ').slice(0,100)).slice(0,6)),
    native:await page.evaluate(()=>[...document.querySelectorAll('main input,main select,main textarea')].filter(e=>!(e as HTMLInputElement).checkValidity()).map(e=>(e as HTMLInputElement).name||e.id).slice(0,8))};});
  await step('employee-new-filled',w,async page=>{await go(page,'/app/employees/new');const filled:string[]=[];
   const byLabel=async(re:RegExp,value:string)=>{const f=await firstVisible(scope(page).getByLabel(re));if(f&&await f.isEditable().catch(()=>false)){await f.fill(value);filled.push(String(re));}};
   await byLabel(/^First name/i,'Isabel');await byLabel(/^Last name/i,'Ramos');await byLabel(/Phone/i,'555-0187');await byLabel(/Email/i,'isabel.ramos@example.test');await byLabel(/Employee (ID|number)/i,'NS-0142');
   for(const sel of await scope(page).locator('select:visible').all()){const opts=await sel.locator('option').evaluateAll((o:HTMLOptionElement[])=>o.filter(x=>x.value&&!x.disabled).map(x=>x.value));if(opts.length&&!(await sel.inputValue())){await sel.selectOption(opts[0]);filled.push('select');}}
   await page.evaluate(()=>window.scrollTo(0,0));await page.waitForTimeout(400);await snap(page,'employee-new-filled',w);return {filled};});
 }

 // ---------- A settings form with a validation error (empty new location; nothing valid to save) ----------
 for(const w of [390,1440])await step('settings-location-invalid',w,async page=>{await go(page,'/app/settings/locations/new');const b=await submitOf(page);const label=(await b.innerText()).trim();
  const name=await firstVisible(scope(page).getByLabel(/name/i));if(name)await name.fill('   ');await b.scrollIntoViewIfNeeded();await b.click();await settle(page,1200);await snap(page,'settings-location-invalid',w);
  return {pressed:label,url:page.url().replace(appUrl,''),invalid:await page.locator('[aria-invalid="true"]').count(),errors:await page.locator('[role="alert"], .c-field__error, .c-error').allInnerTexts().then((t:string[])=>t.map(x=>x.replace(/\s+/g,' ').slice(0,100)).slice(0,6))};});

 // ---------- Expanded disclosures: Help and Company policies ----------
 const expandFirst=async(page:any)=>{const l=await firstVisible(scope(page).locator('summary, button[aria-expanded="false"]'));if(!l)throw Error('nothing expandable');const label=(await l.innerText().catch(()=>'')).trim().replace(/\s+/g,' ').slice(0,60);await l.scrollIntoViewIfNeeded();await l.click();await page.waitForTimeout(600);return {expanded:label};};
 for(const w of [390,1440]){
  await step('help-expanded',w,async page=>{await go(page,'/app/help');const r=await expandFirst(page);await snap(page,'help-expanded',w);return r;});
  await step('policies-expanded',w,async page=>{await go(page,'/app/settings/company-policies');const r=await expandFirst(page);await snap(page,'policies-expanded',w);return r;});
 }

 // ---------- Updates: compose filled (not sent), and an update with partial acknowledgements ----------
 for(const w of [390,1440]){
  await step('updates-compose-filled',w,async page=>{await go(page,'/app/updates/compose');const filled:string[]=[];
   const title=await firstVisible(scope(page).getByLabel(/^Title|Subject|Headline/i))??await firstVisible(scope(page).locator('input[type="text"]:visible, input:not([type]):visible'));if(title){await title.fill('Saturday inventory count');filled.push('title');}
   const body=await firstVisible(scope(page).locator('textarea'));if(body){await body.fill('We count the stockroom after close this Saturday. Plan 30 extra minutes on your closing shift; the count sheets are on the back-office tablet.');filled.push('body');}
   const req=await firstVisible(scope(page).getByText(/Ask (people )?to confirm|Require|confirm/i));if(req){await req.click().catch(()=>{});filled.push('ack');}
   await page.evaluate(()=>window.scrollTo(0,0));await page.waitForTimeout(500);await snap(page,'updates-compose-filled',w);return {filled,sendButtons:await page.locator('main button').allInnerTexts().then((t:string[])=>t.map(x=>x.trim()).filter(x=>/Send|Publish|Post/.test(x)))};});
  await step('update-detail',w,async page=>{await go(page,'/app/updates');const l=await firstVisible(scope(page).locator('a[href^="/app/updates/"]:not([href$="/compose"])'));if(!l)throw Error('no update row');
   await l.click();await settle(page,1500);await page.waitForFunction(()=>!/Checking your current/.test(document.body.innerText),undefined,{timeout:12000}).catch(()=>{});await page.waitForTimeout(600);await snap(page,'update-detail',w);return {url:page.url().replace(appUrl,'')};});
 }

 // ---------- Offline Home ----------
 for(const w of [390,1440])await step('offline-home',w,async page=>{await go(page,'/app');const ctx=page.context();await ctx.setOffline(true);await page.waitForTimeout(1500);
  await page.evaluate(()=>{window.dispatchEvent(new Event('offline'));window.dispatchEvent(new Event('focus'));document.dispatchEvent(new Event('visibilitychange'));});await page.waitForTimeout(3500);
  try{await snap(page,'offline-home',w);return {statusText:await page.evaluate(()=>[...document.querySelectorAll('[role="status"],[role="alert"]')].map(e=>(e.textContent||'').trim()).filter(Boolean).slice(0,5))};}
  finally{await ctx.setOffline(false);await page.waitForTimeout(300);}});

 // ---------- Home at other viewports ----------
 for(const [suffix,opts] of [['1280',{viewport:{width:1280,height:800},deviceScaleFactor:1}],['1024',{viewport:{width:1024,height:768},deviceScaleFactor:1}],['900',{viewport:{width:900,height:1200},deviceScaleFactor:2,isMobile:true,hasTouch:true}],['844x390',{viewport:{width:844,height:390},deviceScaleFactor:2,isMobile:true,hasTouch:true}]] as const){
  if(!want('home-viewport'))continue;
  const ctx=await mkctx(opts as Record<string,unknown>);
  await step('home-viewport',suffix,async page=>{await go(page,'/app');const check=await page.evaluate(()=>({overflow:document.documentElement.scrollWidth-innerWidth,h1:[...document.querySelectorAll('h1')].filter(h=>h.getClientRects().length).map(h=>h.textContent?.trim()).slice(0,3),tabs:!!document.querySelector('.mobile-nav')&&getComputedStyle(document.querySelector('.mobile-nav')!).display!=='none'}));
   await snap(page,'home',suffix);return check;},ctx);
 }
 // Round 5 (Nov 8): Notifications when the list can't be read (the API answers read_failed; nothing is sent anywhere).
 for(const w of [390,1440])await step('notifications-error',w,async page=>{await page.route('**/api/notifications',(r:any)=>r.fulfill({status:503,contentType:'application/json',body:JSON.stringify({state:'unavailable',reason:'read_failed'})}));await go(page,'/app/notifications');await page.waitForTimeout(800);await snap(page,'notifications-error',w);});
 for(const c of contexts)await c.close().catch(()=>{});
 log.push({ownerStateShots:shots});
}

function addDays(date:string,days:number){const d=new Date(date+'T12:00:00Z');d.setUTCDate(d.getUTCDate()+days);return d.toISOString().slice(0,10);}
