() => {
  const vw = innerWidth, out = { clipped: [], offscreen: [], overlap: [], small: [], contrast: [], align: [], radius: [] };
  const vis = e => { const r = e.getBoundingClientRect(); const cs = getComputedStyle(e); return r.width > 0 && r.height > 0 && cs.visibility !== 'hidden' && cs.display !== 'none' && +cs.opacity > 0.05 && !e.closest('[hidden],[aria-hidden="true"] .sr-only'); };
  const srOnly = e => { const cs = getComputedStyle(e); const r = e.getBoundingClientRect(); return (r.width <= 2 && r.height <= 2) || cs.clipPath === 'inset(50%)' || cs.clip === 'rect(0px, 0px, 0px, 0px)'; };
  const name = e => (e.tagName.toLowerCase() + '.' + [...e.classList].slice(0, 3).join('.')).slice(0, 60);
  const text = e => (e.textContent || '').trim().replace(/\s+/g, ' ').slice(0, 40);
  const root = document.querySelector('.page-frame') || document.body;
  const all = [...root.querySelectorAll('*')].filter(e => !e.closest('.mobile-nav, nextjs-portal, [data-nextjs-toast]') && vis(e) && !srOnly(e));
  const leaves = all.filter(e => [...e.childNodes].some(n => n.nodeType === 3 && n.textContent.trim()));
  // 1 clipped or truncated text
  for (const e of leaves) { const cs = getComputedStyle(e); if (cs.overflow !== 'visible' || cs.textOverflow === 'ellipsis') { if (e.scrollWidth > e.clientWidth + 1 || e.scrollHeight > e.clientHeight + 2) out.clipped.push([name(e), text(e), cs.textOverflow === 'ellipsis' ? 'ellipsis' : 'clip', e.scrollWidth - e.clientWidth, e.scrollHeight - e.clientHeight]); } }
  // 2 off screen (content beyond the viewport edges)
  for (const e of leaves) { const r = e.getBoundingClientRect(); if (r.right > vw + 0.5 || r.left < -0.5) out.offscreen.push([name(e), text(e), Math.round(r.left), Math.round(r.right)]); }
  // 3 overlapping text boxes (leaves that aren't nested)
  const rects = leaves.map(e => { const range = document.createRange(); range.selectNodeContents(e); const rs = [...range.getClientRects()].filter(r => r.width > 1 && r.height > 1); return { e, rs }; });
  for (let i = 0; i < rects.length; i++) for (let j = i + 1; j < rects.length; j++) {
    const a = rects[i], b = rects[j]; if (a.e.contains(b.e) || b.e.contains(a.e)) continue;
    for (const ra of a.rs) for (const rb of b.rs) { const ox = Math.min(ra.right, rb.right) - Math.max(ra.left, rb.left), oy = Math.min(ra.bottom, rb.bottom) - Math.max(ra.top, rb.top); if (ox > 2 && oy > 3) { out.overlap.push([name(a.e), text(a.e), name(b.e), text(b.e), Math.round(ox), Math.round(oy)]); } }
  }
  // 4 small targets
  for (const e of all.filter(e => e.matches('a[href], button, input:not([type=hidden]), select, textarea, [role=button], summary'))) { const r = e.getBoundingClientRect(); if (r.height < 32 || r.width < 24) out.small.push([name(e), text(e) || e.getAttribute('aria-label'), Math.round(r.width), Math.round(r.height)]); }
  // 5 contrast
  const parse = c => { const m = c.match(/rgba?\(([^)]+)\)/); if (!m) return null; const p = m[1].split(/[ ,/]+/).filter(Boolean).map(Number); return [p[0], p[1], p[2], p.length > 3 ? p[3] : 1]; };
  const lum = ([r, g, b]) => { const f = v => { v /= 255; return v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4; }; return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b); };
  const bgOf = e => { let layers = []; for (let n = e; n; n = n.parentElement) { const cs = getComputedStyle(n); if (cs.backgroundImage && cs.backgroundImage !== 'none' && /gradient/.test(cs.backgroundImage)) { const c = parse(cs.backgroundImage.match(/rgba?\([^)]+\)/g)?.slice(-1)[0] || ''); if (c && c[3] > 0.9) { layers.push(c); break; } } const c = parse(cs.backgroundColor); if (c && c[3] > 0) { layers.push(c); if (c[3] >= 0.99) break; } } let base = [242, 245, 244]; for (const l of layers.reverse()) base = base.map((v, i) => l[3] * l[i] + (1 - l[3]) * v); return base; };
  for (const e of leaves) { const cs = getComputedStyle(e); const fg = parse(cs.color); if (!fg) continue; const bg = bgOf(e); const f = fg.slice(0, 3).map((v, i) => fg[3] * v + (1 - fg[3]) * bg[i]); const L1 = lum(f), L2 = lum(bg); const ratio = (Math.max(L1, L2) + 0.05) / (Math.min(L1, L2) + 0.05); const size = parseFloat(cs.fontSize), bold = +cs.fontWeight >= 600; const need = size >= 24 || (size >= 18.66 && bold) ? 3 : 4.5; if (ratio < need && !e.closest('button:disabled, [aria-disabled=true], input::placeholder')) out.contrast.push([name(e), text(e), ratio.toFixed(2), need]); }
  // 6 row alignment within a card: the left edge of each row's first text should match
  for (const card of all.filter(e => e.matches('.b-card, .c-card, .q-list'))) {
    const rows = [...card.querySelectorAll(':scope > li, :scope > ul > li, :scope .b-list > li, :scope .c-rows > li')].filter(vis);
    const lefts = rows.map(li => { const t = [...li.querySelectorAll('*')].find(x => [...x.childNodes].some(n => n.nodeType === 3 && n.textContent.trim()) && vis(x) && !srOnly(x) && !x.closest('.b-av, .c-av, .q-av, .b-day, .b-ico, .c-sched-row__time, .c-row__lead, .b-chip, .c-pill')); return t ? Math.round(t.getBoundingClientRect().left) : null; }).filter(x => x !== null);
    if (lefts.length > 1) { const s = [...new Set(lefts)]; if (s.length > 1 && Math.max(...s) - Math.min(...s) > 1) out.align.push([name(card), (card.querySelector('h2, .b-card__h, .c-card__label')?.textContent || '').trim().slice(0, 30), s.join(',')]); }
  }
  // 7 card radius
  for (const card of all.filter(e => e.matches('.b-card, .c-card, .q-list') && !e.parentElement.closest('.b-card, .c-card, .q-list'))) { const r = getComputedStyle(card).borderTopLeftRadius; if (r !== '22px') out.radius.push([name(card), r]); }
  for (const k of Object.keys(out)) out[k] = out[k].slice(0, 25);
  return out;
}
