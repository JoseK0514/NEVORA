() => {
  const vis = e => { const r = e.getBoundingClientRect(); const cs = getComputedStyle(e); return r.width > 2 && r.height > 2 && cs.display !== 'none' && cs.visibility !== 'hidden'; };
  const name = e => (e.tagName.toLowerCase() + '.' + [...e.classList].slice(0, 3).join('.')).slice(0, 60);
  const frame = document.querySelector('main.page-frame');
  if (!frame) return null;
  // The element that paints the band: any element under the frame whose border-image-source is a gradient.
  const painters = [...frame.querySelectorAll('*')].filter(e => vis(e) && getComputedStyle(e).borderImageSource.includes('gradient'));
  let bandBottom = 0, hero = null;
  for (const e of painters) { const cs = getComputedStyle(e); const parts = cs.borderImageOutset.split(' ').map(v => parseFloat(v)); const b = parts.length === 4 ? parts[2] : parts.length >= 3 ? parts[2] : parts[0]; const bottom = e.getBoundingClientRect().bottom + (b || 0); if (bottom > bandBottom) { bandBottom = bottom; hero = e; } }
  // Cards: white boxes with the card radius.
  const cards = [...frame.querySelectorAll('*')].filter(e => { if (!vis(e)) return false; const cs = getComputedStyle(e); return parseFloat(cs.borderTopLeftRadius) >= 18 && (cs.backgroundColor === 'rgb(255, 255, 255)') && e.getBoundingClientRect().width > 300; })
    .filter((e, i, a) => !a.some(o => o !== e && o.contains(e)));
  cards.sort((a, b) => a.getBoundingClientRect().top - b.getBoundingClientRect().top);
  const title = frame.querySelector('h1:not(.q-sr):not(.c-sr)');
  const tr = title && vis(title) ? title.getBoundingClientRect() : null;
  const firstCard = cards[0] ? cards[0].getBoundingClientRect() : null;
  const gaps = [];
  for (let i = 1; i < cards.length; i++) { const a = cards[i - 1].getBoundingClientRect(), b = cards[i].getBoundingClientRect(); if (Math.abs(a.left - b.left) < 4) gaps.push(Math.round(b.top - a.bottom)); }
  const back = [...frame.querySelectorAll('.q-nav__l, .c-nav__back, .c-shift__cancel')].filter(vis).map(e => { const r = e.getBoundingClientRect(); return [name(e), Math.round(r.left), Math.round(r.top), Math.round(r.width), Math.round(r.height)]; });
  const overlapsTitle = tr ? back.filter(b => !(b[2] + b[4] <= tr.top || b[2] >= tr.bottom)) : [];
  return {
    hero: hero ? name(hero) : null, bandBottom: Math.round(bandBottom),
    firstCard: firstCard ? [Math.round(firstCard.left), Math.round(firstCard.top), Math.round(firstCard.width)] : null,
    gapUnderBand: firstCard ? Math.round(firstCard.top - bandBottom) : null,
    titleLeft: tr ? Math.round(tr.left) : null, cardLeft: firstCard ? Math.round(firstCard.left) : null,
    cardGaps: gaps, back, backOverTitle: overlapsTitle.length,
    cardRights: [...new Set(cards.map(c => Math.round(c.getBoundingClientRect().right)))].slice(0, 6),
  };
}
