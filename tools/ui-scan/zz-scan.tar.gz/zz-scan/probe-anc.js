() => {
  const want = ['Issue recovery code', 'Check code', 'Keep my account', 'Confirm deletion request', 'Check against details', 'Cancel', 'Refresh', 'Code from the tablet'];
  const out = [];
  for (const e of document.querySelectorAll('main.page-frame :is(button, a, p, span, label)')) {
    const t = (e.textContent || '').trim();
    if (!want.some(w => t.startsWith(w)) || t.length > 120) continue;
    const r = e.getBoundingClientRect(); if (!r.width) continue;
    const chain = []; let n = e;
    for (let i = 0; i < 7 && n && !n.matches('main'); i++, n = n.parentElement) { const cs = getComputedStyle(n); const rr = n.getBoundingClientRect(); chain.push(`${n.tagName.toLowerCase()}.${[...n.classList].slice(0,3).join('.')} [${Math.round(rr.left)}-${Math.round(rr.right)}] pad:${cs.paddingLeft}/${cs.paddingRight} mar:${cs.marginLeft}/${cs.marginRight} w:${cs.width} mw:${cs.maxWidth} disp:${cs.display}`); }
    out.push({ t: t.slice(0, 30), chain });
  }
  return out;
}
