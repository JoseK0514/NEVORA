() => {
  const vis = e => { const r = e.getBoundingClientRect(); const cs = getComputedStyle(e); return r.width > 2 && r.height > 2 && cs.display !== 'none' && cs.visibility !== 'hidden'; };
  const name = e => (e.tagName.toLowerCase() + '.' + [...e.classList].slice(0, 3).join('.')).slice(0, 60);
  const frame = document.querySelector('main.page-frame'); if (!frame) return null;
  const cards = [...frame.querySelectorAll('*')].filter(e => { if (!vis(e)) return false; const cs = getComputedStyle(e); return parseFloat(cs.borderTopLeftRadius) >= 18 && cs.backgroundColor === 'rgb(255, 255, 255)' && e.getBoundingClientRect().width > 250; })
    .filter((e, i, a) => !a.some(o => o !== e && o.contains(e)));
  const out = [];
  for (const card of cards) {
    const cr = card.getBoundingClientRect(); const items = [];
    const walker = document.createTreeWalker(card, NodeFilter.SHOW_TEXT);
    let n; while ((n = walker.nextNode())) { if (!n.textContent.trim()) continue; const el = n.parentElement; if (!vis(el)) continue; const rg = document.createRange(); rg.selectNodeContents(n); const rr = rg.getBoundingClientRect(); if (!rr.width) continue; items.push([Math.round(rr.left - cr.left), name(el), n.textContent.trim().slice(0, 30)]); }
    for (const b of card.querySelectorAll('button, a.c-btn, .q-btn, input:not([type=hidden]), select, .c-in')) { if (!vis(b)) continue; const r = b.getBoundingClientRect(); items.push(['box ' + Math.round(r.left - cr.left) + '/' + Math.round(cr.right - r.right), name(b), (b.textContent || b.value || '').trim().slice(0, 30)]); }
    out.push({ card: name(card), left: Math.round(cr.left), w: Math.round(cr.width), items: items.slice(0, 40) });
  }
  return out;
}
