function(){
  const vis=e=>{const r=e.getBoundingClientRect();return r.width>0&&r.height>0;};
  const d=e=>{const r=e.getBoundingClientRect();return (e.tagName.toLowerCase()+(e.id?'#'+e.id:'')+'.'+[...e.classList].join('.')).slice(0,70)+(e.getAttribute('aria-label')?'['+e.getAttribute('aria-label').slice(0,30)+']':'')+' @'+Math.round(r.left)+','+Math.round(r.top)+' '+Math.round(r.width)+'x'+Math.round(r.height);};
  const screens=[...document.querySelectorAll('.b-screen')].filter(vis);
  const out=screens.map(s=>({path:(()=>{let p=[],e=s.parentElement;while(e&&!e.matches('main')){p.push(e.tagName.toLowerCase()+'.'+[...e.classList].slice(0,3).join('.'));e=e.parentElement;}return p.join(' < ');})(),
    cls:s.className,hero:[...(s.querySelector('.b-hero')?.children??[])].map(d),stack:[...(s.querySelector('.b-stack')?.children??[])].map(d),after:[...s.parentElement.children].filter(c=>c!==s&&vis(c)).map(d)}));
  const page=[...document.querySelectorAll('main.page-frame > *')].filter(vis).map(d);
  return {screens:out,page};
}
