() => {
  const rootEl = document.querySelector('main.page-frame') || document.body;
  const k = Object.keys(rootEl).find(x => x.startsWith('__reactFiber$'));
  if (!k) return 'no fiber';
  let f = rootEl[k]; while (f.return) f = f.return;
  const out = []; const name = t => typeof t === 'string' ? t : t && (t.displayName || t.name) || (t && t.$$typeof ? String(t.$$typeof) : String(t));
  const ownerName = o => o ? (o.name || name(o.type) || '?') : '-';
  const seen = new Set();
  const walk = (fb, d) => {
    if (!fb || d > 400) return;
    const ch = fb.memoizedProps && fb.memoizedProps.children;
    const scan = (arr, where) => { if (!Array.isArray(arr)) return; const bad = arr.filter(e => e && typeof e === 'object' && e.$$typeof && e.key == null && e._store && !e._store.validated);
      if (bad.length && out.length < 20) out.push({ fiber: name(fb.type), cls: (fb.memoizedProps && fb.memoizedProps.className || '').toString().slice(0, 40), owner: ownerName(fb._debugOwner), where, n: arr.length, bad: bad.map(e => name(e.type) + ' owner=' + ownerName(e._owner)).slice(0, 4) }); };
    scan(ch, 'children');
    if (Array.isArray(ch)) for (const c of ch) if (Array.isArray(c)) scan(c, 'nested');
    let c = fb.child; while (c) { walk(c, d + 1); c = c.sibling; }
  };
  walk(f, 0); return out;
}
