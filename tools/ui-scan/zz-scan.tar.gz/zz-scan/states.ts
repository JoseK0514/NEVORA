// SCRATCH (not committed): extra interactive / state shots (NEVORA_SCAN_STATES=1). Fictional data, disposable database.
/* eslint-disable @typescript-eslint/no-explicit-any */
type Log=unknown[];
const TEST_PASSWORD='Fictional-Phase-A-only!';

export async function runStates(browser:any,main:any,appUrl:string,evidence:string,log:Log){
 const storage=await main.storageState();
 const shots:string[]=[];
 const mk=async(opts:Record<string,unknown>)=>{const ctx=await browser.newContext({storageState:storage,reducedMotion:'reduce',serviceWorkers:'block',deviceScaleFactor:2,isMobile:true,hasTouch:true,...opts});const page=await ctx.newPage();page.setDefaultTimeout(12000);
  page.on('pageerror',(e:Error)=>log.push('state pageerror '+e.message.slice(0,300)));
  page.on('console',(m:{type():string;text():string})=>{if(m.type()==='error')log.push('state console '+m.text().slice(0,300));});return {ctx,page};};
 const {ctx,page}=await mk({viewport:{width:390,height:844}});
 const settle=async(ms=1200)=>{await page.waitForLoadState('networkidle',{timeout:8000}).catch(()=>{});await page.waitForTimeout(ms);};
 const go=async(route:string)=>{await page.goto(appUrl+route);await settle(1800);};
 const snap=async(name:string,p=page,suffix='390')=>{await p.screenshot({path:`${evidence}/state-${name}-${suffix}-fold.png`,fullPage:false});await p.screenshot({path:`${evidence}/state-${name}-${suffix}.png`,fullPage:true});shots.push(`state-${name}-${suffix}`);};
 const step=async(name:string,fn:()=>Promise<unknown>)=>{try{const r=await fn();log.push({state:name,ok:true,...(r&&typeof r==='object'?r:r!==undefined?{info:r}:{})});}catch(e){log.push({state:name,ok:false,error:String((e as Error)?.message??e).slice(0,400)});await page.screenshot({path:`${evidence}/state-${name}-390-failed.png`,fullPage:false}).catch(()=>{});}};
 const firstVisible=async(locator:any)=>{const n=await locator.count();for(let i=0;i<n;i++){const l=locator.nth(i);if(await l.isVisible().catch(()=>false))return l;}return null;};
 const scope=()=>page.locator('main.page-frame, main').first();
 const expandFirst=async()=>{const l=await firstVisible(scope().locator('summary, button[aria-expanded="false"]'));if(!l)throw Error('nothing expandable');const label=(await l.innerText().catch(()=>'')).trim().replace(/\s+/g,' ').slice(0,60);await l.scrollIntoViewIfNeeded();await l.click();await page.waitForTimeout(600);return {expanded:label};};

 // ---------- Focus: Tab 1..8, shots after 3 and 8 ----------
 for(const route of ['/app','/app/schedule','/app/my-pay','/app/requests?tab=new']){
  const slug=route.replace(/^\/app\/?/,'').replace(/[^a-z0-9]+/gi,'-').replace(/-$/,'')||'home';
  await step('focus-'+slug,async()=>{await go(route);await page.evaluate(()=>{(document.activeElement as HTMLElement|null)?.blur?.();window.scrollTo(0,0);});
   const steps:unknown[]=[];
   for(let i=1;i<=8;i++){await page.keyboard.press('Tab');await page.waitForTimeout(150);
    steps.push(await page.evaluate(()=>{const e=document.activeElement as HTMLElement|null;if(!e||e===document.body)return null;const cs=getComputedStyle(e);const r=e.getBoundingClientRect();
     return {tag:e.tagName.toLowerCase(),cls:[...e.classList].slice(0,4).join('.'),text:(e.getAttribute('aria-label')||e.textContent||'').trim().replace(/\s+/g,' ').slice(0,50),rect:[Math.round(r.left),Math.round(r.top),Math.round(r.width),Math.round(r.height)],outline:`${cs.outlineStyle} ${cs.outlineWidth} ${cs.outlineColor} offset ${cs.outlineOffset}`,shadow:cs.boxShadow.slice(0,90)};}));
    if(i===3||i===8){await page.screenshot({path:`${evidence}/state-focus-${slug}-${i}-390.png`,fullPage:false});shots.push(`state-focus-${slug}-${i}-390`);}}
   return {focus:steps};});
 }

 // ---------- Viewport variants: landscape phone and tablet ----------
 for(const [suffix,viewport] of [['844x390',{width:844,height:390}],['900',{width:900,height:1200}]] as const){
  const v=await mk({viewport});
  for(const route of ['/app','/app/schedule','/app/my-time','/app/requests/hub','/app/more']){
   const slug=route.replace(/^\/app\/?/,'').replace(/[^a-z0-9]+/gi,'-').replace(/-$/,'')||'home';
   await step(`viewport-${slug}-${suffix}`,async()=>{await v.page.goto(appUrl+route);await v.page.waitForLoadState('networkidle',{timeout:8000}).catch(()=>{});await v.page.waitForTimeout(1800);
    const check=await v.page.evaluate(()=>({overflow:document.documentElement.scrollWidth-innerWidth,bScreen:!!document.querySelector('.b-screen')&&getComputedStyle(document.querySelector('.b-screen')!).display!=='none',h1:[...document.querySelectorAll('h1')].filter(h=>h.getClientRects().length).map(h=>h.textContent?.trim()).slice(0,3)}));
    await snap(slug,v.page,suffix);return check;});
  }
  await v.ctx.close();
 }

 // ---------- Loading and offline ----------
 await step('loading-my-time',async()=>{await page.goto(appUrl+'/app/my-time',{waitUntil:'commit'});await page.screenshot({path:`${evidence}/state-loading-my-time-390.png`,fullPage:false});shots.push('state-loading-my-time-390');
  await page.waitForTimeout(250);await page.screenshot({path:`${evidence}/state-loading-my-time-250ms-390.png`,fullPage:false});shots.push('state-loading-my-time-250ms-390');await settle();});
 for(const route of ['/app/my-pay','/app']){
  const slug=route.replace(/^\/app\/?/,'').replace(/[^a-z0-9]+/gi,'-').replace(/-$/,'')||'home';
  await step('offline-'+slug,async()=>{await go(route);await ctx.setOffline(true);await page.waitForTimeout(1500);
   // The app renews private reads when the person returns (window focus); offline, that renewal fails.
   await page.evaluate(()=>{window.dispatchEvent(new Event('offline'));window.dispatchEvent(new Event('focus'));document.dispatchEvent(new Event('visibilitychange'));});await page.waitForTimeout(3500);
   await snap('offline-'+slug);
   const text=await page.evaluate(()=>[...document.querySelectorAll('[role="status"],[role="alert"]')].map(e=>(e.textContent||'').trim()).filter(Boolean).slice(0,5));
   await ctx.setOffline(false);await page.waitForTimeout(500);return {statusText:text};});
 }
 await ctx.setOffline(false).catch(()=>{});

 // ---------- Interactive states that don't commit anything ----------
 await step('schedule-sheet',async()=>{await go('/app/schedule');const row=await firstVisible(page.locator('#b-my-agenda a, #b-my-agenda button'));if(!row)throw Error('no shift row');const label=(await row.innerText()).trim().replace(/\s+/g,' ').slice(0,60);await row.click();await settle(1500);await snap('schedule-sheet');return {row:label,url:page.url().replace(appUrl,'')};});
 await step('exchange-why',async()=>{await go('/app/exchange');const s=await firstVisible(page.locator('summary').filter({hasText:/Why other shifts/}));if(!s)throw Error('no Why other shifts row');await s.click();await page.waitForTimeout(700);await s.scrollIntoViewIfNeeded();await snap('exchange-why');
  return {refused:await page.locator('.eb-why__list li').allInnerTexts().then(t=>t.map(x=>x.replace(/\s+/g,' ').slice(0,140)))};});
 await step('schedule-open-why',async()=>{await go('/app/schedule?view=open');await snap('schedule-open');return {};});
 await step('requests-new-empty-send',async()=>{await go('/app/requests?tab=new');const b=await firstVisible(page.getByRole('button',{name:/^Send request|^Sending/}));if(!b)throw Error('no Send request');const disabled=await b.isDisabled();if(!disabled)await b.click();else await b.click({force:true,timeout:3000}).catch(()=>{});await page.waitForTimeout(900);await snap('requests-new-empty-send');
  return {disabled,errors:await page.locator('[role="alert"],[aria-invalid="true"], .c-field__error').allInnerTexts().then(t=>t.slice(0,6))};});
 await step('requests-new-part-day',async()=>{const b=await firstVisible(page.getByRole('button',{name:'Part of day',exact:true}));if(!b)throw Error('no Part of day');await b.click();await page.waitForTimeout(600);await snap('requests-new-part-day');return {};});
 await step('corrections-send-incomplete',async()=>{await go('/app/my-time?view=corrections&edit=new');const b=await firstVisible(page.getByRole('button',{name:/^Send/}));if(!b)throw Error('no Send button');const disabled=await b.isDisabled();if(!disabled)await b.click();else await b.click({force:true,timeout:3000}).catch(()=>{});await page.waitForTimeout(900);await snap('corrections-send-incomplete');
  return {disabled,errors:await page.locator('[role="alert"],[aria-invalid="true"]').allInnerTexts().then(t=>t.slice(0,6))};});
 await step('corrections-filled',async()=>{const filled:string[]=[];
  for(const [i,sel] of (await scope().locator('select:visible').all()).entries()){const opts=await sel.locator('option').evaluateAll((o:HTMLOptionElement[])=>o.filter(x=>x.value&&!x.disabled).map(x=>x.value));if(opts.length){const v=i===0?opts[0]:opts[opts.length-1];await sel.selectOption(v);filled.push('select='+v);await page.waitForTimeout(400);}}
  for(const chip of (await scope().locator('[role="radio"]:visible, input[type="radio"]:visible').all()).slice(0,1)){await chip.click().catch(()=>{});filled.push('radio');}
  const today=new Date(Date.now()-4*3600000).toISOString().slice(0,10);
  for(const d of await scope().locator('input[type="date"]:visible').all()){if(!(await d.inputValue())){await d.fill(today);filled.push('date');}}
  const times=await scope().locator('input[type="time"]:visible, input[placeholder="Choose"]:visible').all();for(const [i,t] of times.entries()){if(!(await t.inputValue())){const typed=await t.getAttribute('type')==='time';await t.fill(i%2?(typed?'17:00':'5:00 PM'):(typed?'09:00':'9:00 AM'));await t.blur().catch(()=>{});filled.push('time');}}
  for(const t of await scope().locator('textarea:visible').all()){if(!(await t.inputValue())){await t.fill('Forgot to clock in at the front counter');filled.push('reason');}}
  await page.evaluate(()=>window.scrollTo(0,0));await page.waitForTimeout(600);await snap('corrections-filled');return {filled};});
 await step('account-delete-armed',async()=>{await go('/app/account/delete');const pw=await firstVisible(page.locator('input[type="password"]'));if(!pw)throw Error('no password field');await pw.fill(TEST_PASSWORD);const box=await firstVisible(page.locator('input[type="checkbox"]'));if(box)await box.check({force:true});else{const l=await firstVisible(page.getByText(/I understand/));await l?.click();}
  await page.waitForTimeout(500);await snap('account-delete-armed');return {armed:await page.locator('[data-armed]').count()};});
 await step('privacy-expanded',async()=>{await go('/app/profile/privacy');const r=await expandFirst();await snap('privacy-expanded');return r;});
 await step('calendar-provider',async()=>{await go('/app/profile/calendar');const b=await firstVisible(page.locator('button.eb-expand[aria-expanded="false"]'));let r:unknown;if(b){r={expanded:(await b.innerText()).trim().slice(0,40)};await b.click();await page.waitForTimeout(600);}else r=await expandFirst();await snap('calendar-provider');return r;});
 await step('help-expanded',async()=>{await go('/app/help');const r=await expandFirst();await snap('help-expanded');return r;});
 await step('updates-detail',async()=>{await go('/app/updates');const row=await firstVisible(scope().locator('a.b-row, a[href*="/app/updates/"], a[href*="communication"]'));if(!row)throw Error('no update row');await row.click();await settle(1500);await page.waitForFunction(()=>!/Checking your current/.test(document.body.innerText),undefined,{timeout:15000}).catch(()=>{});await page.waitForTimeout(800);await snap('updates-detail');return {url:page.url().replace(appUrl,'')};});

 // ---------- States that commit (disposable database): confirm the week, pick up a shift ----------
 await step('schedule-confirm',async()=>{await go('/app/schedule');const card=page.locator('#b-my-review');if(!(await card.count())||!(await card.isVisible().catch(()=>false)))return {note:'no confirmation pending on this week'};
  await snap('schedule-confirm-before');const b=await firstVisible(card.locator('button'));if(!b)throw Error('no confirm button');const label=(await b.innerText()).trim();await b.click();await page.waitForTimeout(400);await page.screenshot({path:`${evidence}/state-schedule-confirm-pending-390.png`,fullPage:false});shots.push('state-schedule-confirm-pending-390');await settle(1500);await snap('schedule-confirm-after');return {pressed:label};});
 await step('exchange-pickup',async()=>{await go('/app/exchange');const b=await firstVisible(page.getByRole('button',{name:/^Pick up/}));if(!b)throw Error('no Pick up button');const label=await b.getAttribute('aria-label')??await b.innerText();await b.scrollIntoViewIfNeeded();await b.click();await page.waitForTimeout(250);
  await page.screenshot({path:`${evidence}/state-exchange-pickup-pending-390.png`,fullPage:false});shots.push('state-exchange-pickup-pending-390');await settle(2500);await snap('exchange-pickup-result');
  return {tapped:label,status:await page.locator('[role="status"],[role="alert"]').allInnerTexts().then(t=>t.map(x=>x.replace(/\s+/g,' ').slice(0,140)).filter(Boolean).slice(0,5))};});
 await ctx.close();
 log.push({stateShots:shots});
}
