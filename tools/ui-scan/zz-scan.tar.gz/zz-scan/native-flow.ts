// The NEVORA phone app's screens (NEVORA_SCAN_UA=native-ios|native-android). The native bridge is simulated in the page
// the way native/capability-ui/main.tsx does: fictional replies only, no provider or device calls. The app's
// /api/mobile/v1/notifications/* reads are answered by Playwright routes from the same scenario.
/* eslint-disable @typescript-eslint/no-explicit-any */
const G='11111111-1111-4111-8111-111111111111';
export function nativeUserAgent(kind:string|undefined){
 if(kind==='native-ios')return 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 NEVORA-Native/iOS/1';
 if(kind==='native-android')return 'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Mobile Safari/537.36 NEVORA-Native/Android/1';
 return null;
}
let scenario='ready';
export async function installNativeBridge(context:any,page:any){
 await context.addInitScript(()=>{
  const sc=sessionStorage.getItem('nv-native-scenario')||'ready',G='11111111-1111-4111-8111-111111111111',nonce='aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa';
  const port:any={postMessage(raw:string){const m=JSON.parse(raw);if(sc==='loading')return;
   let r:any={state:'unavailable'};
   if(m.method==='hello'&&sc!=='error')r={state:'ready',nonce,platform:'ios',spki:'fictional-public-key',keyFingerprint:'a'.repeat(64),permission:sc==='denied'?'denied':'granted',generation:sc==='enabled'?G:null,revision:sc==='enabled'||sc==='revoked'?G:null};
   queueMicrotask(()=>port.onmessage?.({data:JSON.stringify({...r,version:1,id:m.id})}));}};
  Object.assign(window,{nevoraCapabilities:port});
 });
 await page.route('**/api/mobile/v1/notifications/*',(r:any)=>r.fulfill({status:200,contentType:'application/json',body:JSON.stringify(scenario==='enabled'||scenario==='revoked'?{state:'active',generation:G}:{state:'off'})}));
}
async function setScenario(page:any,url:string,name:string){scenario=name;await page.goto(url);await page.evaluate((n:string)=>sessionStorage.setItem('nv-native-scenario',n),name);await page.reload();await page.waitForLoadState('networkidle').catch(()=>{});await page.waitForTimeout(1500);}
const visible=(page:any,sel:string)=>page.locator(sel).filter({visible:true}).first();
export async function runNativeFlow(page:any,appUrl:string,evidence:string,log:unknown[]){
 const widths=(process.env.NEVORA_SCAN_NATIVE_W??'390,900,1440').split(',').map(Number);
 const shot=async(name:string)=>{for(const w of widths){await page.setViewportSize({width:w,height:w>1000?900:w>=768?1024:844});await page.waitForTimeout(500);
  const info=await page.evaluate(()=>({over:document.documentElement.scrollWidth-innerWidth,h:[...document.querySelectorAll('[data-native-status]')].filter(e=>(e as HTMLElement).getClientRects().length).map(e=>e.textContent),focus:(document.activeElement as HTMLElement|null)?.getAttribute('aria-label')||document.activeElement?.tagName}));
  log.push({native:name,width:w,...info});await page.screenshot({path:`${evidence}/native-${name}-${w}.png`,fullPage:true});}};
 const url=appUrl+'/app/profile/device-alerts';
 for(const sc of ['ready','enabled','denied','revoked','error','loading']){try{await setScenario(page,url,sc);await shot(sc);}catch(e){log.push({native:sc,error:String((e as Error).message).slice(0,200)});}}
 if(process.env.NEVORA_SCAN_NATIVE_ALERTS!=='1')return;
 try{await setScenario(page,url,'enabled');await page.setViewportSize({width:widths[0],height:844});await visible(page,'[data-native-review-off]').click();await page.waitForTimeout(600);await shot('confirm-turn-off');}catch(e){log.push({native:'confirm-turn-off',error:String((e as Error).message).slice(0,200)});}
 try{await setScenario(page,url,'revoked');await page.setViewportSize({width:widths[0],height:844});await visible(page,'[data-native-review-setup]').click();await page.waitForTimeout(600);await shot('confirm-use-for-account');}catch(e){log.push({native:'confirm-use-for-account',error:String((e as Error).message).slice(0,200)});}
 try{await setScenario(page,url,'ready');await page.evaluate(()=>window.dispatchEvent(new Event('blur')));await page.waitForTimeout(500);await shot('paused');}catch(e){log.push({native:'paused',error:String((e as Error).message).slice(0,200)});}
 // Keep (the confirm panel's way back) returns focus to the control that opened it.
 try{await setScenario(page,url,'enabled');await page.setViewportSize({width:widths[0],height:844});await visible(page,'[data-native-review-off]').click();await page.waitForTimeout(400);
  const opened=await page.evaluate(()=>{const e=document.activeElement as HTMLElement|null;return e?(e.getAttribute('aria-label')||e.textContent||'').slice(0,40):null;});
  await visible(page,'button:text-is("Keep current setup")').click();await page.waitForTimeout(400);
  log.push({nativeFocus:{confirmOpened:opened,afterKeep:await page.evaluate(()=>{const e=document.activeElement as HTMLElement|null;return e?(e.outerHTML.slice(0,120)):null;})}});}catch(e){log.push({native:'focus',error:String((e as Error).message).slice(0,200)});}
}
export async function runDevicePopover(page:any,appUrl:string,evidence:string,log:unknown[]){
 for(const w of (process.env.NEVORA_SCAN_POPOVER_W??'390,1440').split(',').map(Number)){
  try{scenario='ready';await page.setViewportSize({width:w,height:w>1000?900:844});await page.goto(appUrl+'/app/profile');await page.waitForLoadState('networkidle').catch(()=>{});await page.waitForTimeout(1500);
   // Open it the way a person does: the visible opener (the account menu's Device settings, or the sidebar profile).
   let how='none';
   const direct=page.locator('[popovertarget="portal-device-settings"]').filter({visible:true}).first();
   if(await direct.count()){await direct.scrollIntoViewIfNeeded();await page.screenshot({path:`${evidence}/popover-opener-${w}.png`});how='direct: '+((await direct.getAttribute('aria-label'))||(await direct.textContent())||'').trim().slice(0,40);await direct.click();}
   else{const menu=page.locator('[popovertarget="portal-account-menu"]').filter({visible:true}).first();
    if(await menu.count()){await menu.click();await page.waitForTimeout(300);const item=page.locator('[popovertarget="portal-device-settings"]').filter({visible:true}).first();how='account menu: '+String(await item.count());if(await item.count())await item.click();}}
   if(how==='none'||!(await page.locator('#portal-device-settings:popover-open').count())){await page.evaluate(()=>(document.getElementById('portal-device-settings') as any)?.showPopover());how+=' (+showPopover)';}
   await page.waitForTimeout(1200);
   const rect=await page.evaluate(()=>{const e=document.getElementById('portal-device-settings');if(!e)return null;const r=e.getBoundingClientRect();return {x:Math.round(r.x),y:Math.round(r.y),w:Math.round(r.width),h:Math.round(r.height),vw:innerWidth,vh:innerHeight};});
   log.push({popover:w,how,rect});await page.screenshot({path:`${evidence}/popover-${w}.png`});
   await page.keyboard.press('Tab');await page.waitForTimeout(150);await page.screenshot({path:`${evidence}/popover-focus-${w}.png`});await page.keyboard.press('Escape');
  }catch(e){log.push({popover:w,error:String((e as Error).message).slice(0,200)});}
 }
}
