// SCRATCH (not committed): the reduced-motion press probe (Phase 2 gap closure). With prefers-reduced-motion: reduce, hold
// the pointer down on each distinct visible control, list the transitions and animations that run on it or inside it on
// a moving property, then move the pointer away before releasing, so nothing is clicked. Fictional data only.
/* eslint-disable @typescript-eslint/no-explicit-any */
export async function pressProbe(page:any,max=45){
 const targets=await page.evaluate((max:number)=>{const seen=new Set<string>(),out:any[]=[];
  for(const e of document.querySelectorAll('a[href],button,summary,[role=button],[role=tab],label.c-btn,input[type=checkbox],input[type=radio]')){
   const r=e.getBoundingClientRect();if(r.width<4||r.height<4||r.bottom<0||r.top>innerHeight||r.right<0||r.left>innerWidth)continue;
   if((e as HTMLButtonElement).disabled)continue;const cs=getComputedStyle(e);if(cs.visibility==='hidden'||cs.pointerEvents==='none')continue;
   const key=e.tagName+'.'+[...e.classList].sort().join('.');if(seen.has(key))continue;seen.add(key);
   const id='pp'+out.length;e.setAttribute('data-pp',id);out.push({id,key:key.slice(0,80),x:r.left+r.width/2,y:r.top+r.height/2});if(out.length>=max)break;}
  return out;},max);
 const found:any[]=[];
 for(const t of targets){
  try{await page.mouse.move(t.x,t.y);await page.mouse.down();await page.waitForTimeout(40);
   const anims=await page.evaluate((id:string)=>{const e=document.querySelector(`[data-pp="${id}"]`);if(!e)return [];const MOVE=/^(transform|scale|translate|rotate|top|left|right|bottom|inset|width|height|margin|padding)/;
    return e.getAnimations({subtree:true}).filter((a:any)=>a.playState==='running').map((a:any)=>({p:a.transitionProperty||a.animationName||'?',t:(a.effect?.target as Element)?.className?.toString().slice(0,50)})).filter((a:any)=>MOVE.test(a.p)||!a.p.match(/color|opacity|shadow|background|border|outline|fill|stroke|filter/));},t.id);
   if(anims.length)found.push({control:t.key,anims});
  }catch{/* skip */}
  finally{await page.mouse.move(1,1).catch(()=>{});await page.mouse.up().catch(()=>{});}
 }
  // Switches: a press doesn't toggle, so click each distinct checkbox switch, read what runs on it and its knob, and click
  // it back (the form isn't submitted).
  const toggles=await page.evaluate(()=>{const out:any[]=[];const seen=new Set<string>();for(const e of document.querySelectorAll('input[type=checkbox],[role=switch]')){const r=e.getBoundingClientRect();if(r.width<4||r.height<4||r.top<0||r.bottom>innerHeight)continue;if((e as HTMLInputElement).disabled)continue;const key=e.tagName+'.'+[...e.classList].sort().join('.');if(seen.has(key))continue;seen.add(key);const id='pt'+out.length;e.setAttribute('data-pt',id);out.push({id,key,x:r.left+r.width/2,y:r.top+r.height/2});if(out.length>=8)break;}return out;});
  const switched:any[]=[];
  for(const t of toggles){try{await page.mouse.click(t.x,t.y);await page.waitForTimeout(30);
   const anims=await page.evaluate((id:string)=>{const e=document.querySelector(`[data-pt="${id}"]`);if(!e)return [];return e.getAnimations({subtree:true}).filter((a:any)=>a.playState==='running').map((a:any)=>a.transitionProperty||a.animationName||'?').filter((p:string)=>!/color|opacity|shadow|background|border|outline|fill|stroke|filter/.test(p));},t.id);
   switched.push({control:t.key,moving:anims});await page.waitForTimeout(250);await page.mouse.click(t.x,t.y);await page.waitForTimeout(250);}catch{/* skip */}}
 return {pressed:targets.length,moving:found,switches:switched};
}
