// SCRATCH (not committed): location-limited Manager (Daniel, OWN-DANI at loc-2) Home and Schedule captures.
// Fictional data, owned loopback Postgres and owned local app only. Every non-loopback browser request is aborted.
/* eslint-disable @typescript-eslint/no-explicit-any */
import {readFileSync,mkdirSync,writeFileSync} from 'node:fs';
import {TEST_PASSWORD} from '../src/test/integration/owned-app-fixture';
import {addDays} from '../src/lib/date-utils';

const measureSrc=()=>readFileSync('zz-scan/measure.js','utf8');
const axeSrc=()=>readFileSync('node_modules/axe-core/axe.min.js','utf8');
const settle=(p:any)=>p.waitForLoadState('networkidle',{timeout:8000}).catch(()=>{});
const guard=async(ctx:any,allowed:string[],log:unknown[])=>{await ctx.route('**/*',async(r:any)=>{let o='';try{o=new URL(r.request().url()).origin;}catch{/* data: */}
 if(o&&o!=='null'&&!allowed.includes(o)&&/^https?:/.test(o)){log.push({blocked:o});await r.abort('blockedbyclient');return;}await r.fallback();});};

type Cfg={tag:string;w:number;h:number;text200:boolean};
const ALL_CFGS:Cfg[]=[{tag:'320',w:320,h:700,text200:false},{tag:'390',w:390,h:844,text200:false},{tag:'390-text200',w:390,h:844,text200:true},{tag:'768',w:768,h:1024,text200:false},{tag:'1440',w:1440,h:1000,text200:false}];

/** Text that is clipped by an overflow ancestor, or text boxes that overlap another text box (different nodes). */
const geometry=()=>{
 const root=document.querySelector('main')||document.body;const vw=innerWidth;
 const shell='.mobile-nav, .sidebar, .mobile-header, .section-tabs, .portal-skip-link, nextjs-portal, script, style, noscript, template';
 const vis=(e:Element)=>{const r=e.getBoundingClientRect();return r.width>0&&r.height>0&&(e as any).checkVisibility?.({opacityProperty:true,visibilityProperty:true})!==false;};
 const srOnly=(e:Element)=>{const r=e.getBoundingClientRect();const cs=getComputedStyle(e);return (r.width<=2&&r.height<=2)||cs.clipPath==='inset(50%)'||cs.clip==='rect(0px, 0px, 0px, 0px)'||!!e.closest('.sr-only, .c-sr, .q-sr, .visually-hidden');};
 const desc=(e:Element)=>(e.tagName.toLowerCase()+'.'+[...e.classList].slice(0,2).join('.')).slice(0,48);
 const tw=document.createTreeWalker(root,NodeFilter.SHOW_TEXT);let n:Node|null;const boxes:{t:string;el:Element;r:DOMRect}[]=[];const clipped:string[]=[];const offscreen:string[]=[];
 while((n=tw.nextNode())){const t=(n.textContent||'').trim();if(!t)continue;const p=n.parentElement;if(!p||p.closest(shell)||!vis(p)||srOnly(p))continue;
  const range=document.createRange();range.selectNodeContents(n);const rects=[...range.getClientRects()].filter(r=>r.width>1&&r.height>1);
  for(const r of rects){boxes.push({t:t.slice(0,40),el:p,r});if(r.right>vw+0.5||r.left<-0.5)offscreen.push(t.slice(0,40)+' r='+Math.round(r.right));}
  // Clipped by an ancestor with overflow hidden/clip, or ellipsis on the element itself.
  for(let a:Element|null=p;a&&a!==document.body;a=a.parentElement){const cs=getComputedStyle(a);
   const hx=cs.overflowX!=='visible',hy=cs.overflowY!=='visible';if(!hx&&!hy)continue;const ar=a.getBoundingClientRect();
   if(hx&&cs.overflowX!=='auto'&&cs.overflowX!=='scroll'&&rects.some(r=>r.right>ar.right+1||r.left<ar.left-1)){clipped.push(desc(a)+' x: '+t.slice(0,40));break;}
   if(hy&&cs.overflowY!=='auto'&&cs.overflowY!=='scroll'&&rects.some(r=>r.bottom>ar.bottom+1||r.top<ar.top-1)){clipped.push(desc(a)+' y: '+t.slice(0,40));break;}
   if(cs.overflowX==='auto'||cs.overflowX==='scroll'||cs.overflowY==='auto'||cs.overflowY==='scroll')break;}
  if(getComputedStyle(p).textOverflow==='ellipsis'&&p.scrollWidth>p.clientWidth+1)clipped.push(desc(p)+' ellipsis: '+t.slice(0,40));
 }
 const overlaps:string[]=[];
 for(let i=0;i<boxes.length&&overlaps.length<12;i++)for(let j=i+1;j<boxes.length;j++){const a=boxes[i],b=boxes[j];if(a.el===b.el)continue;
  const ix=Math.min(a.r.right,b.r.right)-Math.max(a.r.left,b.r.left),iy=Math.min(a.r.bottom,b.r.bottom)-Math.max(a.r.top,b.r.top);
  if(ix>2&&iy>Math.min(a.r.height,b.r.height)*0.3){overlaps.push(`"${a.t}" × "${b.t}" (${Math.round(ix)}x${Math.round(iy)})`);if(overlaps.length>=12)break;}}
 // Controls whose own box is smaller than its text (text spills out of a button/link).
 const spill=[...root.querySelectorAll('a, button, [role=button], summary, label')].filter(e=>vis(e)&&!srOnly(e)&&!e.closest(shell)).filter(e=>{const cs=getComputedStyle(e);if(cs.display==='inline')return false;return e.scrollHeight>e.clientHeight+2&&cs.overflowY==='visible';}).slice(0,8).map(e=>desc(e)+' '+(e.textContent||'').trim().slice(0,30));
 // Width use: the page column, and the widest card.
 const page=document.querySelector('.page-frame .c-page, main .c-page');const pr=page?.getBoundingClientRect();const mr=root.getBoundingClientRect();
 const cards=[...root.querySelectorAll('.c-card, section, [class*=card]')].filter(vis).map(e=>Math.round(e.getBoundingClientRect().width));
 const sizes:Record<string,number>={};for(const b of boxes){const fs=getComputedStyle(b.el).fontSize;sizes[fs]=(sizes[fs]||0)+1;}
 return {docOverflow:document.documentElement.scrollWidth-vw,clipped:[...new Set(clipped)].slice(0,12),overlaps,offscreen:[...new Set(offscreen)].slice(0,8),spill,
  layout:{vw,main:[Math.round(mr.left),Math.round(mr.width)],page:pr?[Math.round(pr.left),Math.round(pr.width)]:null,widestCard:cards.length?Math.max(...cards):null,cardWidths:[...new Set(cards)].slice(0,8)},
  fontSizes:sizes,mainText:((root as HTMLElement).innerText||'').trim().replace(/\n{2,}/g,'\n').slice(0,1600)};
};

const CFGS=()=>ALL_CFGS.filter(c=>!process.env.NEVORA_MGR_TAGS||process.env.NEVORA_MGR_TAGS.split(',').includes(c.tag));
export async function runMgr(browser:any,appUrl:string,log:unknown[],o:{week:string;grant:()=>Promise<void>}){
 const out=process.env.NEVORA_MGR_OUT!;mkdirSync(out,{recursive:true});
 const rec:any[]=[];const save=()=>writeFileSync(out+'/mgr-log.json',JSON.stringify({rec,log:log.filter((x:any)=>x&&typeof x==='object'&&('mgr' in x||'blocked' in x||'mgrError' in x))},null,2));
 const nextWeek=addDays(o.week,7);
 const pages:Record<string,any>={};
 const open=async(c:Cfg)=>{
  if(pages[c.tag])return pages[c.tag];
  const phone=c.w<1000;
  const ctx=await browser.newContext({viewport:{width:c.w,height:c.h},deviceScaleFactor:phone?2:1,isMobile:c.w<600,hasTouch:phone,reducedMotion:'reduce',serviceWorkers:'block'});
  await guard(ctx,[appUrl],log);const p=await ctx.newPage();p.setDefaultTimeout(20000);
  p.on('pageerror',(e:Error)=>log.push({mgr:'pageerror',tag:c.tag,msg:e.message.slice(0,300)}));
  p.on('console',(m:any)=>{if(m.type()==='error')log.push({mgr:'console',tag:c.tag,msg:m.text().slice(0,300)});});
  await p.goto(appUrl+'/login');await p.getByLabel('Employee ID',{exact:true}).fill('OWN-DANI');await p.getByLabel('Password',{exact:true}).fill(TEST_PASSWORD);
  await p.getByRole('button',{name:'Sign in',exact:true}).click();await p.waitForURL((u:URL)=>u.pathname.startsWith('/app'),{timeout:30000});await settle(p);
  pages[c.tag]=p;return p;
 };
 const focusWalk=async(p:any)=>{
  await p.evaluate(()=>{(document.activeElement as HTMLElement|null)?.blur();window.scrollTo(0,0);});
  const steps:any[]=[];
  for(let i=1;i<=40;i++){await p.keyboard.press('Tab');await p.waitForTimeout(80);
   const s=await p.evaluate(()=>{const e=document.activeElement as HTMLElement|null;if(!e||e===document.body)return null;const cs=getComputedStyle(e);const r=e.getBoundingClientRect();
    return {el:(e.tagName.toLowerCase()+'.'+[...e.classList].slice(0,2).join('.')).slice(0,50),txt:(e.getAttribute('aria-label')||e.textContent||'').trim().replace(/\s+/g,' ').slice(0,50),inMain:!!e.closest('main'),
     ring:cs.outlineStyle!=='none'&&parseFloat(cs.outlineWidth)>0?`outline ${cs.outlineWidth} ${cs.outlineColor}`:(cs.boxShadow!=='none'?'shadow':'none'),r:[Math.round(r.left),Math.round(r.top+scrollY),Math.round(r.width),Math.round(r.height)]};});
   if(steps.length>2&&s&&steps[0]&&s.el===steps[0].el&&s.txt===steps[0].txt)break;
   steps.push(s);}
  return steps;
 };
 const axe=async(p:any)=>{await p.evaluate(axeSrc());
  return p.evaluate(async()=>{const r=await (window as any).axe.run(document,{resultTypes:['violations']});
   return r.violations.map((v:any)=>({id:v.id,impact:v.impact,help:v.help,nodes:v.nodes.length,targets:v.nodes.slice(0,4).map((n:any)=>({t:String(n.target).slice(0,90),inMain:!!document.querySelector(String(n.target[0]))?.closest('main'),summary:(n.failureSummary||'').slice(0,200)}))}));});};
 const capture=async(screen:string,url:string)=>{
  for(const c of CFGS()){
   try{const p=await open(c);
    await p.goto(appUrl+url);await settle(p);await p.waitForTimeout(1500);
    if(c.text200){await p.evaluate(()=>{document.documentElement.style.fontSize='200%';});await p.waitForTimeout(400);}
    const m=await p.evaluate(new Function('return ('+measureSrc()+')()') as ()=>unknown).catch((e:unknown)=>({error:String(e).slice(0,200)}));
    const g=await p.evaluate(geometry).catch((e:unknown)=>({error:String(e).slice(0,300)}));
    const a=await axe(p).catch((e:unknown)=>[{error:String(e).slice(0,200)}]);
    const rootFs=async()=>p.evaluate(()=>getComputedStyle(document.documentElement).fontSize+'/'+getComputedStyle(document.querySelector('main')||document.body).fontSize);
    const fsBefore=await rootFs();
    await p.screenshot({path:`${out}/${screen}-${c.tag}.png`,fullPage:true});
    const fsAfter=await rootFs();
    const focus=(c.tag==='390'||c.tag==='1440')?await focusWalk(p):null;
    rec.push({screen,tag:c.tag,fsBefore,fsAfter,url:p.url().replace(appUrl,''),m,g,axe:a,focus});save();
   }catch(e){log.push({mgrError:screen+' '+c.tag,e:String((e as Error).message).slice(0,400)});save();}
  }
 };
 log.push({mgr:'start',week:o.week,nextWeek});
 await capture('home','/app');
 await capture('schedule','/app/schedule');
 await capture('schedule-next',`/app/schedule?week=${nextWeek}`);
 try{await o.grant();log.push({mgr:'granted PUBLISH_SCHEDULE'});}catch(e){log.push({mgrError:'grant',e:String((e as Error).stack??e).slice(0,500)});}
 await capture('schedule-publish','/app/schedule');
 for(const p of Object.values(pages))await p.context().close().catch(()=>{});
 save();
}
