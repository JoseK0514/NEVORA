// SCRATCH (not committed): fill-in sweep (fill-a). Fictional data, owned loopback Postgres and owned local fixtures only.
// No email, SMS, payment or AI provider is reached: every non-loopback request from these browsers is aborted.
/* eslint-disable @typescript-eslint/no-explicit-any */
import {readFileSync} from 'node:fs';
import {randomBytes} from 'node:crypto';
import {TEST_PASSWORD} from '../src/test/integration/owned-app-fixture';
import {setEmployeeClockerPin} from '../src/lib/clocker/pins.server';
import {fixtureProof} from '../src/test/integration/shift-change-api';

const measureSrc=()=>readFileSync('zz-scan/measure.js','utf8');
export const measure=async(page:any)=>page.evaluate(new Function('return ('+measureSrc()+')()') as ()=>unknown).catch((e:unknown)=>({error:String(e).slice(0,200)}));
type Rec={row:string;name:string;route:string;profile:string;lang:string;kind:string;note?:string};
/** One capture per width: viewport, settle, measure, full-page and fold screenshots. */
export async function cap(page:any,evidence:string,log:unknown[],rec:Rec,widths:number[]){
 for(const w of widths){
  await page.setViewportSize({width:w,height:w>1000?900:844});await page.waitForTimeout(700);
  const base=`${evidence}/fill-${rec.row}-${rec.name}-${rec.lang}-${w}`;
  const m=await measure(page);
  log.push({sweep:'fill',...rec,width:w,url:page.url(),shot:base+'.png',fold:base+'-fold.png',m});
  await page.screenshot({path:base+'-fold.png',fullPage:false});await page.screenshot({path:base+'.png',fullPage:true});
 }
}
const guard=async(ctx:any,allowed:string[],log:unknown[])=>{await ctx.route('**/*',async(r:any)=>{let o='';try{o=new URL(r.request().url()).origin;}catch{/* data: etc */}
 if(o&&o!=='null'&&!allowed.includes(o)&&/^https?:/.test(o)){log.push({blocked:o});await r.abort('blockedbyclient');return;}await r.fallback();});};
const settle=(p:any)=>p.waitForLoadState('networkidle',{timeout:8000}).catch(()=>{});
const step=async(log:unknown[],name:string,fn:()=>Promise<void>)=>{try{await fn();}catch(e){log.push({fillError:name,e:String((e as Error).message).slice(0,400)});}};
const W=()=>(process.env.NEVORA_FILL_W??'390,1440').split(',').map(Number);

/** A10 Activate business with a well-formed fictional link (#proof=…), in English and Spanish. */
export async function runFillActivate(browser:any,appUrl:string,evidence:string,log:unknown[]){
 const proof=Buffer.alloc(32,11).toString('base64url');
 for(const lang of ['en','es']){
  const ctx=await browser.newContext({viewport:{width:1440,height:900},deviceScaleFactor:1,reducedMotion:'reduce',serviceWorkers:'block'});
  await guard(ctx,[appUrl],log);await ctx.addCookies([{name:'nv-lang',value:lang,url:appUrl}]);
  const p=await ctx.newPage();p.setDefaultTimeout(15000);p.on('pageerror',(e:Error)=>log.push('fill pageerror '+e.message.slice(0,200)));
  const base={row:'A10',route:'/onboarding/activate',profile:'public',lang,kind:'public'};
  await step(log,'a10 ready '+lang,async()=>{await p.goto('about:blank');await p.goto(appUrl+'/onboarding/activate#proof='+proof);await settle(p);await p.locator('#activation-password').waitFor();await p.waitForTimeout(600);
   await cap(p,evidence,log,{...base,name:'link-ready',note:'well-formed fictional #proof link: the password form'},W());});
  await step(log,'a10 mismatch '+lang,async()=>{await p.locator('#activation-password').fill('Fictional-Pass-2026!');await p.locator('#activation-confirm-password').fill('Fictional-Pass-2027!');
   await p.locator('form button[type="submit"]').click();await p.waitForTimeout(700);await cap(p,evidence,log,{...base,name:'link-mismatch',note:'passwords differ (client check)'},W());});
  await step(log,'a10 submitted '+lang,async()=>{await p.locator('#activation-password').fill('Fictional-Pass-2026!');await p.locator('#activation-confirm-password').fill('Fictional-Pass-2026!');
   await p.locator('form button[type="submit"]').click();await p.waitForTimeout(2500);await settle(p);
   await cap(p,evidence,log,{...base,name:'link-server-refused',note:'submitted: this build has no onboarding control service, so the server answer is the real refusal'},W());});
  await step(log,'a10 invalid '+lang,async()=>{await p.goto('about:blank');await p.goto(appUrl+'/onboarding/activate#proof=not-a-real-proof');await settle(p);await p.waitForTimeout(900);
   await cap(p,evidence,log,{...base,name:'bad-link',note:'malformed link fragment'},W());});
  await ctx.close();
 }
}

/** F8 Clocker PIN (Owner) with a fictional local PIN key: set (no PIN), mismatch, saved, reset (PIN already set). */
export async function runFillPin(page:any,appUrl:string,evidence:string,log:unknown[],ex:any,actors:string[]){
 const owner=await fixtureProof(ex,'QAOWNER');const proof={employeeId:'QAOWNER',sessionTokenHash:owner.sessionTokenHash};
 await setEmployeeClockerPin(proof,{employeeId:actors[1],pin:'2468',expectedVersion:0},Buffer.from('ab'.repeat(32),'hex'),ex).catch((e:unknown)=>log.push('fill pin preset '+String(e)));
 const go=async(id:string)=>{await page.goto(appUrl+'/app/employees/'+encodeURIComponent(id)+'/clocker-pin');await settle(page);await page.waitForTimeout(1500);};
 const base={row:'F8',route:'/app/employees/[employeeId]/clocker-pin',profile:'O',lang:'en',kind:'route'};
 await step(log,'f8 set',async()=>{await go(actors[0]);await cap(page,evidence,log,{...base,name:'set-no-pin',note:'Maria has no PIN yet'},W());});
 await step(log,'f8 mismatch',async()=>{await page.locator('#new-clocker-pin').fill('4826');await page.locator('#confirm-clocker-pin').fill('4827');await page.locator('#clocker-pin-form button[type="submit"]').click();await page.waitForTimeout(1200);
  await cap(page,evidence,log,{...base,name:'mismatch',note:'the two PINs differ'},W());});
 await step(log,'f8 saved',async()=>{await go(actors[0]);await page.locator('#new-clocker-pin').fill('4826');await page.locator('#confirm-clocker-pin').fill('4826');await page.locator('#clocker-pin-form button[type="submit"]').click();await page.waitForTimeout(2500);await settle(page);
  await cap(page,evidence,log,{...base,name:'saved',note:'after Save PIN'},W());});
 await step(log,'f8 reset',async()=>{await go(actors[1]);await cap(page,evidence,log,{...base,name:'reset-has-pin',note:'James already has a PIN'},W());});
 await step(log,'j17 pins',async()=>{await page.goto(appUrl+'/app/settings/clocker/pins');await settle(page);await page.waitForTimeout(1500);
  await cap(page,evidence,log,{row:'J17',route:'/app/settings/clocker/pins',profile:'O',lang:'en',kind:'route',name:'pins-with-key',note:'with the Clocker PIN key set'},W());});
}

/** A15–A19 with the owned central billing fixture (local Stripe stand-in, no provider request) in several plan states. */
export async function runFillBilling(browser:any,appUrl:string,evidence:string,log:unknown[],fixture:any){
 await fixture.pool.query("UPDATE commerce.accounts SET profile=$1",[{businessName:'Northside Bakery',email:'central-owner@example.invalid'}]).catch((e:unknown)=>log.push('fill rename '+String(e)));
 const ctx=await browser.newContext({viewport:{width:1440,height:900},deviceScaleFactor:1,reducedMotion:'reduce',serviceWorkers:'block'});
 await guard(ctx,[appUrl,fixture.apiOrigin],log);
 const p=await ctx.newPage();p.setDefaultTimeout(15000);p.on('pageerror',(e:Error)=>log.push('fill pageerror '+e.message.slice(0,200)));
 const name='Northside Bakery';
 const open=async(route:string)=>{await p.goto(appUrl+route+'#handoff='+await fixture.handoff());await p.getByRole('heading',{name,exact:true}).waitFor({timeout:20000}).catch(async()=>{log.push({fillWarn:'no business heading on '+route,h1:await p.locator('h1,h2').allInnerTexts().catch(()=>[])});});await settle(p);await p.waitForTimeout(800);};
 const lang=async(l:string)=>{const b=p.getByRole('button',{name:l==='en'?'English':'Español',exact:true});if(await b.count()&&await b.isEnabled()){await b.click();await p.waitForTimeout(800);}};
 const refresh=async()=>{const b=p.getByRole('button',{name:/^(Refresh status|Actualizar estado)$/});if(await b.count()){await b.first().click();await p.waitForTimeout(1800);await settle(p);}};
 const both=async(row:string,route:string,state:string,note:string)=>{for(const l of ['en','es']){await lang(l);await cap(p,evidence,log,{row,route,profile:'public (Owner handoff)',lang:l,kind:'billing',name:state,note},W());}await lang('en');};
 await step(log,'a15 trial',async()=>{await open('/pages/plans');await both('A15','/pages/plans','trial','trial, no plan chosen yet (fixture: 30-day trial, 4 people)');});
 for(const [s,note] of [['active','Small plan, active subscription'],['past_due','payment past due'],['canceled','subscription canceled, paid through a date']] as const)
  await step(log,'a15 '+s,async()=>{await fixture.subscriptionScenario(s);await refresh();await both('A15','/pages/plans',s,note);});
 await step(log,'a15 unknown',async()=>{await fixture.subscriptionScenario('unknown-provider-state');await refresh();await cap(p,evidence,log,{row:'A15',route:'/pages/plans',profile:'public (Owner handoff)',lang:'en',kind:'billing',name:'provider-unknown',note:'provider state the service does not recognise'},W());});
 await fixture.subscriptionScenario('active').catch(()=>{});
 for(const [row,route,l] of [['A16','/pages/nevora-billing','en'],['A17','/pages/nevora-billing-return','en'],['A18','/pages/es-facturacion','es'],['A19','/pages/es-pago','es']] as const)
  await step(log,row,async()=>{await open(route);await cap(p,evidence,log,{row,route,profile:'public (Owner handoff)',lang:l,kind:'billing',name:'active',note:'fresh handoff, Small plan active'},W());});
 // No handoff (what a direct visit shows), once per row for comparison.
 for(const [row,route,l] of [['A17','/pages/nevora-billing-return','en']] as const)
  await step(log,row+' nohandoff',async()=>{await p.goto(appUrl+route);await settle(p);await p.waitForTimeout(900);await cap(p,evidence,log,{row,route,profile:'public',lang:l,kind:'billing',name:'no-handoff',note:'opened without a handoff'},W());});
 await ctx.close();
}

/** J18 Billing (Owner) on the recovery frame, with fictional status replies for presentation (as
 * commerce-recovery-browser.integration.ts does): the page's own status read is answered in the browser. */
export async function runFillJ18(page:any,appUrl:string,evidence:string,log:unknown[]){
 const day=86400000,iso=(ms:number)=>new Date(Date.now()+ms).toISOString().replace(/\.\d{3}Z$/,'.000Z');
 const base={trialEndsAt:null,paidThrough:null,graceEndsAt:null,plan:'small',employeeLimit:15,activeEmployees:4,billing:true,export:true,observedAt:new Date().toISOString(),validForMs:15000};
 const states:Record<string,unknown>={
  'trial':{...base,state:'trial',operational:true,trialEndsAt:iso(12*day),plan:null,reason:null},
  'trial-ended':{...base,state:'restricted',operational:false,trialEndsAt:iso(-2*day),plan:null,reason:'trial_ended'},
  'payment-failed-grace':{...base,state:'grace',operational:true,paidThrough:iso(-1*day),graceEndsAt:iso(6*day),reason:'payment_failed'},
  'over-limit':{...base,state:'restricted',operational:false,paidThrough:iso(20*day),activeEmployees:18,reason:'employee_limit_exceeded'},
  'paid':{...base,state:'paid',operational:true,paidThrough:iso(24*day),plan:'team',employeeLimit:30,activeEmployees:9,reason:null},
 };
 let mode='actual';
 await page.route('**/api/commerce/status',async(r:any)=>{if(mode==='actual'){await r.fallback();return;}await r.fulfill({status:200,contentType:'application/json',body:JSON.stringify(states[mode])});});
 await page.route('**/api/commerce/handoff',(r:any)=>r.abort('blockedbyclient'));
 for(const lang of ['en','es']){
  await page.context().addCookies([{name:'nv-lang',value:lang,url:appUrl}]);
  for(const s of ['actual',...Object.keys(states)]){
   await step(log,'j18 '+lang+' '+s,async()=>{mode=s;await page.goto(appUrl+'/app/billing?reason=billing_status_unavailable');await settle(page);await page.waitForTimeout(2200);
    await cap(page,evidence,log,{row:'J18',route:'/app/billing',profile:'O',lang,kind:'route',name:s==='actual'?'unavailable':s,note:s==='actual'?'real read: no billing service in this build':'fictional status reply: '+s},W());});
  }
 }
 await page.context().addCookies([{name:'nv-lang',value:'en',url:appUrl}]);
 log.push({fillJ18Done:true});
}
export const fictionalProof=()=>randomBytes(32).toString('base64url');
export {TEST_PASSWORD};
