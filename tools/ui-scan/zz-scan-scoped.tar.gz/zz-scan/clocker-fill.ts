// SCRATCH (not committed): the Clocker screens the Nov 22 sweep could not reach (fill-a), NEVORA_FILL_CLOCKER=1.
// Fictional employees and tablets, owned loopback PostgreSQL. Lost replies, a second tablet, a second person and the
// photo policy are produced in the browser (Playwright routes, a second page, a fake camera), never by changing app code.
//   NEVORA_SCAN_CLOCKER_SIZES  default 1024x768,768x1024,390x844
//   NEVORA_SCAN_CLOCKER_LOCALE en | es
/* eslint-disable @typescript-eslint/no-explicit-any */
import {readFileSync} from 'node:fs';
import {registerClockerDevice} from '../src/lib/clocker/devices.server';
import {setEmployeeClockerPin} from '../src/lib/clocker/pins.server';
import {fixtureProof} from '../src/test/integration/shift-change-api';
import {clockerText} from '../src/components/clocker-copy';

export async function runClockerFill(browser:any,appUrl:string,ex:any,actors:string[],evidence:string,log:unknown[]){
 const measure=async(page:any)=>page.evaluate(new Function('return ('+readFileSync('zz-scan/measure.js','utf8')+')()') as ()=>unknown).catch((e:unknown)=>({error:String(e).slice(0,200)}));
 const q=(text:string,values:unknown[]=[])=>ex.query({text,values});
 const ownerSession=await fixtureProof(ex,'QAOWNER');const owner={employeeId:'QAOWNER',sessionTokenHash:ownerSession.sessionTokenHash};
 const key=Buffer.from('ab'.repeat(32),'hex');
 const locale=process.env.NEVORA_SCAN_CLOCKER_LOCALE==='es'?'es':'en';
 const N=(en:string,params?:Record<string,string|number>)=>clockerText(locale,en,params);
 await q("UPDATE locations SET clocker_key='scan-kiosk-main' WHERE id='loc-1'");
 await q("UPDATE locations SET clocker_key='scan-kiosk-west' WHERE id='loc-2'");
 const [james,ana]=[actors[1],actors[2]];
 for(const [id,pin] of [[james,'2468'],[ana,'1357']])await setEmployeeClockerPin(owner,{employeeId:id,pin,expectedVersion:0},key,ex).catch((e:unknown)=>log.push('pin '+id+' '+String(e)));
 const sizes:[number,number][]=(process.env.NEVORA_SCAN_CLOCKER_SIZES??'1024x768,768x1024,390x844').split(',').map(v=>v.split('x').map(Number) as [number,number]);
 let n=0;
 const shot=async(page:any,name:string,row:string,note='')=>{n++;const tag=String(n).padStart(2,'0')+'-'+name;
  for(const [w,h] of sizes){await page.setViewportSize({width:w,height:h});await page.waitForTimeout(350);
   log.push({sweep:'fill-clocker',row,lang:locale,screen:name,tag,size:w+'x'+h,note,url:page.url(),shot:`${evidence}/ck-${tag}-${locale}-${w}x${h}.png`,m:await measure(page)});
   await page.screenshot({path:`${evidence}/ck-${tag}-${locale}-${w}x${h}.png`});}
  await page.setViewportSize({width:sizes[0][0],height:sizes[0][1]});
  log.push({ck:tag,h1:await page.locator('h1').allInnerTexts().catch(()=>[]),alerts:await page.locator('[role=alert],[role=status]').allInnerTexts().catch(()=>[])});};
 const step=async(name:string,fn:()=>Promise<void>)=>{try{await fn();log.push({ckOk:name});}catch(e){log.push({ckError:name,e:String((e as Error).message).slice(0,400)});}};
 const prep=async(ctx:any)=>{
  if(locale==='es')await ctx.addInitScript(()=>{try{localStorage.setItem('nevora.clocker.locale','es');}catch{/* blocked */}});
  await ctx.route('**/*',async(r:any)=>{let o='';try{o=new URL(r.request().url()).origin;}catch{/* ignore */}if(/^https?:/.test(o)&&o!==appUrl){log.push({blocked:o});await r.abort('blockedbyclient');return;}await r.fallback();});};
 const fresh=async(b:any=browser,opts:any={})=>{const ctx=await b.newContext({viewport:{width:sizes[0][0],height:sizes[0][1]},deviceScaleFactor:1,reducedMotion:'no-preference',serviceWorkers:'block',...opts});
  await prep(ctx);const page=await ctx.newPage();page.setDefaultTimeout(15000);page.on('pageerror',(e:Error)=>log.push('ck pageerror '+e.message.slice(0,200)));return {ctx,page};};
 const settle=(page:any)=>page.waitForLoadState('networkidle',{timeout:8000}).catch(()=>{});
 const enroll=async(page:any,locationId:string,locationKey:string,name:string)=>{
  const pending=await registerClockerDevice(owner,{name,locationId},ex);
  await page.goto(`${appUrl}/clocker/${locationKey}`);await settle(page);await page.waitForTimeout(800);
  await page.locator('textarea[name="enrollmentToken"]').fill(pending.enrollmentToken);
  await page.locator('form button[type="submit"]').click();
  await page.locator('[data-clocker-pin="entry"]').waitFor({timeout:20000});
 };
 const idle=(page:any)=>page.waitForFunction(()=>!document.querySelector('[aria-busy="true"]'),{timeout:15000}).catch(()=>{});
 const enterPin=async(page:any,pin:string)=>{await page.locator('[data-clocker-pin="entry"]').waitFor({timeout:20000});await idle(page);await page.waitForTimeout(250);
  if(await page.locator('[data-clocker-step="id"]').count()){await page.locator('#clocker-employee-id').fill(pin==='1357'?ana:james);await page.locator('#clocker-employee-id').press('Enter');await page.locator('[data-clocker-step="pin"]').waitFor({timeout:10000});await page.waitForTimeout(300);}
  for(const d of pin)await page.locator('[data-clocker-keypad] button[data-key="digit"]').filter({hasText:new RegExp('^'+d+'$')}).click();
  await page.locator('[data-clocker-pin="entry"] button[type="submit"]').click();};
 const state=(page:any,s:string)=>page.locator(`[data-clocker-state="${s}"]`).first().waitFor({timeout:20000});
 const btn=(page:any,en:string)=>page.getByRole('button',{name:N(en),exact:true});
 const done=async(page:any)=>{const d=btn(page,'Done').first();if(await d.count())await d.click();await page.locator('[data-clocker-pin="entry"]').waitFor({timeout:20000});};
 const loseExecute=async(page:any,delay=2500)=>page.route('**/api/clocker/*/punch',async(r:any)=>{const body=r.request().postData()??'';if(body.includes('"execute"')){await new Promise(res=>setTimeout(res,delay));await r.abort().catch(()=>{});}else await r.fallback();});
 const where=async(page:any)=>log.push({where:await page.evaluate(()=>[...document.querySelectorAll('[data-clocker-state]')].map(e=>e.getAttribute('data-clocker-state'))).catch(()=>null),h1:await page.locator('h1').allInnerTexts().catch(()=>[])});

 const B=await fresh();const p=B.page;
 await step('enroll',async()=>{await enroll(p,'loc-1','scan-kiosk-main','Front counter tablet');await idle(p);});
 await step('clock in',async()=>{await enterPin(p,'2468');await state(p,'ready');await btn(p,'Clock in').click();await state(p,'success');await p.waitForTimeout(500);await done(p);});
 // K12: the clock out's reply is lost; Check if it saved finds nothing, so Send it again; then the clock-out receipt.
 await step('k12 chain',async()=>{
  await enterPin(p,'2468');await state(p,'ready');await loseExecute(p);
  await btn(p,'Clock out').click();await p.waitForTimeout(400);await btn(p,'Confirm clock out').click();
  await state(p,'recovery');await p.waitForTimeout(700);await shot(p,'check-if-it-saved','K12','reply lost: the one action is Check if it saved');
  await btn(p,'Something didn’t save?').click();await p.waitForTimeout(500);await shot(p,'saved-action-help','K12','the saved-punch help');
  await btn(p,'Back').click();await state(p,'recovery');await p.unroute('**/api/clocker/*/punch');await p.waitForTimeout(300);
  await btn(p,'Check if it saved').click();await state(p,'retry');await p.waitForTimeout(600);await shot(p,'send-it-again','K12','the check found nothing: Send it again (the retry of the same action)');
  await btn(p,'Send it again').click();await state(p,'success');await p.waitForTimeout(600);await shot(p,'receipt-clock-out','K11','clock-out receipt');
  await done(p);});
 await where(p);
 // K9: a clock in's reply is lost on this tablet, then James clocks in on another Main Office tablet.
 await step('k9 review current',async()=>{
  await enterPin(p,'2468');await state(p,'ready');await loseExecute(p,300);
  await btn(p,'Clock in').click();await state(p,'recovery');await p.unroute('**/api/clocker/*/punch');
  const C=await fresh();try{await enroll(C.page,'loc-1','scan-kiosk-main','Back office tablet');await enterPin(C.page,'2468');await state(C.page,'ready');await C.page.getByRole('button',{name:N('Clock in'),exact:true}).click();await state(C.page,'success');}finally{await C.ctx.close();}
  await btn(p,'Check if it saved').click();await p.locator('[data-clocker-state="review-current"],[data-clocker-state="auth"],[data-clocker-state="retry"],[data-clocker-state="success"]').first().waitFor({timeout:20000});await p.waitForTimeout(600);
  await where(p);await shot(p,'review-current','K9','the earlier punch is out of date (James clocked in on another tablet)');
  const see=btn(p,'See current status');if(await see.count()){await see.click();await state(p,'ready');await p.waitForTimeout(700);await shot(p,'ready-after-review','K9','after See current status');}
  await done(p);});
 await where(p);
 // K13: James's clock out is left unconfirmed; Ana enters her PIN on the same tablet (a second page of its browser);
 // James's screen then checks and finds someone else's sign-in.
 await step('k13 other person',async()=>{
  await enterPin(p,'2468');await state(p,'ready');await loseExecute(p,300);
  await btn(p,'Clock out').click();await p.waitForTimeout(300);await btn(p,'Confirm clock out').click();await state(p,'recovery');await p.unroute('**/api/clocker/*/punch');
  // Ana's PIN check on this tablet: the same request the PIN screen sends, from this tablet's browser (same cookies).
  log.push({anaVerify:await p.evaluate(async(id:string)=>{const r=await fetch('/api/clocker/scan-kiosk-main/pin',{method:'POST',credentials:'same-origin',cache:'no-store',headers:{'Content-Type':'application/json','X-Nevora-Clocker':'1'},body:JSON.stringify({action:'verify',employeeId:id,pin:'1357'})});return r.status;},ana)});
  await p.bringToFront();await btn(p,'Check if it saved').click();await p.locator('[data-clocker-state="other-person"],[data-clocker-state="auth"],[data-clocker-state="retry"],[data-clocker-state="success"]').first().waitFor({timeout:20000});await p.waitForTimeout(600);
  await where(p);await shot(p,'someone-elses-punch','K13','another person signed in on this tablet while James’s punch is unconfirmed');
  const d=btn(p,'Done').first();if(await d.count())await d.click();else{const s=btn(p,'Start over').first();if(await s.count())await s.click();}
  await p.locator('[data-clocker-pin="entry"]').waitFor({timeout:20000});});
 // Settle James's saved clock out so the next steps start clean.
 await step('k13 cleanup',async()=>{await enterPin(p,'2468');await p.locator('[data-clocker-state="recovery"],[data-clocker-state="ready"]').first().waitFor({timeout:20000});
  if(await p.locator('[data-clocker-state="recovery"]').count()){await btn(p,'Check if it saved').click();await p.locator('[data-clocker-state="retry"],[data-clocker-state="success"],[data-clocker-state="ready"],[data-clocker-state="review-current"]').first().waitFor({timeout:20000});
   if(await p.locator('[data-clocker-state="retry"]').count()){await btn(p,'Send it again').click();await state(p,'success');}
   else if(await p.locator('[data-clocker-state="review-current"]').count()){await btn(p,'See current status').click();await state(p,'ready');}}
  await where(p);await done(p);});
 await B.ctx.close();
 // K8: the company photo policy (simulated as scripts/clocker-ipad-ui-qa.mjs does) with Chromium's fake camera.
 await step('k8 photo',async()=>{
  const fake=await browser.browserType().launch({headless:true,args:['--use-fake-device-for-media-stream','--use-fake-ui-for-media-stream']});
  try{
   const P=await fresh(fake,{permissions:['camera']});const pp=P.page;
   const policy={version:1,enabled:true,events:['CLOCK_IN','CLOCK_OUT'],retentionDays:30,failureBehavior:'ALLOW_WITH_EXCEPTION',captureMaxBytes:524288,captureMaxDimension:640,uploadWindowSeconds:300};
   const notice={policyVersion:1,profileVersion:1,companyName:'Northside Bakery',retentionDays:30,assistanceContact:'Front desk (fictional)',assistanceInstructions:'Ask the front desk for an assisted clock action.',cleanupDisclosure:'Fictional cleanup schedule.',backupDisclosure:'Fictional backup retention.'};
   await pp.route('**/api/clocker/*/punch',async(r:any)=>{if(r.request().postDataJSON()?.operation==='state'){const response=await r.fetch();const body=await response.json();await r.fulfill({response,json:{...body,photoCaptureAvailable:true}});}else await r.fallback();});
   await pp.route('**/api/clocker/*/photos',async(r:any)=>{const body=r.request().postDataJSON();log.push({photoOp:body?.operation});if(body.operation==='policy')await r.fulfill({json:{policy,notice}});else await r.fulfill({json:{commandId:body.command?.commandId,state:'missing'}});});
   await enroll(pp,'loc-1','scan-kiosk-main','Photo tablet');await enterPin(pp,'2468');await state(pp,'ready');
   const action=await btn(pp,'Clock in').count()?'Clock in':'Clock out';await btn(pp,action).click();if(action==='Clock out')await btn(pp,'Confirm clock out').click();
   await btn(pp,'Open camera').waitFor({timeout:20000});await pp.waitForTimeout(700);await shot(pp,'photo-notice','K8','photo for '+action.toLowerCase()+': notice before the camera');
   await btn(pp,'Open camera').click();await btn(pp,'Take photo').waitFor({timeout:20000});await pp.waitForTimeout(1500);await shot(pp,'photo-camera','K8','live camera (Chromium fake device)');
   await btn(pp,'Take photo').click();await btn(pp,'Use this photo').waitFor({timeout:20000});await pp.waitForTimeout(700);await shot(pp,'photo-review','K8','photo taken: Use this photo or Retake');
   await btn(pp,'Continue without photo').click();await pp.locator('h1').filter({hasText:N(action==='Clock in'?'Clock in recorded':'Clock out recorded')}).waitFor({timeout:20000}).catch(()=>{});await pp.waitForTimeout(800);
   await shot(pp,'photo-receipt-without-photo','K8','Continue without photo: the receipt with the missing-photo note');
   await P.ctx.close();
  }finally{await fake.close();}});
 // K14: this browser can't open its saved-punch storage (IndexedDB refused).
 await step('k14 storage',async()=>{
  const S=await fresh();await S.ctx.addInitScript(()=>{try{Object.defineProperty(window,'indexedDB',{value:{open(){const r:any={};setTimeout(()=>{r.error=new DOMException('blocked','UnknownError');r.onerror?.(new Event('error'));},10);return r;}},configurable:true});}catch{/* ignore */}});
  await enroll(S.page,'loc-1','scan-kiosk-main','Storage test tablet');await enterPin(S.page,'2468');await state(S.page,'storage');await S.page.waitForTimeout(600);await shot(S.page,'storage-problem','K14','browser storage refused');await S.ctx.close();});
}
