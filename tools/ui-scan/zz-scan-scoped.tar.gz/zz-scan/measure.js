() => {
  // Sweep measurements (scratch, never committed): family markers, words, button styles, text sizes, band.
  const root = document.querySelector('main.page-frame') || document.querySelector('main') || document.body;
  const shell = '.mobile-nav, .sidebar, .mobile-header, .section-tabs, .portal-skip-link, nextjs-portal, [data-nextjs-toast], .c-offline, script, style, noscript, template';
  const vis = e => { if (!e.checkVisibility || !e.checkVisibility({ opacityProperty: true, visibilityProperty: true })) return false; const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
  const srOnly = e => { const r = e.getBoundingClientRect(); const cs = getComputedStyle(e); return (r.width <= 2 && r.height <= 2) || cs.clipPath === 'inset(50%)' || cs.clip === 'rect(0px, 0px, 0px, 0px)' || !!e.closest('.sr-only, .c-sr, .q-sr, .visually-hidden'); };
  const all = [...root.querySelectorAll('*')].filter(e => !e.closest(shell) && vis(e));
  const classes = e => (typeof e.className === 'string' ? e.className : (e.getAttribute('class') || '')).split(/\s+/).filter(Boolean);
  const oldRe = /^(wa|wb|wc|q|sg|nv|kit)-|quiet|signature/i;
  let old = 0, b = 0, corp = 0; const oldPrefixes = {}; const bNamed = { 'b-screen': 0, 'b-band': 0, 'b-hero': 0, 'b-card': 0 };
  for (const e of all) {
    const cl = classes(e);
    if (cl.some(c => oldRe.test(c))) { old++; for (const c of cl) if (oldRe.test(c)) { const p = (c.match(/^(wa|wb|wc|q|sg|nv|kit)-/i) || [c.replace(/[-_].*$/, '')])[0]; oldPrefixes[p] = (oldPrefixes[p] || 0) + 1; } }
    if (cl.some(c => /^b-/.test(c)) || e.hasAttribute('data-nv-b')) b++;
    if (cl.some(c => /^c-/.test(c))) corp++;
    for (const k of Object.keys(bNamed)) if (cl.includes(k)) bNamed[k]++;
  }
  // Teal band: a wide element near the top painted with the B teal (gradient, border-image or solid).
  const teal = /(12, 114, 108|11, 110, 105|8, 80, 76|11, 109, 104|10, 104, 99|13, 115, 109|0, 110, 104|15, 118, 110)/;
  const vw = innerWidth;
  const bandEls = [...(root === document.body ? document.querySelectorAll('body *') : [root, ...root.querySelectorAll('*')])].filter(e => { if (e.closest('.sidebar, .mobile-nav')) return false; const r = e.getBoundingClientRect(); if (r.width < Math.min(300, vw * 0.25) || r.height < 60 || r.top > 500 + scrollY) return false; const cs = getComputedStyle(e); return teal.test(cs.backgroundImage) || teal.test(cs.backgroundColor) || teal.test(cs.borderImageSource); }).filter(vis);
  const band = bandEls.length > 0;
  const bandEl = bandEls[0];
  // Page canvas colour (main or body).
  const bgOf = e => { for (let n = e; n; n = n.parentElement) { const c = getComputedStyle(n).backgroundColor; if (c && c !== 'rgba(0, 0, 0, 0)' && c !== 'transparent') return c; } return 'none'; };
  const canvas = bgOf(root);
  // Words in the main content.
  const tw = document.createTreeWalker(root, NodeFilter.SHOW_TEXT); let n, words = 0; const sizes = {}; const fonts = {}; const textEls = new Set();
  while ((n = tw.nextNode())) {
    const t = n.textContent.trim(); if (!t) continue; const p = n.parentElement; if (!p || p.closest(shell) || !vis(p) || srOnly(p)) continue;
    const w = t.split(/\s+/).filter(x => /[\p{L}\p{N}]/u.test(x)).length; if (!w) continue; words += w; textEls.add(p);
  }
  for (const e of textEls) { const cs = getComputedStyle(e); sizes[cs.fontSize] = (sizes[cs.fontSize] || 0) + 1; const f = cs.fontFamily.split(',')[0].replace(/["']/g, '').trim(); fonts[f] = (fonts[f] || 0) + 1; }
  // Button styles among visible buttons and links styled as buttons.
  const alpha = c => { const m = c.match(/rgba?\(([^)]+)\)/); if (!m) return 0; const p = m[1].split(/[ ,/]+/).filter(Boolean).map(Number); return p.length > 3 ? p[3] : 1; };
  const btns = all.filter(e => {
    if (srOnly(e)) return false;
    if (e.matches('button, [role=button], input[type=submit], input[type=button], summary.b-btn, summary[class*=btn]')) return !e.closest('[role=tablist]') || e.matches('[class*=btn]');
    if (!e.matches('a[href]')) return false;
    const cs = getComputedStyle(e), r = e.getBoundingClientRect(), cl = (e.getAttribute('class') || '');
    if (/btn|button|pill|cta/i.test(cl)) return true;
    const painted = alpha(cs.backgroundColor) > 0.05 || (parseFloat(cs.borderTopWidth) > 0 && cs.borderTopStyle !== 'none' && alpha(cs.borderTopColor) > 0.05 && parseFloat(cs.borderLeftWidth) > 0);
    const text = (e.textContent || '').trim();
    return painted && r.height >= 28 && r.height <= 64 && text.length <= 40 && parseFloat(cs.borderTopLeftRadius) >= 6;
  });
  const styles = {};
  for (const e of btns) {
    const cs = getComputedStyle(e), r = e.getBoundingClientRect();
    const rad = parseFloat(cs.borderTopLeftRadius); const radius = rad >= r.height / 2 - 1 ? 'pill' : Math.round(rad) + 'px';
    const border = parseFloat(cs.borderTopWidth) > 0 && cs.borderTopStyle !== 'none' && alpha(cs.borderTopColor) > 0.05 ? cs.borderTopWidth + ' ' + cs.borderTopColor : 'none';
    const bg = alpha(cs.backgroundColor) > 0.05 ? cs.backgroundColor : 'transparent';
    const key = [bg, border, radius, cs.fontWeight].join(' | ');
    if (!styles[key]) styles[key] = { n: 0, sample: [] };
    styles[key].n++; const lbl = (e.getAttribute('aria-label') || e.textContent || '').trim().replace(/\s+/g, ' ').slice(0, 24); if (styles[key].sample.length < 3 && lbl) styles[key].sample.push(lbl);
  }
  const h1 = [...document.querySelectorAll('h1')].filter(vis).map(e => (e.textContent || '').trim().replace(/\s+/g, ' ').slice(0, 80)).slice(0, 3);
  const firstText = (root.innerText || '').trim().replace(/\s+/g, ' ').slice(0, 260);
  return {
    url: location.pathname + location.search, title: document.title, h1, firstText,
    elements: all.length, oldCount: old, oldPrefixes, bCount: b, bNamed, corpCount: corp,
    shellB: !!document.querySelector('.app-shell[data-nv-b]'),
    band, bandTag: bandEl ? (bandEl.tagName.toLowerCase() + '.' + classes(bandEl).slice(0, 2).join('.')).slice(0, 50) : null,
    canvas, words, buttonStyles: Object.keys(styles).length, buttonDetail: styles, buttons: btns.length,
    textSizes: Object.keys(sizes).sort((a, b) => parseFloat(a) - parseFloat(b)), fonts,
    overflow: document.documentElement.scrollWidth - innerWidth, height: document.documentElement.scrollHeight,
  };
}
