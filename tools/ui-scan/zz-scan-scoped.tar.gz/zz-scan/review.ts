// SCRATCH (not committed): Find cover "Review replacement" before/after captures. Fictional data, owned loopback
// Postgres and owned local app only. Every non-loopback browser request is aborted.
/* eslint-disable @typescript-eslint/no-explicit-any */
import {readFileSync,mkdirSync,writeFileSync} from 'node:fs';
import {TEST_PASSWORD} from '../src/test/integration/owned-app-fixture';
import {addDays} from '../src/lib/date-utils';

const measureSrc=()=>readFileSync('zz-scan/measure.js','utf8');
const axeSrc=()=>readFileSync('node_modules/axe-core/axe.min.js','utf8');
const settle=(p:any)=>p.waitForLoadState('networkidle',{timeout:8000}).catch(()=>{});
const guard=async(ctx:any,allowed:string[],log:unknown[])=>{await ctx.route('**/*',async(r:any)=>{let o='';try{o=new URL(r.request().url()).origin;}catch{/* data: */}
 if(o&&o!=='null'&&!allowed.includes(o)&&/^https?:/.test(o)){log.push({blocked:o});await r.abort('blockedbyclient');return;}await r.fallback();});};
type Q=(text:string,values?:unknown[])=>Promise<any>;
const rows=(r:any)=>Array.isArray(r)?r:r.rows;

const PRIMARY='main .c-review__primary, main form button[type=submit], main a.nv-btn[data-kind=primary], main a.np-button[data-variant=primary]';
const FALLBACK='main .c-review__cancel, main a.nv-btn[data-kind=secondary], main a.c-btn, main a[class*=btn]';

export async function runReview(browser:any,appUrl:string,evidence:string,log:unknown[],q:Q,o:{week:string;today:string}){
 const out=process.env.NEVORA_REVIEW_OUT!;mkdirSync(out,{recursive:true});
 const rec:any[]=[];const save=()=>writeFileSync(out+'/review-log.json',JSON.stringify({rec,log:log.filter((x:any)=>x&&typeof x==='object'&&('review' in x||'blocked' in x||'reviewError' in x))},null,2));
 const nextWeek=addDays(o.week,7);
 // First week ahead with no schedule row at either location: an unpublished (draft) week for both.
 const taken=new Set(rows(await q('SELECT DISTINCT week_start::text AS w FROM schedules')).map((r:any)=>r.w));
 let draftWeek=addDays(o.week,14);for(let k=2;k<12;k++){const w=addDays(o.week,7*k);if(!taken.has(w)){draftWeek=w;break;}}
 log.push({review:'draftWeek',draftWeek,taken:[...taken]});
 const sessions:Record<string,{desk:any;phone:any}>={};
 const login=async(id:string)=>{
  if(sessions[id])return sessions[id];
  const mk=async(phone:boolean,pw?:number)=>{
   const ctx=await browser.newContext(phone?{viewport:{width:pw??Number(process.env.NEVORA_REVIEW_PHONE_W??390),height:pw===320?700:844},deviceScaleFactor:2,isMobile:process.env.NEVORA_REVIEW_TEXT200!=='1',hasTouch:true,reducedMotion:'reduce',serviceWorkers:'block'}:{viewport:{width:1440,height:1000},deviceScaleFactor:1,reducedMotion:'reduce',serviceWorkers:'block'});
   await guard(ctx,[appUrl],log);const p=await ctx.newPage();p.setDefaultTimeout(20000);if(process.env.NEVORA_REVIEW_TEXT200==='1'&&process.env.NEVORA_REVIEW_INLINE200!=='1'){const cdp=await ctx.newCDPSession(p);await cdp.send('Page.enable');await cdp.send('Page.setFontSizes',{fontSizes:{standard:32,fixed:26}});}
   p.on('pageerror',(e:Error)=>log.push({review:'pageerror',id,phone,msg:e.message.slice(0,300)}));
   p.on('console',(m:any)=>{if(m.type()==='error')log.push({review:'console',id,phone,msg:m.text().slice(0,300)});});
   await p.goto(appUrl+'/login');await p.getByLabel('Employee ID',{exact:true}).fill(id);await p.getByLabel('Password',{exact:true}).fill(TEST_PASSWORD);
   await p.getByRole('button',{name:'Sign in',exact:true}).click();await p.waitForURL((u:URL)=>u.pathname.startsWith('/app'),{timeout:30000});await settle(p);
   return p;};
  sessions[id]={desk:await mk(false),phone:await mk(true),...(process.env.NEVORA_REVIEW_MULTI==='1'?{p320:await mk(true,320),p200:await mk(true,390)}:{})} as any;return sessions[id];
 };
 const coverLinks=async(p:any,week:string,loc:string)=>{
  await p.goto(appUrl+`/app/schedule?week=${week}&location=${loc}`);await settle(p);await p.waitForTimeout(1200);
  const links:string[]=await p.locator('a[href*="/app/schedule/coverage"]').evaluateAll((els:HTMLAnchorElement[])=>els.map(a=>a.getAttribute('href')||''));
  return [...new Set(links.filter(h=>h.includes('repair=')))];
 };
 const parse=(href:string)=>{const u=new URL(href,appUrl);return {date:u.searchParams.get('date'),start:u.searchParams.get('start'),end:u.searchParams.get('end'),loc:u.searchParams.get('locationId')};};
 /** Schedule → Find cover → first person. Returns the review URL (path) reached by clicking. */
 const reach=async(p:any,coverHref:string,label:string)=>{
  await p.goto(appUrl+coverHref);await settle(p);await p.waitForTimeout(1000);
  await p.locator('a[href*="/app/schedule/new?review="]').first().waitFor({timeout:20000}).catch(()=>{});
  if(process.env.NEVORA_REVIEW_ONLY4B==='1')await p.screenshot({path:`${process.env.NEVORA_REVIEW_OUT}/coverage-${label}-1440.png`,fullPage:true}).catch(()=>{});
  const cands=p.locator('a[href*="/app/schedule/new?review="]');const n=await cands.count();
  const names:string[]=await cands.evaluateAll((els:HTMLElement[])=>els.map(e=>(e.textContent||'').trim().replace(/\s+/g,' ').slice(0,60)));
  log.push({review:'coverage',label,coverHref,h1:await p.locator('h1').allInnerTexts().catch(()=>[]),candidates:n,names:names.slice(0,6)});
  if(!n)return null;
  await cands.first().click();await p.waitForURL((u:URL)=>u.pathname==='/app/schedule/new'&&u.searchParams.has('review'),{timeout:20000});await settle(p);
  const url=p.url().replace(appUrl,'');let token:any=null;try{token=JSON.parse(Buffer.from(new URL(p.url()).searchParams.get('review')!,'base64url').toString());}catch{/* */}
  return {url,token};
 };
 const focusWalk=async(p:any,shot:string)=>{
  await p.evaluate(()=>{(document.activeElement as HTMLElement|null)?.blur();window.scrollTo(0,0);});
  const prim=await p.evaluate(([a,b]:string[])=>{const v=(e:Element)=>{const r=e.getBoundingClientRect();return r.width>0&&r.height>0;};const e=[...document.querySelectorAll(a)].find(v)||[...document.querySelectorAll(b)].find(v);if(!e)return null;(e as HTMLElement).dataset.revPrimary='1';return (e.textContent||'').trim().replace(/\s+/g,' ');},[PRIMARY,FALLBACK]);
  const steps:any[]=[];let shotTaken=false;
  for(let i=1;i<=45;i++){await p.keyboard.press('Tab');await p.waitForTimeout(90);
   const s=await p.evaluate(()=>{const e=document.activeElement as HTMLElement|null;if(!e||e===document.body)return null;const cs=getComputedStyle(e);const r=e.getBoundingClientRect();
    return {el:(e.tagName.toLowerCase()+'.'+[...e.classList].slice(0,2).join('.')).slice(0,50),txt:(e.getAttribute('aria-label')||e.textContent||(e as HTMLInputElement).value||'').trim().replace(/\s+/g,' ').slice(0,50),inMain:!!e.closest('main'),primary:e.dataset.revPrimary==='1',
     ring:cs.outlineStyle!=='none'&&parseFloat(cs.outlineWidth)>0?`outline ${cs.outlineWidth} ${cs.outlineColor} off ${cs.outlineOffset}`:(cs.boxShadow!=='none'?'shadow '+cs.boxShadow.slice(0,50):'none'),r:[Math.round(r.left),Math.round(r.top),Math.round(r.width),Math.round(r.height)]};});
   steps.push(s);
   if(s?.primary&&!shotTaken){await p.screenshot({path:shot,fullPage:false});shotTaken=true;}
   if(shotTaken&&s&&!s.inMain)break;
   if(i>3&&steps.length>3&&JSON.stringify(s)===JSON.stringify(steps[0]))break;
  }
  return {primary:prim,shot:shotTaken?shot:null,steps};
 };
 const axe=async(p:any)=>{
  await p.evaluate(axeSrc());
  return p.evaluate(async()=>{const r=await (window as any).axe.run(document,{resultTypes:['violations']});
   return r.violations.map((v:any)=>({id:v.id,impact:v.impact,help:v.help,nodes:v.nodes.length,targets:v.nodes.slice(0,4).map((n:any)=>({t:String(n.target).slice(0,90),inMain:!!document.querySelector(String(n.target[0]))?.closest('main'),summary:(n.failureSummary||'').slice(0,160)}))}));});
 };
 const extra=async(p:any)=>p.evaluate(()=>{const m=document.querySelector('main')||document.body;const vw=innerWidth;
  const wide=[...m.querySelectorAll('*')].filter(e=>{const r=e.getBoundingClientRect();return r.width>0&&(r.right>vw+0.5||r.left<-0.5);}).slice(0,6).map(e=>(e.tagName.toLowerCase()+'.'+[...e.classList].slice(0,2).join('.')+' r='+Math.round(e.getBoundingClientRect().right)));
  const clipped=[...m.querySelectorAll('*')].filter(e=>{const cs=getComputedStyle(e);return (cs.overflowX==='hidden'||cs.textOverflow==='ellipsis')&&e.scrollWidth>e.clientWidth+1&&e.clientWidth>0;}).slice(0,6).map(e=>(e.tagName.toLowerCase()+'.'+[...e.classList].slice(0,2).join('.')+' '+(e.textContent||'').trim().slice(0,40)));
  return {docOverflow:document.documentElement.scrollWidth-vw,bodyOverflow:document.body.scrollWidth-vw,wide,clipped,mainText:((m as HTMLElement).innerText||'').trim().replace(/\n{2,}/g,'\n').slice(0,1200)};});
 const capture=async(state:string,id:string,url:string,note:string)=>{
  if(process.env.NEVORA_REVIEW_ONLY4B==='1'&&state!=='4b-daniel-draft')return;
  const s=await login(id);
  const multi=process.env.NEVORA_REVIEW_MULTI==='1';const cfgs:[string,any,boolean][]=multi?[['390',s.phone,false],['320',(s as any).p320,false],['390-text200',(s as any).p200,true],['1440',s.desk,false]]:[['390',s.phone,process.env.NEVORA_REVIEW_INLINE200==='1'],['1440',s.desk,process.env.NEVORA_REVIEW_INLINE200==='1']];
  for(const [w,p,t200] of cfgs){
   try{
    await p.goto(appUrl+url);await settle(p);await p.waitForTimeout(1500);
    if(t200){await p.evaluate(()=>{document.documentElement.style.fontSize='200%';});await p.waitForTimeout(400);}
    const m=await p.evaluate(new Function('return ('+measureSrc()+')()') as ()=>unknown).catch((e:unknown)=>({error:String(e).slice(0,200)}));
    const x=await extra(p);const a=await axe(p).catch((e:unknown)=>[{error:String(e).slice(0,200)}]);
    const fsB=await p.evaluate(()=>getComputedStyle(document.documentElement).fontSize);
    await p.screenshot({path:`${out}/${state}-${w}.png`,fullPage:true});
    log.push({review:'fs',state,w,before:fsB,after:await p.evaluate(()=>getComputedStyle(document.documentElement).fontSize)});
    const f=(w==='390'||w==='1440')?await focusWalk(p,`${out}/${state}-${w}-focus.png`):null;
    rec.push({state,id,width:w,url:p.url().replace(appUrl,''),note,m,x,axe:a,focus:f});save();
   }catch(e){log.push({reviewError:state+' '+w,e:String((e as Error).message).slice(0,400)});save();}
  }
 };
 const qi=(t:string)=>t.split('.').map(x=>'"'+x+'"').join('.');
 const counts=async()=>{const t=rows(await q("SELECT table_schema||'.'||table_name AS table_name FROM information_schema.tables WHERE table_schema NOT IN ('pg_catalog','information_schema') AND table_type='BASE TABLE' ORDER BY 1"));const c:Record<string,number>={};
  for(const {table_name} of t){try{c[table_name]=Number(rows(await q(`SELECT count(*)::int AS n FROM ${qi(table_name)}`))[0].n);}catch{/* */}}return c;};

 // ---- Owner: published (next week, loc-1) and draft (week+14, loc-1) ----
 const owner=await login('QAOWNER');
 const pubLinks=await coverLinks(owner.desk,nextWeek,'loc-1');log.push({review:'links',who:'QAOWNER',week:nextWeek,loc:'loc-1',n:pubLinks.length,gaps:pubLinks.map(parse)});
 const notMidnight=pubLinks.find(h=>{const g=parse(h);return g.end!=='24:00'&&g.start!=='00:00';})??pubLinks[0];
 const midnight=pubLinks.find(h=>{const g=parse(h);return g.end==='24:00'||(g.end!<g.start!);});
 const pubLinks2=await coverLinks(owner.desk,nextWeek,'loc-2');log.push({review:'links',who:'QAOWNER',week:nextWeek,loc:'loc-2',n:pubLinks2.length,gaps:pubLinks2.map(parse)});
 let draftLinks=await coverLinks(owner.desk,draftWeek,'loc-1');log.push({review:'links',who:'QAOWNER',week:draftWeek,loc:'loc-1',n:draftLinks.length,gaps:draftLinks.map(parse),sched:rows(await q('SELECT id,status FROM schedules WHERE week_start=$1',[draftWeek]))});
 if(!draftLinks.length){for(const l of ['loc-1','loc-2'])await q("INSERT INTO schedules(id,location_id,week_start,status,created_by) VALUES($2,$3,$1,'DRAFT','QAOWNER') ON CONFLICT DO NOTHING",[draftWeek,'rev-draft-'+l,l]).catch((e:unknown)=>log.push({review:'draft insert',e:String(e)}));
  draftLinks=await coverLinks(owner.desk,draftWeek,'loc-1');log.push({review:'links-after-insert',n:draftLinks.length,gaps:draftLinks.map(parse)});}
 const draftLinks2=await coverLinks(owner.desk,draftWeek,'loc-2');log.push({review:'links',who:'QAOWNER',week:draftWeek,loc:'loc-2',n:draftLinks2.length,gaps:draftLinks2.map(parse)});
 save();

 let s1:any=null;
 if(notMidnight){s1=await reach(owner.desk,notMidnight,'owner-publish');log.push({review:'reach',state:'1-owner-publish',r:s1});if(s1)await capture('1-owner-publish','QAOWNER',s1.url,'Owner, published week');}
 if(process.env.NEVORA_REVIEW_ONLY1==='1'){
  // Card text check: the same review at 390 with default text (fresh context), font sizes per text element.
  if(s1){const sizesOf=(p:any)=>p.evaluate(()=>{const m=document.querySelector('main')||document.body;const o:Record<string,string>={};const tw=document.createTreeWalker(m,NodeFilter.SHOW_TEXT);let n:Node|null;while((n=tw.nextNode())){const t=(n.textContent||'').trim();const e=n.parentElement;if(!t||!e)continue;const r=e.getBoundingClientRect();if(!r.width)continue;const k=(e.tagName.toLowerCase()+'.'+[...e.classList].slice(0,2).join('.')+' '+t.slice(0,30));if(!(k in o))o[k]=getComputedStyle(e).fontSize;}return o;});
   const sz200=await sizesOf((await login('QAOWNER')).phone);
   const ctx=await browser.newContext({viewport:{width:390,height:844},deviceScaleFactor:2,isMobile:true,hasTouch:true,reducedMotion:'reduce',serviceWorkers:'block'});await guard(ctx,[appUrl],log);const p=await ctx.newPage();
   await p.goto(appUrl+'/login');await p.getByLabel('Employee ID',{exact:true}).fill('QAOWNER');await p.getByLabel('Password',{exact:true}).fill(TEST_PASSWORD);await p.getByRole('button',{name:'Sign in',exact:true}).click();await p.waitForURL((u:URL)=>u.pathname.startsWith('/app'),{timeout:30000});await settle(p);
   await p.goto(appUrl+s1.url);await settle(p);await p.waitForTimeout(1500);await p.screenshot({path:`${out}/1-owner-publish-390-text100.png`,fullPage:true});
   const sz100=await sizesOf(p);rec.push({state:'sizes',sz100,sz200});save();await ctx.close();}
  for(const s of Object.values(sessions) as any[]){for(const k of ['desk','phone','p320','p200'])if(s[k])await s[k].context().close().catch(()=>{});}
  save();return;}
 if(draftLinks[0]){const r=await reach(owner.desk,draftLinks.find(h=>parse(h).end!=='24:00')??draftLinks[0],'owner-draft');log.push({review:'reach',state:'2-owner-draft',r});if(r)await capture('2-owner-draft','QAOWNER',r.url,'Owner, draft week');}
 if(midnight){const r=await reach(owner.desk,midnight,'owner-midnight');log.push({review:'reach',state:'5-owner-to-midnight',r});if(r)await capture('5-owner-to-midnight','QAOWNER',r.url,'Owner, published week, gap that ends at 24:00 (code treats it as overnight)');}
 save();

 // ---- Elena: company-wide Manager without Publish schedules ----
 try{const el=await login('OWN-ELENA');const ln=await coverLinks(el.desk,nextWeek,'loc-1');log.push({review:'links',who:'OWN-ELENA',n:ln.length});
  const pick=ln.find(h=>h===notMidnight)??ln.find(h=>{const g=parse(h);return g.end!=='24:00'&&g.start!=='00:00';})??ln[0]??notMidnight;
  const grants=rows(await q("SELECT * FROM information_schema.tables WHERE table_name ILIKE '%permission%' OR table_name ILIKE '%grant%'")).map((r:any)=>r.table_name);log.push({review:'grant tables',grants});
  if(pick){const r=await reach(el.desk,pick,'elena');log.push({review:'reach',state:'3-elena-no-publish',r});if(r)await capture('3-elena-no-publish','OWN-ELENA',r.url,'Company-wide Manager without Publish schedules, published week');}
 }catch(e){log.push({reviewError:'elena',e:String((e as Error).stack??e).slice(0,500)});}
 save();

 // ---- Daniel: location-limited Manager (Condado, loc-2) ----
 try{const dn=await login('OWN-DANI');
  const own=await coverLinks(dn.desk,nextWeek,'loc-2');log.push({review:'links',who:'OWN-DANI',week:nextWeek,n:own.length,h1:await dn.desk.locator('h1').allInnerTexts().catch(()=>[])});
  const ownDraft=await coverLinks(dn.desk,draftWeek,'loc-2');await dn.desk.screenshot({path:`${out}/daniel-schedule-draftweek-1440.png`,fullPage:true}).catch(()=>{});log.push({review:'links',who:'OWN-DANI',week:draftWeek,n:ownDraft.length});
  const pubPick=own[0]??pubLinks2.find(h=>parse(h).end!=='24:00')??pubLinks2[0];
  if(pubPick){const r=await reach(dn.desk,pubPick,'daniel-published');log.push({review:'reach',state:'4a-daniel-published',from:own[0]?'own schedule':'Owner link',r});
   if(r)await capture('4a-daniel-published','OWN-DANI',r.url,'Location Manager (Condado), published week; link from '+(own[0]?'his schedule':'the Owner schedule'));
   else{await capture('4a-daniel-published-coverage','OWN-DANI',pubPick,'Location Manager on Find cover (no person to choose)');}}
  const dPick=ownDraft[0]??draftLinks2.find(h=>parse(h).end!=='24:00')??draftLinks2[0];
  if(dPick){const r=await reach(dn.desk,dPick,'daniel-draft');log.push({review:'reach',state:'4b-daniel-draft',from:ownDraft[0]?'own schedule':'Owner link',r});
   if(r)await capture('4b-daniel-draft','OWN-DANI',r.url,'Location Manager (Condado), draft week');}
 }catch(e){log.push({reviewError:'daniel',e:String((e as Error).stack??e).slice(0,500)});}
 save();

 // ---- Publish: Owner presses the primary once on the state-1 review ----
 if(s1&&process.env.NEVORA_REVIEW_ONLY4B!=='1'){try{
  const p=owner.desk;const t=s1.token;
  const shiftQ=()=>q("SELECT sh.id,sh.employee_id,sh.date::text AS date,to_char(sh.start_time,'HH24:MI') AS s,to_char(sh.end_time,'HH24:MI') AS e,sc.status,sc.location_id FROM shifts sh JOIN schedules sc ON sc.id=sh.schedule_id WHERE sh.employee_id=$1 AND sh.date=$2 ORDER BY sh.start_time",[t.employeeId,t.locator.date]).then(rows);
  const notifQ=()=>q("SELECT * FROM notifications WHERE employee_id=$1 ORDER BY created_at DESC LIMIT 5",[t.employeeId]).then(rows);
  const before={shifts:await shiftQ(),notif:(await notifQ()).length,counts:await counts()};
  await p.goto(appUrl+s1.url);await settle(p);await p.waitForTimeout(1200);
  const consent=p.locator('#coverage-publication-consent');if(await consent.count())await consent.check();
  const btn=p.locator(PRIMARY).first();const label=(await btn.textContent())?.trim();
  const t0=Date.now();await btn.click();
  await p.waitForURL((u:URL)=>!(u.pathname==='/app/schedule/new'&&u.searchParams.has('review')),{timeout:20000}).catch(()=>{});await settle(p);await p.waitForTimeout(2500);
  const resultUrl=p.url().replace(appUrl,'');
  const m=await p.evaluate(new Function('return ('+measureSrc()+')()') as ()=>unknown).catch(()=>null);const x=await extra(p);const a=await axe(p).catch(()=>[]);
  await p.screenshot({path:`${out}/1-owner-publish-result-1440.png`,fullPage:true});
  const toast=await p.locator('[role=status],[role=alert],[data-sonner-toast],.c-toast').allInnerTexts().catch(()=>[]);
  const after={shifts:await shiftQ(),notif:await notifQ(),counts:await counts()};
  const diff:Record<string,[number,number]>={};for(const k of new Set([...Object.keys(before.counts),...Object.keys(after.counts)]))if(before.counts[k]!==after.counts[k])diff[k]=[before.counts[k],after.counts[k]];
  const detail:Record<string,unknown>={};
  for(const tname of Object.keys(diff))detail[tname]=rows(await q(`SELECT * FROM ${qi(tname)} ORDER BY 1 DESC LIMIT 3`).catch((e:unknown)=>({rows:[String(e)]})));
  const matching=after.shifts.filter((r:any)=>r.s===t.locator.startTime&&(r.e===t.locator.endTime||(t.locator.endTime==='24:00'&&r.e==='00:00')));
  rec.push({state:'publish',label,ms:Date.now()-t0,resultUrl,toast,m,x,axe:a,employee:t.employeeId,locator:t.locator,shiftsBefore:before.shifts,shiftsAfter:after.shifts,newMatching:matching.length,notifBefore:before.notif,notifAfter:after.notif,tableDiff:diff,diffRows:detail});save();
  // The result at phone width, same session cookie set (phone context of the Owner).
  await owner.phone.goto(appUrl+resultUrl);await settle(owner.phone);await owner.phone.waitForTimeout(1500);
  await owner.phone.screenshot({path:`${out}/1-owner-publish-result-390.png`,fullPage:true});
  rec.push({state:'publish-390',url:owner.phone.url().replace(appUrl,''),m:await owner.phone.evaluate(new Function('return ('+measureSrc()+')()') as ()=>unknown).catch(()=>null),x:await extra(owner.phone)});save();
 }catch(e){log.push({reviewError:'publish',e:String((e as Error).stack??e).slice(0,600)});save();}}
 for(const s of Object.values(sessions) as any[]){for(const k of ['desk','phone','p320','p200'])if(s[k])await s[k].context().close().catch(()=>{});}
 save();
}
