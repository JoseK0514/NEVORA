# NEVORA premium components for Claude

Open `component-library.html` in a browser to try the gallery. It works offline and uses fictional people, hours and punches. The comparison contains four working visual options for each of 43 component and workflow examples across 12 families. Choose a Family and Component, try the previews, then use Pick and Your picks to download a selection sheet for Claude. Reloading keeps picks in this browser where local storage is available. The HTML embeds the fonts, upstream code, styles and license notices.

## Integrate on the collaboration branch

This kit was prepared against `claude-codex-collab-nevora` at `57e58b92653f9a4b51e5a3dfa00cbf1e22529b71`. Claude owns UI integration. The full patch adds the two kit directories and pins @radix-ui/themes 3.3.0 in package.json and package-lock.json. It adds no application routes. Extract the archive into a separate folder before applying a patch.

For a clean collaboration checkout, check and apply the full patch. If the exact first kit has already been applied, use upgrade-from-first-kit.patch in place of claude-components.patch in both commands.

```sh
git apply --check /path/to/nevora-premium-components/claude-components.patch
git apply /path/to/nevora-premium-components/claude-components.patch
npm ci --ignore-scripts
```

Place `.np-kit` around the adopted surface. Import components from `@/components/premium`. The gallery imports this same entry point. It also supplies its own editorial navigation, fictional scenarios and browser-only state in `examples/premium-components/`.

```tsx
import { Button, Notice } from "@/components/premium";

export function ReviewActions({ saving, save }: { saving: boolean; save: () => void }) {
  return (
    <section className="np-kit">
      <Notice tone="warning" title="Coverage needs review">
        One closing shift still needs a lead.
      </Notice>
      <Button busy={saving} busyLabel="Saving…" onClick={save}>Save changes</Button>
    </section>
  );
}
```

The kit reuses the branch’s BAvatar, BBusyLabel, BSpin, offline glyph, done tick, ClockerIcon, Phosphor package and design tokens. Gallery branding, type and SVG icons are bundled into the standalone HTML. The separately approved icon handoff covers the application-wide icon migration. Apply it on its own scope.

## Apply a style selection

A selection file names the component, treatment, and source with its documentation URL. Apply only the choices Jose selects.

- **Radix Themes** identifies a live published control. Match its props in `examples/premium-components/radix-samples.tsx` and wrap the component in `NevoraRadixTheme` from `src/components/premium/radix-theme.tsx`. This wrapper applies the portal’s font and action contrast to the upstream theme.
- **Built with Radix** identifies a NEVORA pattern assembled from the published primitives. The editable examples in `examples/premium-components/radix-patterns.tsx` show the composition. Replace the demonstration handlers with the existing product handlers during integration.
- **Phosphor** identifies the real icon artwork. The four icon weights are fill, bold, duotone and regular. Pass the selected weight to Mark.
- **NEVORA treatments** are named in `src/components/premium/treatments.tsx` and styled in `treatments.css`. Wrap a targeted component as shown below. Scope each selection to the named component.
- **Design references** appear beneath the comparisons. Carbon’s notification and recovery guidance informed the messages. Apple’s guidance on standard materials informed the tinted glass panels. The Clocker examples are NEVORA designs.

```tsx
import { Button, ComponentStyle } from "@/components/premium";

<ComponentStyle part="button" treatment="soft">
  <Button icon="check" onClick={save}>Save changes</Button>
</ComponentStyle>
```

## Component inventory

| Family | What to try | Gallery section |
| --- | --- | --- |
| Buttons | Primary, secondary, quiet, destructive, icon-only, disabled and fixed-width busy states | Controls |
| Switches and selection | On, off, unavailable, optimistic save with rollback, checkboxes, radio buttons and segments | Controls |
| Waiting and progress | Roster skeleton, labeled spinner, export progress and completion | Feedback |
| Status and warnings | Text labels for pending, approved, blocked and other states, inline notices and dismissible saved feedback | Feedback |
| Cards and rows | Content cards, action rows, dividers, avatars and icon discs | Overview, People and records |
| Glass surfaces | Teal summary band, glass metric tiles, week picker, zero values and multiline Spanish labels | Overview, People and records |
| Form fields | Text, date, time, search, email, select, helper text, validation, read-only and disabled fields | Forms, Navigation |
| Navigation and filters | Desktop sidebar, compact rail, phone tabs, back, overflow, search and filter chips | Navigation |
| Dialogs and sheets | Details, discard edits, confirm a decision and a responsive action sheet | Controls, Forms, Navigation |
| Results and recovery | Empty, no matches, offline, stale, denied, error, saved and unconfirmed states, each with a next action | Feedback |
| Workforce records | People, overnight shifts, requests and approvals, weekly timecards and pay summaries | People and records |
| Clocker | Setup, employee ID, masked keypad, clock in/out, rest and meal breaks, local photo preview, recorded receipt and status recovery | Clocker tablet |

## Use in real workflows

- **Owner, Manager and Lead** can share navigation, warning, request, approval and schedule components within their existing permissions. Connect them to the branch’s current events, localized labels and records.
- **Employee** can share shift, settings, timecard and pay components. The gallery includes a long name, an overnight shift and zero overtime.
- **Clocker** can use the tabletop action, keypad, camera selection and receipt components with its existing device binding, PIN, camera and punch handlers. The gallery’s simulated confirmation resolves locally. In the actual kiosk, drive a recorded receipt from a confirmed server result, and resolve an unconfirmed request through the existing status check. The demo never uploads a photo.
- **Review** one representative screen for each role and the kiosk using current-versus-proposed captures before a broader rollout. Check long Spanish strings, reduced motion, touch targets, keyboard focus and busy, offline or unconfirmed states. The gallery’s language toggle previews the English and Spanish summary band.
- **Release** Development is the combined acceptance environment. Integration, environment tests and release belong to the normal project workflow. Jose authorizes promotion to main or production.

## Rebuild and verify

From the repository root with its existing locked dependencies, run the following. The Playwright scripts load the repository’s `tools/ci-browser-runtime`. Set `NEVORA_PLAYWRIGHT_RUNTIME_PACKAGE` to another installed copy’s absolute `package.json` when using a shared browser runtime. The layout check also uses the existing axe-core dependency.

```sh
node examples/premium-components/build.mjs /tmp/nevora-component-library.html
npm run typecheck
npm test -- src/components/premium/premium.test.tsx
node examples/premium-components/check-layout.mjs /tmp/nevora-component-library.html
node examples/premium-components/check-workflows.mjs /tmp/nevora-component-library.html
node examples/premium-components/check-options.mjs /tmp/nevora-component-library.html chromium 1440
node examples/premium-components/check-options.mjs /tmp/nevora-component-library.html webkit 390
node examples/premium-components/check-options.mjs /tmp/nevora-component-library.html chromium 320
```

The package includes the standalone preview, the React and gallery source, the full patch, the upgrade patch and these instructions. The exported examples run independently of a NEVORA login or backend. Physical kiosk camera capture, live API behavior and role authorization are integration checks for the consuming application.

