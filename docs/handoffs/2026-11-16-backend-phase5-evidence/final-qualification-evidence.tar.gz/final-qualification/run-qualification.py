from pathlib import Path
import subprocess,os,json,datetime,hashlib,time,re,sys
root=Path('/Users/josek0514/.codex/worktrees/nevora-backend-phase5-20261116/Fuel Scheduler')
base=Path(__file__).parent;source=json.loads((base/'final-source.json').read_text());sha=source['qualificationSha']
env={k:os.environ[k] for k in ['PATH','HOME','TMPDIR','USER','LOGNAME','SHELL','LANG','LC_ALL'] if k in os.environ}
env.update({'CI':'1','NEXT_TELEMETRY_DISABLED':'1','PUSH_FEATURE_ENABLED':'false','PUSH_DELIVERY_ENABLED':'false','PUSH_TEST_DELIVERY_ENABLED':'false','NEVORA_TEST_PG_BIN':'/Users/josek0514/Documents/Codex/2026-11-15/ple/work/pg-xml/runtime/bin','NEVORA_PLAYWRIGHT_RUNTIME_PACKAGE':str(root/'tools/ci-browser-runtime/package.json'),'PHASE_E_EXPECTED_SHA':sha,'CLOCKER_SQL_EXPECTED_SHA':sha,'PHASE_C_EXPECTED_SHA':sha,'PHASE_E_EVIDENCE_DIR':str(base/'phase-e-sql'),'NEVORA_CAPACITY_EVIDENCE':str(base/'capacity'),'PHASE_E_STARTUP_EVIDENCE_DIR':str(base/'startup'),'NEVORA_BUILD_RECEIPT':str(base/'build-source.json')})
for key in ['PHASE_E_EVIDENCE_DIR','NEVORA_CAPACITY_EVIDENCE','PHASE_E_STARTUP_EVIDENCE_DIR']:Path(env[key]).mkdir(exist_ok=True)
node=['node'];pg=node+['scripts/payroll-postgres.mjs'];checks=[]
def add(id,argv,extra=None):checks.append({'id':id,'argv':argv,'envOverrides':extra or {}})
add('source-inventory',['npm','run','check:development-sources'])
add('bootstrap',node+['scripts/onboarding-manifest.mjs'])
add('format',['npm','run','format:check'])
add('test-projects',['npm','run','check:test-projects'])
add('test-project-regressions',['npm','run','test:test-projects'])
add('notifications-qa',['npm','run','test:notifications:qa'])
add('foundation-qa',['npm','run','test:foundation:qa'])
add('units',['npm','test','--','--maxWorkers=1'])
add('types',node+['node_modules/typescript/bin/tsc','--noEmit','--incremental','false'])
add('lint',['npm','run','lint'])
add('release-infrastructure',['npm','run','test:release-engineering'])
add('production-absence',['npm','run','test:dev:production'])
add('inspection-evidence',['npm','run','check:inspection-evidence'])
add('manuals',node+['scripts/manuals/check-manuals.mjs'])
add('owned-pg-startup',node+['--test','scripts/phase-e-owned-startup.check.mjs'])
add('release-postgres',['npm','run','test:release:postgres'])
for n in range(1,5):
 d=base/('clocker-sql-'+str(n));d.mkdir(exist_ok=True)
 add('clocker-sql-'+str(n),node+['scripts/phase-c-clocker-postgres.mjs','--shard='+str(n)+'/4'],{'CLOCKER_SQL_EVIDENCE_DIR':str(d)})
add('clocker-aggregate',node+['scripts/clocker-sql-shards.mjs','aggregate'],{'CLOCKER_SQL_ARTIFACTS_DIR':str(base),'CLOCKER_SQL_EVIDENCE_DIR':str(base/'clocker-aggregate')})
add('fresh-company',pg+['vitest.company-setup-integration.config.mts'])
add('paid-export',pg+['vitest.payroll-export-integration.config.mts'])
add('imports',pg+['vitest.configurable-payroll-integration.config.mts'])
add('company-access',pg+['vitest.company-access-integration.config.mts'])
add('decision-facts',pg+['vitest.exchanges-integration.config.mts','src/test/integration/shift-change-phase3-facts.integration.ts'])
add('phase-e-sql',node+['scripts/phase-e-owned.mjs','sql','--suite','all'])
add('deletion',pg+['vitest.employee-mobile-deletion.config.mts','src/test/integration/employee-mobile-deletion-sql.integration.ts'])
add('passkeys',pg+['vitest.passkeys-integration.config.mts'])
add('staff-tasks',pg+['vitest.staff-tasks-integration.config.mts'])
add('timestamp-token',pg+['vitest.timestamp-token-integration.config.mts'])
add('payroll-pagination-contention',pg+['vitest.payroll-source-pagination-integration.config.mts'])
add('native-payroll-held-guards',pg+['vitest.native-payroll-integration.config.mts'])
add('owner-adviser-local-contract',pg+['vitest.owner-advisor-integration.config.mts'])
add('rondo-leadership-offline-contract',pg+['vitest.rondo-leadership.config.mts'])
add('conversations-held-guards',pg+['vitest.conversations-integration.config.mts'])
add('onboarding',node+['scripts/onboarding-owned.mjs','--suite','all'])
add('commerce',node+['scripts/commerce-postgres.mjs'])
add('build',node+['scripts/release-build.mjs'])
(base/'planned-commands.json').write_text(json.dumps(checks,indent=2)+'\n')
ledger={'source':sha,'environment':'owned fictional local only; external provider sending/AI absent','results':[],'state':'running','startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
def save():
 temp=base/'qualification-ledger.tmp';temp.write_text(json.dumps(ledger,indent=2)+'\n');temp.replace(base/'qualification-ledger.json')
for check in checks:
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==sha,'Source moved during frozen qualification'
 childenv={**env,**check['envOverrides']}
 for key,value in check['envOverrides'].items():
  if key.endswith('_DIR'):Path(value).mkdir(exist_ok=True)
 start=time.monotonic();row={**check,'source':sha,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state':'running','log':check['id']+'.log'};ledger['results'].append(row);save();print('START '+check['id'],flush=True)
 with (base/row['log']).open('wb') as log:
  child=subprocess.Popen(check['argv'],cwd=root,env=childenv,stdout=log,stderr=subprocess.STDOUT)
  row['ownedSupervisorPid']=os.getpid();row['childPid']=child.pid;save();code=child.wait()
 row.update({'state':'passed' if code==0 else 'failed','exitCode':code,'durationSeconds':round(time.monotonic()-start,3),'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'logSha256':hashlib.sha256((base/row['log']).read_bytes()).hexdigest()})
 tail=(base/row['log']).read_text(errors='replace');row['testSummaries']=re.findall(r'(?:Tests|Test Files)\s+[^\n]+',re.sub(r'\x1b\[[0-9;]*m','',tail))[-12:]
 row['trackedSourceUnchanged']=subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()==''
 save();print('END '+check['id']+' '+str(code)+' '+str(row['durationSeconds'])+'s',flush=True)
ledger['state']='complete';ledger['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
print('COMPLETE '+str(len(checks))+' commands; failures '+str(sum(r['exitCode']!=0 for r in ledger['results'])),flush=True)
