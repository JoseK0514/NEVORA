from pathlib import Path
import subprocess,os,json,datetime,hashlib,time,re
root=Path('/Users/josek0514/.codex/worktrees/nevora-backend-phase5-20261116/Fuel Scheduler')
base=Path(__file__).parent
sha=json.loads((base/'final-source.json').read_text())['qualificationSha']
env={k:os.environ[k] for k in ['PATH','HOME','TMPDIR','USER','LOGNAME','SHELL','LANG','LC_ALL'] if k in os.environ}
env.update({'CI':'1','NEXT_TELEMETRY_DISABLED':'1','PUSH_FEATURE_ENABLED':'false','PUSH_DELIVERY_ENABLED':'false','PUSH_TEST_DELIVERY_ENABLED':'false','NEVORA_TEST_PG_BIN':'/Users/josek0514/Documents/Codex/2026-11-15/ple/work/pg-xml/runtime/bin','NEVORA_PLAYWRIGHT_RUNTIME_PACKAGE':str(root/'tools/ci-browser-runtime/package.json'),'PHASE_E_EXPECTED_SHA':sha,'PHASE_C_EXPECTED_SHA':sha,'NEVORA_BUILD_RECEIPT':str(base/'build-source.json'),'HOME_READINESS_EVIDENCE_DIR':str(base/'home-helper'),'NEVORA_READINESS_UI_EVIDENCE':str(base/'readiness-ui'),'NEVORA_READINESS_MATRIX_EVIDENCE':str(base/'readiness-matrix'),'NEVORA_MOBILE_ACCESS_EVIDENCE':str(base/'recovery-browser')})
checks=[]
def add(id,argv,extra=None): checks.append({'id':id,'argv':argv,'envOverrides':extra or {}})
add('source-inventory',['npm','run','check:development-sources'])
add('bootstrap',['node','scripts/onboarding-manifest.mjs'])
add('format',['npm','run','format:check'])
add('units',['npm','test','--','--maxWorkers=1','--reporter=default','--reporter=json','--outputFile='+str(base/'units.json')])
add('types',['node','node_modules/typescript/bin/tsc','--noEmit','--incremental','false'])
add('lint',['npm','run','lint'])
add('release-infrastructure',['npm','run','test:release-engineering'])
add('test-projects',['npm','run','check:test-projects'])
add('test-project-regressions',['npm','run','test:test-projects'])
add('notifications-qa',['npm','run','test:notifications:qa'])
add('foundation-qa',['npm','run','test:foundation:qa'])
add('production-absence',['npm','run','test:dev:production'])
add('inspection-evidence',['npm','run','check:inspection-evidence'])
add('manuals',['node','scripts/manuals/check-manuals.mjs'])
add('owned-pg-startup',['node','--test','scripts/phase-e-owned-startup.check.mjs'])
add('build',['node','scripts/release-build.mjs'])
add('home-helper',['node','--import','./scripts/qa-server-context.mjs','--import','tsx','scripts/phase-e-home-held-response.check.mjs'],{'NODE_ENV':'test'})
add('readiness-browsers',['node','scripts/payroll-postgres.mjs','vitest.all-ui-browser.config.mts','src/test/integration/readiness-ui-browser.integration.ts','src/test/integration/readiness-shift-concurrency-browser.integration.ts','--reporter=default','--reporter=json','--outputFile='+str(base/'readiness-results.json')],{'NODE_ENV':'test'})
add('commerce-recovery-browsers',['node','scripts/payroll-postgres.mjs','vitest.mobile-access-browser.config.mts','src/test/integration/commerce-recovery-browser.integration.ts','src/test/integration/commerce-recovery-effects.integration.ts','--reporter=default','--reporter=json','--outputFile='+str(base/'recovery-results.json')],{'NODE_ENV':'test'})
(base/'planned-commands.json').write_text(json.dumps(checks,indent=2)+'\n')
ledger={'source':sha,'state':'running','environment':'isolated fictional local; no provider/AI calls','results':[]}
def save():
 p=base/'ledger.tmp';p.write_text(json.dumps(ledger,indent=2)+'\n');p.replace(base/'ledger.json')
for check in checks:
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==sha
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip(),'Unexpected source dirt before '+check['id']
 row={**check,'source':sha,'state':'running','log':check['id']+'.log','startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()};ledger['results'].append(row);save();print('START '+check['id'],flush=True)
 start=time.monotonic()
 with (base/row['log']).open('wb') as f:
  child=subprocess.Popen(check['argv'],cwd=root,env={**env,**check['envOverrides']},stdout=f,stderr=subprocess.STDOUT);row.update({'supervisorPid':os.getpid(),'childPid':child.pid});save();code=child.wait()
 raw=(base/row['log']).read_bytes();clean=subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()==''
 row.update({'state':'passed' if code==0 else 'failed','exitCode':code,'sourceUnchanged':clean,'durationSeconds':round(time.monotonic()-start,3),'logSha256':hashlib.sha256(raw).hexdigest(),'testSummaries':re.findall(r'(?:Tests|Test Files)\s+[^\n]+',re.sub(r'\x1b\[[0-9;]*m','',raw.decode(errors='replace')))[-12:]});save();print('END '+check['id']+' '+str(code),flush=True)
ledger['state']='complete';save();print('COMPLETE',flush=True)
