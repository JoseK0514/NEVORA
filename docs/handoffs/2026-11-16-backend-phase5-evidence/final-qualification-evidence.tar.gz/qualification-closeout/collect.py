from pathlib import Path
import json, hashlib, shutil, tarfile

base = Path(__file__).parent
external = base.parent
repo = Path('/Users/josek0514/.codex/worktrees/nevora-backend-phase5-20261116/Fuel Scheduler')
assert json.loads((base/'ledger.json').read_text())['state'] == 'complete'
stage = base/'portable-evidence'
stage.mkdir(exist_ok=True)
selected = set()

def add(path):
    if path.is_file() and not path.is_symlink():
        selected.add(path)

# Actual results and failures, not disposable application/database copies.
for directory in [external/'final-qualification', base, base/'fixture-followup-1', base/'fixture-followup-2', base/'final-source-recheck', external/'final-qualification'/'clocker-browser-red']:
    for pattern in ['*.log', '*.json', '*.py']:
        for path in directory.glob(pattern):
            if not path.name.endswith('-draft.json') and path.name not in ['source-inventory-proposal.json', 'remaining-dependencies-draft.json', 'portable-file-index.json', 'final-evidence-manifest.json']:
                add(path)
for path in external.glob('*.log'):
    add(path)
for name in ['clocker-driver-reviewed', 'clocker-driver-response', 'clocker-driver-cancel']:
    directory = external/name
    for pattern in ['*.json', '*.log']:
        for path in directory.glob(pattern): add(path)
for directory in [external/'final-qualification'/'home-helper', base/'home-helper', base/'readiness-ui', base/'readiness-matrix', base/'recovery-browser']:
    if directory.exists():
        for path in directory.rglob('*.json'):
            relative = path.relative_to(directory)
            if not any(part.startswith('owned-next-') or part in ['app', '.next', 'node_modules'] for part in relative.parts): add(path)
for name in ['phase-e-sql', 'clocker-sql-1', 'clocker-sql-2', 'clocker-sql-3', 'clocker-sql-4']:
    directory = external/'final-qualification'/name
    for path in directory.glob('*.json'): add(path)

files = []
for path in sorted(selected):
    relative = path.relative_to(external)
    destination = stage/relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(path, destination)
    data = path.read_bytes()
    files.append({'archivePath':str(relative),'originalPath':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
reviews = [repo/'.omo/evidence/P4-AUTH-01-code-review.md', *sorted((repo/'.omo/evidence').glob('phase5-*.md'))]
for path in reviews:
    name = path.name
    destination = stage/'reviews'/name
    destination.parent.mkdir(exist_ok=True)
    shutil.copyfile(path,destination)
    data = path.read_bytes()
    files.append({'archivePath':'reviews/'+name,'originalPath':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
(base/'portable-file-index.json').write_text(json.dumps(files,indent=2)+'\n')
print(json.dumps({'stagedFiles':len(files),'bytes':sum(f['bytes'] for f in files),'directory':str(stage)}))
