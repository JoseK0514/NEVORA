from pathlib import Path
import os, subprocess, json, tempfile, socket, secrets, hashlib, time, datetime, signal

base=Path(__file__).parent
repo=Path('/Users/josek0514/.codex/worktrees/nevora-backend-phase5-20261116/Fuel Scheduler')
sha='76f08e5101a1f34fd9dc30cf68b9246fa92ee198'
assert json.loads((base/'ledger.json').read_text())['state']=='complete', 'Serialize after the active runner'
env={k:os.environ[k] for k in ['PATH','HOME','TMPDIR','USER','LOGNAME','SHELL','LANG','LC_ALL'] if k in os.environ}
env.update({'CI':'1','NODE_ENV':'test','NEXT_TELEMETRY_DISABLED':'1','PHASE_E_EXPECTED_SHA':sha,'NEVORA_TEST_PG_BIN':'/Users/josek0514/Documents/Codex/2026-11-15/ple/work/pg-xml/runtime/bin','PHASE_E_STARTUP_EVIDENCE_DIR':str(base/'startup-retry')})
results=[]
def terminate(signum, frame):
    raise InterruptedError('Owned supervisor received signal '+str(signum))
signal.signal(signal.SIGTERM, terminate)
signal.signal(signal.SIGINT, terminate)
def check_source():
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==sha
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True).strip()
def execute(name,argv,childenv):
    check_source()
    start=time.monotonic()
    with (base/(name+'.log')).open('wb') as stream:
        child=subprocess.Popen(argv,cwd=repo,env=childenv,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
        try:
            code=child.wait()
        except BaseException:
            # The live, unreaped child owns this newly created process group.
            # Never signal an arbitrary PID or a group after that custody is lost.
            if child.poll() is None:
                assert os.getpgid(child.pid)==child.pid
                os.killpg(child.pid,signal.SIGTERM)
                try: child.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    os.killpg(child.pid,signal.SIGKILL)
                    child.wait(timeout=5)
            raise
    check_source()
    row={'id':name,'argv':argv,'source':sha,'exitCode':code,'durationSeconds':round(time.monotonic()-start,3),'log':name+'.log','logSha256':hashlib.sha256((base/(name+'.log')).read_bytes()).hexdigest(),'sourceUnchanged':True}
    results.append(row)
    (base/'supplement-ledger.json').write_text(json.dumps({'source':sha,'results':results},indent=2)+'\n')
    print(name,code,flush=True)

execute('owned-pg-startup-retry',['node','--test','scripts/phase-e-owned-startup.check.mjs'],env)

# The default unit project discovers these existing SQL-gated tests but does not
# supply a database. Run only these cases, with the exact fixture-specific prefix.
for name,prefix,files in [
    ('withdrawal-notification-capacity','nevora_foundation_test_',[
        'src/lib/data/requests.withdrawal-carry-forward.test.ts',
        'src/test/integration/employee-notification-capacity.integration.test.ts']),
    ('coverage-repair','nevora_generation_test_',[
        'src/test/integration/coverage-repair.integration.test.ts'])]:
    check_source()
    root=Path(tempfile.mkdtemp(prefix='phase5-supplement-',dir=base))
    token=secrets.token_hex(16)
    (root/'owner').write_text(token)
    data=root/'data'
    with socket.socket() as listener:
        listener.bind(('127.0.0.1',0));port=listener.getsockname()[1]
    binary=Path(env['NEVORA_TEST_PG_BIN'])
    started=False
    def pg(command,args):
        with (root/'supervisor.log').open('ab') as stream:
            subprocess.run([str(binary/command),*args],cwd=repo,env=env,stdout=stream,stderr=subprocess.STDOUT,check=True,timeout=45)
    receipt={'source':sha,'kind':'new owned fictional loopback cluster, fixture-specific disposable prefix','prefix':prefix,'root':str(root),'data':str(data),'port':port,'supervisorPid':os.getpid(),'ownerDigest':hashlib.sha256(token.encode()).hexdigest(),'state':'ALLOCATED','started':False,'closed':False}
    receipt_path=base/(name+'-ownership.json')
    def persist():
        temporary=receipt_path.with_suffix('.tmp')
        temporary.write_text(json.dumps(receipt,indent=2)+'\n')
        temporary.replace(receipt_path)
    persist()
    try:
        pg('initdb',['-D',str(data),'-U','nevora_test','--auth-local=trust','--auth-host=trust','--encoding=UTF8','--no-locale'])
        receipt['state']='STARTING';persist()
        pg('pg_ctl',['-D',str(data),'-l',str(root/'postgres.log'),'-w','start','-o',f"-h 127.0.0.1 -p {port} -k ''"])
        started=True;receipt.update({'started':True,'state':'RUNNING'});persist()
        childenv={**env,'FUEL_TEST_DATABASE_URL':f'postgresql://nevora_test@127.0.0.1:{port}/{prefix}p5_{token[:12]}','FUEL_TEST_ALLOW_DESTRUCTIVE_TEARDOWN':'yes'}
        argv=['node','node_modules/vitest/vitest.mjs','run','--config','vitest.unit.config.mts','--maxWorkers=1',*files,'--reporter=default','--reporter=json','--outputFile='+str(base/(name+'-results.json'))]
        execute(name,argv,childenv)
    finally:
        # A repeated termination request must not interrupt closure recording.
        signal.signal(signal.SIGTERM,signal.SIG_IGN)
        signal.signal(signal.SIGINT,signal.SIG_IGN)
        receipt['state']='STOPPING';persist()
        try:
            assert (root/'owner').read_text()==token, 'Lost owned cluster custody'
            if started or (data/'postmaster.pid').exists():
                pg('pg_ctl',['-D',str(data),'-w','stop','-m','fast'])
            receipt['closed']=not (data/'postmaster.pid').exists()
            receipt['state']='CLOSED' if receipt['closed'] else 'CLOSURE_UNVERIFIED'
            assert receipt['closed'], 'Owned cluster closure unverified'
        except BaseException as error:
            receipt.update({'state':'CLOSURE_UNVERIFIED','closed':False,'closureErrorClass':type(error).__name__})
            raise
        finally:
            persist()
            signal.signal(signal.SIGTERM,terminate)
            signal.signal(signal.SIGINT,terminate)
print('SUPPLEMENT COMPLETE',flush=True)
