from pathlib import Path
import subprocess,os,json,time,hashlib,re
b=Path(__file__).parent;r=Path('/Users/josek0514/.codex/worktrees/nevora-backend-phase5-20261116/Fuel Scheduler');sha=json.loads((b/'final-source.json').read_text())['qualificationSha'];env={k:os.environ[k] for k in ['PATH','HOME','TMPDIR','USER','LOGNAME','SHELL','LANG','LC_ALL'] if k in os.environ};env.update({'CI':'1','NEXT_TELEMETRY_DISABLED':'1','PHASE_E_EXPECTED_SHA':sha,'NEVORA_BUILD_RECEIPT':str(b/'build-source.json')})
checks=[('source-inventory',['npm','run','check:development-sources']),('types',['node','node_modules/typescript/bin/tsc','--noEmit','--incremental','false']),('lint',['npm','run','lint']),('format',['npm','run','format:check']),('release-infrastructure',['npm','run','test:release-engineering']),('manuals',['node','scripts/manuals/check-manuals.mjs']),('default-gated-fixtures',['npm','test','--','--maxWorkers=1','src/test/integration/employee-notification-capacity.integration.test.ts','src/test/integration/coverage-repair.integration.test.ts','--reporter=default','--reporter=json','--outputFile='+str(b/'default-gated-fixtures-results.json')]),('build',['node','scripts/release-build.mjs'])]
l={'source':sha,'state':'running','results':[]}
for name,argv in checks:
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==sha
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=r,text=True).strip()
 row={'id':name,'source':sha,'argv':argv,'state':'running'};l['results'].append(row);(b/'ledger.json').write_text(json.dumps(l,indent=2)+'\n');print('START',name,flush=True);start=time.monotonic()
 with (b/(name+'.log')).open('w') as f:code=subprocess.call(argv,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT)
 row.update({'state':'passed' if code==0 else 'failed','exitCode':code,'durationSeconds':round(time.monotonic()-start,3),'log':name+'.log','logSha256':hashlib.sha256((b/(name+'.log')).read_bytes()).hexdigest(),'sourceUnchanged':not subprocess.check_output(['git','status','--porcelain'],cwd=r,text=True).strip()});(b/'ledger.json').write_text(json.dumps(l,indent=2)+'\n');print('END',name,code,flush=True)
l['state']='complete';(b/'ledger.json').write_text(json.dumps(l,indent=2)+'\n');print('FINAL SOURCE CHECKS COMPLETE',flush=True)
