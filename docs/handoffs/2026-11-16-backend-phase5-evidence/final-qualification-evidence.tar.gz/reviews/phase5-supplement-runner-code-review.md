External supplement.py supervision and teardown review

Code quality BLOCK. Recommendation REQUEST_CHANGES pending the ownership-receipt fix. This assessment covers the runner at qualification-closeout/supplement.py as inspected before execution. The tests were not run by the reviewer.

CRITICAL — None.
HIGH — At supplement.py:47–61 the owner receipt is first written after a successful pg_ctl stop. Ordinary supervisor SIGTERM bypasses Python finally by default. A pg_ctl stop exception also exits the finally block before recording the result. The runner can leave an owned database running with no per-cohort receipt identifying its data directory or unverified closure. Persist the location, port and owner digest before starting the server, update its started state, direct normal termination through cleanup, and persist failed closure status when shutdown fails. Surface any unverified shutdown as a failure. Preserve marker verification before stopping a process.
MEDIUM — None in the requested supervision scope.
LOW — None.

The approved binary reports PostgreSQL 16.15. The private mkdtemp root is unique per cohort. PostgreSQL binds TCP loopback with Unix sockets disabled. The child environment is constructed from an allowlist and the temporary connection URL uses 127.0.0.1 on the allocated port. Both withdrawal and capacity invoke createDisposableFoundationDatabase with nevora_foundation_test_; coverage repair invokes createDisposableGenerationDatabase with nevora_generation_test_. The generated p5_ suffix and 12 hex characters satisfy the adapter. It rejects an existing database and verifies its own database marker before dropping a fixture. The runner additionally checks its separate root marker and uses pg_ctl -D against that root's data subdirectory. Retaining stopped data is consistent with the task.

Evidence: /Users/josek0514/.codex/visualizations/2026/11/16/01a1e554-32a4-75e1-b3f2-a5ac5dde811c/qualification-closeout/supplement.py and src/test/integration/local-postgres.ts at lines 72, 211 and 218 in the 76f08e510 frozen worktree. Programming and remove-ai-slops perspectives consulted in this review thread. The finding concerns resource ownership across process failure. No unnecessary production parsing, fixture abstraction or test mutation was introduced.
