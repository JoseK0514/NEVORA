#3.8 and3.9 complete local checkpoint

C-12 setup accepted first, then C-13device lifecycle/A-04receipt lookup and connectedSection3 gate. See CURRENT-STATE.md, outputs/owner-clocker/review.md and acceptance-sequence.json. Original NEXT-BATCH-3.8 preserved in outputs/owner-clocker/before-inventory. Next NEXT-BATCH-4.1.md. No actual integration/device activation/deployment.
