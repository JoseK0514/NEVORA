# Independent whole-slice review — Owner mobile 3.6 C-08/C-09

**Verdict: WITH FIXES / HOLD this bounded mockup slice.** One Important finding and two Minor findings. No Critical finding demonstrated. The Important finding prevents approval of the supported enlarged-text editor; the two Minor findings remain visible for executor disposition. This is the single independent review, not a production, backend, security, physical-device or assistive-technology certification.

Reviewed artifact SHA256: `df24ebc62af39073b4f6aff1ee297768903b9205e7a421aa47e159ab962ce949`. Baseline: `65f2a5d5cbb596f90a2d08adb2fca30c869e1142e8325e9d25f23326e70d1c64`. Review performed 2026-10-27 against the frozen local artifact at `127.0.0.1:18763`. Canonical implementation and historical evidence were read-only; all reviewer scripts/results are in this directory. No Git mutation, services, application integration or implementation edits occurred.

## Strengths and plan alignment

The implementation keeps the full policy snapshot separate from focused presentation. The mechanically adapted pinned parsers enforce field families, strict thresholds, private labor distinctions and business-time semantics. History chooses the highest revision, strips invalid settings, and never makes an older revision current. The local store preserves operation identity and rejects current inactive-scope writes/replays before permitting replay. Confirmed and ambiguous saves remain distinct.

The whole-review/replacement/conflict flows preserve private lexical values. Independent tests exercised nonempty rates/budgets, not just the seeded null/empty values. Authority changes during read, save acknowledgement and pause clear protected state. A paused save followed by a newer revision recovers the original revision while showing the newer current revision without another write. Scope and raw-form drafts have separate departure boundaries. Settings/More return paths and revision deep links passed; location return focus is the exception below.

The accepted neutral surfaces, native controls, type roles and task navigation are retained. Baseline comparison found only the four declared modified files (`app.js`, `company.js`, `locations.js`, `build.py`) and six policy additions. Other canonical files are byte-identical. No significant scope expansion was found.

## Findings

### Important — R1: Effective date/time cannot be fully read at supported enlarged sizes

- **Location:** `work/owner-mobile/policies.js:33` and `:35`; native datetime field rendering and lack of readable-value fallback. The scoped select fallback at `:34` does not cover this input.
- **Reproduce:** Open Policies → Late arrivals, use 200% root text at 320px or 390px, focus Effective from. The stored native value is `2026-10-01T08:00`. At 320px the control shows the date plus the beginning of the hour while the rest of the time is clipped; at 390px the AM/PM segment is clipped. Tab/segment focus can move which part is clipped. The executor's `rule-320-200.png` also clips the beginning of the date after filling the input.
- **Evidence actually inspected:** `date-320-200.png`, `date-390-200.png`, `date-430-200.png` and corresponding JSON measurements. At 430px this particular value fits. The independent probes assert preservation of the native value, not visual completeness; the screenshots establish the failure. No readable full-value text exists beside the control.
- **Owner effect:** A person using enlarged text cannot verify the complete effective date and time in the editor. This is a meaningful review/editing barrier for a field that determines when the policy applies. DOM overflow checks and minimum control sizes do not detect native internal clipping.
- **Recommended fix:** Keep the native input and add a wrapping full date/time value, including AM/PM or unambiguous 24-hour time and the company-zone context, that updates with current raw input. Alternatively use a native layout that fits all segments at the supported sizes. Verify changed values and keyboard focus at 320/390/430px, 100/200%, across the supported engines.

### Minor — R2: Inherited explicit Off is described as Not set

- **Location:** `work/owner-mobile/policies.js:31`, `inheritedRule ? stateText(inheritedRule) : 'Not set'`.
- **Reproduce:** Fresh policies → select `location-1` → read Early departures. The company setting is explicitly `null` (Off), but the row says `Follows company · Not set`.
- **Evidence:** Failed expectation in `probes-corrected.json` and `inherited-off.png`. The test expected `Follows company … Off` and observed `Follows company · Not set`.
- **Owner effect:** The summary misstates deliberate company disablement as missing configuration. Graded Minor because the underlying inheritance and saved value remain correct, both states currently produce no alert, and the company scope can be inspected. It is still a distinct-state requirement and should be corrected.
- **Recommended fix:** Pass the inherited value through the existing undefined/null-aware `stateText` function rather than using truthiness; retain the unavailable-company branch.

### Minor — R3: Returning to the location loses the initiating control focus

- **Location:** `work/owner-mobile/app.js:504`, location-return branch calls `locationsUI.open(...)` without restoring focus after its asynchronous refresh.
- **Reproduce:** Locations → search Aguada → open Aguada → Operational policies → Back. Location detail and directory query return correctly, but focus lands on `BODY`, not Operational policies.
- **Evidence:** `location-focus.json` (`tag: BODY`, empty ID) and the failed focus expectation in `probes-corrected.json`.
- **Owner effect:** Keyboard users lose their place and must traverse back to the contextual action. Graded Minor because the correct location/query return, all controls remain reachable, and no draft or write is lost. It nevertheless misses the explicit exact-return-focus requirement.
- **Recommended fix:** Restore `[data-lo-action=policies]` after the location detail has completed its read/render; preserve return scroll and handle unavailable-location fallback deliberately.

## Verification actually performed

- Independently reran the unchanged assertions in **20 model checks: 20 passed** (`model.log`). The copied runner only changes its root resolution.
- Independently reran **28 Chromium policy journeys: 28 passed** (`browser-rerun.log`, `browser-chromium.json`). Copy changes only the report destination. Initial `browser.log` records a missing Playwright module caused by my first NODE_PATH; the rerun uses the installed path recorded in environment.json. This was a harness setup failure, not a product failure.
- Added **12 focused browser probes: 10 passed, 2 failed** (`probes-corrected.json`). The two failures are R2/R3. Three passing probes capture native date values/screenshots; their pass does not assert visual completeness, and R1 comes from actual image inspection. The original `probes.json` also records a premature assertion against the loading state during async read; the corrected runner waits for the expected terminal access-ended state without changing the requirement. Original failure evidence remains.
- Added **3 browser cases: 3 passed** (`additional.json`): skipped/ambiguous New York DST selections preserve raw entries and cannot apply; invalid company defaults remain unavailable while location overrides remain readable; authority loss during pause clears retained private state.
- Independently checked all four pinned import hashes, vendor bytes/hash and ISC license against the installed Temporal 0.5.1 package: **7 passed** (`provenance.json`). Inspected the mechanical adapter and source parser/history/time/service/route boundaries. Did not rerun its source-writing import script.
- Independently compared baseline/current canonical filenames and bytes (`source-diff.json`). Artifact hash remained unchanged.
- Inspected executor final matrix: all seven commands exit zero with before/after hashes matching the candidate; **20 models, 10 source checks, 84 policy browser cases across Chromium/Firefox/WebKit, 19 focus observations, 43 captures**. Reviewed capture/contrast records (minimum reported text contrast 5.0289:1) and preserved neighbor logs (**35 Chromium + 19 model**, executor-run). Those are inspected executor evidence, not independent reruns.
- Actual images inspected: independent `inherited-off.png` and all three date images; executor `main-390-100.png`, `rule-320-200.png`, `rule-tail-320-200.png`, `private-390-200.png`, `replacement-tail.png`, `history-430-200.png`, and `rule-430-100.png`. The supported-size capture matrix was checked as recorded evidence; I do not claim visual inspection of every frame.

## Code quality

**WATCH.** Model/store/view separation and narrowly scoped integration are sound for this preview. The new handwritten policy controller compresses substantial state transitions and large templates into single lines, making future changes harder to review. This did not establish another functional blocker. Prefer readable functions and named transition helpers when maintaining this controller; avoid broad refactoring merely to close this bounded review.

## Behaviors considered and set aside — executor must dispose each line

- Real server authorization, transaction locks, receipt/replay races and persistence: this is an explicitly in-memory simulation; source-contract inspection is not backend verification.
- Real employee/customer/pay data, operational recomputation, payroll arithmetic, notifications and message delivery: unauthorized here and deliberately absent; policy changes correctly leave seeded operational neighbors unchanged.
- Physical iPhone/Android keyboards, native OS picker popovers, actual VoiceOver/TalkBack and OS text scaling: browser engine emulation is insufficient; these remain separate acceptance work. R1 is a demonstrated browser failure and is **not** set aside under this limit.
- Browser back/forward history-stack semantics and durable restoration of unsaved drafts after reload: the existing standalone mockup uses replaceState and explicitly loses in-memory changes on reload; internal Back/deep-link context and dirty departure were reviewed instead.
- Malformed server history metadata (for example an invalid changedAt outside the typed revision-row contract): not generated by the current store or reached through an Owner action; invalid **settings** in valid metadata were reviewed and tested.
- Peak histories/rate arrays at parser maximum cardinality and sustained performance: no performance acceptance workload exists for this local preview; source maximums are not a demonstrated responsiveness guarantee.
- Manager/Employee/public policy projection and app-level private-data enforcement: this task is Owner-only; no public projection was introduced. In-memory preview globals are not an authorization boundary.
- Prior 3.5 live-resize sticky-clearance issue and unrelated historical screens: remain historical scope; no independent new material failure was shown there.
- Later roadmap groups 3.7–3.9, complete Clocker/Updates/statements, Spanish dictionaries, production integration, deployment and release: outside C-08/C-09 and not certified.

**Bounded assessment:** The policy state model and tested recovery paths are substantially aligned with the plan, but the effective-date editor needs repair before this slice meets its supported enlarged-text requirement. Resolve R1, disposition R2/R3 explicitly, and rerun the focused regressions plus final-source verification. No merge/deployment is requested or approved by this review.
