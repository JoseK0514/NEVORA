const fs=require('fs'),vm=require('vm'),assert=require('node:assert/strict');
const checks=[],root='work/owner-mobile/',delay=ms=>new Promise(r=>setTimeout(r,ms));
function boot(){
 const handlers={},winHandlers={},nodes=new Map(),out={html:'',parent:null,root:null},fieldValues=new Map();let page='clocker',clock=Date.parse('2026-10-27T12:00:00Z'),authority='owner-one';
 const content={style:{setProperty(){}},get innerHTML(){return out.html},set innerHTML(v){out.html=v;nodes.clear();},getBoundingClientRect:()=>({height:84})};
 const node=key=>{if(!nodes.has(key))nodes.set(key,{id:key.replace('#',''),value:fieldValues.get(key)||'',scrollTop:0,style:{setProperty(){}},dataset:{},focus(){out.focus=key},matches:()=>false,closest:selector=>selector==='.form-field'?{getBoundingClientRect:()=>({top:150,bottom:200,height:50})}:null,getBoundingClientRect:()=>({top:0,bottom:844,height:84}),setSelectionRange(){},select(){out.selected=true},scrollHeight:80});return nodes.get(key)};
 const $=selector=>{if(selector==='#home-content')return content;if(selector==='#app-scroll')return node(selector);if(selector.includes('h1'))return out.html.includes('<h1')?node(selector):null;const id=selector.match(/#([\w-]+)$/)?.[1];if(id)return out.html.includes('id="'+id+'"')?node('#'+id):null;return node(selector)};
 const document={visibilityState:'visible',hasFocus:()=>true,activeElement:null,addEventListener:(k,f)=>(handlers[k]??=[]).push(f),querySelector:$,fonts:{ready:Promise.resolve()}};
 const context=vm.createContext({console,URL,Date,Intl,Math,JSON,Number,String,Boolean,Array,Object,Set,Map,RegExp,Promise,CSS:{escape:s=>s},navigator:{onLine:true,clipboard:{writeText:async()=>{}}},location:{href:'http://127.0.0.1:18763/nevora-owner-mobile.html?page=clocker'},history:{replaceState:(_,__,u)=>context.location.href=String(u)},document,window:{addEventListener:(k,f)=>(winHandlers[k]??=[]).push(f)},setTimeout:(fn,ms)=>{const timer=setTimeout(fn,ms);if(ms>=1000)timer.unref();return timer},clearTimeout,setInterval:()=>0,clearInterval(){},requestAnimationFrame:f=>f(),ResizeObserver:class{observe(){}disconnect(){}}});
 for(const name of ['clocker-store.js','clocker-enrollment.js','clocker-devices.js'])if(fs.existsSync(root+name))vm.runInContext(fs.readFileSync(root+name,'utf8'),context,{filename:name});
 assert.equal(typeof context.createOwnerClockerDevices,'function','the Owner device controller must be implemented');
 assert.equal(typeof context.createOwnerClockerStore,'function','the shared real device model must be available');
 const locations=[{id:'location-1',key:'arecibo',name:'Arecibo',shortName:'Arecibo',clockerKey:'arecibo',active:true},{id:'location-2',key:'isabela',name:'Isabela',shortName:'Isabela',clockerKey:'isabela',active:true}];
 const store=context.createOwnerClockerStore({gate:()=> 'ready',authority:()=>authority,now:()=>clock,locations:()=>locations,context:()=>({timeZone:'America/Puerto_Rico'})});
 const api={escapeHTML:s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])),icon:()=>'<svg aria-hidden="true"></svg>',$,page:()=>page,scroll:()=>node('#app-scroll'),navigate:v=>{page=v},header(){},origin:()=>({location:0,parent:'settings',query:'',feature:'clocker',scroll:0}),parent:o=>{out.parent=o;page='settings'},root:v=>{out.root=v;page=v},openLocations:o=>{out.locations=o;page='locations'}};
 const ui=context.createOwnerClockerDevices(api,store);
 const send=(kind,target)=>{const e={target,preventDefault(){},stopImmediatePropagation(){}};for(const f of handlers[kind]||[])f(e)};
 const click=action=>send('click',{disabled:false,dataset:{clockerAction:action},closest(){return this}});
 const choose=id=>send('click',{disabled:false,dataset:{clockerId:id},closest(){return this}});
 const input=(id,name,value)=>{fieldValues.set('#'+id,value);send('input',{id,name,value,closest(){return this}})};
 const change=(id,value)=>send('change',{id,value,closest(){return this}});
 const submit=id=>send('submit',{id,closest(){return this}});
 const lifecycle=event=>{for(const f of winHandlers[event]||[])f({target:context.window})};
 return {ui,store,out,locations,click,choose,input,change,submit,lifecycle,clockBy:ms=>clock+=ms,authority:v=>authority=v,context};
}
async function test(name,fn){try{await fn();checks.push({name,pass:true})}catch(e){checks.push({name,pass:false,error:e.message})}console.log(JSON.stringify(checks.at(-1)))}
(async()=>{
 async function registered(h){h.ui.open({view:'add'});await delay(160);h.input('clocker-name','name','Review tablet');h.change('clocker-location','location-1');h.submit('clocker-add-form');}
 await test('late register callback hides code when device was revoked before handoff',async()=>{const h=boot();await registered(h);h.store.previewDevice('device-5',{state:'REVOKED',version:2,enrollmentExpiresAt:null});await delay(240);assert.equal(h.ui.snapshot().hasSetupCode,false);assert.ok(!h.out.html.includes('SAMPLE-ONLY_nev_enr_'));});
 await test('late register callback hides code when location becomes inactive before handoff',async()=>{const h=boot();await registered(h);h.locations[0].active=false;await delay(240);assert.equal(h.ui.snapshot().hasSetupCode,false);});
 await test('late register callback after blur remains private and unknown',async()=>{const h=boot();await registered(h);h.lifecycle('blur');await delay(240);assert.equal(h.ui.snapshot().hasSetupCode,false);assert.equal(h.ui.snapshot().unknown,true);assert.equal(h.store.snapshot().writes,1);});
 await test('late register callback after authority change remains private',async()=>{const h=boot();await registered(h);h.authority('other-owner');await delay(240);assert.equal(h.ui.snapshot().hasSetupCode,false);assert.equal(h.ui.snapshot().connection,'denied');});
 await test('background renewal clears code for inactive location',async()=>{const h=boot();await registered(h);await delay(240);h.locations[0].active=false;h.clockBy(35000);h.ui.previewTick();assert.equal(h.ui.snapshot().hasSetupCode,false);});
 fs.writeFileSync('outputs/owner-clocker/independent-review/additional-controller.json',JSON.stringify({checks,passed:checks.filter(c=>c.pass).length,failed:checks.filter(c=>!c.pass).length},null,2));
})();