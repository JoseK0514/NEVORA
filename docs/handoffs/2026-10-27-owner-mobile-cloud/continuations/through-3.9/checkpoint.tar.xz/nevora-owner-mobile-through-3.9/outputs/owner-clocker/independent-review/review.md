# Independent whole-pair review — original frozen candidate

**Verdict: WITH FIXES. Critical: 0. Important: 2. Minor: 0.** The two Important findings must be dispositioned and repaired before accepting 3.8, 3.9 and the connected Section 3 gate. This is a standalone MOBILE OWNER mockup review, not approval for application integration, merge, deployment or real tablet activation.

Reviewed artifact SHA-256: `824432b53a6e5cccbd48f9b61e4ca9a6a4e2cbedefd3c470c54f28f8955aaea4`.
Accepted 3.7 baseline: `eb46b93e000698263da10213df2a482fcd318a05c0993363564d96738ebf47e9`.
Pinned read-only application: `46e202786863279302026ee03a0e225c359fa55c`.
Review date: 2026-10-27 UTC.

This is the single fresh independent review of both batches. No subagents or additional reviewers were used. Only this new independent-review directory was written. Canonical implementation, generated artifact, inventory, historical reports, reference source and Git state were not edited. All 82 canonical file hashes still matched review-source.json at the final audit. Later author repairs must retain this original report and receive a separate disposition; this verdict does not approve later bytes.

## Scope and strengths

Read the review package, AGENTS/START-HERE/current checkpoint, working agreements, accepted design, Section 3 roadmap and gates, brief/plan/interfaces/ledger and all three worker contracts. Inspected the eight changed JavaScript files, two scoped style files, build wiring and baseline integration diffs. Compared the owning pinned device manager, action handler, device server, view allowlist, setup transport, receipt component, receipt API and receipt reader contracts.

The division between shared mutation store, device controller, pure enrollment renderer and read-only receipt store is sound. REGISTER/ROTATE/RENAME/REVOKE retain immutable identity and version checks. Pending setup is distinct from Registered; inactive locations block new enrollment while preserving rename/revoke. Unknown results require a fresh read and an explicit next action rather than replay or recovery of a lost token. Sample codes are visibly unusable for real enrollment and absent from ordinary reads and debug snapshots. Private view cleanup and ordinary draft retention have substantial focused coverage. Root integration preserves Location, Settings, Team and exact Timecards return context without introducing a second application shell.

Scoped focus scrolling repairs the previously observed device outer-frame shift. Independently exercised native Rename focus at all six 320/390/430 × 100/200 combinations kept the outer frame at zero scroll, task header visible and document width contained. The inspected captures retain the accepted typography, neutral surfaces, teal actions and native fields.

## Important findings

### I-01 — Delayed successful enrollment can display a code already contradicted by the fresh device read

**Location:** `work/owner-mobile/clocker-devices.js:152` and `:153`; shared REGISTER/ROTATE success handling.

After execute returns, save waits 200 ms. It then reads current devices but installs `result.setup` whenever any ready payload exists. It does not require the corresponding current device to retain the result's version, PENDING state and enrollment expiry, or its location to remain active. The later metadata-renewal path performs those checks; the initial handoff does not.

Reproduction on the frozen candidate: submit Add for location-1; before the delayed completion runs, update newly created device-5 to version 2 / REVOKED / null enrollment expiry through the existing simulation adapter. The successful fresh read contains that revoked device, yet the UI says “Sample code ready,” renders its old setup code and reports `hasSetupCode: true`. Independently reproduced both in the controller harness and Chromium. A second controller probe deactivating the location during the same interval also retained the code. This is not an assertion about a real server or operational attack.

**Owner effect:** the Owner is instructed to hand off an obsolete setup code even though this same view already knows its device was revoked or its location became inactive. It violates the current-source protection applied during subsequent renewal. The stale handoff can remain until renewal, rather than being a single rendering frame.

**Repair:** before installing the immediate code, reconcile the successful result against the fresh row using the same identity/version/state/expiry/active-location predicate as renewal, plus current authority/access and expiry. Keep truthful acknowledgement of the earlier command while explaining that the code is no longer current; do not replay or retrieve a token. Add REGISTER and ROTATE regressions for revocation/version replacement and inactive location between execution and handoff. Existing blur/authority interruption controls passed independently.

Evidence: [additional-controller.json](additional-controller.json), [additional-browser.json](additional-browser.json), [revocation-race.json](revocation-race.json), [actual handoff capture](revocation-race.png). The evidence JSON contains metadata only, not a copied code value.

### I-02 — Receipt lookup retains the original tablet name after a confirmed rename

**Location:** `work/owner-mobile/clocker-receipts-store.js:9`, `:24` and `:26`; integration provider at `work/owner-mobile/app.js:527`.

The receipt fixture retains the string `Front counter tablet` and never joins the current device store. Person and location names are refreshed, but the device label is not. The pinned `reference/application/src/lib/clocker/recovery-review.server.ts` explicitly projects `d.name` from the current device joined by immutable device identity; the worker contract also describes current joined person/device/location labels.

Reproduction in Chromium: rename device-1 to “Renamed counter tablet” through its normal UI and wait for confirmed success. Open receipt lookup in the same preview session and check `4a9c7ed1-9b42-4dc0-8847-324d7ade7832`. Device management reads the new name; the fresh receipt still reports “Front counter tablet.” This is a connected whole-pair defect absent from the separate label tests.

**Owner effect:** a freshly checked receipt names a tablet differently from the current device directory, making identification and assisted troubleshooting misleading after an ordinary supported rename. Punch/action/person/time identity is unchanged; no time mutation or corruption was observed.

**Repair:** store the receipt's immutable device identity and join its current label through a read-only shared provider. Preserve historical receipt access for revoked devices/inactive locations; fail clearly if a required joined source cannot be confirmed. Add a normal UI rename → fresh receipt check regression, and verify revoke does not erase recorded history. Do not add a punch writer or credential exposure.

Evidence: [receipt-name-probe.json](receipt-name-probe.json), [renamed-device-receipt.json](renamed-device-receipt.json), [reproduction script](receipt-name-probe.cjs).

## Checks actually run by this reviewer

| Independent execution | Result |
| --- | --- |
| Shared device model | 22 passed / 0 failed |
| Receipt model | 17 passed / 0 failed |
| Receipt view model | 3 passed / 0 failed |
| Existing device controller | 9 passed / 0 failed |
| Existing Chromium setup journeys | 29 passed / 0 failed |
| Existing Chromium device journeys | 21 passed / 0 failed |
| Existing Chromium receipt journeys | 27 passed / 0 failed |
| Existing Chromium connected seams | 5 passed / 0 failed |
| Additional controller probes | 3 passed / 2 failed, both I-01 triggers |
| Additional Chromium probes | 6 passed / 2 failed, I-01 and I-02 |
| Changed JavaScript syntax | 8 files passed |
| Frozen-source audit | 82 canonical files match; artifact hash matches |

Behavioral total: **142 passed / 4 failed assertions across 146 cases**, with the four failed assertions representing the two Important findings above. Existing tests contribute 133 passing cases; new probes contribute 9 passing and 4 failing cases. Syntax/hash verification is listed separately, not inflated into behavioral case totals.

All executions used local fictional state. Copied existing browser tests preserve assertions and adapt only output paths and relocated project-root resolution. The first receipt/setup copy attempt resolved the root incorrectly and failed before test execution with ENOENT; the path correction and initial harness failure are documented in [audit.json](audit.json). The subsequent complete runs passed. Existing failures, earlier author evidence and source snapshots remain preserved. Additional RED probes deliberately record failed expectations in JSON; their process completion alone is not a pass. See [final-audit.json](final-audit.json) for end-of-review hashes and syntax results.

The executor's separate `candidate2/commands.json` was inspected: all 29 recorded commands exited zero with matching before/after hashes. Executor totals are 368 full browser journeys (87 setup + 63 devices + 81 receipts + 15 seams + 122 neighbors), plus separately counted 45 renderer and 90 device-layout cases, 42 model + 9 controller + 10 source checks. The neighbor total covers Locations 49, Setup 16, Triage 29 and Policies 28. These are inspected executor records, **not independent reruns** of Firefox/WebKit, neighbor suites, renderer/layout suites, source checks or contrast sampling. Their success does not invalidate the new failing probes.

## Visual inspection and considered behavior

Actually opened candidate2 images for Add 320/200, code 390/100, receipt 320/200, device 320/200, replacement 390/200, directory 430/100, no-location, denied, unavailable and the capture named not-recorded-320-100. Also opened independently generated long-person receipt facts at 320/200 and 430/200, plus the obsolete-code reproduction capture. Narrow layouts require vertical scrolling; no newly demonstrated text overlap, unreadable code wrapping or material shell shift was found in these inspected views. The capture named not-recorded-320-100 actually catches “Checking…”; it is loading evidence, not proof of the final empty state. The independent receipt suite separately verifies the final not-recorded outcome.

| Behavior considered | Disposition and basis |
| --- | --- |
| Owner/current authority, source unavailable and access end | Reviewed and covered by model/controller/browser checks; no additional material finding. |
| Current version and active-location write guards | Reviewed against pinned actions/server and passing model cases. Initial handoff inconsistency is I-01. |
| REGISTER pending vs registered; ACTIVE/setup/revoked filter counts | Source-aligned and independently exercised. |
| Rename identity/location/history; replacement/reconnect/revoke consequences | Source-aligned command shape and normal journeys; receipt label seam is I-02. |
| Inactive locations | Rename/revoke remain allowed; registration/rotation blocked. Post-execution handoff change is I-01. |
| Unknown-before/after, duplicate submit, deliberate current-read recovery | Existing independent suites pass; no invented replay/token retrieval. |
| Code storage, URL/debug leakage, hide/expiry/blur/offline/pagehide/navigation | Inspected and covered by independent setup suite; no new finding beyond I-01. |
| Late save and clipboard callbacks | Existing setup coverage plus independent blur/authority probes pass; obsolete fresh metadata at handoff fails I-01. |
| Known-code metadata renewal | Same-version renewal preserves known code/selection; changed version, inactive location and failed read clear it in independent probes. |
| Ordinary draft retention, dirty departure and conflict review | Existing independent device/controller journeys pass. |
| No active location and return from owning Locations | Existing independent setup/seam journeys pass, including supported reload. |
| UUID validation, no-result wording, distinct action kinds | Existing model/receipt journeys pass; no fabricated success or corrective write. |
| Receipt validity/authority/pause/reference-edit retirement | Existing model/receipt journeys pass. |
| Current company time zone and exact person/performed-date week | Source inspected; independent receipt/seam journeys pass, including Timecards reload return. |
| Location/More/Settings/Team query/filter/focus and safe route context | Integration inspected and independent journeys exercised; no additional material defect. |
| Long names, enlarged native fields/code and sticky task headers | Actual captures plus independent browser checks inspected; repaired device outer-frame probe passes all six sizes. |
| Accepted visual tokens/controls and neighboring workflow integrity | No broad redesign in diff. Executor neighbor records inspected; focused integration independently exercised. |

## Behaviors considered and set aside from this verdict

- Real enrollment redemption, cookies, session/origin/SQL transaction enforcement and actual tablet activation: pinned contracts were read to establish semantics, but operational integration is explicitly unauthorized and absent.
- Real employee/customer/pay data, delivery/messages, production credentials and operational APIs: explicitly outside this standalone fictional preview; no such actions performed.
- Real iPhone/Android software keyboards, VoiceOver/TalkBack and physical safe-area behavior: browser viewport/native-keyboard tests cannot certify those; remain separate acceptance states.
- Durable persistence or cross-browser synchronization of mockup state: reload reset is disclosed and intentionally scoped; this does not excuse within-session I-01/I-02.
- Employee/Manager kiosk or mobile workflows: this pair is Owner-only, even where the real receipt reader also supports Managers.
- Git publication, merge/deployment, database migrations and application checkout changes: not authorized or needed for this review; no readiness claim made for them.
- A global design/shell redesign, including the existing enlarged bottom-navigation footprint: accepted system is the baseline; judged only material regressions in these tasks, with no new regression demonstrated by the inspected captures/probes.
- Exhaustive physical accessibility, every possible browser/viewport and all prior roadmap functionality: bounded local evidence only; independently reran the stated Chromium/model subset and inspected the executor matrix rather than claiming exhaustive certification.

## Assessment

**Local mockup acceptance: WITH FIXES.** Keep 3.8/3.9 and the connected Section 3 gate open until both Important findings receive the single combined author repair/disposition and meaningful final-source verification. Preserve this original review and its RED evidence. The implementation otherwise follows the bounded plan and accepted system; no additional review seat or broad redesign is recommended.
