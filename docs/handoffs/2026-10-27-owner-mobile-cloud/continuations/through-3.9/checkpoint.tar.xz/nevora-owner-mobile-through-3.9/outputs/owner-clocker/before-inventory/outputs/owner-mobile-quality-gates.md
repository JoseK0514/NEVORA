# Owner mobile phase completion standard

Standing user instruction recorded October27,2026: finish the current phase, verify it, then continue to the next phase in order. Routine transitions within the Owner mobile mockup do not need another permission request. The accepted design foundation remains in force.

A phase can advance only when:

1. Every planned batch in that phase is complete, with no known unresolved material findings or failed required checks.
2. Its connected Owner journeys work from entry through action/result and back, including dates, people, locations, filters, focus and relevant deep links.
3. Actual visual inspection confirms consistent type, spacing, alignment, icons, buttons and color meaning at320/390/430px and100/200% text, with long and missing content.
4. Keyboard/focus, accessible names, loading, empty, error, stale/conflict and uncertain-result behavior are checked as applicable.
5. Meaningful focused and affected neighboring checks pass against the final source. Review findings are reproduced, repaired and rechecked; evidence and limitations remain visible.
6. A section-level walkthrough and completion record are saved with scope, screenshots, source hash, check results, resolved findings and remaining dependencies.

If a required check fails, that phase stays open. Fix and recheck it before starting the next phase. Do not carry known material defects forward or treat a passing build as enough evidence.

Keep one implementation batch active. Preserve the current mobile Owner visual system and feature inventory. Scope changes or real operational actions require their own authorization; the standing instruction does not authorize production changes, real employee/pay/customer-data operations or messages.

Prototype-complete, integrated, physically tested and deployed remain separate states. Browser/DOM checks do not certify real screen readers or physical iPhone/Android behavior. Unverified release requirements stay explicitly pending.

Current position: Batch3.7 H-03 passes the bounded local mockup gate after original independent WITH FIXES review and one verified author repair. Evidence outputs/owner-setup/review.md; final source eb46b93e000698263da10213df2a482fcd318a05c0993363564d96738ebf47e9. OverallSection3 remains in progress; next3.8 Clocker setup/protected code, then3.9 and connected section walkthrough. Physical-device/software-keyboard/real-assistive-tech, actual integration and deployment remain separate.
