# Nevora Owner mobile continuation

This package continues Jose's existing design conversation. Before implementing, read START-HERE.md, then CONVERSATION-CONTEXT.md and WORKING-AGREEMENTS.md. The next bounded job is NEXT-BATCH-3.6.md. Read the full inventory/roadmap when advancing a batch.

Canonical editable mockup: work/owner-mobile. Build only with python3 work/owner-mobile/build.py. outputs/nevora-owner-mobile.html is generated. reference/application is a frozen READ ONLY actual-app source reference at 46e202786863279302026ee03a0e225c359fa55c, not the implementation target. Preserve the approved visual system in root DESIGN.md; the application's reference DESIGN.MD does not supersede it.

Current batch3.5 is complete on 65f2a5d5cbb596f90a2d08adb2fca30c869e1142e8325e9d25f23326e70d1c64. The next batch is3.6 company/location policies and history/conflicts. Work only on the mobile Owner mockup. Maintain one active implementation batch and verify it before proceeding. Existing reviews, snapshots and tests are historical evidence: preserve them and record new results separately.

No production integration, real employee/customer/pay data, real messages, operational APIs, migrations or deployment is authorized. This package has no credentials and no Git history. If Cloud attaches it to a repository, inspect that repository's instructions/status/development branch before making changes; avoid overwriting concurrent work. Follow platform tool/skill instructions available in Cloud, and report unavailable capabilities truthfully. Detailed original user agreements are in WORKING-AGREEMENTS.md.
