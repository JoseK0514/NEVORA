#3.8 C-12 local acceptance

Accepted first on `ab1974cb3c6d4be0dff9809a4ff2a208e2fec2ee78afa5cde861cf6611588918` after complete setup journeys and verified review repair I-01. Protected sample code is reconciled before initial handoff and during renewal; authority/subject/version/expiry/private cleanup verified. Intermediate inventory57/39/4 preserved in acceptance-3.8-coverage.json. See [whole-pair report](review.md), final command matrix and original independent review/disposition. No real tablet activation or service integration.
