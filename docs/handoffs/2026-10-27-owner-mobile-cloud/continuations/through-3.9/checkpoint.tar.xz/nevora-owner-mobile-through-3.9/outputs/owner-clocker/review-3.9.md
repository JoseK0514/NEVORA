#3.9 C-13/A-04 local acceptance

Accepted after3.8 on `ab1974cb3c6d4be0dff9809a4ff2a208e2fec2ee78afa5cde861cf6611588918`: device lifecycle plus saved receipt lookup, current-name shared join after repair I-02, no punch writer. Inventory59/37/4. Device/receipt/Timecards/Location source and context seams pass. See [whole-pair report](review.md), final command matrix and original independent review/disposition.
