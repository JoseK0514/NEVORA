#!/bin/sh
NEVORA_WEBKIT_ROOT=/home/agent/.cache/ms-playwright/webkit-2336/minibrowser-wpe
export WEBKIT_EXEC_PATH="$NEVORA_WEBKIT_ROOT/bin"
export WEBKIT_INJECTED_BUNDLE_PATH="$NEVORA_WEBKIT_ROOT/lib"
export WEBKIT_INSPECTOR_RESOURCES_PATH="$NEVORA_WEBKIT_ROOT/share"
export LD_LIBRARY_PATH="$NEVORA_WEBKIT_ROOT/lib:$NEVORA_WEBKIT_ROOT/sys/lib:/workspace/nevora-webkit-libs/extracted/usr/lib/x86_64-linux-gnu"
export WEBKIT_FORCE_COMPLEX_TEXT=1
exec "$NEVORA_WEBKIT_ROOT/bin/MiniBrowser" "$@"
