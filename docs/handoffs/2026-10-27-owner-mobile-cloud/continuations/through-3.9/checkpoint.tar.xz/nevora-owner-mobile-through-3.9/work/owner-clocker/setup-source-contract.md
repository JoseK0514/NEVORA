# Owner Clocker setup source contract

Pinned read-only application: `reference/application`, commit `46e202786863279302026ee03a0e225c359fa55c`. The canonical edit target is `work/owner-mobile`.

## Owner enrollment

- Inventory C-12 is `/app/settings/clocker`: add named device at active location; show/copy/hide setup code; no-active-location path; pending/error/stale write; transient code protection. It does not authorize a real connected device.
- `src/components/clocker-device-manager.tsx` is the owning Owner surface. REGISTER asks for `name` (required native input, maximum 80) and `locationId` (required native select containing active locations). The source says to choose the permanent location. The immediate result shows device/location context, a read-only textarea, Copy setup code and Hide code. Expiry removes the code. Clipboard denial selects the complete textarea and announces a fallback.
- `src/app/app/settings/clocker/actions.ts` REGISTER accepts exactly `operation`, `name`, `locationId`; active Owner and origin proof come from the server. Successful immediate setup returns `{code, expiresAt}` alongside a secret-free device DTO. Unknown writes require refreshed device state before another mutation; no blind replay or token retrieval is promised.
- `src/lib/clocker/views.ts` exposes device `id`, `name`, `locationId`, `version`, `state`, `lastSeenAt`, `enrollmentExpiresAt`, and location `id`, `name`, `clockerKey`, `active`. Credentials, hashes, workspace/session proof are excluded.
- `src/lib/clocker/devices.server.ts` validates a trimmed 1–80 printable-character name and current active location. REGISTER creates a one-use token bound to the current Owner/session with a database-derived ten-minute lifetime. Its real transport shape is `nev_enr_` followed by 64 lowercase hexadecimal characters. ROTATE replaces old setup code and existing tablet access while preserving location/time records. A locally displayed mockup code must be visibly invalid as a real token and labeled sample-only.

## Tablet transport boundary

`src/components/clocker-setup.tsx`, `src/lib/clocker/setup.server.ts` and `src/app/api/clocker/[location]/setup/route.ts` belong to the tablet side. They establish that the Owner code is not an employee PIN, cookies are required on the tablet, redemption is location-bound and one-use, and a status read confirms connection before success. A failed/unknown setup is not success. They do not authorize building a tablet kiosk in MOBILE OWNER.

The real transport uses origin/header checks, no-store/private responses, 600-second prepared cookies and a cookie-authenticated status reconciliation. It signs out the portal session on the shared tablet only after confirmed setup. None of those actual security guarantees is claimed by the local view helper.

## Mockup adaptation

The pure view only displays escaped data received from its manager. Native field names preserve the source contract. The shared manager/store author current read/mutation states; the view never invents success, an active connection, returned credentials, notification delivery, or a retrievable historical setup code. Code display guards against expiry even if a timer is delayed. Hide/expiry/failure/access-end views must contain no protected code.

No code is written to browser storage, URL, logs or evidence. Evidence records code presence/length and cleanup assertions, rather than printing a sample value. Screenshots may show the visibly invalid fictional sample where the handoff itself is under review.

Final selectors and input types are frozen in `interfaces.md`; implementation begins only after that file exists.
