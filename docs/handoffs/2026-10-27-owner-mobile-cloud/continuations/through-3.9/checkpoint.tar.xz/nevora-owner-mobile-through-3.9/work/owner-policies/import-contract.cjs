// Mechanical pinned-source adapter: no application execution, service or database imports.
const fs=require('fs'),path=require('path'),crypto=require('crypto'),{stripTypeScriptTypes}=require('node:module');
const root=path.resolve(__dirname,'../..'),ref=root+'/reference/application/',out=root+'/work/owner-mobile/',inputs=[];
function read(p){const s=fs.readFileSync(ref+p,'utf8');inputs.push({path:p,sha256:crypto.createHash('sha256').update(s).digest('hex')});return s;}
function js(s){return stripTypeScriptTypes(s.replace(/^import[\s\S]*?from\s*["'][^"']+["'];\s*/gm,'').replace(/^export /gm,''),{mode:'strip'});}
const labor=js(read('src/lib/business-improvements/labor-budget/model.ts'));
const model=js(read('src/lib/business-improvements/company-policies/model.ts').split('export function companyPolicyCommandHash')[0]);
const history=js(read('src/lib/business-improvements/company-policies/history.ts'));
const time=js(read('src/lib/business-time.ts'));
const code=`/* Mechanically adapted pinned contracts. See work/owner-policies/contract-provenance.json. */\nvar ownerPolicyContract = (()=>{\nconst Temporal=temporal.Temporal;\nconst parseLaborPlanningInputs=(()=>{${labor}\nreturn parseLaborPlanningInputs;})();\nconst model=(()=>{${model}\nreturn {parseCompanyPolicySettings,parseCompanyPolicyCommand,effectiveCompanyPolicies};})();\nconst parseCompanyPolicySettings=model.parseCompanyPolicySettings;\nconst history=(()=>{${history}\nreturn projectCompanyPolicyHistory;})();\nconst time=(()=>{${time}\nreturn {formatBusinessDateTimeInput,policyEffectiveInstant};})();\nreturn {parseSettings:parseCompanyPolicySettings,parseCommand:model.parseCompanyPolicyCommand,effective:model.effectiveCompanyPolicies,history,localInput:time.formatBusinessDateTimeInput,effectiveInstant:time.policyEffectiveInstant,edit(base,key,value){const next=JSON.parse(JSON.stringify(base)),section=key==='overtimeRisk'?'labor':'attendance';if(value!==undefined){next[section]??={};next[section][key]=value;}else if(next[section])delete next[section][key];return parseCompanyPolicySettings(next);}};\n})();\n`;
fs.writeFileSync(out+'policy-contract.js',code);
const vendor='/workspace/nevora-policy-runtime/node_modules/@js-temporal/polyfill/';
fs.writeFileSync(out+'policy-temporal.js',fs.readFileSync(vendor+'dist/index.umd.js','utf8').replace(/\/\/# sourceMappingURL=.*$/m,''));
fs.copyFileSync(vendor+'LICENSE',out+'policy-temporal-LICENSE');
fs.writeFileSync(__dirname+'/contract-provenance.json',JSON.stringify({referenceCommit:'46e202786863279302026ee03a0e225c359fa55c',inputs,adapter:'Node24 stripTypeScriptTypes, remove imports/exports; isolate namespaces; omit node-only command hash, no changed validation statements',temporal:{version:JSON.parse(fs.readFileSync(vendor+'package.json')).version,license:'ISC',source:'npm @js-temporal/polyfill',sha256:crypto.createHash('sha256').update(fs.readFileSync(out+'policy-temporal.js')).digest('hex')}},null,2));
