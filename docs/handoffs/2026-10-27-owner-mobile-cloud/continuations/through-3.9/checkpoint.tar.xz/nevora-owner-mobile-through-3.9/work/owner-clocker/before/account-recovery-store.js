/* Fictional recovery issuance only. Invalid display samples never authenticate. */
function createOwnerAccountRecoveryStore(team,invitations){
 let mode,clock,proofs,serial,epoch;
 function reset(){mode='ready';clock=0;proofs=[];serial=0;epoch=(epoch||0)+1;}
 reset();
 const now=()=>Date.now()+clock;
 const methods=[['photo','In person, photo ID','Verified in person with a photo ID.'],['known','In person, I know them','Verified in person; I know this employee.'],['records','Workplace records','Verified through our workplace records and a trusted colleague.'],['other','Something else','']];
 function eligibility(id){const actor=team.snapshot().actor,p=team.get(id);if(mode==='denied'||!actor.active||actor.accessRole!=='Owner')return 'denied';if(!p)return 'missing';if(id===actor.id)return 'self';if(!p.active)return 'inactive';if(!invitations.credentialed(id))return 'setup';return 'eligible';}
 function validate(input){const m=methods.find(m=>m[0]===input?.method),note=m?(m[0]==='other'?String(input?.note||'').trim():m[2]):'';const errors={};if(!m)errors.method='Choose how you verified their identity.';if(m?.[0]==='other'&&(note.length<10||note.length>500||/[\u0000-\u001f\u007f]/.test(note)))errors.note='Describe how you checked in 10–500 characters, without sensitive details.';if(input?.confirmed!==true)errors.confirmed='Confirm that you verified their identity yourself.';return {ok:!Object.keys(errors).length,errors,attestation:note};}
 function issue(id,input,scenario='normal'){
  const v=validate(input);if(!v.ok)return {state:'invalid',errors:v.errors};if(eligibility(id)!=='eligible')return {state:'unavailable'};if(mode==='unavailable'||scenario==='unknown-before')return {state:'unconfirmed'};
  for(const p of proofs)if(p.personId===id&&!p.retired)p.retired=true;
  const p=team.get(id),at=now(),record={number:++serial,personId:id,employeeVersion:p.version,issuedAt:at,expiresAt:at+15*60*1000,retired:false};proofs.push(record);
  if(scenario==='denied-after'){mode='denied';return {state:'unavailable'};}if(scenario==='unknown')return {state:'unconfirmed'};
  return {state:'issued',employeeId:p.employeeId,proof:'SAMPLE / '+p.employeeId+' / NOT VALID FOR SIGN-IN',expiresAt:record.expiresAt};
 }
 return {methods,eligibility,validate,issue,reset,now,advance:ms=>{clock+=ms;},setMode:value=>{mode=value;},snapshot:()=>({now:now(),proofs:proofs.map(p=>({...p,valid:!p.retired&&p.expiresAt>now()&&team.get(p.personId)?.active&&team.get(p.personId)?.version===p.employeeVersion})),epoch})};
}
