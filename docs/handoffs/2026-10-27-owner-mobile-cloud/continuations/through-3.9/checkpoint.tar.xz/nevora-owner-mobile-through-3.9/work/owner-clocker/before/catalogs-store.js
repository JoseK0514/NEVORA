/* Fictional Owner catalogs. Positions use timestamp CAS; break types use integer versions. */
function createOwnerCatalogStore(api) {
 const kind=api.kind, copy=v=>JSON.parse(JSON.stringify(v));
 let rows=[],serial=3,stamp=0,session=0,mode='ready',sources={people:'ready'},writes=0;
 const timestamp=()=>`2026-10-26 11:24:00.${String(++stamp).padStart(6,'0')}-04`;
 const authority=()=>JSON.stringify([api.authority(),session,mode==='denied']);
 const gate=()=>api.gate?api.gate():api.allowed()?'ready':'denied';
 const permitted=()=>api.owner()&&gate()!=='denied'&&mode!=='denied';
 const available=()=>permitted()&&gate()==='ready'&&mode==='ready';
 function publicCatalog(){return rows.map(({id,key,name,active})=>({id,key,name,active}));}
 const changed=()=>api.changed?.(publicCatalog());
 function reset(){session++;serial=3;stamp=0;writes=0;mode='ready';sources={people:'ready'};rows=kind==='positions'?
  ['Team member','Cashier','Counter service'].map((name,i)=>({id:'position-'+(i+1),key:i<2?name:'position-3',name,active:i<2,updatedAt:timestamp()})):
  [['Rest break','REST',15],['Meal break','MEAL',null],['Personal break','OTHER',null]].map(([name,category,targetMinutes],i)=>({id:'break-type-'+(i+1),name,category,targetMinutes,active:i<2,version:1}));}
 reset();
 function read(){if(!permitted())return {state:'denied'};if(!available())return {state:'unavailable'};return {state:'ready',rows:rows.map(p=>({...copy(p),...(kind==='positions'?{people:sources.people==='ready'?api.people().filter(e=>e.active&&e.positions.includes(p.key)).length:null}:{})})),observedAt:new Date(api.now()).toISOString(),validForMs:45000,authority:authority()};}
 function validate(input,creating=!input.id){
  const errors={},allowed=kind==='positions'?['id','name','active','expectedUpdatedAt']:['id','name','category','targetMinutes','active','expectedVersion'];
  if(!input||Object.keys(input).some(k=>!allowed.includes(k)))return {ok:false,errors:{name:'Review the current fields before saving.'}};
  let name=typeof input.name==='string'?input.name.trim():'';if(kind==='breaks')name=name.normalize('NFC');
  if(!name||[...name].length>80||kind==='breaks'&&/[\u0000-\u001f\u007f]/.test(name))errors.name='Enter a name of 1–80 characters'+(kind==='breaks'?', without control characters.':'.');
  if(rows.some(p=>p.id!==input.id&&p.name.toLowerCase()===name.toLowerCase()))errors.name=kind==='positions'?'A position already uses this name. Edit or reactivate the existing position.':'A break type already uses this name. Edit or reactivate the existing type.';
  if(!creating&&(kind==='positions'?typeof input.expectedUpdatedAt!=='string'||!input.expectedUpdatedAt:Number.isInteger(input.expectedVersion)===false||input.expectedVersion<1||input.expectedVersion>=2147483647))errors.name='Refresh current details before saving.';
  if((!creating||kind==='breaks')&&typeof input.active!=='boolean')errors.active='Choose the current active state.';
  if(kind==='breaks'){
   if(!['REST','MEAL','OTHER'].includes(input.category))errors.category='Choose Rest, Meal or Other.';
   if(input.targetMinutes!==null&&(!Number.isInteger(input.targetMinutes)||input.targetMinutes<1||input.targetMinutes>1440))errors.targetMinutes='Enter whole minutes from 1 to 1,440, or leave this blank.';
  }
  return {ok:!Object.keys(errors).length,errors,value:{name,active:creating&&kind==='positions'?true:input.active,...(kind==='breaks'?{category:input.category,targetMinutes:input.targetMinutes}:{})}};
 }
 function save(input,scenario='normal',key=authority()){
  if(!permitted()||key!==authority())return {state:'denied'};if(!available())return {state:'unavailable'};
  const creating=!input.id,valid=validate(input,creating);if(!valid.ok)return {state:'invalid',errors:valid.errors};
  let row=creating?null:rows.find(p=>p.id===input.id);if(!creating&&!row)return {state:'missing'};
  if(row&&(kind==='positions'?row.updatedAt!==input.expectedUpdatedAt:row.version!==input.expectedVersion))return {state:'conflict'};
  if(scenario==='failure')return {state:'error'};if(scenario==='unknown-before')return {state:'unconfirmed'};
  if(creating){const id=(kind==='positions'?'position-':'break-type-')+(++serial);row={id,...(kind==='positions'?{key:id,updatedAt:timestamp()}:{version:1}),...valid.value};rows.push(row);}
  else Object.assign(row,valid.value,kind==='positions'?{updatedAt:timestamp()}:{version:row.version+1});
  writes++;changed();if(scenario==='unknown-after')return {state:'unconfirmed'};
  return kind==='positions'?{state:'confirmed',success:creating?'Position added.':'Position updated. Existing memberships and history are retained.',...(!creating?{updatedAt:row.updatedAt}:{})}:{state:'confirmed',breakType:copy(row)};
 }
 return {kind,read,save,validate,authority,available,now:api.now,reset,publicCatalog,countSource:()=>available()?rows.filter(p=>p.active).map(copy):null,
  capture:id=>{const p=available()&&rows.find(p=>p.id===id&&p.active);if(!p||kind!=='breaks')return null;const {name,category,targetMinutes,version}=p;return copy({id,name,category,targetMinutes,version});},
  previewReadMode:v=>{mode=v;changed();},previewSource:(key,value)=>{sources[key]=value;changed();},previewAuthority:()=>{session++;changed();},previewEmpty:()=>{rows=[];changed();},
  previewRow:(id,patch)=>{const p=rows.find(p=>p.id===id);if(p){Object.assign(p,copy(patch),kind==='positions'?{updatedAt:timestamp()}:{version:p.version+1});changed();}},snapshot:()=>({kind,mode,writes,sources:{...sources}})};
}
