const pw=require('playwright'),fs=require('fs'),crypto=require('crypto'),assert=require('node:assert/strict');
const engine=process.argv.find(v=>v.startsWith('--engine='))?.slice(9)||'chromium',tag=process.argv.find(v=>v.startsWith('--tag='))?.slice(6)||'latest',checks=[];
(async()=>{const b=await pw[engine].launch(engine==='webkit'?{executablePath:process.env.NEVORA_WEBKIT_EXECUTABLE||'/workspace/nevora-webkit-libs/run-webkit.sh'}:undefined);
 for(const width of [320,390,430])for(const zoom of [100,200]){
  const p=await b.newPage({viewport:{width,height:844}});p.setDefaultTimeout(5000);await p.goto('http://127.0.0.1:18763/nevora-owner-mobile.html?page=clocker');await p.locator('.cd-body[aria-busy=false]').waitFor();
  await p.evaluate(zoom=>{document.documentElement.style.fontSize=zoom+'%';ownerLocations.store.previewLocation('location-1',{name:'Arecibo community services and administration reception location'});ownerClockerDevices.store.previewDevice('device-1',{name:'Front reception shared tablet for community services and administration'});},zoom);
  for(const view of ['list','detail','rename','rotate','revoke']){
   const name=view+' '+width+'px '+zoom+'%';
   try{await p.evaluate(view=>ownerClockerDevices.open({view,id:view==='list'?null:'device-1'}),view);await p.locator('.cd-body[aria-busy=false]').waitFor();await p.waitForTimeout(50);
    const geometry=await p.evaluate(()=>{const root=document.querySelector('#app-scroll'),nav=document.querySelector('.cd-nav'),h1=nav.querySelector('h1'),rect=h1.getBoundingClientRect(),out={overflow:root.scrollWidth>root.clientWidth+1,navWidth:nav.getBoundingClientRect().width,titleWidth:rect.width,small:[]};for(const el of document.querySelectorAll('.cd-nav button,.cd-body button,.cd-body input,.cd-body select,.cd-body textarea')){const r=el.getBoundingClientRect();if(r.width&&r.height&&(r.height<43.5||r.width<43.5))out.small.push({label:el.textContent||el.id,width:r.width,height:r.height});}return out;});
    assert.equal(geometry.overflow,false,JSON.stringify(geometry));assert.deepEqual(geometry.small,[],JSON.stringify(geometry));
    if(view==='rename'){const focus=await p.evaluate(()=>({outerScroll:document.querySelector('#app').scrollTop,fieldTop:document.querySelector('#clocker-name').closest('.form-field').getBoundingClientRect().top,headerTop:document.querySelector('.cd-nav').getBoundingClientRect().top,headerBottom:document.querySelector('.cd-nav').getBoundingClientRect().bottom}));assert.equal(focus.outerScroll,0,JSON.stringify(focus));assert.ok(focus.headerTop>=0,JSON.stringify(focus));assert.ok(focus.fieldTop>=focus.headerBottom-1,JSON.stringify(focus));}
    const capture=engine==='chromium'?'outputs/owner-clocker/devices-'+view+'-'+width+'-'+zoom+'-'+tag+'.png':null;if(capture)await p.screenshot({path:capture});checks.push({name,pass:true,geometry,capture});
   }catch(error){checks.push({name,pass:false,error:error.message});}console.log(JSON.stringify(checks.at(-1)));
  }await p.close();
 }
 await b.close();fs.writeFileSync('outputs/owner-clocker/devices-layout-'+engine+'-'+tag+'.json',JSON.stringify({artifactSha256:crypto.createHash('sha256').update(fs.readFileSync('outputs/nevora-owner-mobile.html')).digest('hex'),engine,checks,passed:checks.filter(c=>c.pass).length,failed:checks.filter(c=>!c.pass).length},null,2));if(checks.some(c=>!c.pass))process.exitCode=1;
})();
