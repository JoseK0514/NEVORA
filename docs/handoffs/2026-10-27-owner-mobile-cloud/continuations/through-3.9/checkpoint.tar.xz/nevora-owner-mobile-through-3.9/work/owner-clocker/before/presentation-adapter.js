/* Deliberate presentation boundaries, never a replacement of arbitrary page text. */
function ownerTerm(slot,fallback){const p=brandingStore?.presentation();return p?.state==='ready'&&p.words!=='standard'?ownerPresentationData.wordPreset(p.words).en[slot]:(fallback||ownerPresentationData.DEFAULT_WORDS.en[slot]);}
function ownerModuleState(id){if(!brandingStore)return 'on';const p=brandingStore.presentation();if(p.state!=='ready')return 'unavailable';if(id==='payStatements'){const c=companyStore.featureFacts();if(c.state!=='ready')return 'unavailable';if(!c.payrollEnabled)return 'off';}return p.modules[id]?'on':'off';}
function ownerFeatureModule(id){return {timeoff:'timeOff',exchanges:'marketplace',updates:'updates',compose:'updates',mypay:'payStatements',breaks:'breaks'}[id]||null;}
function ownerFeatureAllowed(id){const m=ownerFeatureModule(id);return !m||ownerModuleState(m)==='on';}
function ownerFeatureLabel(f){if(!f)return f;const labels={locations:ownerTerm('locations','Locations'),newlocation:'Add '+ownerTerm('location','location').toLowerCase(),addperson:'Add '+ownerTerm('person','employee').toLowerCase()};return {...f,name:labels[f.id]||f.name};}
function applyOwnerPresentation(){
 brandingUI?.applyCurrent();triageUI?.invalidate();
 const values=[['[data-feature=addperson]','Add '+ownerTerm('person','employee').toLowerCase()],['[data-feature=newlocation]','Add '+ownerTerm('location','location').toLowerCase()]];
 for(const [selector,label]of values)for(const el of document.querySelectorAll(selector)){const span=el.querySelector('span:not(.tool-icon)');if(span&&!span.querySelector('*')&&span.textContent!==label)span.textContent=label;if(el.hasAttribute('aria-label')&&el.getAttribute('aria-label')!==label)el.setAttribute('aria-label',label);}
}
