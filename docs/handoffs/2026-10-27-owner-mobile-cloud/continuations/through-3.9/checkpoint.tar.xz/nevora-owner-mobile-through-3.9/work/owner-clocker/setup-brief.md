# Owner Clocker setup — bounded view brief

Date: 2026-10-27. Scope: standalone MOBILE OWNER 3.8 / C-12, implemented in parallel with the authorized 3.9 device-management slice. Frozen reference commit: `46e202786863279302026ee03a0e225c359fa55c`.

Owner job: name a shared tablet, deliberately choose its permanent active location, and privately hand off a one-use sample setup code. The Owner remains in the accepted Company settings / Clocker devices world. This is not the tablet kiosk, employee PIN entry, or a real enrollment.

The pure setup helper owns the add form and setup-code presentation only. The device manager owns event handling, submission, read/unknown-result reconciliation, drafts, clipboard behavior, location availability, focus lifecycle, expiry timers, protected-value cleanup and parent return. The shared store owns fictional state and validation. No real service, message, credential or device is involved.

Use accepted task navigation, native form controls, definition groups, neutral notices, Phosphor symbols, teal actions and existing 44/48px controls. Keep the full device/location identity readable. Code is a complete wrapping read-only sample, never an ellipsis, URL parameter, persisted value or copied real credential. Explain ten-minute/one-use behavior and that a code does not confirm a connected device. Hiding clears this display; it must not imply revocation.

Implementation waits for `work/owner-clocker/interfaces.md` to freeze the helper name, inputs, views, selectors and action identifiers. The helper will not mutate state, attach listeners or read the DOM.

Owned files: `work/owner-mobile/clocker-enrollment.js`, `work/owner-clocker/setup-*`, and `outputs/owner-clocker/setup-*`. Shared styles, controller, store, build and artifact are owned by other agents.

Evidence is additive. Preserve accepted source, existing reports and each RED run. Root coordinates final build, affected-neighbor checks, inventory and final review. Browser evidence covers the static local mockup only; physical devices, software keyboards, real screen readers, application integration and operational enrollment remain unverified.
