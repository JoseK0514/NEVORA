from pathlib import Path
import hashlib,json,subprocess,concurrent.futures,os,datetime,shutil
root=Path(__file__).resolve().parents[2];out=root/'outputs/owner-setup';artifact=root/'outputs/nevora-owner-mobile.html';neighbor=Path('/workspace/nevora-setup-neighbors')
shutil.copy2(artifact,neighbor/'outputs/nevora-owner-mobile.html');shutil.copytree(root/'work/owner-mobile',neighbor/'work/owner-mobile',dirs_exist_ok=True)
def sha():return hashlib.sha256(artifact.read_bytes()).hexdigest()
commands=[('source',['python3','work/owner-setup/source-check.py'],root),('model',['node','--test','work/owner-setup/model-check.cjs'],root),('focus',['node','work/owner-setup/focus-check.cjs'],root),('captures',['node','work/owner-setup/capture.cjs'],root)]
commands += [(e,['node','work/owner-setup/browser-check.cjs','--engine='+e],root) for e in ['chromium','firefox','webkit']]
commands += [('review-'+e,['node','work/owner-setup/review-regression.cjs','--engine='+e],root) for e in ['chromium','firefox','webkit']]
commands += [('neighbor-triage',['node','work/owner-triage/browser-check.cjs'],neighbor),('neighbor-policies',['node','work/owner-policies/browser-check.cjs'],neighbor)]
def run(item):
 name,cmd,cwd=item;before=sha();env={**os.environ,'NEVORA_WEBKIT_EXECUTABLE':'/workspace/nevora-webkit-libs/run-webkit.sh','NEVORA_REVIEW_REPORT':str(out/(name+'.json'))}
 with (out/('final-'+name+'.log')).open('w') as log:r=subprocess.run(cmd,cwd=cwd,stdout=log,stderr=subprocess.STDOUT,env=env)
 return {'name':name,'command':cmd,'cwd':str(cwd),'exit':r.returncode,'source_before':before,'source_after':sha(),'log':'outputs/owner-setup/final-'+name+'.log'}
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:records=list(ex.map(run,commands))
r={'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_sha256':sha(),'commands':records,'all_passed':all(v['exit']==0 and v['source_before']==v['source_after']==sha() for v in records)}
(out/'final-verification.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2));raise SystemExit(not r['all_passed'])
