/* Owner triage: current fictional reads only. No commands, notes or private reasons. */
function createOwnerTriageStore(api){
 const {team,schedule,clock,attendance,timeoff,exchanges,corrections,workforce}=api,base='2026-10-26',DAY=86400000;
 let mode='ready',session=1;
 const day=n=>new Date(n-4*3600000).toISOString().slice(0,10),add=(d,n)=>clock.addDays(d,n),offset=d=>Math.round((Date.parse(d+'T12:00Z')-Date.parse(base+'T12:00Z'))/DAY),week=d=>add(d,-((new Date(d+'T12:00Z').getUTCDay()+6)%7));
 const authority=()=>JSON.stringify([[team.snapshot().actor.id,team.snapshot().actor.active,team.snapshot().actor.accessRole,team.snapshot().actor.roleGeneration],session,timeoff.authority?.(),exchanges.authority?.(),attendance.authority?.(),corrections.authority?.(),workforce.authority?.(),clock.snapshot?.().mode,[timeoff,exchanges,attendance,corrections,workforce].map(s=>{const r=s.snapshot?.()||{};return[r.mode,r.readMode,r.enabled,r.sources,r.sourceModes];})]);
 const time=t=>{const [h,m]=t.split(':').map(Number);return (h%12||12)+(m?':'+String(m).padStart(2,'0'):'')+(h>=12&&h<24?' PM':' AM');};
 const when=d=>new Intl.DateTimeFormat('en-US',{weekday:'short',month:'short',day:'numeric',timeZone:'UTC'}).format(new Date(d+'T12:00Z'));
 function read({location=null,demo='ready'}={}){
  if(!team.isOwner()||mode==='denied')return {state:'unavailable',reason:'access_denied'};
  if(mode!=='ready'||demo==='error')return {state:'unavailable',reason:'read_failed'};
  exchanges.activate();const at=clock.now(),today=day(at),start=week(today),end=add(start,6),next=add(start,7),items=[],sources={},problems=[];
  const scoped=loc=>!loc||!location||loc===location;
  const item=(id,bucket,kind,title,detail,target,loc=null,date=null)=>{if(scoped(loc))items.push({id,bucket,kind,title,detail,target,location:loc,date});};
  const take=(name,reader,facet)=>{let r;try{r=reader();}catch{r={state:'unavailable'};}if(r.state==='unavailable'&&['access_denied','authentication_required'].includes(r.reason))throw Error('access_denied');const okay=r.state==='ready'&&(!facet||r.sources?.[facet]==='ready')&&Number.isFinite(Date.parse(r.observedAt))&&at-Date.parse(r.observedAt)>=-1000&&at<Date.parse(r.observedAt)+r.validForMs;sources[name]=okay?'ready':'unavailable';if(!okay)problems.push(name);return okay?r:null;};
  try{
   const model=schedule.snapshot();sources.schedule='ready';
   const a=take('clock-ins',()=>attendance.read(),'clockins');
   if(a)for(const r of a.items.filter(r=>r.family==='clockins'))item('attendance:'+r.key,'now','clockins',r.employeeName,r.status==='no_punches'?'No clock-in for ended shift':'Started, not clocked in',{page:'attendance',itemId:r.key,filter:'clockins'},r.locationId,r.workDate);
   const ar=take('time records',()=>attendance.read(),'records');
   if(ar)for(const r of ar.items.filter(r=>r.family==='records'))item('attendance:'+r.key,'planning','records',r.employeeName,r.observations[0]?.label||'Recorded attendance review',{page:'attendance',itemId:r.key,filter:'records'},r.locationId,r.workDate);
   for(const s of model.shifts.filter(s=>(!s.person||s.isCalloutApproved)&&s.date>=start&&s.date<=end))item('shift:'+s.id,s.date===today?'now':s.date<today?'past':'planning','coverage','Unassigned shift',time(s.start)+'–'+time(s.end)+(s.end==='24:00'||s.end<s.start?' next day':''),{page:'schedule',date:s.date,shiftId:s.id},s.loc,s.date);
   // Coverage-period checks share the accepted Schedule rule semantics. Distinct
   // configured-period gaps and optional unassigned shifts keep separate labels.
   for(const loc of Object.keys(model.rules).filter(scoped)){
    const r=model.rules[loc];
    if(r.minimum==null||r.lead==null||!r.periods?.length){item('rules:'+loc,'planning','setup','Finish staffing rules','Minimum staffing, lead and coverage periods',{page:'schedule',date:today,action:'rules'},loc);continue;}
    for(const p of r.periods){
     const date=add(start,(p.day+6)%7),minute=t=>Number(t.split(':')[0])*60+Number(t.split(':')[1]),dateMinute=d=>Date.parse(d+'T00:00Z')/60000,left=dateMinute(date)+minute(p.start),right=dateMinute(date)+minute(p.end),hhmm=n=>{const m=n-dateMinute(date);return String(Math.floor(m/60)).padStart(2,'0')+':'+String(m%60).padStart(2,'0');};
     if(!Number.isFinite(left)||!Number.isFinite(right)||right<=left||!Number.isInteger(p.day)||p.day<0||p.day>6)throw Error('Invalid period');
     const assigned=model.shifts.filter(s=>s.loc===loc&&s.person&&!s.isCalloutApproved).map(s=>{const a=dateMinute(s.date)+minute(s.start),z=minute(s.end),b=dateMinute(s.date)+z+(z<=minute(s.start)?1440:0);return {...s,a,b};}).filter(s=>s.a<right&&s.b>left);
     const points=[...new Set([left,right,...assigned.flatMap(s=>[Math.max(left,s.a),Math.min(right,s.b)])])].sort((a,b)=>a-b),gaps=[];
     for(let i=0;i<points.length-1;i++){const a=points[i],b=points[i+1],present=assigned.filter(s=>s.a<=a&&s.b>=b),missing=Math.max(0,(p.minimum??r.minimum)-present.length),lead=r.lead&&!present.some(s=>s.lead),positions=(p.positions||[]).filter(pos=>present.filter(s=>s.position===pos.name).length<pos.quantity),needs=[missing?missing+' more '+(missing===1?'person':'people'):'',lead?'Designated lead':null,...positions.map(pos=>api.positionLabel?api.positionLabel(pos.name):pos.name)].filter(Boolean).join(' · ');
      if(!needs)continue;const last=gaps.at(-1);if(last&&last.b===a&&last.needs===needs)last.b=b;else gaps.push({a,b,needs});
     }
     for(const gap of gaps){const a=hhmm(gap.a),b=hhmm(gap.b);item('gap:'+loc+':'+date+':'+a+':'+b,date===today?'now':date<today?'past':'planning','gap','Coverage period needs review',time(a)+'–'+time(b)+' · '+gap.needs,{page:'schedule',date,action:'day',context:'Coverage period '+time(a)+'–'+time(b)+' needs review.',requirements:gap.needs},loc,date);}
    }
   }
   const toState=api.moduleState?.('timeOff')||'on',exState=api.moduleState?.('marketplace')||'on';
   const t=toState==='on'?take('time off',()=>timeoff.read(),'pending'):null;if(toState!=='on'){sources['time off']=toState==='off'?'disabled':'unavailable';if(toState!=='off')problems.push('time off');}if(t)for(const r of t.requests.filter(r=>r.status==='PENDING'))item('timeoff:'+r.id,'requests','timeoff',r.name,'Time off · '+when(r.startDate)+(r.endDate!==r.startDate?' – '+when(r.endDate):''),{page:'timeoff',requestId:r.id},r.primaryLocation,r.startDate);
   const x=exState==='on'?take('shift requests',()=>exchanges.read(),'waiting'):null;if(exState!=='on'){sources['shift requests']=exState==='off'?'disabled':'unavailable';sources['open cover']=sources['shift requests'];if(exState!=='off')problems.push('shift requests');}if(x)for(const r of x.requests.filter(r=>['PENDING','MANAGER_PENDING'].includes(r.status)))item('exchange:'+r.id,'requests',r.kind==='CALLOUT'?'callout':r.kind==='SWAP'?'swap':'pickup',r.name,(r.kind==='CALLOUT'?'Unable to work':r.kind==='SWAP'?'Shift swap':'Coverage pickup')+' · '+when(r.source.date),{page:'exchanges',requestId:r.id,filter:'waiting'},r.source.loc,r.source.date);
   const offers=exState==='on'?take('open cover',()=>exchanges.read(),'open'):null;if(offers)for(const r of offers.requests.filter(r=>r.status==='OPEN'))item('exchange:'+r.id,'planning','offers',r.name,'Open coverage request · '+when(r.source.date),{page:'exchanges',requestId:r.id,filter:'open'},r.source.loc,r.source.date);
   const c=take('corrections',()=>corrections.read());if(c)for(const r of c.requests)item('correction:'+r.id,'planning','corrections',r.employeeName,r.kind==='MISSING_ENTRY'?'Missing-time correction':'Recorded-time correction',{page:'corrections',requestId:r.id},r.locationId);
   const tc=take('timecards',()=>clock.read({startDate:start,endDate:end}));if(tc)for(const r of tc.cards.filter(r=>r.state!=='FINALIZED'&&(r.card.entries.length||r.history.length))){const p=team.get(r.card.employeeId);item('timecard:'+r.card.employeeId+':'+start,'planning','timecards',r.card.employeeName,r.state==='APPROVED'?'Approved · Ready to finalize':'Recorded time to review',{page:'timecards',employeeId:r.card.employeeId,startDate:start,endDate:end},p?.loc);}
   const w=take('weekly hours',()=>workforce.read({weekStart:start,location}),'hours');if(w){for(const p of w.people.filter(p=>['unset','under','over'].includes(p.hourStatus)))item('hours:'+p.id+':'+start,'planning','hours',p.name,p.hourStatus==='unset'?'Weekly hour target not set':p.scheduledHours+' planned hours · '+p.target+' hour target',{page:'teamweek',week:start,personId:p.id,filter:p.hourStatus==='unset'?'unset':'outside'},p.location);}
   const av=take('availability',()=>workforce.read({weekStart:next,location}),'availability');if(av){for(const p of av.people.filter(p=>p.eligible&&!p.submitted))item('availability:'+p.id+':'+next,'planning','availability',p.name,'Availability not submitted · '+when(next),{page:'availability',week:next,personId:p.id,filter:'missing'},p.location);if(!av.deadline)item('deadline:'+next,'planning','setup','Set availability deadline','Week of '+when(next),{page:'schedule',date:next,action:'deadline'});}
   item('plan:'+next,'planning','schedule','Review next week',when(next)+' – '+when(add(next,6)),{page:'schedule',date:next,action:'day'});
   const unique=new Map();for(const i of items){const prior=unique.get(i.id);if(prior){if(JSON.stringify(prior)===JSON.stringify(i))continue;if(i.kind!=='gap'||prior.kind!=='gap')throw Error('Conflicting item identity');i.id+=':'+encodeURIComponent(i.target.requirements);if(unique.has(i.id)&&JSON.stringify(unique.get(i.id))!==JSON.stringify(i))throw Error('Conflicting period identity');}unique.set(i.id,i);}items.splice(0,items.length,...unique.values());
   const countComplete=['schedule','clock-ins','time off','shift requests'].every(k=>['ready','disabled'].includes(sources[k]));
   const published=s=>model.publications[offset(week(s.date))+':'+s.loc]?.status==='Published';
   const shifts=model.shifts.filter(s=>s.person&&!s.isCalloutApproved&&s.date===today&&scoped(s.loc)&&published(s));
   const roster=shifts.map(s=>({id:s.id,employeeId:s.person,name:team.get(s.person)?.name||'Employee unavailable',initials:team.get(s.person)?.initials||'',tone:team.get(s.person)?.tone||'',loc:s.loc,start:s.start,end:s.end}));
   const entries=tc?tc.cards.flatMap(r=>r.card.entries):null,openPeople=entries?new Set(entries.filter(e=>e.endAt===null&&e.sourceKind!=='ADJUSTMENT'&&scoped(e.locationId)).map(e=>e.personId)):null;
   const nextShift=roster.filter(s=>Date.parse(today+'T'+s.start+':00-04:00')>at).sort((a,b)=>a.start.localeCompare(b.start)||a.id.localeCompare(b.id))[0]||null;
   const empty=demo==='empty',clear=demo==='clear';const resultItems=empty?[]:clear?items.filter(i=>!['now','requests'].includes(i.bucket)):items;
   return {state:'ready',today,week:start,observedAt:new Date(at).toISOString(),validForMs:45000,authority:authority(),sources,problems,complete:problems.length===0,countComplete,count:countComplete?resultItems.filter(i=>['now','requests'].includes(i.bucket)).length:null,items:resultItems,staffing:{scheduled:empty?0:roster.length,clockedIn:empty?0:openPeople?.size??null,roster:empty?[]:roster,next:empty?null:nextShift}};
  }catch(error){return {state:'unavailable',reason:error.message==='access_denied'?'access_denied':'invalid_source'};}
 }
 return {read,authority,now:clock.now,setReadMode:v=>{mode=v;},previewAuthority:()=>{session++;}};
}
