from pathlib import Path
from html.parser import HTMLParser
import ast, hashlib, json, re, subprocess
root=Path(__file__).resolve().parents[2];source=root/'work/owner-mobile';artifact=root/'outputs/nevora-owner-mobile.html';html=artifact.read_text();sha=hashlib.sha256(artifact.read_bytes()).hexdigest();checks=[]
def check(name,value):checks.append({'name':name,'pass':bool(value)})
tree=ast.parse((source/'build.py').read_text());lists=[ast.literal_eval(n) for n in ast.walk(tree) if isinstance(n,ast.List) and n.elts and all(isinstance(e,ast.Constant) and isinstance(e.value,str) for e in n.elts)];css_files=next(v for v in lists if v[0].endswith('.css'));js_files=next(v for v in lists if v[0].endswith('.js'));css='\n'.join((source/f).read_text() for f in css_files);js='\n'.join((source/f).read_text() for f in js_files)
check('Canonical artifact matches complete build',html==(source/'template.html').read_text().replace('__APP_CSS__',css).replace('__APP_JS__',js))
check('All canonical scripts parse',all(subprocess.run(['node','--check',str(source/f)],capture_output=True).returncode==0 for f in js_files))
check('No unresolved template slots','__APP_CSS__' not in html and '__APP_JS__' not in html)
class Inspect(HTMLParser):
 def __init__(self):super().__init__();self.ids=[];self.remote=[]
 def handle_starttag(self,tag,attrs):
  a=dict(attrs)
  if 'id' in a:self.ids.append(a['id'])
  if tag in ['img','script','link'] and a.get('src',a.get('href','')).startswith(('http://','https://')):self.remote.append(tag)
p=Inspect();p.feed(html);check('Static IDs unique',len(p.ids)==len(set(p.ids)));check('No remote assets',not p.remote)
check('No operational network or persistence',not re.search(r'\b(?:fetch|XMLHttpRequest|WebSocket|localStorage|sessionStorage)\b',js))
definitions=set(re.findall(r'(--[\w-]+)\s*:',css))|set(re.findall(r"setProperty\(['\"](--[\w-]+)",js));check('CSS roles defined or measured',not set(re.findall(r'var\((--[\w-]+)',css))-definitions)
check('Application checkout untouched',not subprocess.check_output(['git','-C','/workspace/NEVORA','status','--porcelain'],text=True).strip())
manifest=json.loads((root/'reference/application-snapshot.json').read_text())
# Snapshot shape is inspected separately below; full reference identity also recorded by arrival validation.
provenance=json.loads((root/'work/owner-policies/contract-provenance.json').read_text());check('Pinned imported contract inputs unchanged',all(hashlib.sha256((root/'reference/application'/v['path']).read_bytes()).hexdigest()==v['sha256'] for v in provenance['inputs']))
check('Accepted baseline preserved',hashlib.sha256((root/'outputs/owner-clocker/before.html').read_bytes()).hexdigest()=='eb46b93e000698263da10213df2a482fcd318a05c0993363564d96738ebf47e9')
r={'source_sha256':sha,'checks':checks,'passed':sum(c['pass'] for c in checks),'failed':sum(not c['pass'] for c in checks),'limits':'App status checks attached checkout only; reference source identity is pinned. No runtime application tests or production certification.'};(root/'outputs/owner-clocker/source-checks.json').write_text(json.dumps(r,indent=2));print(json.dumps(r));raise SystemExit(bool(r['failed']))
