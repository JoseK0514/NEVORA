/* Fixed source vocabulary and module definitions, read-only reference46e2027. */
const ownerPresentationData=(()=>{
/** Company vocabulary (B2). Fixed presets rather than free text, so every
 * word has a reviewed English and Puerto Rico Spanish form and copy stays
 * grammatical. Applied to navigation, settings and page titles; full
 * sentences adopt these slots when strings move into dictionaries (B5). */
const WORD_PRESET_IDS = ["standard", "retail", "restaurant", "field", "care"]         ;
                                                            
                                                                                                
                                                                                          

const WORD_PRESETS               = [
  { id: "standard", name: "Standard",
    en: { person: "Employee", people: "Employees", location: "Location", locations: "Locations" },
    es: { person: "Empleado", people: "Empleados", location: "Ubicación", locations: "Ubicaciones" } },
  { id: "retail", name: "Retail",
    en: { person: "Associate", people: "Associates", location: "Store", locations: "Stores" },
    es: { person: "Asociado", people: "Asociados", location: "Tienda", locations: "Tiendas" } },
  { id: "restaurant", name: "Restaurant",
    en: { person: "Team member", people: "Team members", location: "Restaurant", locations: "Restaurants" },
    es: { person: "Miembro del equipo", people: "Miembros del equipo", location: "Restaurante", locations: "Restaurantes" } },
  { id: "field", name: "Field services",
    en: { person: "Technician", people: "Technicians", location: "Site", locations: "Sites" },
    es: { person: "Técnico", people: "Técnicos", location: "Sede", locations: "Sedes" } },
  { id: "care", name: "Care",
    en: { person: "Caregiver", people: "Caregivers", location: "Facility", locations: "Facilities" },
    es: { person: "Cuidador", people: "Cuidadores", location: "Instalación", locations: "Instalaciones" } },
];

const DEFAULT_WORDS = WORD_PRESETS[0];
const wordPreset = (id         )             => WORD_PRESETS.find(p => p.id === id) ?? DEFAULT_WORDS;
/** For mid-sentence use: "Add team member", "All stores". */
const lower = (word        ) => word.charAt(0).toLowerCase() + word.slice(1);

/** Company modules (B2). An Owner can turn off features the company doesn't
 * use. A module that is off disappears from navigation, tabs, the finder,
 * Home and the Inbox, and its pages, actions and APIs refuse to work. Turning
 * a module off never deletes anything: switching it back on restores it. */
const MODULE_IDS = ["timeOff", "marketplace", "updates", "payStatements", "breaks"]         ;
                                                   
                                                       

                                
               
               
                      
                                                   
                  
                                                                             
                       
  

const MODULES                     = [
  { id: "timeOff", name: "Time off", description: "Employees request time off and managers approve it.",
    offNote: "Employees can’t request time off. Approved time off stays on the schedule." },
  { id: "marketplace", name: "Shift swaps and cover", description: "Employees offer, swap and pick up open shifts.",
    offNote: "Employees can’t offer, swap or pick up shifts. Shifts already traded stay as they are." },
  { id: "updates", name: "Company updates", description: "Announcements with optional acknowledgement.",
    offNote: "Updates are hidden from everyone and nothing new can be posted. Past updates are kept." },
  { id: "payStatements", name: "Pay statements", description: "Employees see their statements in NEVORA.", requires: "payroll",
    offNote: "Employees see their hours instead of statements. Payroll runs are unaffected." },
  { id: "breaks", name: "Breaks on the Clocker", description: "Employees start and end breaks on Clocker tablets.",
    offNote: "Employees can’t start a break on the Clocker. A break already started can still be ended." },
];

const ALL_MODULES_ON                 = { timeOff: true, marketplace: true, updates: true, payStatements: true, breaks: true };

function enabledModules(disabled                                       )                 {
  const off = new Set((disabled ?? []).filter((id)                 => MODULE_IDS.includes(id            )));
  return Object.fromEntries(MODULE_IDS.map(id => [id, !off.has(id)]))                  ;
}

const disabledList = (modules                )             => MODULE_IDS.filter(id => !modules[id]);

/** The module that owns a portal path, if any. The Requests overview stays:
 * it also holds availability, which is not a module. */
function moduleForPath(path        )                  {
  const pathname = path.split(/[?#]/, 1)[0];
  const under = (prefix        ) => pathname === prefix || pathname.startsWith(`${prefix}/`);
  if (under("/app/requests/hub")) return null;
  if (under("/app/requests")) return "timeOff";
  if (under("/app/exchange")) return "marketplace";
  if (under("/app/updates")) return "updates";
  if (under("/app/my-pay")) return "payStatements";
  if (under("/app/settings/breaks")) return "breaks";
  return null;
}

const pathEnabled = (path        , modules                 = ALL_MODULES_ON) => {
  const id = moduleForPath(path);
  return !id || modules[id];
};

/** Things still in progress that would be stranded if a module turned off. */
                                                               
function blockerText(id          , count        )         {
  const n = count === 1 ? "1 request" : `${count} requests`;
  return id === "timeOff" ? `${n} for time off ${count === 1 ? "is" : "are"} waiting for a decision. Decide ${count === 1 ? "it" : "them"} first.`
    : `${count === 1 ? "1 shift swap or cover request is" : `${count} shift swap or cover requests are`} still open. Let ${count === 1 ? "it" : "them"} finish first.`;
}

/** Manager request types that belong to a module (Inbox and Home tasks). */
function requestTypeAllowed(type        , modules                 = ALL_MODULES_ON)          {
  if (type === "TIME_OFF") return modules.timeOff;
  if (type === "EXCHANGE" || type === "CALLOUT") return modules.marketplace;
  return true;
}

return {WORD_PRESETS,WORD_PRESET_IDS,DEFAULT_WORDS,wordPreset,lower,MODULES,MODULE_IDS,ALL_MODULES_ON,enabledModules,disabledList,moduleForPath,pathEnabled,blockerText,requestTypeAllowed};})();
