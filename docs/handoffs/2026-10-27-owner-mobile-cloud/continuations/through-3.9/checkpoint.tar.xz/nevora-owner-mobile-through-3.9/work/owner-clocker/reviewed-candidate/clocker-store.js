/* Fictional Owner-only Clocker device administration. No browser/device credentials. */
function createOwnerClockerStore(api){
 const clone=v=>JSON.parse(JSON.stringify(v)),operations=['REGISTER','RENAME','ROTATE','REVOKE'];
 let rows=[],serial=4,tokenSerial=0,generation=0,mode='ready',reads=0,writes=0;
 const now=()=>api.now(),authority=()=>JSON.stringify([api.authority(),generation]);
 const gate=()=>api.gate()==='denied'||mode==='denied'?'denied':api.gate()!=='ready'||mode!=='ready'?'unavailable':'ready';
 function reset(){generation++;serial=4;tokenSerial=0;mode='ready';reads=0;writes=0;rows=[
  {id:'device-1',name:'Front counter tablet',locationId:'location-1',version:3,state:'ACTIVE',lastSeenAt:new Date(now()-300000).toISOString(),enrollmentExpiresAt:null},
  {id:'device-2',name:'Rincón welcome tablet',locationId:'location-2',version:1,state:'PENDING',lastSeenAt:null,enrollmentExpiresAt:new Date(now()+600000).toISOString()},
  {id:'device-3',name:'Isabela tablet',locationId:'location-3',version:2,state:'EXPIRED',lastSeenAt:null,enrollmentExpiresAt:new Date(now()-60000).toISOString()},
  {id:'device-4',name:'Previous counter tablet',locationId:'location-1',version:5,state:'REVOKED',lastSeenAt:new Date(now()-86400000).toISOString(),enrollmentExpiresAt:null}
 ];}
 function locations(){const v=api.locations();return Array.isArray(v)?v:null;}
 function read(){reads++;const g=gate();if(g!=='ready')return {state:g};const places=locations(),context=api.context();if(!places||!context)return {state:'unavailable'};return {state:'ready',devices:clone(rows).map(r=>r.state==='PENDING'&&Date.parse(r.enrollmentExpiresAt)<=now()?{...r,state:'EXPIRED'}:r),locations:clone(places),timeZone:context.timeZone,observedAt:new Date(now()).toISOString(),validForMs:45000,authority:authority()};}
 function validate(input){
  const errors={},op=input?.operation,allowed=op==='REGISTER'?['operation','name','locationId']:['operation','deviceId','expectedVersion',...(op==='RENAME'?['name']:[])];
  if(!input||!operations.includes(op)||Object.keys(input).some(k=>!allowed.includes(k)))errors.form='Check the device details and try again.';
  if(op==='REGISTER'||op==='RENAME'){const name=typeof input.name==='string'?input.name.trim():'';if(!name||[...name].length>80||/[\u0000-\u001f\u007f]/.test(input.name))errors.name='Enter a device name of 1–80 printable characters.';}
  if(op==='REGISTER'&&(typeof input.locationId!=='string'||!locations()?.some(l=>l.id===input.locationId&&l.active)))errors.locationId='Choose a current active location.';
  if(op!=='REGISTER'&&(!Number.isSafeInteger(input?.expectedVersion)||input.expectedVersion<1||input.expectedVersion>9999999999||typeof input.deviceId!=='string'||!/^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/.test(input.deviceId)))errors.form='Refresh this device before changing it.';
  return {ok:!Object.keys(errors).length,errors};
 }
 function execute(input,scenario='normal',expectedAuthority=authority()){
  if(expectedAuthority!==authority()||gate()==='denied')return {state:'denied',error:'Current Owner access is required.'};
  if(read().state!=='ready')return {state:'unavailable',error:'Current devices could not be confirmed. Refresh before editing.'};
  const v=validate(input);if(!v.ok)return {state:'invalid',errors:v.errors,error:Object.values(v.errors)[0]};
  const op=input.operation,current=rows.find(d=>d.id===input.deviceId);
  if(op!=='REGISTER'&&(!current||current.version!==input.expectedVersion))return {state:'conflict',error:'This device changed. Refresh its current details before trying again.'};
  if(op==='ROTATE'&&!locations().some(l=>l.id===current.locationId&&l.active))return {state:'invalid',errors:{form:'Choose an active location before creating a new setup code.'},error:'This device’s location is inactive or unavailable.'};
  if(scenario==='failure')return {state:'invalid',errors:{form:'The change was not saved. Your entries are kept.'},error:'The change was not saved. Your entries are kept.'};
  if(scenario==='unknown-before')return {state:'unconfirmed',error:'The update could not be confirmed. Refresh devices before making another change.'};
  let device,setup;
  if(op==='REGISTER'){device={id:'device-'+(++serial),name:input.name.trim(),locationId:input.locationId,version:1,state:'PENDING',lastSeenAt:null,enrollmentExpiresAt:new Date(now()+600000).toISOString()};rows.push(device);}
  else{device=current;device.version++;if(op==='RENAME')device.name=input.name.trim();else if(op==='REVOKE'){device.state='REVOKED';device.enrollmentExpiresAt=null;}else{device.state='PENDING';device.enrollmentExpiresAt=new Date(now()+600000).toISOString();}}
  writes++;
  // Deliberately invalid for real enrollment. Never retain this value in row state.
  if(op==='REGISTER'||op==='ROTATE')setup={code:'SAMPLE-ONLY_nev_enr_'+(++tokenSerial).toString(16).padStart(64,'0'),expiresAt:device.enrollmentExpiresAt};
  if(scenario==='unknown-after')return {state:'unconfirmed',error:'The update could not be confirmed. Refresh devices before making another change.'};
  if(scenario==='confirmed-read-failed')mode='unavailable';
  return {state:'confirmed',device:clone(device),...(setup?{setup}:{})};
 }
 reset();
 return {gate,authority,now,read,validate,execute,reset,previewReadMode:v=>{mode=v;},previewDevice:(id,patch)=>{const d=rows.find(d=>d.id===id);if(d)Object.assign(d,clone(patch));},previewEmpty:()=>{rows=[];},previewAuthority:()=>{generation++;},snapshot:()=>({writes,reads,mode,deviceCount:rows.length})};
}
