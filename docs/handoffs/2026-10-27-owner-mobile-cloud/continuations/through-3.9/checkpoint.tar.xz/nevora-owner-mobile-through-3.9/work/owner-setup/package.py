"""Separate 3.7 source/evidence overlay for the immutable original 3.5 handoff."""
from pathlib import Path
import hashlib,json,tarfile,subprocess
r=Path(__file__).resolve().parents[2]
roots=['work/owner-mobile','work/owner-policies','work/owner-setup','outputs/owner-policies','outputs/owner-setup','outputs/nevora-owner-mobile.html','outputs/owner-mobile-current-coverage.json','outputs/owner-mobile-delivery-plan.md','outputs/owner-mobile-delivery-plan.json','outputs/owner-mobile-quality-gates.md','outputs/owner-mobile-remaining.md','CURRENT-STATE.md','ACTIVE-BATCH.md','AGENTS.md','START-HERE.md','NEXT-BATCH-3.6.md','NEXT-BATCH-3.7.md','NEXT-BATCH-3.8.md','DESIGN.md','CONVERSATION-CONTEXT.md','WORKING-AGREEMENTS.md']
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
archive=Path('/workspace/shared/downloads/nevora-owner-mobile-3.7.tar.xz');assert not archive.exists(),'Preserve an existing archive; select a new identified checkpoint.'
files=[]
for name in roots:
 p=r/name;assert p.exists(),p;files.extend([p] if p.is_file() else [f for f in p.rglob('*') if f.is_file() and '__pycache__' not in f.parts])
manifest=r/'outputs/owner-setup/source-evidence-manifest.json';files=[p for p in sorted(set(files)) if p!=manifest]
records=[{'path':str(p.relative_to(r)),'bytes':p.stat().st_size,'sha256':h(p)} for p in files]
manifest.write_text(json.dumps({'batch':'3.7','base_repository':'JoseK0514/NEVORA','base_branch':'codex/owner-mobile-cloud-handoff-20261027','base_artifact_sha256':'65f2a5d5cbb596f90a2d08adb2fca30c869e1142e8325e9d25f23326e70d1c64','previous_accepted_3.6_sha256':'7edd132760a949c11c164420b874337ce2d80a4c1e9c6e42cc77735507fee5fe','artifact_sha256':h(r/'outputs/nevora-owner-mobile.html'),'scope':'Standalone MOBILE OWNER source/evidence overlay containing3.6+3.7 continuation. Extract original handoff first, then overlay these files into a COPY outside the application checkout. Original immutable manifest remains historical. No application integration, real services/data/messages, Git publication/merge/deployment or seven-branch policy exception.','files':records},indent=2))
archive.parent.mkdir(exist_ok=True,parents=True)
with tarfile.open(archive,'w:xz') as t:
 for p in files+[manifest]:t.add(p,arcname='nevora-owner-mobile-3.7/'+str(p.relative_to(r)))
problems=[]
with tarfile.open(archive,'r:xz') as t:
 for v in records:
  data=t.extractfile('nevora-owner-mobile-3.7/'+v['path']).read()
  if len(data)!=v['bytes'] or hashlib.sha256(data).hexdigest()!=v['sha256']:problems.append(v['path'])
 extract=Path('/workspace/nevora-owner-3.7-package-check');assert not extract.exists();t.extractall(extract,filter='data')
copy=extract/'nevora-owner-mobile-3.7';subprocess.run(['python3','work/owner-mobile/build.py'],cwd=copy,check=True,capture_output=True)
assert h(copy/'outputs/nevora-owner-mobile.html')==h(r/'outputs/nevora-owner-mobile.html')
result={'archive':str(archive),'bytes':archive.stat().st_size,'sha256':h(archive),'source_sha256':h(r/'outputs/nevora-owner-mobile.html'),'files_verified':len(records),'problems':problems,'extracted_rebuild_matches':True,'extraction':str(copy),'limits':'Overlay includes source/evidence through3.7; immutable pinned reference/runtime/history supplied by original3.5handoff. No real application integration or deployment.'}
Path('/workspace/shared/downloads/nevora-owner-mobile-3.7-validation.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2));assert not problems
