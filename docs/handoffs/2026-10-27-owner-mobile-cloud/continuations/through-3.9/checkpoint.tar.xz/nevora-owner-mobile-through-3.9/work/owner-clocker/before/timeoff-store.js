/* Fictional company time-off decisions. Pending-only source contract, no command replay API. */
function createOwnerTimeOffStore(team,schedule,clock){
 const copy=x=>JSON.parse(JSON.stringify(x)),DAY=86400000;
 let moduleSource=()=> 'on';
 let records,mode,sources,enabled=true,session=1,reads=0,writes=0;
 const now=()=>clock.now();
 const validDate=v=>typeof v==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(v)&&Number.isFinite(Date.parse(v+'T12:00Z'))&&new Date(v+'T12:00Z').toISOString().slice(0,10)===v;
 const minute=t=>Number(t.split(':')[0])*60+Number(t.split(':')[1]);
 const validTime=(v,end=false)=>typeof v==='string'&&(end&&v==='24:00'||/^([01]\d|2[0-3]):[0-5]\d$/.test(v));
 const addDay=(d,n)=>new Date(Date.parse(d+'T12:00Z')+n*DAY).toISOString().slice(0,10);
 const instant=(d,t)=>Date.parse(d+'T00:00:00-04:00')+minute(t)*60000;
 function interval(r){return [instant(r.startDate,r.startTime||'00:00'),r.startTime?instant(r.endDate,r.endTime):instant(addDay(r.endDate,1),'00:00')];}
 const shiftInterval=s=>{const start=instant(s.date,s.start),end=instant(s.date,s.end);return [start,end<=start?end+DAY:end];};
 const intersects=(a,b)=>Math.max(a[0],b[0])<Math.min(a[1],b[1]);
 function reset(){mode='ready';sources={pending:'ready',approved:'ready',declined:'ready',schedule:'ready'};enabled=true;reads=0;writes=0;records=[
  {id:'timeoff-maria',employeeId:'person-9',startDate:'2026-10-30',endDate:'2026-10-30',reason:'I have a family appointment and would like to take the day off.',status:'PENDING',createdAt:'2026-10-24T09:15:00-04:00'},
  {id:'timeoff-alex',employeeId:'person-1',startDate:'2026-10-28',endDate:'2026-10-28',startTime:'09:00',endTime:'13:00',reason:'A morning appointment. I can work after 1:00 PM.',status:'PENDING',createdAt:'2026-10-25T10:30:00-04:00'},
  {id:'timeoff-casey',employeeId:'person-8',startDate:'2026-11-05',endDate:'2026-11-06',reason:'Family visit. Thank you for reviewing these two days.',status:'PENDING',createdAt:'2026-10-23T14:00:00-04:00'},
  {id:'timeoff-ana',employeeId:'person-6',startDate:'2026-11-03',endDate:'2026-11-03',startTime:'10:00',endTime:'14:00',reason:'Personal appointment.',status:'APPROVED',createdAt:'2026-10-21T08:00:00-04:00',reviewerName:'Morgan Vega',reviewedAt:'2026-10-24T11:00:00-04:00'},
  {id:'timeoff-sam',employeeId:'person-3',startDate:'2026-10-19',endDate:'2026-10-21',reason:'',status:'APPROVED',createdAt:'2026-10-13T08:00:00-04:00'},
  {id:'timeoff-jordan',employeeId:'person-10',startDate:'2026-10-29',endDate:'2026-10-29',reason:'Personal day.',status:'DENIED',createdAt:'2026-10-20T09:00:00-04:00',reviewerName:'Jamie Patel',reviewedAt:'2026-10-24T15:15:00-04:00'}
 ];}reset();
 function authority(){const a=team.snapshot().actor;return JSON.stringify([a.id,a.accessRole,a.active,a.roleGeneration,session,enabled,moduleSource(),'sample-company','timeoff']);}
 function access(ignoreModule=false){if(!team.isOwner()||mode==='denied'||Object.values(sources).includes('denied'))return 'access_denied';if(mode==='signed-out')return 'authentication_required';if(!ignoreModule&&(!enabled||moduleSource()==='off'))return 'module_disabled';if(!ignoreModule&&moduleSource()==='unavailable')return 'read_failed';return null;}
 const tabOf=r=>({PENDING:'pending',APPROVED:'approved',DENIED:'declined'})[r.status];
 function read(){reads++;const denied=access();if(denied)return {state:'unavailable',reason:denied};if(!['ready','empty'].includes(mode))return {state:'unavailable',reason:({limit:'source_limit',schema:'schema_missing'})[mode]||'read_failed'};
  const state=Object.fromEntries(Object.entries(sources).map(([k,v])=>[k,v==='ready'?'ready':'unavailable']));if(['pending','approved','declined'].every(k=>state[k]==='unavailable'))return {state:'unavailable',reason:'read_failed'};
  try{const model=state.schedule==='ready'?schedule.snapshot():null,requests=[];
   for(const raw of mode==='empty'?[]:records){const tab=tabOf(raw);if(!tab||state[tab]!=='ready')continue;if(!validDate(raw.startDate)||!validDate(raw.endDate)||raw.startDate>raw.endDate||Boolean(raw.startTime)!==Boolean(raw.endTime)||raw.startTime&&(raw.startDate!==raw.endDate||!validTime(raw.startTime)||!validTime(raw.endTime,true)||minute(raw.startTime)>=minute(raw.endTime)))throw Error('Invalid request');
    const p=team.get(raw.employeeId),impacts=model?model.shifts.filter(s=>s.person===raw.employeeId&&!s.isCalloutApproved&&intersects(interval(raw),shiftInterval(s))).map(s=>({id:s.id,date:s.date,start:s.start,end:s.end,location:s.loc})).sort((a,b)=>a.date.localeCompare(b.date)||a.start.localeCompare(b.start)||a.id.localeCompare(b.id)):null;
    requests.push({...copy(raw),name:p?.name||raw.employeeName||'Employee unavailable',displayId:p?.employeeId||'Not available',initials:p?.initials||'',tone:p?.tone||'',primaryLocation:p?.loc||'No primary location',profileAvailable:!!p,partial:!!raw.startTime,calendarDays:Math.round((Date.parse(raw.endDate+'T12:00Z')-Date.parse(raw.startDate+'T12:00Z'))/DAY)+1,reason:raw.reason||'',reviewerName:raw.reviewerName||null,reviewedAt:raw.reviewedAt||null,impacts});
   }
   requests.sort((a,b)=>a.status===b.status?(a.status==='PENDING'?a.startDate.localeCompare(b.startDate)||a.createdAt.localeCompare(b.createdAt):b.startDate.localeCompare(a.startDate)||b.createdAt.localeCompare(a.createdAt)):a.status.localeCompare(b.status));
   const counts=Object.fromEntries(['pending','approved','declined'].map(k=>[k,state[k]==='ready'?requests.filter(r=>tabOf(r)===k).length:null]));return {state:'ready',requests,counts,sources:state,observedAt:new Date(now()).toISOString(),validForMs:45000,authority:authority()};
  }catch{return {state:'unavailable',reason:'invalid_source'};}
 }
 function decide(command,scenario='normal',key=authority()){const denied=access();if(denied||key!==authority())return {state:'unavailable',reason:denied||'access_denied'};if(!command?.requestId||!['APPROVED','DENIED'].includes(command.decision))return {state:'not_saved',reason:'invalid'};
  const r=records.find(r=>r.id===command.requestId);if(!r||r.status!=='PENDING')return {state:'not_saved',reason:'no_longer_pending'};
  if(scenario==='concurrent'){Object.assign(r,{status:'DENIED',reviewerName:'Morgan Vega',reviewedAt:new Date(now()).toISOString()});return {state:'not_saved',reason:'no_longer_pending'};}
  if(['unknown-before','failure'].includes(scenario))return {state:'unknown'};
  const actor=team.snapshot().actor;Object.assign(r,{status:command.decision,reviewerName:actor.name,reviewedAt:new Date(now()).toISOString()});writes++;
  if(scenario==='unknown-after')return {state:'unknown'};return {state:'saved',requestId:r.id,decision:r.status,reviewerName:r.reviewerName,reviewedAt:r.reviewedAt};
 }
 function approvedOverlap({employeeId,date,startTime='00:00',endTime='24:00'}){if(access(true)||mode!=='ready'||sources.approved!=='ready'||sources.schedule!=='ready')return null;try{const a=shiftInterval({date,start:startTime,end:endTime});return records.some(r=>r.employeeId===employeeId&&r.status==='APPROVED'&&intersects(interval(r),a));}catch{return null;}}
 return {currentAccess:access,setModuleSource:fn=>{moduleSource=fn;},blockerSource:()=>!team.isOwner()||mode!=='ready'||Object.values(sources).includes('denied')||sources.pending!=='ready'?{state:'unavailable'}:{state:'ready',count:records.filter(r=>r.status==='PENDING').length},read,decide,approvedOverlap,authority,now,reset,tabOf,validDate,weekFor:d=>{const day=new Date(d+'T12:00Z').getUTCDay();return addDay(d,-((day+6)%7));},setReadMode:v=>{mode=v;},setEnabled:v=>{enabled=!!v;},previewSource:(k,v)=>{sources[k]=v;},previewAuthority:()=>{session++;},previewRequest:(id,patch)=>{const r=records.find(r=>r.id===id);if(r)Object.assign(r,copy(patch));},samplePending:()=>records.find(r=>r.id==='timeoff-maria')?.status==='PENDING',snapshot:()=>({reads,writes,mode,enabled,sources:{...sources}})};
}
