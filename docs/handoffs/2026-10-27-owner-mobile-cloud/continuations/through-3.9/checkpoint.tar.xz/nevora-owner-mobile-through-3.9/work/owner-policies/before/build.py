from pathlib import Path
root=Path(__file__).resolve().parents[2]
source=root/"work/owner-mobile"
css="\n".join((source/name).read_text() for name in ["styles.css","schedule.css","team.css","invitations.css","manager-access.css","clocker-pin.css","account-recovery.css","operational-rules.css","timecards.css","corrections.css","timecard-actions.css","attendance.css","workforce.css","timeoff.css","exchanges.css","triage.css","company.css","locations.css","catalogs.css","branding.css","features.css"])
js="\n".join((source/name).read_text() for name in ["schedule.js","team-store.js","invitation-store.js","manager-access-store.js","clocker-pin-store.js","account-recovery-store.js","operational-rules-store.js","team.js","invitations.js","manager-access.js","clocker-pin.js","account-recovery.js","operational-rules.js","timecards-store.js","timecard-actions-store.js","timecard-actions.js","timecards.js","corrections-store.js","corrections.js","attendance-store.js","attendance.js","workforce-store.js","workforce.js","timeoff-store.js","timeoff.js","exchanges-store.js","exchanges.js","triage-store.js","triage.js","company-store.js","company.js","locations-store.js","locations.js","catalogs-store.js","catalogs.js","brand-colors.js","presentation-data.js","branding-store.js","branding.js","features.js","presentation-adapter.js","app.js"])
h=(source/"template.html").read_text().replace("__APP_CSS__",css).replace("__APP_JS__",js)
(root/"outputs/nevora-owner-mobile.html").write_text(h)
print("Built self-contained owner mobile mockup")
