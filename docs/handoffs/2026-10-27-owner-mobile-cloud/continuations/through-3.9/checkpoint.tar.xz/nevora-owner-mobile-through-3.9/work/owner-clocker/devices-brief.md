# Clocker devices: bounded C-13 controller

This worker owns the standalone mobile Owner directory, details, rename, rotation/reconnection/replacement review, revoke review and the shared private-code lifecycle. Root owns the single in-memory device model, integration, baseline and final inventory. The enrollment helper renders Add device and the immediate code handoff; it does not own another device list or command state.

The accepted system remains the Company/Locations task header, native fields, definition groups, neutral consequences, teal actions and 44/48px controls. Each state has one primary task. Device identity and its fixed location remain visible when reviewing access changes. Active, Needs setup and Removed are distinct filters; inactive locations keep Rename and Revoke while creating a code waits for an active location.

All content is fictional and resets with the artifact. This work calls no application API, device endpoint, external service, real clipboard service or messaging system. The local browser Copy action only attempts the platform clipboard from an explicit user gesture. Owner tablet instructions are descriptive; no tablet simulator is introduced.

Before implementation, freeze `interfaces.md`, add failing controller behavior tests, preserve their RED evidence, then implement and preserve GREEN evidence. Browser checks use only the integrated static artifact on localhost port 18763, after root integration. Final claims are bounded by the checks actually run.

Required journeys: directory filters and empty states; exact device detail; rename draft/validation/save; replacement/reconnection/new-code review; revoke confirmation/result; stale write/current details; uncertain original-operation reconciliation; no active location; read failure and recovery; authority change; blur/offline/pagehide/hidden expiry cleanup; exact Settings/More/Location return with focus; 320/390/430px at 100/200%, keyboard, live header clearance and private-value absence from URL/storage/snapshots.

No changes to frozen `reference/application`, real application, Git, services, operational data, messages or deployment.
