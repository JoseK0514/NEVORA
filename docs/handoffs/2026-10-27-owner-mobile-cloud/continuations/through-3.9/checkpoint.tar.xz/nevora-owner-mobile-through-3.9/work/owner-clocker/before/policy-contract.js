/* Mechanically adapted pinned contracts. See work/owner-policies/contract-provenance.json. */
var ownerPolicyContract = (()=>{
const Temporal=temporal.Temporal;
const parseLaborPlanningInputs=(()=>{                          
             
                     
                            
               
                   
                                               
                    
                            
  
                            
             
                            
                  
                
                 
                   
  
                                                                        
/** Central company-policy custody owns persistence, workspace subject validation,
 * immutable revision/audit, location inheritance and source provenance. These
 * values grant no read permission and do not approve a calculation method. */
                            
                                    
                                        
                                                            
  
                             
                          
                      
                 
                   
                                         
                                           
    
                                      
                                                          
            
                      
                        
                                   
      
              
                                       
                                                
                                  
    
  
const object = (v         )                               =>
  !!v && typeof v === "object" && !Array.isArray(v);
const text = (v         )              =>
  typeof v === "string" &&
  v.length > 0 &&
  v.length <= 200 &&
  v === v.trim() &&
  !/[\u0000-\u001f\u007f]/.test(v);
const fields = (v                         , keys          ) =>
  Object.keys(v).length === keys.length &&
  keys.every((k) => Object.hasOwn(v, k));
// Lexical decimal storage only. No conversion, scale, currency or rounding
// default; Finance must define arithmetic before any monetary output exists.
const decimal = (v         )              =>
  typeof v === "string" && v.length <= 80 && /^(0|[1-9]\d*)(\.\d+)?$/.test(v);
const currency = (v         )              =>
  typeof v === "string" && /^[A-Z]{3}$/.test(v);
const instant = (v         )              => {
  try {
    return typeof v === "string" && Temporal.Instant.from(v).toString() !== "";
  } catch {
    return false;
  }
};
const location = (v         )                     => v === null || text(v);

/** Preserve bounded lexical decimal rates/budgets with their explicit currency/unit
 * and instant windows. Same employee/location rate windows may not overlap; no
 * rounding, currency conversion, monetary scale or approved Finance method is inferred. */
function parseLaborPlanningInputs(v         )                      {
  if (
    !object(v) ||
    !fields(v, ["rates", "budgets", "calculationMethod"]) ||
    !(v.rates === null || (Array.isArray(v.rates) && v.rates.length <= 5000)) ||
    !(
      v.budgets === null ||
      (Array.isArray(v.budgets) && v.budgets.length <= 500)
    )
  )
    throw Error("invalid_labor_inputs");
  const rates =
    v.rates === null
      ? null
      : (v.rates             ).map((r)                    => {
          if (
            !object(r) ||
            !fields(r, [
              "id",
              "employeeId",
              "locationId",
              "rate",
              "currency",
              "rateUnit",
              "validFrom",
              "validUntil",
            ]) ||
            !text(r.id) ||
            !text(r.employeeId) ||
            !location(r.locationId) ||
            !decimal(r.rate) ||
            !currency(r.currency) ||
            typeof r.rateUnit !== "string" ||
            !["HOUR", "SHIFT", "SALARY_PERIOD"].includes(r.rateUnit) ||
            !instant(r.validFrom) ||
            !(
              r.validUntil === null ||
              (instant(r.validUntil) &&
                Temporal.Instant.compare(r.validUntil, r.validFrom) > 0)
            )
          )
            throw Error("invalid_labor_rate");
          return {
            id: r.id,
            employeeId: r.employeeId,
            locationId: r.locationId,
            rate: r.rate,
            currency: r.currency,
            rateUnit: r.rateUnit                                 ,
            validFrom: r.validFrom,
            validUntil: r.validUntil,
          };
        });
  const budgets =
    v.budgets === null
      ? null
      : (v.budgets             ).map((b)                      => {
          if (
            !object(b) ||
            !fields(b, [
              "id",
              "locationId",
              "startAt",
              "endAt",
              "amount",
              "currency",
            ]) ||
            !text(b.id) ||
            !location(b.locationId) ||
            !decimal(b.amount) ||
            !currency(b.currency) ||
            !instant(b.startAt) ||
            !instant(b.endAt) ||
            Temporal.Instant.compare(b.endAt, b.startAt) <= 0
          )
            throw Error("invalid_labor_budget");
          return {
            id: b.id,
            locationId: b.locationId,
            startAt: b.startAt,
            endAt: b.endAt,
            amount: b.amount,
            currency: b.currency,
          };
        });
  let calculationMethod                                         = null;
  if (v.calculationMethod !== null) {
    const m = v.calculationMethod;
    if (
      !object(m) ||
      !fields(m, ["id", "revision"]) ||
      !text(m.id) ||
      !Number.isSafeInteger(m.revision) ||
      Number(m.revision) < 1
    )
      throw Error("invalid_method_reference");
    calculationMethod = { id: m.id, revision: Number(m.revision) };
  }
  if (
    (rates && new Set(rates.map((r) => r.id)).size !== rates.length) ||
    (budgets && new Set(budgets.map((b) => b.id)).size !== budgets.length)
  )
    throw Error("duplicate_labor_input");
  for (let i = 0; i < (rates?.length ?? 0); i++) {
    const a = rates [i];
    for (let j = 0; j < i; j++) {
      const b = rates [j];
      if (
        a.employeeId === b.employeeId &&
        a.locationId === b.locationId &&
        (a.validUntil === null ||
          Temporal.Instant.compare(b.validFrom, a.validUntil) < 0) &&
        (b.validUntil === null ||
          Temporal.Instant.compare(a.validFrom, b.validUntil) < 0)
      )
        throw Error("overlapping_labor_rate");
    }
  }
  return { rates, budgets, calculationMethod };
}

/** No trusted Finance method catalogue exists at this source. A company-owned
 * reference never becomes approval. Every unit, including hourly, stays unavailable.
 * Central callers must use captured canonical inputs, not request-supplied claims. */
function laborBudgetReadiness(
  input                            ,
)                       {
  const inputs = input === null ? null : parseLaborPlanningInputs(input);
  const hasRates = !!inputs?.rates?.length,
    hasBudgets = !!inputs?.budgets?.length;
  return {
    state: "not_configured",
    estimatedCost: null,
    variance: null,
    customerInputs: {
      rates: hasRates ? "provided" : "not_configured",
      budgets: hasBudgets ? "provided" : "not_configured",
    },
    calculationMethod: "not_configured",
    methodReference: inputs?.calculationMethod ?? null,
    missing: [
      ...(!hasRates ? ["customer_rates"         ] : []),
      ...(!hasBudgets ? ["customer_budgets"         ] : []),
      "approved_calculation_method",
    ],
    timeBases: {
      planned: "separate_input_required",
      actual: "RECORDED_ELAPSED_INCLUDING_BREAKS",
      compensated: "not_configured",
    },
  };
}

return parseLaborPlanningInputs;})();
const model=(()=>{                      
                           
                           
                        
  
                                 
                                  
                                        
             
                        
                                                        
                                              
        
           
                   
                        
                                                
                                     
        
           
                  
                        
                                                
                                                              
        
           
  
                                         
        
                                         
                                           
                                           
                                      
                          
                        
  
/** Compensation is an explicit company reference/readiness contract. It never
 * interprets law or computes wage entitlement from a rule label. */
                         
                        
                        
                 
                                   
                                     
                                 
  
                                           
                                               
                                                              
                            
                                         
                                         
                                     
                                         
                                                    
  
                              
             
                                        
                              
  
                                 
             
                                                 
                                       
  
                             
                      
                           
                            
                                  
  
const object = (v         )                               =>
  !!v && typeof v === "object" && !Array.isArray(v);
const text = (v         , max = 300)              =>
  typeof v === "string" &&
  v === v.trim() &&
  v.length > 0 &&
  v.length <= max &&
  !/[\u0000-\u001f\u007f]/.test(v);
const keys = (v                         , allowed          ) => {
  if (Object.keys(v).some((k) => !allowed.includes(k)))
    throw Error("Invalid company policy fields");
};
const instant = (v         ) => {
  if (!text(v, 100)) throw Error("Invalid effective date");
  return Temporal.Instant.from(v).toString();
};
function threshold(v         , extra           = [])                {
  if (!object(v)) throw Error("Invalid company rule");
  keys(v, ["thresholdMinutes", "comparison", "effectiveFrom", ...extra]);
  if (
    !Number.isSafeInteger(v.thresholdMinutes) ||
    Number(v.thresholdMinutes) < 0 ||
    Number(v.thresholdMinutes) > 525600 ||
    typeof v.comparison !== "string" ||
    !["GT", "GTE"].includes(v.comparison)
  )
    throw Error("Invalid explicit threshold");
  return {
    thresholdMinutes: Number(v.thresholdMinutes),
    comparison: v.comparison                ,
    effectiveFrom: instant(v.effectiveFrom),
  };
}
function parseCompanyPolicySettings(
  value         ,
)                        {
  if (!object(value) || value.version !== 1)
    throw Error("Invalid company policy version");
  keys(value, ["version", "attendance", "labor"]);
  const output                        = { version: 1 };
  if (value.attendance !== undefined) {
    if (!object(value.attendance)) throw Error("Invalid attendance settings");
    keys(value.attendance, [
      "lateness",
      "earlyDeparture",
      "longEntry",
      "missingClockIn",
      "missingClockOut",
    ]);
    const attendance                           = {};
    for (const field of ["lateness", "earlyDeparture"]         )
      if (Object.hasOwn(value.attendance, field))
        attendance[field] =
          value.attendance[field] === null
            ? null
            : threshold(value.attendance[field]);
    if (Object.hasOwn(value.attendance, "longEntry")) {
      const rule = value.attendance.longEntry;
      if (rule === null) attendance.longEntry = null;
      else {
        const base = threshold(rule, ["basis", "appliesTo"]);
        if (
          !object(rule) ||
          typeof rule.basis !== "string" ||
          !["RECORDED_ELAPSED", "EFFECTIVE_ELAPSED"].includes(rule.basis) ||
          typeof rule.appliesTo !== "string" ||
          !["OPEN", "CLOSED", "BOTH"].includes(rule.appliesTo)
        )
          throw Error("Invalid entry basis");
        attendance.longEntry = {
          ...base,
          basis: rule.basis                                            ,
          appliesTo: rule.appliesTo                              ,
        };
      }
    }
    if (Object.hasOwn(value.attendance, "missingClockIn")) {
      const rule = value.attendance.missingClockIn;
      if (rule === null) attendance.missingClockIn = null;
      else {
        const base = threshold(rule, ["association", "cutoff"]);
        if (
          !object(rule) ||
          rule.association !== "CAPTURED_PUBLISHED_SHIFT" ||
          typeof rule.cutoff !== "string" ||
          !["AFTER_SCHEDULE_START", "AFTER_SCHEDULE_END"].includes(rule.cutoff)
        )
          throw Error("Invalid expected-assignment basis");
        attendance.missingClockIn = {
          ...base,
          association: rule.association,
          cutoff: rule.cutoff                                                 ,
        };
      }
    }
    if (Object.hasOwn(value.attendance, "missingClockOut")) {
      const rule = value.attendance.missingClockOut;
      if (rule === null) attendance.missingClockOut = null;
      else {
        const base = threshold(rule, ["association", "cutoff"]);
        if (
          !object(rule) ||
          rule.association !== "CAPTURED_PUBLISHED_SHIFT" ||
          rule.cutoff !== "AFTER_SCHEDULE_END"
        )
          throw Error("Invalid clock-out basis");
        attendance.missingClockOut = {
          ...base,
          association: rule.association,
          cutoff: rule.cutoff,
        };
      }
    }
    output.attendance = attendance;
  }
  if (value.labor !== undefined) {
    if (!object(value.labor)) throw Error("Invalid labor settings");
    keys(value.labor, [
      "overtimeRisk",
      "compensation",
      "rates",
      "budgets",
      "calculationMethod",
    ]);
    const labor                      = {};
    if (Object.hasOwn(value.labor, "overtimeRisk")) {
      const rule = value.labor.overtimeRisk;
      if (rule === null) labor.overtimeRisk = null;
      else {
        const base = threshold(rule, [
          "basis",
          "window",
          "aggregation",
          "dayBoundaryTime",
          "weekStartsOn",
        ]);
        if (
          !object(rule) ||
          typeof rule.basis !== "string" ||
          ![
            "RECORDED_ELAPSED_INCLUDING_BREAKS",
            "EFFECTIVE_ELAPSED_INCLUDING_BREAKS",
          ].includes(rule.basis) ||
          typeof rule.window !== "string" ||
          !["BUSINESS_DAY", "BUSINESS_WEEK"].includes(rule.window) ||
          typeof rule.aggregation !== "string" ||
          !["COMPANY", "LOCATION"].includes(rule.aggregation) ||
          typeof rule.dayBoundaryTime !== "string" ||
          !/^([01][0-9]|2[0-3]):[0-5][0-9]$/.test(rule.dayBoundaryTime) ||
          (rule.window === "BUSINESS_WEEK"
            ? !Number.isSafeInteger(rule.weekStartsOn) ||
              Number(rule.weekStartsOn) < 0 ||
              Number(rule.weekStartsOn) > 6
            : rule.weekStartsOn !== undefined)
        )
          throw Error("Invalid actual-time overtime basis");
        labor.overtimeRisk = {
          ...base,
          basis: rule.basis                             ,
          window: rule.window                              ,
          aggregation: rule.aggregation                                   ,
          dayBoundaryTime: rule.dayBoundaryTime,
          ...(rule.window === "BUSINESS_WEEK"
            ? { weekStartsOn: Number(rule.weekStartsOn) }
            : {}),
        };
      }
    }
    if (Object.hasOwn(value.labor, "compensation")) {
      const rule = value.labor.compensation;
      if (rule === null) labor.compensation = null;
      else {
        if (!object(rule)) throw Error("Invalid compensation setting");
        keys(rule, [
          "effectiveFrom",
          "ruleReference",
          "breakTreatment",
          "excludedBreakTypeIds",
        ]);
        if (
          !text(rule.ruleReference) ||
          typeof rule.breakTreatment !== "string" ||
          ![
            "INCLUDE_ALL_RECORDED_BREAKS",
            "EXCLUDE_SELECTED_BREAK_TYPES",
          ].includes(rule.breakTreatment) ||
          !Array.isArray(rule.excludedBreakTypeIds) ||
          rule.excludedBreakTypeIds.length > 100 ||
          rule.excludedBreakTypeIds.some((v) => !text(v, 200)) ||
          new Set(rule.excludedBreakTypeIds).size !==
            rule.excludedBreakTypeIds.length ||
          (rule.breakTreatment === "INCLUDE_ALL_RECORDED_BREAKS" &&
            rule.excludedBreakTypeIds.length)
        )
          throw Error("Invalid explicit compensation basis");
        labor.compensation = {
          effectiveFrom: instant(rule.effectiveFrom),
          ruleReference: rule.ruleReference,
          breakTreatment:
            rule.breakTreatment                                      ,
          excludedBreakTypeIds: [...rule.excludedBreakTypeIds].sort(),
        };
      }
    }
    const planning = parseLaborPlanningInputs({
      rates: value.labor.rates ?? null,
      budgets: value.labor.budgets ?? null,
      calculationMethod: value.labor.calculationMethod ?? null,
    });
    for (const field of ["rates", "budgets", "calculationMethod"]         )
      if (Object.hasOwn(value.labor, field))
        Object.assign(labor, { [field]: planning[field] });
    output.labor = labor;
  }
  return output;
}
/** Normalize the operation UUID and validate a complete scope revision. null location
 * selects company defaults; a location ID selects that override stream. This shape
 * validation does not establish current Owner rights or referenced-subject ownership. */
function parseCompanyPolicyCommand(
  value         ,
)                       {
  if (!object(value)) throw Error("Invalid company policy command");
  keys(value, ["operationId", "expectedRevision", "locationId", "settings"]);
  // PostgreSQL integer revisions must leave room for the atomic expected + 1.
  if (
    typeof value.operationId !== "string" ||
    !/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(
      value.operationId,
    ) ||
    !Number.isSafeInteger(value.expectedRevision) ||
    Number(value.expectedRevision) < 0 ||
    Number(value.expectedRevision) > 2147483646 ||
    !(value.locationId === null || text(value.locationId, 200))
  )
    throw Error("Invalid company policy command");
  return {
    operationId: value.operationId.toLowerCase(),
    expectedRevision: Number(value.expectedRevision),
    locationId: value.locationId,
    settings: parseCompanyPolicySettings(value.settings),
  };
}
/** Absent override keys inherit; null unconfigures; provided arrays replace the
 * complete company array. Omitted employee rates never become zero. */
function effectiveCompanyPolicies(
  company                              ,
  location                              ,
)                           {
  // Saved JSON is untrusted too. Reject invalid revisions before selecting any
  // inherited/overridden rule; never coerce or rewrite immutable history.
  company = company === null ? null : parseCompanyPolicySettings(company);
  location = location === null ? null : parseCompanyPolicySettings(location);
  const own = (section                        , field        ) => {
    const override = location?.[section]                                       ;
    return override && Object.hasOwn(override, field)
      ? override[field]
      : ((company?.[section]                                       )?.[field] ??
          null);
  };
  return {
    version: 1,
    attendance: {
      lateness: own("attendance", "lateness"),
      earlyDeparture: own("attendance", "earlyDeparture"),
      longEntry: own("attendance", "longEntry"),
      missingClockIn: own("attendance", "missingClockIn"),
      missingClockOut: own("attendance", "missingClockOut"),
    },
    labor: {
      overtimeRisk: own("labor", "overtimeRisk"),
      compensation: own("labor", "compensation"),
      rates: own("labor", "rates"),
      budgets: own("labor", "budgets"),
      calculationMethod: own("labor", "calculationMethod"),
    },
  }                            ;
}

return {parseCompanyPolicySettings,parseCompanyPolicyCommand,effectiveCompanyPolicies};})();
const parseCompanyPolicySettings=model.parseCompanyPolicySettings;
const history=(()=>{                                                                                
                    
                       
  
                                                                                 
                               
     
                                                       
                                                        
  
                                                                                     
                                               
                                                                                    
     
                           
                                 
                                                                         
     
  
                             
                                     
                               
  
const changedKeys = new Set([
  "attendance.lateness",
  "attendance.earlyDeparture",
  "attendance.longEntry",
  "attendance.missingClockIn",
  "attendance.missingClockOut",
  "labor.overtimeRisk",
  "labor.compensation",
  "labor.rates",
  "labor.budgets",
  "labor.calculationMethod",
]);
function projectRevision(row                      )                        {
  // Select metadata explicitly. Never spread an unvalidated settings payload or
  // reflect parser messages/unknown changed-key content into the Owner view.
  const metadata = {
    operationId: row.operationId,
    revision: row.revision,
    locationId: row.locationId,
    changedAt: row.changedAt,
    changedKeys:
      Array.isArray(row.changedKeys) && row.changedKeys.length <= changedKeys.size &&
      row.changedKeys.every((key) => typeof key === "string" && changedKeys.has(key))
        ? [...row.changedKeys]            
        : null,
  };
  let settings                       ;
  try {
    settings = parseCompanyPolicySettings(row.settings);
  } catch {
    return { ...metadata, state: "unavailable", reason: "invalid_settings" };
  }
  return { ...metadata, state: "valid", settings };
}
/** Owner-only recovery display. This does not supply effective policies or
 * convert an invalid latest revision into an absent/unconfigured scope. */
function projectCompanyPolicyHistory(rows                        )                       {
  const revisions = rows.map(projectRevision);
  const latest = new Map                                      ();
  for (const row of revisions) {
    const previous = latest.get(row.locationId);
    if (!previous || row.revision > previous.revision) latest.set(row.locationId, row);
  }
  const locationIds = [null, ...[...latest.keys()].filter((id)               => id !== null).sort()];
  const scopes                       = locationIds.map((locationId) => {
    const selected = latest.get(locationId);
    if (!selected) return { locationId, expectedRevision: 0, state: "not_configured", selected: null };
    if (selected.state === "unavailable") {
      return {
        locationId,
        expectedRevision: selected.revision,
        state: "unavailable",
        reason: selected.reason,
        selected,
      };
    }
    return { locationId, expectedRevision: selected.revision, state: "valid", selected };
  });
  return { revisions, scopes };
}

return projectCompanyPolicyHistory;})();
const time=(()=>{/**
 * Business-local calendar values cross into elapsed time only through an explicit
 * IANA zone. Scheduling periods use nominal wall minutes; clock and calendar
 * events use instants, so converting either model with the host zone is unsafe.
 */
class InvalidBusinessLocalTimeError extends Error {
  constructor() { super('Enter a valid business-local time that is neither ambiguous nor skipped by daylight saving time.'); }
}
function zoned(now      , timeZone        ) {
  return Temporal.Instant.fromEpochMilliseconds(now.getTime()).toZonedDateTimeISO(timeZone);
}
function businessDate(now      , timeZone        )         {
  return zoned(now, timeZone).toPlainDate().toString();
}
function businessTime(now      , timeZone        )         {
  return zoned(now, timeZone).toPlainTime().toString({ smallestUnit: 'minute' });
}
/** Reject DST gaps and repeated times instead of guessing which instant a form meant. */
function localDateTimeToInstant(local        , timeZone        )         {
  try {
    if (!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(local)) throw new Error();
    const value = Temporal.PlainDateTime.from(local, { overflow: 'reject' });
    return new Date(value.toZonedDateTime(timeZone, { disambiguation: 'reject' }).epochMilliseconds).toISOString();
  } catch { throw new InvalidBusinessLocalTimeError(); }
}
/** Convert event boundaries only; scheduled hours remain nominal wall minutes. */
function shiftBoundaryInstants(shift                  , timeZone        )                                     {
  try {
    const period = shiftPeriod(shift);
    // UTC serialization preserves nominal calendar coordinates; these are not elapsed instants.
    const nominalLocalDateTime = (minutes        ) => new Date(minutes * 60000).toISOString().slice(0, 16);
    return { startAt: localDateTimeToInstant(nominalLocalDateTime(period.start), timeZone), endAt: localDateTimeToInstant(nominalLocalDateTime(period.end), timeZone) };
  } catch { throw new InvalidBusinessLocalTimeError(); }
}
function formatBusinessDateTimeInput(iso                    , timeZone        )         {
  if (!iso) return '';
  const value = Temporal.Instant.from(iso).toZonedDateTimeISO(timeZone);
  return value.toPlainDateTime().toString({ smallestUnit: 'minute' });
}
/** Preserve the exact stored instant when a minute-resolution form is unchanged. */
function policyEffectiveInstant(local        , original                    , timeZone        )         {
  if (original && local === formatBusinessDateTimeInput(original, timeZone)) return original;
  return localDateTimeToInstant(local, timeZone);
}
function formatBusinessDateTime(iso        , timeZone        )         {
  // Browser ICU versions differ in their literal punctuation ("," vs "at").
  // Compose the same readable timestamp during server rendering and hydration.
  const parts = new Intl.DateTimeFormat('en-US', { timeZone, month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }).formatToParts(new Date(iso));
  const value = (type                              ) => parts.find(part => part.type === type)?.value;
  return `${value('month')} ${value('day')}, ${value('hour')}:${value('minute')} ${value('dayPeriod')}`;
}

function formatBusinessClock(now      , timeZone        )         {
  return new Intl.DateTimeFormat('en-US', { timeZone, hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true }).format(now);
}
function formatBusinessTimestamp(iso        , timeZone        )         {
  return formatBusinessDateTime(iso, timeZone);
}

return {formatBusinessDateTimeInput,policyEffectiveInstant};})();
return {parseSettings:parseCompanyPolicySettings,parseCommand:model.parseCompanyPolicyCommand,effective:model.effectiveCompanyPolicies,history,localInput:time.formatBusinessDateTimeInput,effectiveInstant:time.policyEffectiveInstant,edit(base,key,value){const next=JSON.parse(JSON.stringify(base)),section=key==='overtimeRisk'?'labor':'attendance';if(value!==undefined){next[section]??={};next[section][key]=value;}else if(next[section])delete next[section][key];return parseCompanyPolicySettings(next);}};
})();
