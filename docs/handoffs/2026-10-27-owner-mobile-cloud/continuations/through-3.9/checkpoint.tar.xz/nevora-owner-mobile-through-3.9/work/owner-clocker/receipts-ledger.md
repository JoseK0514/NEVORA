# A-04 saved receipt construction and verification ledger

Scope and ownership are in receipts-brief.md / receipts-source-contract.md. Only the receipt store/view/styles plus receipt-prefixed task/evidence records were edited by this worker. Root owns app/build integration and final batch acceptance. No actual-app source, services, network APIs, employee data, messages, Git or deployment operation was used.

## Source-first construction

Read root AGENTS/START-HERE/CURRENT-STATE/CONVERSATION-CONTEXT/WORKING-AGREEMENTS, accepted DESIGN, 3.8 boundary, current A-04 inventory and delivery plan, pinned recovery component/page/API/service/UUID parser/private snapshot controller and exact associated component/integration/access tests. Source remains read-only. Applied the available test-driven-development and verification-before-completion skills; using-superpowers explicitly excludes dispatched subagents. No additional subagent/review was requested by this worker.

The store's fixture references align with the existing sample-entry-6 Timecards record. Reads return joined current labels and immutable action facts; none mutate the recorded entry. Denied/shared unavailable reads stop before private joins. UI retirement covers reference edits, generation/authority changes, leaving, blur/hidden/offline, unavailable reads and the 15-second observation budget. Timecards handoff carries exact person and period plus non-private origin; callback return freshly reads the reference.

## Preserved RED and repairs

1. `outputs/owner-clocker/receipts-model-red.json`: factory missing, expected assertion failure. Minimal read-only store implementation then passed 15 checks in original `receipts-model-green.json`.
2. Initial full Chromium report `receipts-browser-chromium-2026-10-27T20-06-33-135Z.json`: 18 passing, 7 failing. Six phone/text cases demonstrated that scrolling the whole form group lacked the measured task-header clearance. Added the existing scoped scroll-margin role to `.form-field`; final test checks the entire label/group, a stronger assertion than input-only clearance.
3. The seventh initial failure counted the root sidecar's unrelated **Reset sample** button. Scoped the prohibited reset/new-punch assertion to the owning `#home-content` task, preserving the original failed report. No feature assertion was removed.
4. Parent found current company time zone was omitted in the first implementation. `receipts-timezone-model-red.json` records two failures; `receipts-browser-chromium-2026-10-27T20-07-14-147Z.json` records the rendered date failure. Added confirmed `context().timeZone` to each observation; unavailable/invalid context fails closed. The view uses that zone for display and performed-date week. Pacific/Pago_Pago moves the exact first fixture from Monday Oct26 to Sunday Oct25 and correctly hands off Oct19–25. Green model is 17 checks.
5. `receipts-view-model-red.json` catches deep-link truncation turning an invalid 37-character string into a different valid UUID. Preserve the full input and validate it strictly. `receipts-view-model-green.json` passes all 3 view-model checks, including explicit-check prefill and exact origin context.
6. Root integration inspection found a return-context wrapper mismatch; the receipt route now writes `{returnContext:...}` matching the root safe parser. Root owns Team-filter/reload and nested Timecards reload seams; no arbitrary URL focus selector is executed.
7. Rolling-source Chromium `receipts-browser-chromium-2026-10-27T20-09-27-310Z.json`: all 27 functional cases passed; command deliberately failed its artifact guard because root rebuilt during the run. It remains preliminary evidence, not final-source acceptance.
8. Initial unadapted WebKit launch failed before any cases because the base host lacks GTK4/graphene/harfbuzz-icu/manette/hyphen/GLES libraries. Runner now accepts the same existing isolated executable adapter as prior verified Cloud gates: `NEVORA_WEBKIT_EXECUTABLE=/workspace/nevora-webkit-libs/run-webkit.sh`. No implementation/source assertion was adapted; actual WebKit is run through the established launcher.

## Final-source verification

Final receipt implementation frozen at:

- store `e5e6f3716d9af7b79d787f1428df25bb1f20228537624eb0d8fec22168586783`
- view `614e0fba9745bb61bf9e990773eb7a353c171520ac059b2a4465fac69dd441c8`
- style `b2eadc1f25cbb4b0dcb9acfa70383c83510ace96993b8e717620c27c9dd590f6`

Final model command reports are `receipts-model-final.json` (17/17) and `receipts-view-model-final.json` (3/3). Browser reports carry both artifact-before/after, source hashes, engine, exact cases and captures; the guard refuses a changed artifact. Each engine covers 27 journeys, including all four action kinds, no-result uncertainty, reference retirement, current failure/offline/pause/expiry/authority races, exact person/period Timecards and parent return, current company-zone boundary, invalid deep links, keyboard, neighboring data immutability and 320/390/430px at 100/200% text. Twelve screenshots per engine capture field and long recorded facts. Root's final verification summary identifies the final accepted browser reports and wider connected seams.

Final receipt-only results: **81/81 browser journeys, 20/20 model checks, 36 captures**, all on unchanged artifact `4420d01a9cb174494145944275eadab26bae87f017a7a2142a50af39f100a473`:

- `receipts-browser-chromium-2026-10-27T20-10-31-492Z.json` — 27/27.
- `receipts-browser-firefox-2026-10-27T20-10-31-907Z.json` — 27/27.
- `receipts-browser-webkit-2026-10-27T20-11-13-596Z.json` — 27/27, established local executable adapter.

All final commands exited zero; artifact-before/after and receipt source hashes agree. The separate `outputs/owner-clocker/receipts-verification-summary.json` binds these reports/captures. No implementation edits followed these checks.

Author inspection of the 320px/200% and 390px/100% field captures plus Chromium320/200, Firefox390/100 and WebKit430/200 long-fact captures confirms the entire Saved reference label/focus field clears the measured task header, text/controls wrap and the accepted typography/palette/task system remains. This is local browser evidence, not independent final approval, physical-device/software-keyboard testing, real screen-reader certification, operational service behavior or production integration.

## Pre-review clipped-shell focus investigation

After the initial receipt matrix, a device-controller focus defect prompted a separate receipt investigation. `receipts-focus-check.cjs` measures the absolute clipped-shell scroll, content-owner/preview boundary and complete task-header visibility for open, invalid input, Check, Refresh and Timecards return at every 320/390/430px × 100/200% combination. It invokes the product actions directly to exclude automation's own scrolling behavior.

All **90 probes passed** across Chromium/Firefox/WebKit. Every `.app.scrollTop` remained zero; after Check/Refresh/Timecards return, `#app-scroll` and task-header top were both 28px at every combination. No receipt product defect was reproduced, and no receipt implementation file changed. Reports:

- `receipts-focus-red-chromium-2026-10-27T20-14-41-879Z.json` — 30/30. The filename was chosen before execution; its recorded result is passing, so it is **not** claimed as a RED reproduction.
- `receipts-focus-probe-firefox-2026-10-27T20-15-43-723Z.json` — 30/30.
- `receipts-focus-probe-webkit-2026-10-27T20-15-43-723Z.json` — 30/30.

The original receipt capture harness itself called `scrollIntoView({block:'start'})` when positioning field/fact screenshots. That automation call could move the clipped outer shell independently of the product's own `block:'nearest'` focus helper. Preserving all original evidence, corrected only capture positioning to explicit `#app-scroll` deltas and strengthened the main reflow assertions with absolute shell/header/preview checks. Root's candidate2 matrix reruns the receipt 27×3 suites with this corrected capture harness against the device-focus-repaired artifact. Root's final combined evidence supersedes the earlier pair artifact; the receipt implementation hashes above remain unchanged.
