/* Metadata-only invitation simulation. No usable links, tokens or delivery. */
function createOwnerInvitationStore(team){
 const clone=x=>JSON.parse(JSON.stringify(x)),WINDOW=15*60*1000;
 let clock,serial,operationSerial,history,latest,operations,activated,counters,readMode,deliveryAvailable;
 function reset(){clock=Date.parse('2026-10-26T15:24:00Z');serial=0;operationSerial=0;history=new Map();latest=new Map();operations=new Map();counters=new Map();readMode='ready';deliveryAvailable=true;activated=new Set(team.all().filter(p=>p.accountState==='Active').map(p=>p.id));activated.add('sample-owner');
  const p=team.get('person-4');if(p){activated.delete(p.id);const r={id:'sample-invitation-'+(++serial),employeeId:p.id,revision:1,employeeVersion:p.version,email:p.email.trim().toLowerCase(),issuedAt:clock-3*60*1000,expiresAt:clock+12*60*1000,issuerName:'Jamie Patel',retired:false,consumed:false,delivery:'PROVIDER_ACCEPTED',deliveryAt:clock-3*60*1000};history.set(r.id,r);latest.set(p.id,r.id);}
 }
 reset();
 const current=id=>history.get(latest.get(id));
 const validEmail=email=>typeof email==='string'&&email.length<=254&&/^[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+$/.test(email);
 const authorized=()=>{const actor=team.snapshot().actor;return actor.active&&actor.accessRole==='Owner'&&readMode!=='denied';};
 const delivery=r=>r.delivery==='PREPARED'&&clock-r.deliveryAt>=10000?'UNKNOWN':r.delivery;
 function lifecycle(r,p){if(r.consumed)return 'CONSUMED';if(r.retired)return r.retired==='REVOKED'?'REVOKED':'INVALIDATED';if(r.expiresAt<=clock)return 'EXPIRED';if(!p.active||r.employeeVersion!==p.version||r.email!==p.email.trim().toLowerCase()||activated.has(p.id))return 'INVALIDATED';return 'ISSUED';}
 function status(id){
  if(!authorized())return {state:'unavailable',reason:'access_denied'};
  if(readMode==='unavailable')return {state:'unavailable',reason:'read_failed'};
  const p=team.get(id);if(!p)return {state:'unavailable',reason:'access_denied'};
  const eligibility=id==='sample-owner'?'SELF_ISSUE_DENIED':!p.active?'INACTIVE':activated.has(id)?'ALREADY_ACTIVATED':!validEmail(p.email)?'NO_EMAIL':'INVITABLE',r=current(id),state=r?lifecycle(r,p):null;
  const masked=validEmail(p.email)?p.email.slice(0,1)+'***@'+p.email.split('@')[1]:null;
  return {state:'ready',employeeId:id,employeeVersion:p.version,eligibility,registeredEmailMasked:masked,invitationRevision:r?.revision||0,invitation:r?{id:r.id,state,issuedAt:r.issuedAt,expiresAt:r.expiresAt,issuerName:r.issuerName}:null,delivery:r?delivery(r):'UNAVAILABLE',allowedCommands:[...(eligibility==='INVITABLE'?['ISSUE']:[]),...(state==='ISSUED'?['REVOKE']:[])],retryAfterMs:null};
 }
 function prepare(id,action){const s=status(id);if(s.state!=='ready'||!s.allowedCommands.includes(action))return {ok:false,state:'unavailable',reason:'source_unavailable'};
  const command={action,operationId:'sample-invitation-operation-'+(++operationSerial),expectedInvitationRevision:s.invitationRevision,...(action==='ISSUE'?{expectedEmployeeVersion:s.employeeVersion}:{invitationId:s.invitation.id})};
  return {ok:true,command,review:clone(s)};
 }
 function execute(id,command,scenario='normal'){
  if(!authorized())return {state:'unavailable',reason:'access_denied'};
  const fingerprint=JSON.stringify({id,command}),old=operations.get(command.operationId);
  if(old)return old.fingerprint===fingerprint?{state:'saved',receipt:receipt(old)}:{state:'conflict',reason:'changed_replay'};
  const p=team.get(id),r=current(id);if(!p)return {state:'unavailable',reason:'source_unavailable'};
  if(command.expectedInvitationRevision!==(r?.revision||0))return {state:'conflict',reason:'invitation_changed'};
  if(command.action==='ISSUE'){
   if(!deliveryAvailable||scenario==='unavailable')return {state:'unavailable',reason:'delivery_unavailable'};
   if(command.expectedEmployeeVersion!==p.version)return {state:'conflict',reason:'employee_changed'};
   const s=status(id);if(s.state!=='ready'||s.eligibility!=='INVITABLE')return {state:'invalid',message:'This employee cannot receive an invitation.'};
   const bucket=Math.floor(clock/WINDOW),target=id+':'+bucket,global='global:'+bucket;
   if((counters.get(target)||0)>=3||(counters.get(global)||0)>=300||scenario==='limited')return {state:'limited',retryAfterMs:WINDOW-clock%WINDOW};
   counters.set(target,(counters.get(target)||0)+1);counters.set(global,(counters.get(global)||0)+1);
   if(r&&!r.consumed&&!r.retired)r.retired='REISSUED';
   const created={id:'sample-invitation-'+(++serial),employeeId:id,revision:(r?.revision||0)+1,employeeVersion:p.version,email:p.email.trim().toLowerCase(),issuedAt:clock,expiresAt:clock+WINDOW,issuerName:'Jamie Patel',retired:false,consumed:false,delivery:scenario==='delivery-failed'?'FAILED':scenario==='delivery-unknown'?'UNKNOWN':scenario==='delivery-prepared'?'PREPARED':'PROVIDER_ACCEPTED',deliveryAt:clock};history.set(created.id,created);latest.set(id,created.id);
   operations.set(command.operationId,{fingerprint,operationId:command.operationId,employeeId:id,invitationId:created.id,revision:created.revision,action:'ISSUE',committedAt:clock,expiresAt:created.expiresAt});
  }else if(command.action==='REVOKE'){
   if(!r||r.id!==command.invitationId||r.retired||r.consumed)return {state:'conflict',reason:'invitation_changed'};
   r.retired='REVOKED';operations.set(command.operationId,{fingerprint,operationId:command.operationId,employeeId:id,invitationId:r.id,revision:r.revision,action:'REVOKE',committedAt:clock,expiresAt:r.expiresAt});
  }else return {state:'invalid',message:'Choose an available invitation action.'};
  if(scenario==='unknown')return {state:'outcome_unknown',operationId:command.operationId};
  return {state:'saved',receipt:receipt(operations.get(command.operationId))};
 }
 function receipt(op){const r=history.get(op.invitationId);const {fingerprint,...safe}=op;return {...clone(safe),delivery:r?delivery(r):'UNAVAILABLE'};}
 function lookup(operationId){if(!authorized())return {state:'unavailable',reason:'access_denied'};if(readMode==='unavailable')return {state:'unavailable',reason:'source_unavailable'};const op=operations.get(operationId);return op?{state:'saved',receipt:receipt(op)}:{state:'unavailable',reason:'source_unavailable'};}
 return {credentialed:id=>activated.has(id),reset,status,prepare,execute,lookup,now:()=>clock,advance:ms=>{clock+=ms;},setReadMode:mode=>{readMode=mode;},setDeliveryAvailable:value=>{deliveryAvailable=value;},
  snapshot:()=>({now:clock,invitations:[...history.values()].map(r=>{const p=team.get(r.employeeId);return {id:r.id,employeeId:r.employeeId,revision:r.revision,state:p?lifecycle(r,p):'INVALIDATED',issuedAt:r.issuedAt,expiresAt:r.expiresAt,delivery:delivery(r)};}),operations:[...operations.values()].map(receipt)}),
  activate:id=>{const r=current(id);activated.add(id);if(r)r.consumed=true;},setDelivery:(id,state)=>{const r=current(id);if(r){r.delivery=state;r.deliveryAt=clock;}},
 };
}
