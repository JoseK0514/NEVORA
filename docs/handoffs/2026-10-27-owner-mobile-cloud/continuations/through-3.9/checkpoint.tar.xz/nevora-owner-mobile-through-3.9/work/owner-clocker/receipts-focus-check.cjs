/* Focus regression: scroll only the content owner; never displace the clipped app shell. */
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
let pw;try{pw=require('playwright');}catch{pw=require('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');}
const root=path.resolve(__dirname,'../..'),engine=process.argv.find(v=>v.startsWith('--engine='))?.slice(9)||'chromium',label=process.argv.find(v=>v.startsWith('--label='))?.slice(8)||'probe',stamp=new Date().toISOString().replace(/[:.]/g,'-'),out=path.join(root,'outputs/owner-clocker'),sha=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex'),artifact=path.join(root,'outputs/nevora-owner-mobile.html');
(async()=>{
 const before=sha(artifact),browser=await pw[engine].launch(engine==='webkit'&&process.env.NEVORA_WEBKIT_EXECUTABLE?{executablePath:process.env.NEVORA_WEBKIT_EXECUTABLE}:{}),results=[],captures=[];
 for(const width of [320,390,430])for(const scale of [100,200]){
  const p=await browser.newPage({viewport:{width,height:844}});p.setDefaultTimeout(7000);
  await p.goto('http://127.0.0.1:18763/nevora-owner-mobile.html?page=clocker-recovery&crParent=settings');
  await p.evaluate(scale=>document.documentElement.style.fontSize=scale===200?'200%':'100%',scale);
  async function observe(step){
   const values=await p.evaluate(()=>{const app=document.querySelector('.app'),main=document.querySelector('#app-scroll'),nav=document.querySelector('.cr-nav'),preview=document.querySelector('.preview-line'),field=document.querySelector('#cr-reference').closest('.form-field');const rect=e=>({top:e.getBoundingClientRect().top,bottom:e.getBoundingClientRect().bottom,height:e.getBoundingClientRect().height});return {outerScrollTop:app.scrollTop,innerScrollTop:main.scrollTop,app:rect(app),main:rect(main),nav:rect(nav),preview:rect(preview),field:rect(field),active:document.activeElement?.id};});
   try{assert.equal(values.outerScrollTop,0,'clipped outer .app must never scroll');assert.ok(values.main.top>=values.preview.bottom-.5,'content scroll owner stays below preview line');assert.ok(values.nav.top>=values.main.top-.5&&values.nav.bottom<=844,'task header stays visible at the content boundary');results.push({width,scale,step,pass:true,values});}
   catch(error){results.push({width,scale,step,pass:false,error:error.message,values});const name=`receipts-focus-${label}-${engine}-${width}-${scale}-${step}-${stamp}.png`;await p.screenshot({path:path.join(out,name)});captures.push(name);}
  }
  // Invoke the owning view directly so the automation's own scrollIntoView cannot
  // move the shell before measuring the product's focus behavior.
  await p.evaluate(()=>ownerClockerReceipts.open({parent:'settings'}));await observe('open');
  await p.evaluate(()=>document.querySelector('#cr-form').requestSubmit());await observe('error');
  await p.evaluate(()=>{const input=document.querySelector('#cr-reference');input.value='4a9c7ed1-9b42-4dc0-8847-324d7ade7832';input.dispatchEvent(new Event('input',{bubbles:true}));document.querySelector('#cr-form').requestSubmit();});await p.waitForFunction(()=>ownerClockerReceipts.snapshot().connection==='ready');await observe('check');
  await p.evaluate(()=>ownerClockerReceipts.refresh({feedback:true}));await observe('refresh');
  await p.evaluate(()=>document.querySelector('[data-cr-receipt="0"]').click());await p.waitForFunction(()=>ownerTimecards.snapshot().readState==='ready');
  await p.evaluate(()=>document.querySelector('[data-tc-action=back]').click());await p.waitForFunction(()=>ownerClockerReceipts.snapshot().connection==='ready');await observe('timecards-return');
  await p.close();
 }
 const report={engine,label,artifactBefore:before,artifactSha256:sha(artifact),sourceSha256:sha(path.join(root,'work/owner-mobile/clocker-receipts.js')),results,captures,passed:results.filter(r=>r.pass).length,failed:results.filter(r=>!r.pass).length};
 const name=`receipts-focus-${label}-${engine}-${stamp}.json`;fs.writeFileSync(path.join(out,name),JSON.stringify(report,null,2)+'\n');await browser.close();console.log(JSON.stringify({report:name,passed:report.passed,failed:report.failed,artifactStable:report.artifactBefore===report.artifactSha256,failures:results.filter(r=>!r.pass).map(r=>({width:r.width,scale:r.scale,step:r.step,outerScrollTop:r.values.outerScrollTop,mainTop:r.values.main.top,navTop:r.values.nav.top}))}));process.exitCode=report.failed||report.artifactBefore!==report.artifactSha256?1:0;
})().catch(error=>{console.error(error);process.exitCode=1;});
