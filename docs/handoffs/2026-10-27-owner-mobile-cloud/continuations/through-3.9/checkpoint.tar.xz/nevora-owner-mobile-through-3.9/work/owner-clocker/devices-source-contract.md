# Pinned device management contract

Reference commit: `46e202786863279302026ee03a0e225c359fa55c`; read-only source under `reference/application`.

| Owning source | Required behavior |
| --- | --- |
| `src/lib/clocker/views.ts` | Device view allow-list is id, name, locationId, version, state, lastSeenAt and enrollmentExpiresAt. Current reads contain no setup secret, credential, proof or hash. |
| `src/lib/clocker/devices.server.ts` | Owner/session authority and workspace are current at final transaction boundary. Mutations use immutable device id plus expectedVersion. Device names trim and accept 1–80 printable Unicode characters. |
| `src/lib/clocker/devices.server.ts` REGISTER | Active location required; fixed location and new device identity; ten-minute, one-use setup token bound to issuing Owner/session; PENDING does not mean registered. |
| `src/lib/clocker/devices.server.ts` RENAME | Label-only update. The device id, fixed location, state and existing records remain. |
| `src/lib/clocker/devices.server.ts` ROTATE | Active location required; same identity/location; immediately removes old access and old code; new ten-minute enrollment. ACTIVE → Replace, REVOKED → Reconnect, setup states → New code. |
| `src/lib/clocker/devices.server.ts` REVOKE | Removes access and enrollment immediately; keeps original punches/time records; may revoke at inactive location. |
| `src/app/app/settings/clocker/actions.ts` | Exact command fields, current Owner authority and origin; immediate result is the sole setup-secret handoff. An uncertain result requires current-device refresh before another mutation. |
| `src/components/clocker-device-manager.tsx` and `.test.tsx` | Active includes ACTIVE only; Needs setup includes UNREGISTERED/PENDING/EXPIRED; Removed includes REVOKED. Device options, deliberate access-change review, Cancel-first focus, empty and no-active-location recovery. |

The mobile mockup follows the source's uncertainty boundary: no second mutation until an explicit current-device refresh. It retains a description of the original attempted command for context, without replay or invented operation lookup. A matching name/state alone does not prove an uncertain operation completed. A missing immediate secret cannot be recovered from ordinary reads; a deliberate new rotation is required after reviewing current details.

Private code is transient controller memory only, absent from URL, read payloads, snapshot/debug output, browser storage and HTML after hide/expiry/lifecycle cleanup. Hide removes this view; it does not imply revocation. Blur, hidden document, offline, pagehide, route departure and authority end remove the secret immediately. New command execution never occurs while an earlier operation remains uncertain.

Root's frozen `interfaces.md` is authoritative for the local implementation boundary. No actual server authorization, enrollment redemption, persistence, real tablet operation or integration is claimed.
