from pathlib import Path
p=Path('work/owner-mobile/app.js');s=p.read_text()
def replace(a,b,count=1):
 global s
 assert s.count(a)==count,(a[:100],s.count(a));s=s.replace(a,b)
replace('policiesUI=null,setupUI=null;','policiesUI=null,setupUI=null,clockerDevicesUI=null,clockerReceiptsUI=null;')
# All company-wide root pages, including public header/scope, allowed routes and fallback task rendering.
s=s.replace("'policies','setup']","'policies','setup','clocker','clocker-recovery']")
replace("if(tab==='setup')tab='home';","if(tab==='setup')tab='home';if(tab==='clocker-recovery')tab='team';")
replace("if(['timecards','corrections','settings'","if(['timecards','corrections','clocker','settings'")
replace("policies:0,setup:0","policies:0,setup:0,clocker:0,'clocker-recovery':0")
replace('setupUI?.reset();','setupUI?.reset();clockerDevicesUI?.reset();clockerReceiptsUI?.reset();')
replace('policiesUI?.guardNavigation(page))','policiesUI?.guardNavigation(page)||clockerDevicesUI?.guardNavigation(page))')
replace('setupUI?.onNavigate(page);','setupUI?.onNavigate(page);clockerDevicesUI?.onNavigate(page);clockerReceiptsUI?.onNavigate(page);')
replace('function renderRoot(){',"function renderRoot(){\n if(currentPage==='clocker'&&clockerDevicesUI){clockerDevicesUI.render();return;}\n if(currentPage==='clocker-recovery'&&clockerReceiptsUI){clockerReceiptsUI.render();return;}")
replace(" if(id==='timecards'&&timecardsUI)"," if(id==='devices'&&clockerDevicesUI){if(!$('#overlay').hidden)close({restoreFocus:false});return clockerDevicesUI.open({...context,parent:'more',feature:'devices',query:featureQuery,location:locationIndex,scroll:$('#app-scroll').scrollTop});}\n if(id==='clocker-recovery'&&clockerReceiptsUI){const parent=currentPage==='team'?'team':currentPage==='settings'?'settings':'more';if(!$('#overlay').hidden)close({restoreFocus:false});return clockerReceiptsUI.open({...context,parent,feature:'clocker-recovery',location:locationIndex,query:featureQuery,scroll:$('#app-scroll').scrollTop,focus:parent==='team'?'[data-feature=team-tools]':'[data-feature=clocker-recovery]',returnContext:{teamQuery,teamStatus,teamRole}});}\n if(id==='timecards'&&timecardsUI)")
replace('openPolicies:context=>policiesUI.open(context),','openClocker:context=>clockerDevicesUI.open(context),openPolicies:context=>policiesUI.open(context),')
replace("if(origin.parent==='setup')return setupUI.restore(origin);","if(origin.parent==='setup')return setupUI.restore(origin);if(origin.parent==='clocker')return clockerDevicesUI.open(origin.clockerReturn||{parent:'hub'});")
replace("openPolicies:(p,context)=>policiesUI.open", "openClocker:(p,context)=>clockerDevicesUI.open({locationId:p.id,locationReturn:context,parent:'location',location:context.location,view:'list'}),openPolicies:(p,context)=>policiesUI.open")
anchor='window.ownerSetup=setupUI;'
addition='''
function safeClockerContext(value){
 try{const v=typeof value==='string'?JSON.parse(value):value;if(!v||typeof v!=='object'||Array.isArray(v))return null;const out={};
 for(const key of ['parent','feature','query','view','id','queryList','filter','locationId','reference','startDate','endDate','employeeId'])if(typeof v[key]==='string'&&v[key].length<2048)out[key]=v[key];
 for(const key of ['scroll','location','lookupScroll'])if(Number.isFinite(v[key])&&v[key]>=0)out[key]=v[key];
 if(typeof v.checked==='boolean')out.checked=v.checked;if(v.returnContext&&typeof v.returnContext==='object')out.returnContext={teamQuery:String(v.returnContext.teamQuery||'').slice(0,160),teamStatus:['active','inactive','all'].includes(v.returnContext.teamStatus)?v.returnContext.teamStatus:'active',teamRole:['all','Owner','Manager','Employee'].includes(v.returnContext.teamRole)?v.returnContext.teamRole:'all'};
 if(v.locationReturn&&typeof v.locationReturn==='object'){const t=v.locationReturn;out.locationReturn={parent:['more','hub','setup'].includes(t.parent)?t.parent:'hub',location:Number(t.location)||0,scroll:Number(t.scroll)||0,query:String(t.query||''),feature:String(t.feature||'locations'),id:String(t.id||''),queryList:String(t.queryList||''),filter:['all','setup','ready','inactive'].includes(t.filter)?t.filter:'all',view:['detail','clocker','list'].includes(t.view)?t.view:'detail'};}
 return out;}catch{return null;}
}
const clockerStore=createOwnerClockerStore({gate:()=>companyStore.catalogAccess('devices'),authority:()=>companyStore.authority(),now:timecardsStore.now,locations:()=>{const r=locationsStore.read();return r.state==='ready'?r.locations:null;},context:()=>companyStore.brandingContext()});
clockerDevicesUI=createOwnerClockerDevices({...catalogAPI,parent:async origin=>{if(origin.locationReturn){await locationsUI.open(origin.locationReturn);focusRoot('[data-lo-action=devices]');return;}await catalogAPI.parent('devices',origin);},openLocations:origin=>{const context=safeClockerContext({...origin,...origin.clockerReturn})||{};return locationsUI.open({...origin,parent:'clocker',clockerReturn:context,view:'list'});}},clockerStore);window.ownerClockerDevices=clockerDevicesUI;
const clockerReceiptsStore=createOwnerClockerReceiptsStore({gate:()=>companyStore.catalogAccess('clocker-recovery'),authority:()=>companyStore.authority(),now:timecardsStore.now,locations:()=>{const r=locationsStore.read();return r.state==='ready'?r.locations:null;},people:()=>teamStore.directory()});
clockerReceiptsUI=createOwnerClockerReceipts({...catalogAPI,parent:async origin=>{
 if(origin.parent==='settings'||origin.parent==='hub')return catalogAPI.parent('devices',{...origin,parent:'hub'});
 if(origin.parent==='clocker')return clockerDevicesUI.open(origin.returnContext||{});
 locationIndex=Number.isInteger(origin.location)&&origin.location<places.length?origin.location:0;
 const page=origin.parent==='team'?'team':'more',u=new URL(location.href);u.search='';u.hash='';u.searchParams.set('page',page);u.searchParams.set('location',String(locationIndex));history.replaceState(null,'',u);
 if(page==='team'){const c=origin.returnContext||{};teamQuery=c.teamQuery||'';teamStatus=c.teamStatus||'active';teamRole=c.teamRole||'all';teamUI.showDirectory();}else featureQuery=origin.query||'';
 navigate(page);$('#app-scroll').scrollTop=origin.scroll||0;focusRoot(page==='team'?'[data-feature=team-tools]':'[data-feature=clocker-recovery]');
},openTimecards:context=>{const back=safeClockerContext(context.clockerRecoveryReturn),u=new URL(location.href);u.search='';u.hash='';u.searchParams.set('page','timecards');u.searchParams.set('crReturn',JSON.stringify(back));history.replaceState(null,'',u);timecardsUI.open(context);}},clockerReceiptsStore);window.ownerClockerReceipts=clockerReceiptsUI;
function restoreClockerTimecards(params){if(params.get('page')!=='timecards')return false;const context=safeClockerContext(params.get('crReturn'));if(!context)return false;timecardsUI.open({employeeId:params.get('employee'),startDate:params.get('start'),endDate:params.get('end'),returnLabel:'Clocker recovery',returnTo:()=>clockerReceiptsUI.open(context)});return true;}
'''
replace(anchor,anchor+addition)
replace('restoreTriageNested(params)||restoreFeatureNested(params)','restoreClockerTimecards(params)||restoreTriageNested(params)||restoreFeatureNested(params)')
replace("if(triageNestedRestored){}else if(params.get('page')==='setup')", "if(triageNestedRestored){}else if(params.get('page')==='clocker'||params.get('page')==='companytool'&&params.get('setting')==='devices')clockerDevicesUI.open({location:locationIndex,parent:params.get('coparent')||'hub',feature:params.get('cofeature')||'devices',query:params.get('coq')||'',scroll:Number(params.get('cdscroll'))||0,view:params.get('cdview'),id:params.get('cdid'),queryList:params.get('cdq')||'',filter:params.get('cdfilter'),locationId:params.get('cdloc'),locationReturn:safeClockerContext({locationReturn:safeClockerContext(params.get('cdreturn'))})?.locationReturn});else if(params.get('page')==='clocker-recovery')clockerReceiptsUI.open({location:locationIndex,parent:params.get('crParent')||'team',feature:params.get('cofeature')||'clocker-recovery',query:params.get('coq')||'',scroll:Number(params.get('crScroll'))||0,reference:params.get('crReference')||'',startDate:params.get('crStart')||'',endDate:params.get('crEnd')||'',employeeId:params.get('crEmployee')||'',returnContext:safeClockerContext(params.get('crReturn'))?.returnContext});else if(params.get('page')==='setup')")
replace("queryList:params.get('lq')||'',filter:params.get('lfilter')", "clockerReturn:safeClockerContext(params.get('loClocker')),queryList:params.get('lq')||'',filter:params.get('lfilter')")
p.write_text(s)
# Focused Company entry and Location adjunct; original sample-link journey stays reachable.
p=Path('work/owner-mobile/company.js');s=p.read_text();a="if(el.dataset.coItem==='policies')";assert s.count(a)==1;s=s.replace(a,"if(el.dataset.coItem==='devices')return api.openClocker({...origin,parent:'hub',feature:'devices',scroll:api.scroll().scrollTop});"+a);p.write_text(s)
p=Path('work/owner-mobile/locations.js');s=p.read_text();a="...(origin.parent==='setup'?{suScroll:origin.scroll}:{}),";assert s.count(a)==1;s=s.replace(a,a+"...(origin.parent==='clocker'?{loClocker:JSON.stringify(origin.clockerReturn||{})}:{}),")
s=s.replace("origin.parent==='setup'?'setup checklist':origin.parent==='more'", "origin.parent==='clocker'?'Clocker devices':origin.parent==='setup'?'setup checklist':origin.parent==='more'")
s=s.replace('Connecting a Clocker device is a later setup step.','Manage sample shared tablets in Clocker devices.')
a="${B('Copy sample link','copy',true)}";assert s.count(a)==1;s=s.replace(a,a+"${B('Manage Clocker devices','devices',true)}")
a="if(action==='clocker')return start('clocker');";assert s.count(a)==1;s=s.replace(a,a+"if(action==='devices'&&valid()&&current()?.active)return api.openClocker(current(),{...origin,queryList:query,filter,id:selected,view:'clocker'});")
p.write_text(s)
print('App/Company/Location integration source wired; build awaits controller file')
