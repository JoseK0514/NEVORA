/* Saved tablet references inspect evidence only; the employee finishes on the same tablet. */
function createOwnerClockerReceipts(api,store){
 const E=api.escapeHTML,I=api.icon,$=api.$,active=()=>api.page()==='clocker-recovery';
 const actionNames={CLOCK_IN:'Clock in',CLOCK_OUT:'Clock out',START_BREAK:'Start break',END_BREAK:'End break'};
 let origin={},reference='',selected='',payload=null,connection='idle',invalid='',bound=null,expires=0,epoch=0,expiryTimer=null,renewTimer=null,observer=null;
 const B=(label,action,secondary=true,extra='')=>`<button type="button" class="btn${secondary?' secondary':''}" data-cr-action="${action}" ${extra}>${E(label)}</button>`;
 function clearTimers(){clearTimeout(expiryTimer);clearTimeout(renewTimer);}
 function focus(selector='h1'){
  const el=$('#home-content '+selector)||$('#home-content h1');if(!el)return;
  if(!el.matches('button,input,summary'))el.tabIndex=-1;
  el.focus({preventScroll:true});
  (el.closest('.form-field')||el).scrollIntoView({block:'nearest'});
 }
 function navigationContext(){return {...origin,reference,startDate:origin.startDate||'',endDate:origin.endDate||'',employeeId:origin.employeeId||'',checked:!!selected,lookupScroll:api.scroll().scrollTop};}
 function route(){
  const u=new URL(location.href);u.search='';u.hash='';
  const values={page:'clocker-recovery',location:origin.location??0,coq:origin.query||'',cofeature:origin.feature||'clockerrecovery',crParent:origin.parent||'more',crScroll:origin.scroll||0,crFocus:origin.focus||'',crReference:reference,crStart:origin.startDate||'',crEnd:origin.endDate||'',crEmployee:origin.employeeId||''};
  for(const[k,v]of Object.entries(values))u.searchParams.set(k,String(v));
  if(origin.returnContext)u.searchParams.set('crReturn',JSON.stringify({returnContext:origin.returnContext}));
  history.replaceState(null,'',u);
 }
 function parentLabel(){return ({settings:'Settings',hub:'Settings',team:'Team',person:'employee',timecards:'Timecards',home:'Home',clocker:'Clocker devices',more:'More'})[origin.parent]||'More';}
 function clear(state='paused'){
  epoch++;clearTimers();payload=null;expires=0;connection=state;
 }
 function deny(){clear('denied');bound=null;reference='';selected='';invalid='';if(active()){route();render();}}
 function pause(state='paused'){clear(state);if(active())render();}
 function current(){
  if(bound&&bound!==store.authority()||store.gate()==='denied'){deny();return false;}
  if(store.gate()!=='ready'){pause('unavailable');return false;}
  if(payload&&store.now()>=expires){pause('expired');return false;}
  return connection==='ready'&&!!payload;
 }
 function frame(body){
  observer?.disconnect();
  $('#home-content').innerHTML=`<div class="tm-page-nav tm-task-nav cr-nav"><button type="button" class="icon-button" data-cr-action="back" aria-label="Back to ${E(parentLabel())}">${I('arrow-left')}</button><h1>Clocker recovery</h1>${selected&&connection!=='loading'&&connection!=='denied'?'<button type="button" class="btn secondary cr-refresh" data-cr-action="refresh">Refresh</button>':''}</div><div class="root-body tm-body cr-body" aria-busy="${connection==='loading'}">${body}<p class="co-footer">Sample receipt lookup · Local preview</p></div>`;
  api.header();
  const header=$('.cr-nav'),bodyEl=$('.cr-body'),measure=()=>bodyEl.style.setProperty('--cr-header-height',header.getBoundingClientRect().height+'px');
  measure();observer=new ResizeObserver(measure);observer.observe(header);
 }
 function stamp(value){return new Intl.DateTimeFormat('en-US',{timeZone:payload.timeZone,month:'short',day:'numeric',year:'numeric',hour:'numeric',minute:'2-digit',timeZoneName:'short'}).format(new Date(value));}
 const fact=(label,value)=>`<div><dt>${E(label)}</dt><dd>${value}</dd></div>`;
 function result(){
  if(connection==='idle')return '';
  if(connection==='loading')return '<section class="co-source cr-feedback" id="cr-result" role="status"><h2>Checking the saved receipt…</h2><p>Reading the saved action for this reference.</p></section>';
  if(connection==='ready'&&payload){
   const receipts=payload.receipts;
   return `<section class="cr-feedback" id="cr-result" tabindex="-1" aria-labelledby="cr-result-title"><div class="co-source" role="status"><h2 id="cr-result-title">${receipts.length?'Recorded action found':'Not recorded yet'}</h2><p>${receipts.length?'Check it with the employee, then they finish on the same tablet.':'It may still be in progress. They check again on the same tablet.'}</p></div>${receipts.length?`<ul class="cr-receipts">${receipts.map((r,index)=>`<li><h3>${E(r.employeeName)}</h3><dl class="cr-facts">${fact('Action',E(actionNames[r.action]||'Recorded action'))}${fact('Recorded',`<time datetime="${E(r.performedAt)}">${E(stamp(r.performedAt))}</time>`)}${fact('Device',E(r.deviceName))}${fact('Location',E(r.locationName))}</dl><button type="button" class="btn secondary" data-cr-action="timecards" data-cr-receipt="${index}">View this person’s timecard${I('arrow-right')}</button></li>`).join('')}</ul>`:''}<details class="tm-disclosure cr-reference"><summary><span>Reference checked</span>${I('caret-right')}</summary><div><p>${E(payload.commandId)}</p><p class="tm-help">Checked ${E(stamp(payload.observedAt))}. Checking a receipt doesn’t change recorded time.</p></div></details></section>`;
  }
  const states={denied:['Your session ended','Current Owner access is required before checking this action. Private receipt details were cleared.'],offline:['You’re offline','Keep the saved reference and check again when you’re back online.'],paused:['Receipt lookup paused','The private receipt was cleared. Check the saved reference again to continue.'],expired:['Check the receipt again','The previous observation is no longer current. Check the saved reference for current evidence.'],unavailable:['Couldn’t check the receipt','Keep the saved reference and check again when you’re back online.']};
  const [title,detail]=states[connection]||states.unavailable;
  return `<section class="co-source cr-feedback" id="cr-result" tabindex="-1" role="${connection==='denied'||connection==='unavailable'?'alert':'status'}"><h2>${title}</h2><p>${detail}</p></section>`;
 }
 function render(){
  if(!active())return;
  if(connection!=='denied'&&(bound&&bound!==store.authority()||store.gate()==='denied'))return deny();
  frame(`<p class="cr-intro">Look up a saved clock-in receipt.</p><form id="cr-form" novalidate aria-label="Check a saved action"><div class="form-field"><label for="cr-reference">Saved reference</label><input id="cr-reference" name="reference" type="text" value="${E(reference)}" required maxlength="36" pattern="[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}" autocomplete="off" autocapitalize="none" spellcheck="false" aria-describedby="cr-reference-help${invalid?' cr-reference-error':''}" ${invalid?'aria-invalid="true"':''} ${connection==='loading'||connection==='denied'?'disabled':''}><p class="tm-help" id="cr-reference-help">Use the full reference shown on the employee’s tablet.</p>${invalid?`<p class="tm-field-error" id="cr-reference-error">${E(invalid)}</p>`:''}</div><button type="submit" class="btn" data-cr-action="check" ${connection==='loading'||connection==='denied'?'disabled':''}>${connection==='loading'?'Checking…':'Check'}</button></form>${result()}<div class="co-list cr-timecards"><button type="button" class="co-row" data-cr-action="timecards" ${connection==='loading'||connection==='denied'?'disabled':''}><span><strong>Time wrong or missing?</strong><span class="tm-help">Fix it in Timecards</span></span>${I('caret-right','chevron')}</button></div>`);
 }
 async function refresh({feedback=false}={}){
  if(!active()||!selected)return;
  if(bound&&bound!==store.authority()||store.gate()==='denied')return deny();
  if(!navigator.onLine)return pause('offline');
  if(document.visibilityState==='hidden')return pause();
  const generation=++epoch,identity=store.authority(),commandId=selected,started=store.now(),scroll=api.scroll().scrollTop;
  const focusKey=document.activeElement?.dataset.crAction;
  clearTimers();payload=null;expires=0;connection='loading';render();
  await new Promise(resolve=>setTimeout(resolve,120));
  if(generation!==epoch||!active()||commandId!==selected)return;
  if(identity!==store.authority()||store.gate()==='denied')return deny();
  if(!navigator.onLine)return pause('offline');
  if(document.visibilityState==='hidden')return pause();
  const r=store.read(commandId);
  if(r.state!=='ready'){if(r.reason==='access_denied')return deny();connection='unavailable';render();if(feedback)focus('#cr-result');return;}
  const remaining=r.validForMs-Math.max(0,store.now()-started);
  if(r.commandId!==selected||!Array.isArray(r.receipts)||r.receipts.length>100||!Number.isFinite(Date.parse(r.observedAt))||r.validForMs<1||r.validForMs>15000||remaining<=0){pause('unavailable');return;}
  bound=identity;payload=r;expires=store.now()+remaining;connection='ready';render();api.scroll().scrollTop=scroll;
  if(feedback)focus('#cr-result');else if(focusKey)focus('[data-cr-action="'+CSS.escape(focusKey)+'"]');
  expiryTimer=setTimeout(()=>pause('expired'),remaining);
  renewTimer=setTimeout(()=>{if(active()&&document.visibilityState==='visible'&&navigator.onLine&&document.hasFocus())void refresh();},Math.max(1000,Math.floor(remaining*.7)));
 }
 function check(){
  if(connection==='loading'||connection==='denied')return;
  const result=store.validateReference(reference);clear('idle');selected='';invalid=result.error;
  if(!result.ok){route();render();focus('#cr-reference');return;}
  reference=result.commandId;selected=result.commandId;invalid='';route();void refresh({feedback:true});
 }
 function receiptWeek(receipt,timeZone){
  const parts=Object.fromEntries(new Intl.DateTimeFormat('en-US',{timeZone,year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(new Date(receipt.performedAt)).map(p=>[p.type,p.value]));
  const date=parts.year+'-'+parts.month+'-'+parts.day;
  const day=new Date(date+'T12:00:00Z'),offset=(day.getUTCDay()+6)%7;day.setUTCDate(day.getUTCDate()-offset);
  const startDate=day.toISOString().slice(0,10);day.setUTCDate(day.getUTCDate()+6);return {startDate,endDate:day.toISOString().slice(0,10)};
 }
 function timecards(index){
  if(connection==='denied'||store.gate()==='denied')return deny();
  const canUseReceipt=payload&&current(),receipt=canUseReceipt?payload.receipts[Number.isInteger(index)?index:0]:null;
  if(connection==='denied')return;
  const context=navigationContext(),period=origin.startDate&&origin.endDate?{startDate:origin.startDate,endDate:origin.endDate}:receipt?receiptWeek(receipt,payload.timeZone):{};
  pause('paused');
  api.openTimecards({...period,employeeId:receipt?.employeeId||origin.employeeId||undefined,returnLabel:'Clocker recovery',returnTo:()=>open(context),clockerRecoveryReturn:context});
 }
 async function open(context={}){
  clear('idle');bound=null;invalid='';selected='';
  origin={parent:'more',feature:'clockerrecovery',location:0,query:'',scroll:0,...api.origin(),...context};
  reference=typeof context.reference==='string'?context.reference:'';
  api.navigate('clocker-recovery');route();
  if(store.gate()==='denied')return deny();
  if(store.gate()!=='ready')connection='unavailable';
  render();
  if(context.checked&&store.validateReference(reference).ok){selected=store.validateReference(reference).commandId;await refresh();if(active()){api.scroll().scrollTop=Number(context.lookupScroll)||0;focus('#cr-result');}}
  else focus('#cr-reference');
 }
 document.addEventListener('submit',event=>{if(active()&&event.target.id==='cr-form'){event.preventDefault();event.stopImmediatePropagation();check();}},true);
 document.addEventListener('input',event=>{
  if(!active()||event.target.id!=='cr-reference'||connection==='denied')return;
  const input=event.target,start=input.selectionStart,end=input.selectionEnd;reference=input.value;selected='';invalid='';clear('idle');route();render();const next=$('#cr-reference');next.focus({preventScroll:true});next.setSelectionRange(start,end);
 });
 document.addEventListener('click',event=>{
  if(!active())return;const button=event.target.closest('[data-cr-action]');if(!button||button.disabled||button.dataset.crAction==='check')return;
  event.preventDefault();event.stopImmediatePropagation();
  const action=button.dataset.crAction;
  if(action==='back'){const destination={...origin};clear();bound=null;selected='';reference='';observer?.disconnect();return api.parent(destination);}
  if(action==='refresh')return void refresh({feedback:true});
  if(action==='timecards')return timecards(button.hasAttribute('data-cr-receipt')?Number(button.dataset.crReceipt):undefined);
 },true);
 for(const name of ['blur','pagehide','offline'])window.addEventListener(name,event=>{if(active()&&event.target===window)pause(name==='offline'?'offline':'paused');});
 for(const name of ['focus','pageshow','online','storage'])window.addEventListener(name,event=>{
  if(!active()||name==='focus'&&event.target!==window)return;
  if(bound&&bound!==store.authority()||store.gate()==='denied')return deny();
  if(document.visibilityState==='visible'&&navigator.onLine&&selected)void refresh();
 });
 document.addEventListener('visibilitychange',()=>{if(!active())return;if(document.visibilityState==='hidden')pause();else if(navigator.onLine&&selected)void refresh();});
 setInterval(()=>{if(!active())return;if(bound&&bound!==store.authority()||store.gate()==='denied')return deny();if(payload&&store.gate()!=='ready')return pause('unavailable');if(payload&&store.now()>=expires)pause('expired');},500);
 return {open,render,refresh,onNavigate:page=>{if(page!=='clocker-recovery'){clear();observer?.disconnect();}},reset:()=>{clear('idle');bound=null;selected='';reference='';origin={};invalid='';store.reset();},previewReadMode:mode=>{store.previewReadMode(mode);if(store.gate()==='denied')return deny();if(!selected){if(active()){connection=store.gate()==='ready'?'idle':'unavailable';render();}return;}return refresh();},previewTick:current,snapshot:()=>({connection,hasPrivateData:!!payload,reference,selected,origin:{...origin},expires,...store.snapshot()}),store};
}
