from pathlib import Path
import hashlib,json,subprocess
r=Path(__file__).resolve().parents[2];h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads((r/p).read_text())
original=read('manifest.json');missing=[];changed=[]
for v in original['files']:
 p=r/v['path']
 if not p.exists():missing.append(v['path'])
 elif h(p)!=v['sha256']:changed.append(v['path'])
allowed={'AGENTS.md','START-HERE.md','DESIGN.md','NEXT-BATCH-3.6.md','outputs/nevora-owner-mobile.html','outputs/owner-mobile-current-coverage.json','outputs/owner-mobile-delivery-plan.json','outputs/owner-mobile-delivery-plan.md','outputs/owner-mobile-quality-gates.md','outputs/owner-mobile-remaining.md'}
unexpected=[p for p in changed if not p.startswith('work/owner-mobile/') and p not in allowed]
ref=read('reference/application-snapshot.json');files=ref['files'];pairs=files.items() if isinstance(files,dict) else [(v['path'],v) for v in files]
ref_errors=[];ref_count=0
for path,v in pairs:
 expected=v['sha256'] if isinstance(v,dict) else v;ref_count+=1
 if h(r/'reference/application'/path)!=expected:ref_errors.append(path)
prior=read('outputs/owner-policies/source-evidence-manifest.json');old_evidence_errors=[v['path'] for v in prior['files'] if v['path'].startswith(('outputs/owner-policies/','work/owner-policies/')) and h(r/v['path'])!=v['sha256']]
old_next=next(v for v in prior['files'] if v['path']=='NEXT-BATCH-3.6.md');assert h(r/old_next['path'])==old_next['sha256']
review=read('outputs/owner-setup/review-resolution.json');assert h(r/review['original_review'])==review['original_review_sha256']
git=subprocess.check_output(['git','-C','/workspace/NEVORA','status','--porcelain'],text=True)
result={'source_sha256':h(r/'outputs/nevora-owner-mobile.html'),'original_manifest_files':len(original['files']),'missing_original_files':missing,'intentional_changes':changed,'unexpected_original_changes':unexpected,'prior_policy_evidence_changes':old_evidence_errors,'reference_files':ref_count,'reference_changes':ref_errors,'original_independent_review_unchanged':True,'application_checkout_clean':not git.strip(),'historical_manifest_unchanged':True,'all_passed':not(missing or unexpected or old_evidence_errors or ref_errors or git.strip()),'initial_validation_disposition':'First allowlist omitted the already-completed3.6 marker; corrected after confirming exact3.6manifest hash. No original evidence or reference was altered.'}
(r/'outputs/owner-setup/preservation-final.json').write_text(json.dumps(result,indent=2));print({k:v for k,v in result.items() if k!='intentional_changes'});assert result['all_passed']
# Inventory documents agree, H-03 alone advanced after3.6; parity Q requirements remain unverified.
c=read('outputs/owner-mobile-current-coverage.json');before=json.loads((r/'outputs/owner-setup/before-inventory/owner-mobile-current-coverage.json').read_text()) if (r/'outputs/owner-setup/before-inventory/owner-mobile-current-coverage.json').exists() else None
if before is None:before=json.loads((r/'outputs/owner-setup/before-inventory/outputs/owner-mobile-current-coverage.json').read_text())
assert [v['id'] for v,b in zip(c['rows'],before['rows']) if v!=b]==['H-03']
assert all(not q['verified'] for q in c['cross_cutting_acceptance'])
d=read('outputs/owner-mobile-delivery-plan.json');assert c['mockup_sha256']==d['mockup_sha256']==d['latest_mockup_sha256']==result['source_sha256'];assert d['current_remaining_group_count']==c['counts']['remaining_or_partial_groups']==40
assert sum(v.get('status')!='mockup_complete' for v in d['sections'])==8
(r/'outputs/owner-setup/inventory-check.json').write_text(json.dumps({'source_sha256':result['source_sha256'],'changed_workflow_rows':['H-03'],'counts':c['counts'],'open_sections':8,'new_sections_after3':7,'conditional_sections':1,'all_passed':True},indent=2))
