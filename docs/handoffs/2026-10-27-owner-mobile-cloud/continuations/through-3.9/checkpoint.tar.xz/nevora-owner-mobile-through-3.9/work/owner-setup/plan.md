# Bounded plan

1. Snapshot baseline; inspect pinned source and existing owning editors. RED pure model cases for actual two checks, active subject scope, zero/false, unavailable source and authority.
2. Implement setup read model. RED Home/checklist→exact staffing/targets/Location→truthful reread→Home journeys. Build focused view and minimal integration. Reuse current header/list/native editor primitives; no new writes.
3. Focused source/model/browser + affected triage/Location/policy neighbors. Inspect320/390/430@100/200, long/empty/failure, keyboard and exact return. Resolve material issues before one final independent review.
4. One independent whole-batch review; preserve original, grade by user effect, one combined material repair, final-source checks. Update H-03 only, current56/40/4 if passed. Save separately identified source/evidence checkpoint;3.8 follows.

Interfaces: locations/company/workforce→setup read projection; setup→triageHome coarse summary and read-only focused checklist; checklist→existing owning Schedule/Location editors; editor return→fresh checklist then Home origin. Rule: original field/write contracts remain authoritative, no deadline/policy/pay prerequisites invented. Non-Git evidence preserved; Git-specific commit/delete helpers do not apply to this isolated workspace.
