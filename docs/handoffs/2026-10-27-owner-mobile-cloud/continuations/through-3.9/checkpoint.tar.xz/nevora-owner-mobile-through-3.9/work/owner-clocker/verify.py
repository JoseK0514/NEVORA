"""Verify a frozen Clocker candidate; historical output is never overwritten."""
from pathlib import Path
import subprocess,concurrent.futures,json,hashlib,shutil,os,sys,datetime
r=Path(__file__).resolve().parents[2];n=Path('/workspace/nevora-clocker-neighbors');out=r/'outputs/owner-clocker';label=next((v.split('=',1)[1] for v in sys.argv if v.startswith('--label=')),'candidate2');dest=out/label;dest.mkdir(exist_ok=False);(dest/'captures').mkdir()
h=lambda:hashlib.sha256((r/'outputs/nevora-owner-mobile.html').read_bytes()).hexdigest()
shutil.copy2(r/'outputs/nevora-owner-mobile.html',n/'outputs/nevora-owner-mobile.html');shutil.copytree(r/'work/owner-mobile',n/'work/owner-mobile',dirs_exist_ok=True)
commands=[('source',['python3','work/owner-clocker/source-check.py'],r),('model',['node','--test','work/owner-clocker/model-check.cjs'],r),('receipts-model',['node','work/owner-clocker/receipts-model-check.cjs'],r),('receipts-view-model',['node','work/owner-clocker/receipts-view-model-check.cjs'],r),('controller',['node','work/owner-clocker/devices-controller-check.cjs','--out='+str(dest/'controller.json')],r),('integration',['node','work/owner-clocker/integration-check.cjs'],r),('captures',['node','work/owner-clocker/capture.cjs'],r)]
for e in ['chromium','firefox','webkit']:
 commands.extend([(family+'-'+e,['node','work/owner-clocker/'+script,'--engine='+e,flag+label],r) for family,script,flag in [('setup','setup-browser-check.cjs','--phase='),('devices','devices-browser-check.cjs','--tag='),('receipts','receipts-browser-check.cjs','--phase='),('seams','seams-check.cjs','--tag='),('layout','devices-layout-check.cjs','--tag='),('renderer','setup-view-check.cjs','--phase=')]])
commands.extend([('review-'+e,['node','work/owner-clocker/review-regression.cjs','--engine='+e,'--label='+label],r) for e in ['chromium','firefox','webkit']])
commands.extend([(family,['node','work/'+family+'/browser-check.cjs'],n) for family in ['owner-locations','owner-setup','owner-triage','owner-policies']])
def run(item):
 name,cmd,cwd=item;before=h();env={**os.environ,'NEVORA_WEBKIT_EXECUTABLE':'/workspace/nevora-webkit-libs/run-webkit.sh','NEVORA_CAPTURE_DIR':str(dest/'captures'),'NEVORA_CHECK_REPORT':str(dest/'integration.json'),'NEVORA_SEAMS_REPORT':str(dest/(name+'.json'))}
 with (dest/(name+'.log')).open('w') as f:p=subprocess.run(cmd,cwd=cwd,stdout=f,stderr=subprocess.STDOUT,env=env)
 return {'name':name,'command':cmd,'cwd':str(cwd),'exit':p.returncode,'source_before':before,'source_after':h(),'log':str((dest/(name+'.log')).relative_to(r))}
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:records=list(ex.map(run,commands))
# Copy per-command results before any later run of the same adapted suite.
for family in ['owner-locations','owner-setup','owner-triage','owner-policies']:
 candidates=[n/'work'/family/'browser-chromium.json',n/'outputs'/family/'browser-chromium.json'];p=next((p for p in candidates if p.exists()),None)
 if p:shutil.copy2(p,dest/(family+'.json'))
result={'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_sha256':h(),'records':records,'all_passed':all(v['exit']==0 and v['source_before']==v['source_after']==h() for v in records)}
(dest/'commands.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2));raise SystemExit(not result['all_passed'])
