/* Fictional presentation service: brand section, shared revision and immutable logo assets. */
function createOwnerBrandingStore(api){
 const C=ownerBrandColors,D=ownerPresentationData,copy=v=>JSON.parse(JSON.stringify(v)),UUID=/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
 let settings,revision,history,operations,assets,mode,assetMode,session=0,writes=0,uploads=0;
 const identity=()=>JSON.stringify([api.actor?.()||'sample-owner','sample-company']),authority=()=>JSON.stringify([api.authority(),session,mode==='denied']);
 const gate=()=>mode==='denied'?'denied':api.gate(),status=()=>gate()==='denied'?'denied':mode!=='ready'||gate()!=='ready'?'unavailable':'ready';
 function reset(){session++;mode='ready';assetMode='ready';writes=0;uploads=0;revision=0;history=[];operations=new Map();assets=new Map();settings={version:1,brand:{seed:null,algorithm:1,tokens:null,adjustments:[],logoAssetId:null}};}reset();
 const exact=(v,keys)=>v&&typeof v==='object'&&!Array.isArray(v)&&Object.keys(v).length===keys.length&&Object.keys(v).every(k=>keys.includes(k));
 function parse(v){
  if(!v||typeof v!=='object'||Array.isArray(v)||typeof v.operationId!=='string'||!UUID.test(v.operationId)||!Number.isSafeInteger(v.expectedRevision)||v.expectedRevision<0||v.expectedRevision>2147483646)return null;
  const base={operationId:v.operationId.toLowerCase(),expectedRevision:v.expectedRevision};
  if(v.section==='words')return exact(v,['operationId','expectedRevision','section','preset'])&&D.WORD_PRESET_IDS.includes(v.preset)?{...base,section:'words',preset:v.preset}:null;
  if(v.section==='modules')return exact(v,['operationId','expectedRevision','section','disabled'])&&Array.isArray(v.disabled)&&v.disabled.length<=D.MODULE_IDS.length&&v.disabled.every(id=>D.MODULE_IDS.includes(id))&&new Set(v.disabled).size===v.disabled.length?{...base,section:'modules',disabled:D.MODULE_IDS.filter(id=>v.disabled.includes(id))}:null;
  if(v.section!=='brand'||!exact(v,['operationId','expectedRevision','section','seed','logoAssetId'])||!(v.seed===null||typeof v.seed==='string'&&C.normalizeSeed(v.seed))||!(v.logoAssetId===null||typeof v.logoAssetId==='string'&&UUID.test(v.logoAssetId)))return null;
  const seed=v.seed===null?null:C.normalizeSeed(v.seed);return {...base,section:'brand',seed:seed===C.DEFAULT_SEED?null:seed,logoAssetId:v.logoAssetId?.toLowerCase()||null};
 }
 const facts=()=>{try{return api.features?.()||{state:'ready',payrollEnabled:true,blockers:{timeOff:0,marketplace:0}};}catch{return {state:'unavailable'};}};
 function readFeatures(){const r=read(),f=facts();if(r.state!=='ready')return r;if(f.state!=='ready')return {state:'unavailable'};return {...r,words:settings.words?.preset||'standard',disabled:copy(settings.modules?.disabled||[]),payrollEnabled:f.payrollEnabled,blockers:copy(f.blockers),reviewFilters:copy(f.reviewFilters||{}),retainedOpen:copy(f.retainedOpen||{})};}
 function presentation(){const r=read();return r.state==='ready'?{state:'ready',words:settings.words?.preset||'standard',modules:D.enabledModules(settings.modules?.disabled)}:{state:r.state};}
 const changedKeys=(before,after)=>['brand','words','modules'].flatMap(section=>[...new Set([...Object.keys(before[section]||{}),...Object.keys(after[section]||{})])].filter(field=>JSON.stringify(before[section]?.[field])!==JSON.stringify(after[section]?.[field])).map(field=>section+'.'+field)).sort();

 const inspectLogo=bytes=>{
  if(!bytes.length)return {ok:false,problem:'empty'};if(bytes.length>262144)return {ok:false,problem:'too_large'};
  const ascii=(at,s)=>[...s].every((c,i)=>bytes[at+i]===c.charCodeAt(0)),be=at=>((bytes[at]<<24)>>>0)+(bytes[at+1]<<16)+(bytes[at+2]<<8)+bytes[at+3],le=at=>bytes[at]|bytes[at+1]<<8|bytes[at+2]<<16;let width,height,mediaType;
  if(bytes.length>=24&&[137,80,78,71,13,10,26,10].every((b,i)=>bytes[i]===b)&&ascii(12,'IHDR')){width=be(16);height=be(20);mediaType='image/png';}
  else if(bytes.length>=30&&ascii(0,'RIFF')&&ascii(8,'WEBP')){mediaType='image/webp';if(ascii(12,'VP8 ')&&bytes[23]===157&&bytes[24]===1&&bytes[25]===42){width=(bytes[26]|bytes[27]<<8)&16383;height=(bytes[28]|bytes[29]<<8)&16383;}else if(ascii(12,'VP8L')&&bytes[20]===47){const bits=bytes[21]|bytes[22]<<8|bytes[23]<<16|bytes[24]<<24;width=(bits&16383)+1;height=(bits>>>14&16383)+1;}else if(ascii(12,'VP8X')){width=le(24)+1;height=le(27)+1;}}
  if(width===undefined)return {ok:false,problem:'unsupported'};if(Math.min(width,height)<32)return {ok:false,problem:'too_small'};if(Math.max(width,height)>2048)return {ok:false,problem:'too_big'};if(width/height>4||height/width>4)return {ok:false,problem:'shape'};return {ok:true,image:{width,height,mediaType,byteSize:bytes.length}};
 };
 const logoProblems={empty:'Choose an image file.',too_large:'Use an image up to 256 KB.',unsupported:'Choose a PNG or WebP image.',too_small:'Use an image at least 32 pixels on each side.',too_big:'Use an image no larger than 2,048 pixels on each side.',shape:'Neither side can be more than four times the other.'};
 function image(id){if(!id)return {state:'none'};if(status()!=='ready'||assetMode!=='ready')return {state:'unavailable'};const a=assets.get(id);return a?{state:'ready',id,src:'data:'+a.mediaType+';base64,'+a.dataBase64,width:a.width,height:a.height,mediaType:a.mediaType,byteSize:a.byteSize}:{state:'unavailable'};}
 function read(){const state=status();if(state!=='ready')return {state};const context=api.context();if(!context)return {state:'unavailable'};return {state:'ready',revision,brand:copy(settings.brand),image:image(settings.brand.logoAssetId),context:copy(context),history:copy(history.slice(0,20)),observedAt:new Date(api.now()).toISOString(),validForMs:45000,authority:authority()};}
 function save(value,scenario='normal',key=authority()){
  const state=status();if(key!==authority()||state==='denied')return {state:'denied'};if(state!=='ready')return {state:'unavailable'};const command=parse(value);if(!command)return {state:'invalid'};
  const hash=JSON.stringify(command),prior=operations.get(command.operationId);if(prior)return prior.identity===identity()&&prior.hash===hash?{state:'confirmed',result:copy(prior.result)}:{state:'conflict'};
  if(command.expectedRevision!==revision)return {state:'conflict'};
  if(command.section==='brand'&&command.logoAssetId&&!assets.has(command.logoAssetId))return {state:'denied'};if(command.section==='brand'&&command.logoAssetId&&assetMode!=='ready')return {state:'unavailable'};
  if(command.section==='modules'){const newlyOff=command.disabled.filter(id=>!(settings.modules?.disabled||[]).includes(id));for(const id of newlyOff.filter(id=>['timeOff','marketplace'].includes(id))){const f=facts();if(f.state!=='ready'||!Number.isInteger(f.blockers?.[id])||f.blockers[id]<0)return {state:'unavailable'};if(f.blockers[id]>0)return {state:'busy',module:id,count:f.blockers[id]};}}
  if(scenario==='failure')return {state:'error'};if(scenario==='unknown-before')return {state:'unconfirmed'};
  const next=copy(settings);
  if(command.section==='brand'){const derived=command.seed?C.deriveBrand(command.seed):null,usable=derived&&!derived.adjustments.some(a=>a.code==='grey');next.brand={seed:usable?derived.seed:null,algorithm:1,tokens:usable?derived.tokens:null,adjustments:derived?derived.adjustments.map(a=>a.code):[],logoAssetId:command.logoAssetId};}
  if(command.section==='words')next.words={preset:command.preset};if(command.section==='modules')next.modules={disabled:copy(command.disabled)};
  const changes=changedKeys(revision?settings:{version:1,brand:{}},next);settings=next;revision++;writes++;
  const result={operationId:command.operationId,revision,changedAt:new Date(api.now()).toISOString(),changedKeys:changes};history.unshift({...copy(result),settings:copy(settings)});operations.set(command.operationId,{identity:identity(),hash,result:copy(result)});return scenario==='unknown-after'?{state:'unconfirmed'}:{state:'confirmed',result:copy(result)};
 }
 async function upload(value,scenario='normal',key=authority()){
  const state=status();if(key!==authority()||state==='denied')return {state:'denied'};if(state!=='ready'||assetMode!=='ready')return {state:'unavailable'};
  if(!exact(value,['operationId','dataBase64'])||!UUID.test(value.operationId)||typeof value.dataBase64!=='string'||value.dataBase64.length>360000||!/^[A-Za-z0-9+/]+={0,2}$/.test(value.dataBase64))return {state:'invalid',message:'Choose a PNG or WebP image up to 256 KB.'};
  let bytes;try{bytes=Uint8Array.from(atob(value.dataBase64),c=>c.charCodeAt(0));}catch{return {state:'invalid',message:logoProblems.unsupported};}const inspected=inspectLogo(bytes);if(!inspected.ok)return {state:'invalid',message:logoProblems[inspected.problem]};
  let hash;try{hash=await api.hash(bytes);}catch{return {state:'unconfirmed'};}if(key!==authority()||status()==='denied')return {state:'denied'};if(status()!=='ready'||assetMode!=='ready')return {state:'unavailable'};
  const id=value.operationId.toLowerCase(),prior=assets.get(id);if(prior)return prior.identity===identity()&&prior.hash===hash?{state:'confirmed',result:{assetId:id,...copy(inspected.image)}}:{state:'conflict'};
  if(scenario==='failure')return {state:'error'};if(scenario==='unknown-before')return {state:'unconfirmed'};
  assets.set(id,{...copy(inspected.image),hash,identity:identity(),dataBase64:value.dataBase64});uploads++;return scenario==='unknown-after'?{state:'unconfirmed'}:{state:'confirmed',result:{assetId:id,...copy(inspected.image)}};
 }
 return {read,readFeatures,presentation,save,upload,image,inspectLogo,logoProblems,parse,authority,now:api.now,reset,gate:status,previewReadMode:v=>{mode=v;},previewAssetMode:v=>{assetMode=v;},previewAuthority:()=>{session++;},previewOtherSection:patch=>{const before=revision?copy(settings):{version:1,brand:{}};if(patch.words)settings.words=copy(patch.words);if(patch.modules)settings.modules=copy(patch.modules);revision++;history.unshift({operationId:crypto.randomUUID(),revision,changedAt:new Date(api.now()).toISOString(),changedKeys:changedKeys(before,settings),settings:copy(settings)});},snapshot:()=>({revision,mode,writes,uploads,settings:copy(settings),assets:assets.size,operations:operations.size})};
}
