"""Archive the separately identified standalone3.6 source/evidence, never the app checkout."""
from pathlib import Path
import hashlib,json,tarfile
root=Path(__file__).resolve().parents[2]
roots=['work/owner-mobile','work/owner-policies','outputs/owner-policies','outputs/nevora-owner-mobile.html','outputs/owner-mobile-current-coverage.json','outputs/owner-mobile-delivery-plan.md','outputs/owner-mobile-delivery-plan.json','outputs/owner-mobile-quality-gates.md','outputs/owner-mobile-remaining.md','CURRENT-STATE.md','AGENTS.md','START-HERE.md','NEXT-BATCH-3.6.md','NEXT-BATCH-3.7.md','DESIGN.md','CONVERSATION-CONTEXT.md','WORKING-AGREEMENTS.md']
files=[]
for name in roots:
 p=root/name
 files.extend([p] if p.is_file() else [f for f in p.rglob('*') if f.is_file() and '__pycache__' not in f.parts])
manifest=root/'outputs/owner-policies/source-evidence-manifest.json';files=[p for p in sorted(set(files)) if p!=manifest]
records=[{'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]
manifest.write_text(json.dumps({'batch':'3.6','base_repository':'JoseK0514/NEVORA','base_branch':'codex/owner-mobile-cloud-handoff-20261027','base_artifact_sha256':'65f2a5d5cbb596f90a2d08adb2fca30c869e1142e8325e9d25f23326e70d1c64','artifact_sha256':hashlib.sha256((root/'outputs/nevora-owner-mobile.html').read_bytes()).hexdigest(),'scope':'Standalone MOBILE OWNER source/evidence update. Extract original handoff first; overlay only into a copy of its extracted package outside the app checkout. Immutable original transport manifest intentionally remains historical. No app integration.','files':records},indent=2))
archive=Path('/workspace/shared/downloads/nevora-owner-mobile-3.6.tar.xz');archive.parent.mkdir(exist_ok=True,parents=True)
with tarfile.open(archive,'w:xz') as tar:
 for p in files+[manifest]:tar.add(p,arcname='nevora-owner-mobile-3.6/'+str(p.relative_to(root)))
problems=[]
with tarfile.open(archive,'r:xz') as tar:
 for r in records:
  data=tar.extractfile('nevora-owner-mobile-3.6/'+r['path']).read()
  if len(data)!=r['bytes'] or hashlib.sha256(data).hexdigest()!=r['sha256']:problems.append(r['path'])
result={'archive':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files_verified':len(records),'problems':problems}
Path('/workspace/shared/downloads/nevora-owner-mobile-3.6-validation.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2));raise SystemExit(bool(problems))
