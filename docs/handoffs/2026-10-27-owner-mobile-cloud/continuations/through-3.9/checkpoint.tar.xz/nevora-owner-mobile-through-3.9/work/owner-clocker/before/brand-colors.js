/* Source-derived color math, actual-app46e2027. Default mockup styling is mapped separately. */
const ownerBrandColors=(()=>{
/** Colour maths for company branding: sRGB, OKLab/OKLCH (Björn Ottosson) and
 * WCAG 2 contrast. Pure and dependency-free so the editor preview and the
 * server derive the same tokens. */
                                                       // 0..1, gamma encoded
                                                         // h in degrees

function parseHex(value        )             {
  const match = /^#([0-9a-f]{6})$/i.exec(value.trim());
  if (!match) return null;
  const n = parseInt(match[1], 16);
  return { r: ((n >> 16) & 255) / 255, g: ((n >> 8) & 255) / 255, b: (n & 255) / 255 };
}

function toHex({ r, g, b }     )         {
  const byte = (v        ) => Math.round(Math.min(1, Math.max(0, v)) * 255).toString(16).padStart(2, "0");
  return `#${byte(r)}${byte(g)}${byte(b)}`.toUpperCase();
}

const toLinear = (v        ) => (v <= 0.04045 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4);
const toGamma = (v        ) => (v <= 0.0031308 ? 12.92 * v : 1.055 * v ** (1 / 2.4) - 0.055);

function rgbToOklch(rgb     )        {
  const r = toLinear(rgb.r), g = toLinear(rgb.g), b = toLinear(rgb.b);
  const l = Math.cbrt(0.4122214708 * r + 0.5363325363 * g + 0.0514459929 * b);
  const m = Math.cbrt(0.2119034982 * r + 0.6806995451 * g + 0.1073969566 * b);
  const s = Math.cbrt(0.0883024619 * r + 0.2817188376 * g + 0.6299787005 * b);
  const L = 0.2104542553 * l + 0.793617785 * m - 0.0040720468 * s;
  const A = 1.9779984951 * l - 2.428592205 * m + 0.4505937099 * s;
  const B = 0.0259040371 * l + 0.7827717662 * m - 0.808675766 * s;
  const h = (Math.atan2(B, A) * 180) / Math.PI;
  return { l: L, c: Math.hypot(A, B), h: h < 0 ? h + 360 : h };
}

/** Unclamped linear sRGB for an OKLCH colour (may fall outside 0..1). */
function oklchToLinear({ l: L, c, h }       ) {
  const A = c * Math.cos((h * Math.PI) / 180), B = c * Math.sin((h * Math.PI) / 180);
  const l = (L + 0.3963377774 * A + 0.2158037573 * B) ** 3;
  const m = (L - 0.1055613458 * A - 0.0638541728 * B) ** 3;
  const s = (L - 0.0894841775 * A - 1.291485548 * B) ** 3;
  return {
    r: 4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s,
    g: -1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s,
    b: -0.0041960863 * l - 0.7034186147 * m + 1.707614701 * s,
  };
}

const inGamut = (v                                     ) =>
  [v.r, v.g, v.b].every(x => x >= -1e-6 && x <= 1 + 1e-6);

/** Keep lightness and hue; reduce chroma until the colour fits sRGB. */
function oklchToRgb(color       )      {
  let lo = 0, hi = color.c, best = { ...color, c: 0 };
  if (inGamut(oklchToLinear(color))) best = color;
  else for (let i = 0; i < 24; i++) {
    const mid = (lo + hi) / 2;
    if (inGamut(oklchToLinear({ ...color, c: mid }))) { lo = mid; best = { ...color, c: mid }; } else hi = mid;
  }
  const lin = oklchToLinear(best);
  return { r: toGamma(Math.max(0, lin.r)), g: toGamma(Math.max(0, lin.g)), b: toGamma(Math.max(0, lin.b)) };
}

function luminance({ r, g, b }     )         {
  return 0.2126 * toLinear(r) + 0.7152 * toLinear(g) + 0.0722 * toLinear(b);
}

function contrast(a              , b              )         {
  const x = typeof a === "string" ? parseHex(a) : a, y = typeof b === "string" ? parseHex(b) : b;
  if (!x || !y) return 0;
  const [hi, lo] = [luminance(x), luminance(y)].sort((p, q) => q - p);
  return (hi + 0.05) / (lo + 0.05);
}

/** Shortest distance between two hues, in degrees (0..180). */
const hueDistance = (a        , b        ) => {
  const d = Math.abs(a - b) % 360;
  return d > 180 ? 360 - d : d;
};

/** Mix `a` into `b` (default white) by `amount` in gamma-encoded sRGB, the
 * way CSS `color-mix(in srgb, a amount, b)` does. */
function mix(a        , amount        , b = "#FFFFFF")         {
  const x = parseHex(a), y = parseHex(b);
  if (!x || !y) return b;
  return toHex({ r: x.r * amount + y.r * (1 - amount), g: x.g * amount + y.g * (1 - amount), b: x.b * amount + y.b * (1 - amount) });
}

/** Company brand colours (B1). One seed colour becomes the portal's teal
 * ladder. Every output keeps the accessibility floors the approved teal
 * meets, so a company can change the colour but never the readability.
 * The default NEVORA teal returns the hand-tuned values exactly. */
const BRAND_ALGORITHM = 1         ;
const DEFAULT_SEED = "#077572";

                           
                                                                                
                                                                                      
                                        
  

const DEFAULT_TOKENS              = {
  accent: "#077572", accentHover: "#055C5A", accentStrong: "#07605F", accentWash: "#E7F3F2",
  accentLine: "#C9E0DE", accentTint: "#F3F9F8", accentSelect: "#CDE7E5", accentPressed: "#D3EAE8",
  masthead: "#1C4A47", mastheadInk: "#CFE3E1",
};

/** The only custom properties a company brand may set. */
const BRAND_CSS_VARS                                             = {
  accent: "--g-accent", accentHover: "--g-accent-hover", accentStrong: "--g-accent-strong", accentWash: "--g-accent-wash",
  accentLine: "--g-accent-line", accentTint: "--g-accent-tint", accentSelect: "--g-accent-select", accentPressed: "--g-accent-pressed",
  masthead: "--g-masthead", mastheadInk: "--g-masthead-ink",
};

                                                                                                          
                                                                                                         
                                                                                                                                    

const WHITE = "#FFFFFF", INSET = "#F6F7F8";
/** Status hues (OKLCH) the brand must stay visibly apart from: danger, the
 * urgent bar, warning and success. */
const STATUS = [
  { hue: 29.5, name: "the error red" }, { hue: 31.4, name: "the urgent red" },
  { hue: 55.8, name: "the warning amber" }, { hue: 154.6, name: "the success green" },
];
const STATUS_BAND = 10, GREY_CHROMA = 0.03, TINT_MIX = 0.12;

const hex = (color       ) => toHex(oklchToRgb(color));
const clamp = (v        , lo        , hi        ) => Math.min(hi, Math.max(lo, v));

/** Darken (or lighten) in small steps until `ok` holds, keeping hue and chroma. */
function solve(color       , ok                            , step = -0.005)        {
  let current = { ...color };
  for (let i = 0; i < 200 && !ok(hex(current)); i++) current = { ...current, l: clamp(current.l + step, 0.05, 0.99) };
  return current;
}

function normalizeSeed(value        )                {
  const rgb = parseHex(value);
  return rgb ? toHex(rgb) : null;
}

function deriveBrand(seedInput        )               {
  const seed = normalizeSeed(seedInput) ?? DEFAULT_SEED;
  if (seed === DEFAULT_SEED) return { seed, algorithm: BRAND_ALGORITHM, tokens: { ...DEFAULT_TOKENS }, adjustments: [] };
  const adjustments                    = [];
  let base = rgbToOklch(parseHex(seed) );

  if (base.c < GREY_CHROMA) {
    adjustments.push({ code: "grey", message: "This colour is too close to grey to mark buttons and links, so NEVORA teal is used instead." });
    return { seed, algorithm: BRAND_ALGORITHM, tokens: { ...DEFAULT_TOKENS }, adjustments };
  }

  const clash = STATUS.map(s => ({ ...s, distance: hueDistance(base.h, s.hue) })).filter(s => s.distance < STATUS_BAND)
    .sort((a, b) => a.distance - b.distance)[0];
  if (clash) {
    // Move to the nearer edge that is clear of every status band.
    const candidates = STATUS.flatMap(s => [s.hue - STATUS_BAND, s.hue + STATUS_BAND]).map(h => (h + 360) % 360)
      .filter(h => STATUS.every(s => hueDistance(h, s.hue) >= STATUS_BAND - 1e-9))
      .sort((a, b) => hueDistance(a, base.h) - hueDistance(b, base.h));
    base = { ...base, h: candidates[0] };
    adjustments.push({ code: "status-hue", message: `The hue was shifted slightly so it can’t be mistaken for ${clash.name} used for alerts.` });
  }

  // Accent: white button text at 5:1 or better; never so dark it merges with the masthead.
  let accent = { ...base };
  if (contrast(hex(accent), WHITE) < 4.5) {
    accent = solve(accent, v => contrast(v, WHITE) >= 5);
    adjustments.push({ code: "darkened", message: "Darkened so white text on buttons stays readable (at least 5:1)." });
  } else if (accent.l < 0.36) {
    accent = { ...accent, l: 0.36 };
    adjustments.push({ code: "lightened", message: "Lightened a little so buttons stay distinct from the dark header." });
  }

  const c = accent.c, h = accent.h;
  const wash = { l: 0.955, c: Math.min(c * 0.15, 0.03), h };
  const washHex = hex(wash);
  // Links and counts also sit on tints of the accent (its wash, and CSS mixes of
  // up to 12% over white). NEVORA teal clears 4.5:1 there, so every brand must.
  const onTints = (v        ) => contrast(v, washHex) >= 4.5 && contrast(v, mix(v, TINT_MIX)) >= 4.5;
  if (!onTints(hex(accent))) {
    accent = solve(accent, onTints);
    if (!adjustments.some(a => a.code === "darkened"))
      adjustments.push({ code: "darkened", message: "Darkened slightly so links stay readable on tinted backgrounds." });
  }
  const hover = solve({ l: accent.l - 0.08, c: c * 0.84, h }, v => contrast(v, WHITE) >= 4.5);
  const strong = solve({ l: accent.l - 0.065, c: c * 0.86, h }, v => contrast(v, washHex) >= 4.5);
  const masthead = solve({ l: Math.min(0.376, accent.l - 0.13), c: Math.min(c * 0.58, 0.08), h }, v => contrast(v, WHITE) >= 7);
  const mastheadHex = hex(masthead);
  const mastheadInk = solve({ l: 0.9, c: Math.min(c * 0.25, 0.045), h }, v => contrast(v, mastheadHex) >= 4.5, 0.005);

  return {
    seed, algorithm: BRAND_ALGORITHM, adjustments,
    tokens: {
      accent: hex(accent), accentHover: hex(hover), accentStrong: hex(strong), accentWash: washHex,
      accentLine: hex({ l: 0.889, c: Math.min(c * 0.29, 0.05), h }),
      accentTint: hex({ l: 0.977, c: Math.min(c * 0.08, 0.012), h }),
      accentSelect: hex({ l: 0.908, c: Math.min(c * 0.32, 0.055), h }),
      accentPressed: hex({ l: 0.92, c: Math.min(c * 0.28, 0.05), h }),
      masthead: mastheadHex, mastheadInk: hex(mastheadInk),
    },
  };
}

/** The pairs the portal relies on, with the floor each must meet. */
function contrastReport(tokens             )                  {
  const rows                                             = [
    ["button", "White text on buttons", WHITE, tokens.accent, 4.5],
    ["button-hover", "White text on pressed buttons", WHITE, tokens.accentHover, 4.5],
    ["link", "Links on white", tokens.accent, WHITE, 4.5],
    ["link-tint", "Links on tinted backgrounds", tokens.accent, mix(tokens.accent, TINT_MIX), 4.5],
    ["link-wash", "Links on the selected tint", tokens.accent, tokens.accentWash, 4.5],
    ["selected", "Selected text on its tint", tokens.accentStrong, tokens.accentWash, 4.5],
    ["masthead", "White text on the header", WHITE, tokens.masthead, 7],
    ["masthead-secondary", "Secondary text on the header", tokens.mastheadInk, tokens.masthead, 4.5],
    ["focus", "Focus ring on white", tokens.accent, WHITE, 3],
    ["focus-inset", "Focus ring on grey panels", tokens.accent, INSET, 3],
  ];
  return rows.map(([id, label, fg, bg, minimum]) => {
    const ratio = Math.floor(contrast(fg, bg) * 100) / 100;
    return { id, label, ratio, minimum, pass: ratio >= minimum };
  });
}

/** Inline custom properties for `.app-shell`. Only known keys and strict hex
 * values pass, so stored data can never inject other CSS. */
function brandStyle(tokens                                                                )                                     {
  if (!tokens) return undefined;
  const style                         = {};
  for (const key of Object.keys(BRAND_CSS_VARS)                         ) {
    const value = tokens[key];
    if (typeof value === "string" && /^#[0-9A-F]{6}$/i.test(value)) style[BRAND_CSS_VARS[key]] = value.toUpperCase();
  }
  return Object.keys(style).length === Object.keys(BRAND_CSS_VARS).length ? style : undefined;
}

/** The kiosk keeps its own teal variables (U9); a brand maps onto them. */
function clockerBrandStyle(tokens                                )                                     {
  const portal = brandStyle(tokens);
  if (!portal || !tokens) return undefined;
  return { "--clocker-accent": portal["--g-accent"], "--clocker-accent-hover": portal["--g-accent-hover"], "--clocker-focus": portal["--g-accent-strong"], "--clocker-soft": portal["--g-accent-wash"] };
}

const isDefaultBrand = (tokens             ) =>
  (Object.keys(DEFAULT_TOKENS)                         ).every(k => tokens[k].toUpperCase() === DEFAULT_TOKENS[k]);

return {deriveBrand,contrastReport,normalizeSeed,DEFAULT_SEED,DEFAULT_TOKENS,contrast,mix,brandStyle};
})();
