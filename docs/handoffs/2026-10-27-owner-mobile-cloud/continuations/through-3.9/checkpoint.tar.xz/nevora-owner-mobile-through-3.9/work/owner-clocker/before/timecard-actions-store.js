/* Fictional revision-bound timecard decisions. No service, database or payment transport. */
function createOwnerTimecardActionsStore(team,clock){
 const copy=x=>JSON.parse(JSON.stringify(x)),success={APPROVE:'approved',FINALIZE:'finalized',REOPEN:'reopened'};
 let receipts=new Map(),writes=0,session=1,modes=[],payroll=new Set();
 const authority=()=>JSON.stringify([team.snapshot().actor.id,team.snapshot().actor.active,team.snapshot().actor.accessRole,team.snapshot().actor.roleGeneration,session,'sample-company','timecards']);
 const uuid=x=>typeof x==='string'&&/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(x);
 const safe=x=>typeof x==='string'&&x===x.trim()&&x.length>0&&x.length<=500&&!/[\u0000-\u001f\u007f]/.test(x);
 function validate(c){return !!c&&typeof c==='object'&&uuid(c.operationId)&&typeof c.employeeId==='string'&&!!c.employeeId.trim()&&c.employeeId===c.employeeId.trim()&&c.employeeId.length<=200&&Number.isSafeInteger(c.expectedRevision)&&c.expectedRevision>=0&&/^[a-f0-9]{32}$/.test(c.expectedSourceHash)&&Object.hasOwn(success,c.action)&&clock.period(c.startDate,c.endDate).ok&&(!Object.hasOwn(c,'note')||safe(c.note))&&(c.action!=='REOPEN'||safe(c.note))&&!Object.keys(c).some(k=>!['operationId','employeeId','startDate','endDate','expectedRevision','expectedSourceHash','action','note'].includes(k));}
 function command(item,action,note,operationId=crypto.randomUUID()){return {operationId,employeeId:item.card.employeeId,startDate:item.card.startDate,endDate:item.card.endDate,expectedRevision:item.revision,expectedSourceHash:item.sourceHash,action,...(note!=null?{note}: {})};}
 function exclusion(item,action){if(item.card.employeeId===team.snapshot().actor.id)return 'self';if(item.card.issues.length)return 'issues';if(action==='FINALIZE'?item.state!=='APPROVED':!['DRAFT','REOPENED','NEEDS_REVIEW'].includes(item.state))return 'state';return null;}
 function matches(r,c){return !!r&&r.status===success[c.action]&&r.operationId===c.operationId&&r.revision===c.expectedRevision+1&&Object.keys(r).length===3;}
 function submit(c,mode=modes.shift()||'normal',binding=authority()){
  if(!team.isOwner()||binding!==authority()||clock.snapshot().mode==='denied'||mode==='denied')return {status:'denied'};
  if(!validate(c))return {status:'invalid'};
  if(!['ready','empty'].includes(clock.snapshot().mode)||mode==='unavailable')return {status:'unavailable'};
  // Reopen's payroll guard precedes the database command, including replay, in the actual service.
  if(c.action==='REOPEN'&&payroll.has(c.employeeId))return {status:'blocked',reason:'payroll_approved'};
  const key=JSON.stringify([binding,c]),prior=receipts.get(c.operationId);
  if(prior)return prior.key===key?copy(prior.result):{status:'conflict'};
  if(mode==='unknown-before')return {status:'outcome-unknown',operationId:c.operationId};
  if(mode==='conflict')return {status:'conflict'};
  const result=clock.read({startDate:c.startDate,endDate:c.endDate}),item=result.cards?.find(i=>i.card.employeeId===c.employeeId);
  if(result.state!=='ready'||!item)return {status:'unavailable'};
  if(c.employeeId===team.snapshot().actor.id)return {status:'blocked',reason:'self_review'};
  if(item.revision!==c.expectedRevision||item.sourceHash!==c.expectedSourceHash)return {status:'conflict'};
  if(clock.lifecycleDomain.finalized().some(p=>p.personId===c.employeeId&&p.startAt.slice(0,10)<=c.endDate&&clock.addDays(p.endAt.slice(0,10),-1)>=c.startDate&&(p.startAt.slice(0,10)!==c.startDate||clock.addDays(p.endAt.slice(0,10),-1)!==c.endDate)))return {status:'blocked',reason:'overlapping_period'};
  if(c.action==='REOPEN'){if(item.state!=='FINALIZED')return {status:'blocked',reason:'period_state'};}
  else{if(item.state==='FINALIZED')return {status:'blocked',reason:'period_state'};if(item.card.issues.length)return {status:'blocked',reason:'unresolved_time'};if(c.action==='FINALIZE'&&item.state!=='APPROVED')return {status:'blocked',reason:'approval_required'};}
  const revision=clock.lifecycleDomain.capture(c),receipt={status:success[c.action],operationId:c.operationId,revision};writes++;receipts.set(c.operationId,{key,result:copy(receipt)});
  if(mode==='unknown-after')return {status:'outcome-unknown',operationId:c.operationId};
  if(mode==='mismatched')return {...receipt,revision:revision+1};
  return receipt;
 }
 function review(period,cards,ids,action,uuid=()=>crypto.randomUUID()){
  if(!['APPROVE','FINALIZE'].includes(action)||!ids.length||ids.length>100||new Set(ids).size!==ids.length)throw Error('Select 1 to 100 current timecards.');
  const commands=ids.map(id=>{const i=cards.find(i=>i.card.employeeId===id);if(!i||exclusion(i,action)||i.card.startDate!==period.startDate||i.card.endDate!==period.endDate)throw Error('Refresh and review the selected timecards again.');return Object.freeze(command(i,action,null,uuid()));});
  if(new Set(commands.map(c=>c.operationId)).size!==commands.length)throw Error('Each timecard needs a separate operation.');
  return Object.freeze({period:Object.freeze({...period}),binding:authority(),commands:Object.freeze(commands)});
 }
 function current(review,cards){return review.binding===authority()&&review.commands.every(c=>{const i=cards.find(i=>i.card.employeeId===c.employeeId);return !!i&&!exclusion(i,c.action)&&i.revision===c.expectedRevision&&i.sourceHash===c.expectedSourceHash&&i.card.startDate===review.period.startDate&&i.card.endDate===review.period.endDate;});}
 function run(review,isCurrent,onOutcome){let stopped=false;return review.commands.map(command=>{let result={status:'not-submitted'};if(!stopped&&isCurrent()){result=submit(command,undefined,review.binding);if(['approved','finalized'].includes(result.status)&&!matches(result,command))result={status:'outcome-unknown',operationId:command.operationId};}if(!['approved','finalized'].includes(result.status))stopped=true;const outcome={command,...result};onOutcome?.(outcome);return outcome;});}
 return {authority,validate,command,exclusion,matches,submit,review,current,run,reset:()=>{receipts.clear();writes=0;session++;modes=[];payroll.clear();},previewModes:values=>{modes=[...values];},previewPayroll:(id,value)=>{if(value)payroll.add(id);else payroll.delete(id);},previewAuthority:()=>{session++;},snapshot:()=>({writes,receipts:receipts.size})};
}
