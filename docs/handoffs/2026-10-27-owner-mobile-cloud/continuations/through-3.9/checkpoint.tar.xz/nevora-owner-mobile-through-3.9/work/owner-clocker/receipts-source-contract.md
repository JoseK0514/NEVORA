# A-04 source contract and integration interface

Pinned read-only actual-app source: `46e202786863279302026ee03a0e225c359fa55c`. Inspected:

- `src/components/clocker-recovery-review.tsx` and its component tests: exact UUID input, uppercase normalization, reference-edit retirement, pause-on-blur/offline, no request while offline, current private snapshots, same-tablet guidance, Timecards row.
- `src/app/app/clocker-recovery/page.tsx`, `src/app/app/employees/recovery-composition.test.tsx`: current company-wide management boundary; Owner Settings return; authority keys the selection.
- `src/app/api/manager/clocker-recovery/route.ts`: protected read POST accepts exactly `{commandId}`; 401/403 means denied; no punch writer.
- `src/lib/clocker/recovery-review.server.ts`, `src/lib/clocker/punch-command.ts`, `src/lib/private-snapshot-client.ts`, `src/test/integration/clocker-recovery-review.integration.ts`, `src/test/integration/company-access-recovery-calendar.integration.ts`: lowercase full UUID; workspace-scoped immutable ledger joined to current person/device/location labels; ≤100 receipts; observedAt and 1–15000ms validity; current management/session/company rechecks; absent result has no history side effect.

`createOwnerClockerReceiptsStore({gate,authority,now,locations,people,context})`:

- `gate()` returns ready/denied/unavailable; `authority()` and `now()` forward current shared authority/time.
- `validateReference(value)` returns `{ok,commandId,error}`; UI trims and lowercases before source UUID validation. Errors distinguish empty and malformed references.
- `read(commandId)` is a synchronous fictional read: source-shaped `{state:'ready',commandId,receipts:[{employeeId,employeeName,deviceName,locationName,action,performedAt,timeEntryId}],observedAt,validForMs:15000,authority}` plus current company `timeZone`, or `{state:'unavailable',reason}`. It does not retain a private result. Missing joined source is a read failure; inactive historical people/locations remain valid historical joins.
- `context()` supplies the current confirmed company time zone, corresponding to the pinned page's timeZone prop. Display and performed-date week use that observation. An unavailable/invalid confirmed context fails closed; only older isolated model fixtures that omit the context function use the fixed sample-zone fallback.
- `previewReadMode(mode)`, `reset()`, `snapshot()` are local verification adapters. Modes ready/error/denied/empty; snapshot exposes counters/mode, never private receipts. No writer exists.
- Shared locations input is an array `{id,key,name,...}` or null when unavailable. Shared people is the existing Team directory array `{id,name,...}` or null. Neither is copied into durable storage.

Fictional saved references align to existing Timecards recorded samples. No operational ledger is queried or changed:

| Reference | Employee | Existing entry | Action/time | Device/location |
|---|---|---|---|---|
| `4a9c7ed1-9b42-4dc0-8847-324d7ade7832` | person-1 | sample-entry-6 | CLOCK_IN · 2026-10-26T06:00:00-04:00 | Front counter tablet · location-1 |
| `bb8a042e-044c-4205-9aab-23a87511e789` | person-1 | sample-entry-6 | START_BREAK · 2026-10-26T08:00:00-04:00 | same |
| `c3773e70-b462-4c46-95ea-d5650a57e746` | person-1 | sample-entry-6 | END_BREAK · 2026-10-26T08:30:00-04:00 | same |
| `de542bbc-2d5a-44ea-90eb-b6ec3e20c134` | person-1 | sample-entry-6 | CLOCK_OUT · 2026-10-26T10:00:00-04:00 | same |
| any other valid UUID | none | none | Not recorded yet | no receipt implied |

The view is `createOwnerClockerReceipts(api,store)`, page `clocker-recovery`. API: `{escapeHTML,icon,$,page,scroll,navigate,header,parent,origin,openTimecards}`. `header()` refreshes root identity; `parent(origin)` restores the exact root-owned parent. `open(context)` accepts `{parent,feature,location,query,scroll,focus,reference,startDate,endDate,employeeId,checked,lookupScroll,returnContext}`. `returnContext` contains only root-owned navigation state. No private receipt is included.

The view returns `{open,render,refresh,onNavigate,reset,previewReadMode,previewTick,snapshot,store}`. `onNavigate(page)` clears private results and pending callbacks when leaving. `openTimecards({employeeId?,startDate?,endDate?,returnLabel:'Clocker recovery',returnTo,clockerRecoveryReturn})` preserves the return callback and serializable non-private lookup context. A found receipt chooses its exact person and performed-date week unless an explicit source period was supplied; no-result uses supplied person/period or the existing Timecards default. Timecards owns date validation, card contents and any correction decisions.

Deep-link parameters written by the view: `page=clocker-recovery`, `location`, `coq`, `cofeature`, `crParent`, `crScroll`, `crFocus`, `crReference`, `crStart`, `crEnd`, `crEmployee`. Root restores these via `open(context)`; a reference is prefilled and requires Check. A callback return uses `checked:true` to perform a fresh lookup rather than restore private content. Root may serialize `clockerRecoveryReturn` on the Timecards URL for reload return. `returnContext` is serialized as the safe root-compatible wrapper `crReturn={returnContext:...}` when present.

Root deliberately restores known parent controls (Team Tools, More Clocker recovery, Settings Clocker devices); raw URL `crFocus` is navigation provenance and is not executed as an arbitrary CSS selector. Team filters and serializable return state are root allowlisted.

Denied/changed authority clears selection/reference and result; unavailable/paused/offline/expired clears the entire private receipt. The user-entered reference may remain outside the private result until access ends. Reference editing cancels previous observation and selection. All asynchronous completion checks generation, visibility, connectivity and current authority/gate; fresh results expire within the 15-second budget.
