/* Fictional operational scope revisions. No live permission/session changes. */
function createOwnerManagerAccessStore(team){
 const copy=x=>JSON.parse(JSON.stringify(x));
 let revisions,operations,locations,serial,readMode,clock;
 const fromCore=scope=>scope?.kind==='company'?{mode:'COMPANY',locationIds:[]}:scope?.kind==='locations'?{mode:'LOCATIONS',locationIds:scope.locations.map(name=>locations.find(l=>l.name===name)?.id).filter(Boolean).sort()}:null;
 const toCore=scope=>scope?{kind:scope.mode==='COMPANY'?'company':'locations',locations:scope.locationIds.map(id=>locations.find(l=>l.id===id)?.name).filter(Boolean)}:null;
 function append(p,action,scope,source='OWNER_ASSIGNMENT'){
  const history=revisions.get(p.id)||[],record={employeeId:p.id,revision:(history.at(-1)?.revision||0)+1,roleGeneration:p.roleGeneration,action,scope:copy(scope),source,createdAt:clock};history.push(record);revisions.set(p.id,history);return record;
 }
 function reset(){revisions=new Map();operations=new Map();serial=0;readMode='ready';clock=Date.parse('2026-10-26T15:24:00Z');locations=team.locations.map((name,i)=>({id:'sample-location-'+(i+1),name,active:true}));for(const p of team.all())if(p.accessRole==='Manager'&&p.managerScope)append(p,'ASSIGN',fromCore(p.managerScope));}
 reset();team.setManagementListener((p,scope)=>append(p,'ASSIGN',fromCore(scope)));
 const authorized=()=>{const actor=team.snapshot().actor;return readMode!=='denied'&&actor.active&&actor.accessRole==='Owner';};
 function selection(value){if(!value||Object.keys(value).sort().join(',')!=='locationIds,mode'||!['COMPANY','LOCATIONS'].includes(value.mode)||!Array.isArray(value.locationIds))return null;const ids=value.locationIds;
  if(value.mode==='COMPANY')return ids.length?null:{mode:'COMPANY',locationIds:[]};
  if(!ids.length||ids.length>100||new Set(ids).size!==ids.length||ids.some(id=>!locations.some(l=>l.id===id&&l.active)))return null;
  return {mode:'LOCATIONS',locationIds:[...ids].sort()};
 }
 function read(id){
  if(!authorized())return {state:'unavailable',reason:'access_denied'};
  if(readMode==='unavailable')return {state:'unavailable',reason:'read_failed'};
  const p=team.get(id);if(!p)return {state:'unavailable',reason:'access_denied'};
  const history=revisions.get(id)||[],r=history.at(-1);let scopeState='UNASSIGNED',scope=null;
  if(r){if(r.roleGeneration!==p.roleGeneration)scopeState='LIFECYCLE_CHANGED';else if(r.action==='REVOKE')scopeState='REVOKED';else{scope=selection(r.scope);if(scope)scopeState='ASSIGNED';}}
  return {state:'ready',current:{employeeId:id,employeeVersion:p.version,role:p.accessRole,active:p.active,roleGeneration:p.roleGeneration,scopeRevision:r?.revision||0,scopeState,scope},locations:copy(locations.filter(l=>l.active)),history:copy(history.slice(-100).reverse()),historyTruncated:history.length>100};
 }
 function prepare(id,action,value,baseline){
  if(!authorized())return {ok:false,reason:'access_denied'};
  if(!baseline||baseline.state!=='ready'||baseline.current.employeeId!==id||baseline.current.role!=='Manager'||!baseline.current.active)return {ok:false,reason:'inapplicable'};
  const scope=action==='ASSIGN'?selection(value):null;if(!['ASSIGN','REVOKE'].includes(action)||action==='ASSIGN'&&!scope||action==='REVOKE'&&!baseline.current.scope)return {ok:false,reason:'invalid',message:'Choose company-wide access or at least one available location.'};
  const c=baseline.current;return {ok:true,command:{operationId:'sample-access-operation-'+(++serial),action,expectedEmployeeVersion:c.employeeVersion,expectedRoleGeneration:c.roleGeneration,expectedScopeRevision:c.scopeRevision,...(action==='ASSIGN'?{scope}:{})}};
 }
 function execute(id,command,scenario='normal'){
  if(!authorized())return {state:'unavailable',reason:'access_denied'};
  if(readMode==='unavailable'||scenario==='unavailable')return {state:'unavailable'};
  if(!command||!command.operationId||!['ASSIGN','REVOKE'].includes(command.action))return {state:'invalid',message:'Review an available management-access change.'};
  const fingerprint=JSON.stringify({id,command}),old=operations.get(command.operationId);
  if(old)return old.fingerprint===fingerprint?{state:'saved',receipt:copy(old.receipt)}:{state:'conflict',reason:'changed_replay'};
  if(scenario==='unknown-before')return {state:'outcome_unknown',operationId:command.operationId};
  const p=team.get(id),r=revisions.get(id)?.at(-1);
  if(!p||p.accessRole!=='Manager'||!p.active||p.version!==command.expectedEmployeeVersion||p.roleGeneration!==command.expectedRoleGeneration)return {state:'conflict',reason:'employee_changed'};
  if((r?.revision||0)!==command.expectedScopeRevision)return {state:'conflict',reason:'scope_changed'};
  const scope=command.action==='ASSIGN'?selection(command.scope):null;
  if(command.action==='ASSIGN'&&!scope)return {state:'invalid',message:'A selected location is no longer available. Review the current locations.'};
  const saved=append(p,command.action,scope),receipt={operationId:command.operationId,employeeId:id,revision:saved.revision,roleGeneration:saved.roleGeneration,committedAt:clock,action:saved.action,scope:copy(scope)};
  operations.set(command.operationId,{fingerprint,receipt});team.syncManagementScope(id,toCore(scope));
  return scenario==='unknown'?{state:'outcome_unknown',operationId:command.operationId}:{state:'saved',receipt:copy(receipt)};
 }
 return {syncLocations:catalog=>{locations=catalog.map(p=>({id:'sample-'+p.id,name:p.key,active:p.active}));},read,prepare,execute,reset,selection,setReadMode:value=>{readMode=value;},setLocationActive:(id,active)=>{const l=locations.find(l=>l.id===id);if(l)l.active=active;},setLocationName:(id,name)=>{const l=locations.find(l=>l.id===id);if(l)l.name=name;},
  snapshot:()=>({operations:[...operations.values()].map(v=>copy(v.receipt)),revisions:copy([...revisions.values()].flat()),locations:copy(locations)}),now:()=>clock,advance:ms=>{clock+=ms;}};
}
