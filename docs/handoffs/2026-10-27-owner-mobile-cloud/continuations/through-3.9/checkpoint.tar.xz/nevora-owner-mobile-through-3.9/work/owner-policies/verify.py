from pathlib import Path
import hashlib,json,subprocess,concurrent.futures,os,datetime
root=Path(__file__).resolve().parents[2];out=root/'outputs/owner-policies';artifact=root/'outputs/nevora-owner-mobile.html'
def sha():return hashlib.sha256(artifact.read_bytes()).hexdigest()
commands=[('source',['python3','work/owner-policies/source-check.py']),('model',['node','--test','work/owner-policies/model-check.cjs']),('focus',['node','work/owner-policies/focus-check.cjs']),('captures',['node','work/owner-policies/capture.cjs'])]+[(e,['node','work/owner-policies/browser-check.cjs','--engine='+e]) for e in ['chromium','firefox','webkit']]
commands += [('review-'+e,['node','work/owner-policies/review-regression.cjs','--engine='+e]) for e in ['chromium','firefox','webkit']]
commands += [('neighbor-model',['node','work/owner-features/model-check.cjs']),('neighbor-browser',['node','work/owner-features/browser-check.cjs','--engine=chromium'])]
def run(item):
 name,cmd=item;before=sha();cwd=root if not name.startswith('neighbor-') else Path('/workspace/nevora-policy-neighbors');env={**os.environ,'NEVORA_WEBKIT_EXECUTABLE':'/workspace/nevora-webkit-libs/run-webkit.sh','NEVORA_REVIEW_REPORT':str(out/(name+'.json'))}
 with (out/('final-'+name+'.log')).open('w') as log:result=subprocess.run(cmd,cwd=cwd,stdout=log,stderr=subprocess.STDOUT,env=env)
 return {'name':name,'command':cmd,'exit':result.returncode,'source_before':before,'source_after':sha(),'log':'outputs/owner-policies/final-'+name+'.log'}
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:records=list(ex.map(run,commands))
r={'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_sha256':sha(),'commands':records,'all_passed':all(v['exit']==0 and v['source_before']==v['source_after']==sha() for v in records)}
(out/'final-verification.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2));raise SystemExit(not r['all_passed'])
