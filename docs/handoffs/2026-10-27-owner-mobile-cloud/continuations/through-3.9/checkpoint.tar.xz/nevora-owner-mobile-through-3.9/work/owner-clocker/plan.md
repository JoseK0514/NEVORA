# Ordered acceptance with parallel construction

1. Snapshot3.7; inspect pinned contracts, freeze interfaces and ownership. Shared store test-first; workers independently inspect/build enrollment, devices, receipts with RED→GREEN.
2. Root integrates existing Settings/Locations/Team/More/direct routes and Timecards returns. Source-correct whole journeys and sensitive-code cleanup before acceptance.
3. Final stable source: focused model/browser across Chromium/Firefox/WebKit, phone320/390/430at100/200, native control/keyboard/focus/layout/contrast and actual images. Affected Location, setup, policy, Team/Timecards and Section3workflow seams as appropriate; copied historical runners preserve originals.
4. One fresh independent whole-pair review; record original grades and exclusions, reproduce/repair material findings once and final-source verify. Accept3.8then3.9separately. Inventory57then59working,39then37remaining,4exclusions if passed; connected Section3gate beforeSection4. No integration/deployment/device certification.
