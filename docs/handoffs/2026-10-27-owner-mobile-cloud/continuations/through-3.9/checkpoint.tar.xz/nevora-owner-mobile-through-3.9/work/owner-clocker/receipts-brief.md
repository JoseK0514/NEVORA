# A-04 saved Clocker receipt lookup

Bounded standalone MOBILE OWNER work, parallel with the explicitly authorized 3.8/3.9 Clocker batch. Continue the accepted focused task header, neutral notices, definition rows, native fields, shared type and 44/48px controls. No real app or service work.

An Owner enters the exact saved tablet reference, checks immutable recorded action evidence, and guides the employee to finish on the same tablet. An empty ledger result is **Not recorded yet**, never proof of cancellation. Time wrong or missing opens the existing Timecards person/period workflow, then returns to this lookup and its exact parent. No reset, new punch, replay, private cached-current receipt, credential, notification or persistence operation is introduced.

Work is limited to new receipt store/view/style files and receipt-prefixed task/evidence records. Root owns build/app/discovery integration. Original source and historical evidence remain preserved.

Checks: meaningful model RED→GREEN; current-read/denied/offline/paused/expired/reference-retirement browser journeys; direct/More/Settings/Team/Timecards returns; keyboard and phone/text reflow; final source hashes recorded with evidence. Real services, physical devices and real screen readers remain outside this standalone evidence.
