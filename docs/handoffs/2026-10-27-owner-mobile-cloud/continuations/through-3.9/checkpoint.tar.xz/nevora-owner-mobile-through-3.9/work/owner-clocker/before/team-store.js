/* Fictional, revisioned Team records. No network, credentials, or persistence. */
function createOwnerTeamStore(seed,locations){
 const copy=x=>JSON.parse(JSON.stringify(x));
 const initialSeed=copy(seed);
 const roles=['Employee','Lead','Manager','Owner'],positions=['Team member','Cashier'];
 const stable={'Marco Ramos':'person-7','Casey Ruiz':'person-8','María Torres':'person-9','Jordan Díaz':'person-10','Chris Vega':'person-11','Morgan Vega':'person-12'};
 let retiredPositions=new Set(),retiredLocations=new Set(),positionsCurrent=()=>true;
 let records=[],actor,serial=12,operationSerial=0,operations=new Map(),managementListener=()=>{};
 function reset(){positions.splice(0,positions.length,'Team member','Cashier');retiredPositions=new Set();retiredLocations=new Set();serial=12;operationSerial=0;operations=new Map();actor={id:'sample-owner',employeeId:'NV-OWNER',firstName:'Jamie',lastName:'Patel',name:'Jamie Patel',phone:'7875550199',email:'jamie.owner@example.com',accessRole:'Owner',loc:locations[0],positions:[],eligibleLocations:[...locations],active:true,status:'active',version:1,roleGeneration:1,initials:'JP',accountState:'Active',onShift:false,tone:''};records=initialSeed.map((p,i)=>{
  const words=p.name.split(' '),id=i<6?'person-'+(i+1):stable[p.name];
  return {...copy(p),id,employeeId:'NV-'+String(1000+Number(id.split('-')[1])),firstName:words.slice(0,-1).join(' '),lastName:words.at(-1),phone:p.name==='Chris Vega'?'':'787555'+String(100+Number(id.split('-')[1])).padStart(4,'0'),email:['Dana Cruz','Chris Vega'].includes(p.name)?'':p.name.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replaceAll(' ','.')+'@example.com',accessRole:i<3?'Lead':p.accessRole,positions:i<3||['Marco Ramos','Casey Ruiz'].includes(p.name)?[...positions]:p.name==='Morgan Vega'?[]:['Team member'],eligibleLocations:[p.loc],active:p.status!=='inactive',version:1,roleGeneration:1,managerScope:p.accessRole==='Manager'?{kind:'locations',locations:[p.loc]}:null,accountState:p.status==='inactive'?'Inactive':p.name==='Taylor López'?'Invited':['Dana Cruz','María Torres'].includes(p.name)?'Not invited':'Active'};
 });}
 reset();
 const find=id=>id===actor.id?actor:records.find(p=>p.id===id);
 const text=value=>String(value??'').trim();
 const needsScope=(p,v)=>v.accessRole==='Manager'&&v.active!==false&&(!p||p.accessRole!=='Manager'||!p.active);
 function normalize(values,kind,current){
  const v=copy(values);
  if(kind==='scheduling')v.loc=current?.loc;
  if(kind!=='scheduling'){
   for(const k of ['firstName','lastName','email','employeeId','loc'])v[k]=text(v[k]);
   v.employeeId=(current?.employeeId||v.employeeId).toUpperCase();
   const digits=text(v.phone).replace(/\D/g,'');v.phone=digits.length===11&&digits[0]==='1'?digits.slice(1):digits;
   v.active=kind==='add'?true:v.active!==false;v.accessRole=v.accessRole||'Employee';
  }
  v.positions=[...new Set(v.positions||[])];v.eligibleLocations=[...new Set([...(v.eligibleLocations||[]),v.loc||current?.loc].filter(Boolean))];
  if(v.managerScope)v.managerScope={kind:v.managerScope.kind,locations:[...new Set(v.managerScope.locations||[])]};
  return v;
 }
 function validate(kind,values,id){
  const p=find(id),v=normalize(values,kind,p),errors={};
  if(!actor.active||actor.accessRole!=='Owner')return {values:v,errors:{_form:'Your Owner access changed. Sign in again before managing employees.'}};
  if(kind!=='add'&&!p)return {values:v,errors:{_form:'This employee is no longer available. Return to Team and open the current profile.'}};
  if(kind!=='scheduling'){
   for(const k of ['firstName','lastName'])if(!v[k]||v[k].length>160||/[\p{Cc}\p{Cf}]/u.test(v[k]))errors[k]='Enter a '+(k==='firstName'?'first':'last')+' name, up to 160 characters.';
   if(!v.employeeId||v.employeeId.length>128||/[\p{Cc}\p{Cf}]/u.test(v.employeeId))errors.employeeId='Enter an employee ID, up to 128 characters.';
   else if([actor,...records].some(x=>x.id!==id&&x.employeeId.toUpperCase()===v.employeeId))errors.employeeId='This employee ID is already in use. Enter a different ID.';
   if(!/^[+\d\s().-]+$/.test(text(values.phone))||!/^\d{10}$/.test(v.phone))errors.phone='Enter a 10-digit phone number. A leading US country code is also accepted.';
   if(v.email&&(v.email.length>254||!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v.email)))errors.email='Enter a valid email address, or leave it blank.';
   else if(v.email&&[actor,...records].some(x=>x.id!==id&&x.email.toLowerCase()===v.email.toLowerCase()))errors.email='This email is already in use. Check the address.';
   if(!roles.includes(v.accessRole))errors.accessRole='Choose an available app role.';
   if(p?.accessRole==='Owner'&&p.active&&(!v.active||v.accessRole!=='Owner')&&[actor,...records].filter(x=>x.active&&x.accessRole==='Owner').length<=1)errors.active='Keep at least one active Owner. Add or promote another Owner before making this change.';
   if(!locations.includes(v.loc)||retiredLocations.has(v.loc)&&p?.loc!==v.loc)errors.loc='Choose an active primary location, or keep the existing location.';
   if(needsScope(p,v)){
    const scope=v.managerScope;
    if(!scope||!['company','locations'].includes(scope.kind)||scope.kind==='locations'&&(!scope.locations.length||scope.locations.some(l=>!locations.includes(l)||retiredLocations.has(l))))errors.managerScope='Choose the locations this Manager can manage.';
   }
  }
  if(kind==='add'||kind==='scheduling'){
   if(!positionsCurrent()&&(kind==='scheduling'||v.positions.length))errors.positions='Current positions are unavailable. Refresh before changing qualifications.';
   if(v.positions.some(x=>!positions.includes(x)||retiredPositions.has(x)&&!p?.positions.includes(x)))errors.positions='A selected position is unavailable. Review the current choices.';
   if(v.eligibleLocations.some(x=>!locations.includes(x)||retiredLocations.has(x)&&!p?.eligibleLocations.includes(x)&&p?.loc!==x))errors.eligibleLocations='A selected location is unavailable. Review the current choices.';
  }
  return {values:v,errors};
 }
 function prepare(kind,values,id=null,version=null){
  const checked=validate(kind,values,id);if(Object.keys(checked.errors).length)return {ok:false,...checked};
  if(kind==='scheduling')return {ok:true,operation:{kind,values:checked.values,employeeId:id,expectedVersion:version}};
  const operation={id:'sample-team-op-'+(++operationSerial),kind,values:checked.values,employeeId:id,expectedVersion:version,status:'prepared'};
  operations.set(operation.id,operation);return {ok:true,operation:copy(operation)};
 }
 function commit(operationId){
  if(operationId&&typeof operationId==='object'&&operationId.kind==='scheduling'){const op=operationId,p=find(op.employeeId);if(!p||p.version!==op.expectedVersion)return {ok:false,code:'conflict'};const v=validate('scheduling',op.values,op.employeeId);if(Object.keys(v.errors).length)return {ok:false,code:'invalid',errors:v.errors};Object.assign(p,{positions:v.values.positions,eligibleLocations:v.values.eligibleLocations,version:p.version+1});return {ok:true,employee:copy(p),updatedVersion:p.version};}
  const op=operations.get(operationId);if(!op)return {ok:false,code:'unavailable',message:'This save cannot be confirmed. Reopen the current employee.'};
  if(op.status==='complete')return {ok:true,replayed:true,employee:copy(find(op.employeeId)),operation:copy(op)};
  const current=find(op.employeeId);
  if(op.kind!=='add'&&(!current||current.version!==op.expectedVersion))return {ok:false,code:'conflict',message:'This employee changed after you opened the form. Your draft is kept. Review the latest profile before saving.'};
  const result=validate(op.kind,op.values,op.employeeId);if(Object.keys(result.errors).length)return {ok:false,code:'validation',...result};
  const v=result.values;const assignsManagement=needsScope(current,v)&&op.kind!=='scheduling';let p;
  if(op.kind==='add'){
   const id='person-'+(++serial);p={id,employeeId:v.employeeId,firstName:v.firstName,lastName:v.lastName,name:v.firstName+' '+v.lastName,phone:v.phone,email:v.email,accessRole:v.accessRole,loc:v.loc,positions:v.positions,eligibleLocations:v.eligibleLocations,active:true,status:'active',onShift:false,initials:(v.firstName[0]+v.lastName[0]).toUpperCase(),tone:'',version:1,roleGeneration:1,managerScope:v.accessRole==='Manager'?v.managerScope:null,accountState:'Not invited'};records.push(p);op.employeeId=id;
  }else if(op.kind==='scheduling'){
   p=current;Object.assign(p,{positions:v.positions,eligibleLocations:[...new Set([...v.eligibleLocations,p.loc])],version:p.version+1});
  }else{
   p=current;if(p.accessRole!==v.accessRole||p.active!==v.active)p.roleGeneration++;const scope=needsScope(current,v)?v.managerScope:v.accessRole==='Manager'?current.managerScope:null;
   Object.assign(p,{firstName:v.firstName,lastName:v.lastName,name:v.firstName+' '+v.lastName,initials:(v.firstName[0]+v.lastName[0]).toUpperCase(),phone:v.phone,email:v.email,loc:v.loc,accessRole:v.accessRole,active:v.active,status:v.active?'active':'inactive',eligibleLocations:[...new Set([...p.eligibleLocations,v.loc])],managerScope:scope,version:p.version+1});
   if(!p.active)p.accountState='Inactive';else if(p.accountState==='Inactive')p.accountState='Sign-in required';
  }
  if(assignsManagement)managementListener(copy(p),copy(p.managerScope));
  op.status='complete';op.savedVersion=p.version;return {ok:true,employee:copy(p),operation:copy(op)};
 }
 return {setManagementListener:fn=>{managementListener=fn;},syncManagementScope:(id,scope)=>{const p=find(id);if(p)p.managerScope=copy(scope);},reset,clear:()=>{records=[];operations=new Map();},roles:[...roles],get positions(){return [...positions];},setPositionsSource:fn=>{positionsCurrent=fn;},positionsAvailable:()=>positionsCurrent(),syncPositions:catalog=>{positions.splice(0,positions.length,...catalog.map(p=>p.key));retiredPositions=new Set(catalog.filter(p=>!p.active).map(p=>p.key));},get locations(){return [...locations];},syncLocations:catalog=>{locations.splice(0,locations.length,...catalog.map(p=>p.key));retiredLocations=new Set(catalog.filter(p=>!p.active).map(p=>p.key));},needsScope:(p,v)=>needsScope(p,v),validate,prepare,commit,
  directory:()=>copy([...records,actor]),isOwner:()=>actor.active&&actor.accessRole==='Owner',searchText:value=>String(value||'').normalize('NFKD').replace(/[\u0300-\u036f]/g,'').toLocaleLowerCase().trim(),ambiguousName:id=>{const p=find(id),key=v=>String(v||'').normalize('NFKD').replace(/[\u0300-\u036f]/g,'').toLocaleLowerCase().trim();return p&&[actor,...records].filter(x=>key(x.name)===key(p.name)).length>1;},catalog:()=>({positions:positions.map(name=>({name,active:!retiredPositions.has(name)})),locations:locations.map(name=>({name,active:!retiredLocations.has(name)}))}),previewRetired:(kind,names)=>{if(kind==='positions')retiredPositions=new Set(names);else retiredLocations=new Set(names);},
  all:()=>copy(records),get:id=>find(id)?copy(find(id)):null,operation:id=>operations.has(id)?copy(operations.get(id)):null,
  snapshot:()=>copy({actor,people:records,operations:[...operations.values()]}),
  bumpVersion:id=>{const p=find(id);if(p)p.version++;}
 };
}
