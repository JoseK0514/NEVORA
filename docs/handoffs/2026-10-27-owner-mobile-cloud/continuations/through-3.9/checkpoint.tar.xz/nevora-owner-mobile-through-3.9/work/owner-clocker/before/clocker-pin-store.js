/* Fictional PIN setup metadata. Private checksums support sample uniqueness only. */
function createOwnerClockerPinStore(team){
 let pins,mode,saves,identities,epoch;
 const copy=x=>JSON.parse(JSON.stringify(x));
 function reset(){epoch=(epoch||0)+1;mode='ready';saves=[];identities=new Map([['person-1',2]]);pins=new Map([['person-1',{version:2,checksum:'ce44e96ecfd0004515dd4a73f52b742e680ea8410952f513b28472aae600cc3f'}]]);}
 reset();
 const admission=()=>{const actor=team.snapshot().actor;return mode!=='denied'&&actor.active&&actor.accessRole==='Owner';};
 function read(id){if(!admission())return {state:'unavailable',reason:'access_denied'};if(mode==='unavailable')return {state:'unavailable',reason:'read_failed'};const p=team.get(id);if(!p)return {state:'unavailable',reason:'access_denied'};if(!p.active)return {state:'inactive'};const r=pins.get(id);return {state:'ready',employeeId:id,configured:!!r,version:r?.version||0};}
 function validate(pin,confirm){if(typeof pin!=='string'||!/^[0-9]{4}$/.test(pin))return {ok:false,field:'pin',message:'Enter exactly four digits.'};if(typeof confirm!=='string'||pin!==confirm)return {ok:false,field:'confirm',message:'Enter the same four digits in both fields.'};return {ok:true};}
 async function save(id,input,scenario='normal'){
  if(!admission())return {state:'denied'};
  const valid=validate(input?.pin,input?.confirm);if(!valid.ok)return {state:'invalid',...valid};
  if(!Number.isSafeInteger(input.expectedVersion)||input.expectedVersion<0)return {state:'stale'};
  if(mode==='unavailable'||scenario==='unavailable')return {state:'unavailable'};
  const token=epoch,expected=input.expectedVersion;
  const checksum=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(input.pin))),b=>b.toString(16).padStart(2,'0')).join('');
  if(token!==epoch)return {state:'cancelled'};
  const current=read(id);if(current.state!=='ready')return {state:current.reason==='read_failed'?'unavailable':'denied'};
  if(current.version!==expected||scenario==='stale')return {state:'stale'};
  if(scenario==='duplicate'||[...pins.entries()].some(([other,r])=>other!==id&&r.checksum===checksum))return {state:'invalid',field:'pin',message:'This PIN is unavailable. Choose a different PIN.'};
  if(scenario==='unknown-before')return {state:'unknown'};
  const version=current.version+1;pins.set(id,{version,checksum});identities.set(id,0);saves.push({employeeId:id,version});
  if(scenario==='denied-after'){mode='denied';return {state:'denied'};}
  if(scenario==='unknown')return {state:'unknown'};
  return {state:'saved',version};
 }
 return {read,validate,save,reset,admitted:admission,setReadMode:value=>{mode=value;},
  snapshot:()=>({pins:[...pins].map(([employeeId,p])=>({employeeId,configured:true,version:p.version})),saves:copy(saves),tabletIdentities:[...identities].map(([employeeId,count])=>({employeeId,count}))}),
  previewIdentity:(id,count)=>identities.set(id,count)};
}
