"""Cumulative standalone continuation through3.9; original handoff is preserved."""
from pathlib import Path
import json,hashlib,tarfile,subprocess
r=Path(__file__).resolve().parents[2];h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
roots=['work/owner-mobile','work/owner-policies','work/owner-setup','work/owner-clocker','outputs/owner-policies','outputs/owner-setup','outputs/owner-clocker','outputs/nevora-owner-mobile.html','outputs/owner-mobile-current-coverage.json','outputs/owner-mobile-delivery-plan.md','outputs/owner-mobile-delivery-plan.json','outputs/owner-mobile-quality-gates.md','outputs/owner-mobile-remaining.md','CURRENT-STATE.md','ACTIVE-BATCH.md','AGENTS.md','START-HERE.md','NEXT-BATCH-3.6.md','NEXT-BATCH-3.7.md','NEXT-BATCH-3.8.md','NEXT-BATCH-4.1.md','CONTINUATION-PROMPT-3.9.md','DESIGN.md','CONVERSATION-CONTEXT.md','WORKING-AGREEMENTS.md']
archive=Path('/workspace/shared/downloads/nevora-owner-mobile-through-3.9.tar.xz');assert not archive.exists();files=[]
for name in roots:
 p=r/name;assert p.exists();files.extend([p] if p.is_file() else [v for v in p.rglob('*') if v.is_file() and '__pycache__' not in v.parts])
manifest=r/'outputs/owner-clocker/source-evidence-manifest.json';files=[p for p in sorted(set(files)) if p!=manifest];records=[{'path':str(p.relative_to(r)),'bytes':p.stat().st_size,'sha256':h(p)} for p in files]
manifest.write_text(json.dumps({'batch':'through3.9','artifact_sha256':h(r/'outputs/nevora-owner-mobile.html'),'base_original_artifact_sha256':'65f2a5d5cbb596f90a2d08adb2fca30c869e1142e8325e9d25f23326e70d1c64','previous_accepted3.7_sha256':'eb46b93e000698263da10213df2a482fcd318a05c0993363564d96738ebf47e9','reference_commit':'46e202786863279302026ee03a0e225c359fa55c','scope':'Cumulative standalone MOBILE OWNER continuation3.6–3.9. Overlay onto a validated copy of immutable original3.5handoff OUTSIDE applicationcheckout. No real app/services/data/messages/tabletactivation/merge/deployment. Originalmanifest remains historical.','files':records},indent=2))
archive.parent.mkdir(exist_ok=True,parents=True);prefix='nevora-owner-mobile-through-3.9'
with tarfile.open(archive,'w:xz') as t:
 for p in files+[manifest]:t.add(p,arcname=prefix+'/'+str(p.relative_to(r)))
problems=[]
with tarfile.open(archive,'r:xz') as t:
 for v in records:
  data=t.extractfile(prefix+'/'+v['path']).read()
  if len(data)!=v['bytes'] or hashlib.sha256(data).hexdigest()!=v['sha256']:problems.append(v['path'])
result={'archive':str(archive),'archive_sha256':h(archive),'archive_bytes':archive.stat().st_size,'archive_root':prefix,'files_verified':len(records),'problems':problems,'artifact_sha256':h(r/'outputs/nevora-owner-mobile.html'),'manifest':'outputs/owner-clocker/source-evidence-manifest.json'};Path('/workspace/shared/downloads/nevora-owner-mobile-through-3.9-validation.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2));assert not problems
