/* Source-defined two-check projection; no operational writes. */
function evaluateOwnerSetupFacts(facts){
 try{
  const {locations,rules,people,targets}=facts;
  if(!Array.isArray(locations)||!Array.isArray(people)||!rules||!targets)throw Error();
  const activeLocations=locations.filter(l=>l.active),coverage=[],missing=new Map();
  const validTime=t=>typeof t==='string'&&/^(?:[01]\d|2[0-3]):[0-5]\d$/.test(t);
  for(const l of activeLocations){
   const r=rules[l.key];if(!r||!Array.isArray(r.periods))throw Error();
   if(r.minimum!=null&&(!Number.isInteger(r.minimum)||r.minimum<1||r.minimum>100)||r.lead!=null&&typeof r.lead!=='boolean')throw Error();
   if(r.periods.some(p=>!Number.isInteger(p.day)||p.day<0||p.day>6||!validTime(p.start)||!validTime(p.end)&&p.end!=='24:00'||p.start>=p.end||p.minimum!=null&&(!Number.isInteger(p.minimum)||p.minimum<1||p.minimum>100)))throw Error();
   const needs=[r.minimum==null?'Minimum staff':null,r.lead==null?'Lead rule':null,!r.periods.length?'Coverage period':null].filter(Boolean);
   if(needs.length)coverage.push({id:l.id,key:l.key,name:l.name,needs});
  }
  for(const p of people.filter(p=>p.active!==false)){
   const target=targets[p.id];
   if(target!=null&&(typeof target!=='number'||!Number.isFinite(target)||target<0||target>168))throw Error();
   if(target==null)missing.set(p.id,{id:p.id,name:p.name});
  }
  const steps={coverageOpen:!activeLocations.length||coverage.length>0,missingTargets:missing.size};
  return {state:'ready',steps,done:(steps.coverageOpen?0:1)+(steps.missingTargets?0:1),locationCount:activeLocations.length,coverage,activePeopleIds:[...new Set(people.filter(p=>p.active!==false).map(p=>p.id))],locations,people:[...missing.values()]};
 }catch{return {state:'unavailable'};}
}
function createOwnerSetupStore(api){
 let mode='ready',sources={coverage:'ready',hours:'ready'};
 const gate=()=>api.gate()==='denied'||mode==='denied'?'denied':api.gate()!=='ready'||mode!=='ready'?'unavailable':'ready';
 const authority=()=>api.authority();
 function read(){
  const access=gate();if(access!=='ready')return {state:access};
  if(Object.values(sources).some(v=>v!=='ready'))return {state:'unavailable'};
  const locations=api.locations(),hours=api.hours();
  if(!locations||hours.state!=='ready'||hours.sources.hours!=='ready')return {state:hours.reason==='access_denied'?'denied':'unavailable'};
  const model=api.schedule(),r=evaluateOwnerSetupFacts({locations,rules:model.rules,people:hours.people.map(p=>({...p,active:true})),targets:model.targets});
  return r.state==='ready'?{...r,authority:authority(),observedAt:new Date(api.now()).toISOString(),validForMs:45000}:r;
 }
 return {read,gate,authority,now:api.now,reset:()=>{mode='ready';sources={coverage:'ready',hours:'ready'};},previewReadMode:v=>{mode=v;},previewSource:(k,v)=>{sources[k]=v;}};
}
