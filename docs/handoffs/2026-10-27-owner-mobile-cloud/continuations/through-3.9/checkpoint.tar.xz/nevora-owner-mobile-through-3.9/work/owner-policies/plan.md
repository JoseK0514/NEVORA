# Bounded implementation plan

1. Preserve baseline, source contracts and Cloud runtime identity. Inspect baseline browser.
2. RED model cases: snapshot/private preservation, all modes, strict validation, DST, revision selection, replay/conflict/unknown and current authority. Implement local store with source parsers.
3. RED browser journey: Settings and More entry, scoped focused editing, reviewed save, history and return. Implement owning policy view/CSS, minimal app/company navigation wiring.
4. Verify exceptional journeys and neighbors: failed reads, authority cleanup, inactive/no locations, replacement and conflict, known/unknown save, pause/offline, native fields, long text, keyboard, 320/390/430px at100/200%, review canvas, contrast. Preserve failed evidence; resolve material findings.
5. One fresh whole-slice independent review under executing-plans skill; grade by actual effect, repair material findings with RED→GREEN, final-source recheck. Update C-08/C-09 only when passed. Preserve new source/evidence manifest. Next3.7 remains ordered behind this gate.

Pre-flight shared interfaces: source parser→store uses validated full snapshots; store→view exposes private Owner-only history, no public projection; view→app uses catalogAPI parent context and navigation guards; location/company→store supplies current authority, stable catalog and zone. No incompatible contracts found. Source protocol binds all decisions.
