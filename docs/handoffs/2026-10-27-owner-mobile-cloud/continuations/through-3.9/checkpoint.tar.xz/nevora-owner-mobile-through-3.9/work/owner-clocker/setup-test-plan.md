# Owner Clocker setup verification plan

Write behavior assertions against the real pure helper before implementation, then preserve the expected missing-feature failure under `outputs/owner-clocker/setup-red-*`. After implementing, preserve `setup-green-*` separately. Tests do not require or invoke operational services.

Pure-render checks target real failures: wrong field contract or omitted native constraints; offering inactive locations; losing a draft after validation; escaping failures in names, options, summaries or code; controls enabled during a pending write; clipped/incomplete code markup; showing code at/after expiry; code leakage in hidden/expired states; and falsely claiming that issuing/hiding a code connects/revokes a device. Use literal fixtures and independently specified assertions. Do not assert incidental formatting or snapshot the entire helper.

After root integration on local port 18763, `setup-browser-check.cjs` will exercise:

1. Settings entry → add → native validation → current name/location → pending → sample code → copy success/fallback → hide → exact parent/device return.
2. No active location → existing Locations path and return; location change/active-state loss before submit.
3. Known failure, unknown write and stale result: no duplicate submit; refresh current state before retry; no reconstructed/lost token.
4. Protected-code cleanup on hide, expiry, navigation, blur, hidden document, offline, pagehide, reset and access end, including pending callback/lifecycle races.
5. Full code wraps with no horizontal overflow at 320/390/430px, 100/200% text; long device/location names; form/validation/header clearance; native keyboard order, visible focus, complete labels and copy fallback selection.
6. Honest sample wording and absence of nonlocal operational requests or browser errors. Root owns broader Location/Team/Settings/setup/device/receipt neighbor checks and section walkthrough.

Each browser run records current artifact SHA-256, engine, checks, page errors/network observations and capture paths under `outputs/owner-clocker/setup-*`. Browser runner is prepared without changing generated artifact. Browser assertions must adapt to the frozen interface, not weaken the intended behavior.
