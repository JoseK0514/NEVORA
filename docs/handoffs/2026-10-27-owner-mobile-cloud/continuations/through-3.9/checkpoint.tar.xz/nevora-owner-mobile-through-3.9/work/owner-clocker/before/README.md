> Current continuation record (October27): 3.5 Features and words is complete on `65f2a5d5cbb596f90a2d08adb2fca30c869e1142e8325e9d25f23326e70d1c64`; see `work/owner-features/handoff.md` and `outputs/owner-features/review.md`. Next3.6 Company/location operational policies/history. Earlier hashes and next-step paragraphs below are historical phase records, not the current starting point. Full current inventory/roadmap: `outputs/owner-mobile-current-coverage.json` and `outputs/owner-mobile-delivery-plan.md`.

# Canonical owner mobile mockup

Edit `template.html`, `styles.css`, `schedule.css`, `team.css`, `invitations.css`, `manager-access.css`, `clocker-pin.css`, `account-recovery.css`, `operational-rules.css`, `timecards.css`, `corrections.css`, `schedule.js`, `team-store.js`, `invitation-store.js`, `manager-access-store.js`, `clocker-pin-store.js`, `account-recovery-store.js`, `operational-rules-store.js`, `team.js`, `invitations.js`, `manager-access.js`, `clocker-pin.js`, `account-recovery.js`, `operational-rules.js`, `timecards-store.js`, `timecard-actions-store.js`, `timecard-actions.js`, `timecard-actions.css`, `timecards.js`, `corrections-store.js`, `corrections.js` and `app.js` here. From the workspace root, run `python3 work/owner-mobile/build.py` to produce `outputs/nevora-owner-mobile.html`. The build joins the canonical stylesheets and loads the Schedule factory, Team/invitation/Manager-access stores and views before app wiring. Earlier `build_mockup.py` and `refine_v2.py` are historical and must not overwrite this source.

The current deliverable extends the approved teal/system-font/Phosphor direction with foundation corrections and connected fictional Schedule workflows. Its scope is `work/schedule-mobile/brief.md`; design records are root `DESIGN.md`, `.impeccable/design.json` and `.21st/design.json`. The pre-existing `.21st/DESIGN.md` unknown-source snapshot is preserved, not regenerated. Other Owner workflows remain previews; no full Owner parity, real authorization, backend integration, notifications or durable persistence is claimed.

Current verification entry points from the workspace root:

- `python3 work/schedule-mobile/verify-source.py`: canonical embedding and source checks.
- `node work/schedule-mobile/module-check.cjs`: fictional Schedule model scenarios.
- `node work/schedule-mobile/foundation-check.cjs --engine=chromium`: foundation browser scenarios; also supports `webkit` and `firefox`.
- `node work/schedule-mobile/critical-check.cjs --engine=chromium`: critical Schedule browser scenarios; also supports `webkit` and `firefox`.

Inspect runner configuration before execution and serve the workspace at the runner's expected local URL. These commands describe the available checks, not a claim that this documentation pass ran them. Current final review: `outputs/schedule-review-results.md`. Older `outputs/review-results.md`, `outputs/browser-checks.json` and `work/approved-refinement/` runners describe the historical V3 stage; they are not current Schedule acceptance evidence.

Frozen artifact recorded for this handoff: `outputs/nevora-owner-mobile.html`, SHA-256 `5c52f30136facbc25872e5ccd50c7815a9468d910133c106b52f6b11fde24bf7`. This documentation refresh changes no build or UI source and supplies no independent UI, accessibility or production certification.

## Later Team profile/Add/Edit phase

The historical Schedule-stage hash above stays frozen. Current Team scope and evidence: `work/owner-team/brief.md` and `outputs/owner-team-review.md`. Team store checks: `node work/owner-team/store-check.cjs`; browser cases: `node work/owner-team/browser-check.cjs --engine=chromium` (also webkit/firefox).

`createOwnerTeamStore` owns revisioned sample identity and separate core/scheduling commands. `createOwnerTeam` owns rendering and navigation. `syncTeamRecords` and public scheduler `syncPeople(records)` bridge current metadata without resetting shifts/publications/templates/targets/exclusions. New weekly hours remain unset. Internal person-1… IDs preserve scheduler identity; immutable displayed NV-… employee IDs are illustrative. Real integration must reuse actual source employee IDs and server commands, not install this simulation store.

The fixture's first three designated shift leads now carry Lead app roles, resolving its earlier mismatch with source lead-capability rules. Existing shift assignments remain unchanged. The current Owner actor is an explicit separate sample fixture for last-active-Owner validation, not an inferred real company account. All contact addresses/numbers remain fictional. Invitation delivery, session revocation, protected reads and server authorization are not verified by prototype tests.


Owner invitations continue the Team profile through one Account access row and focused full-page status/review/results. Sources and boundaries: `work/owner-invitations/source-contract.md`, `brief.md`; final scoped report: `outputs/owner-invitations-review.md`. The invitation model never creates a usable activation link, token or credential and makes no delivery request. Pending/unknown actions retain their original operation; non-denied read failure preserves a saved receipt. Invitations remain distinct from employee activity and credential activation.

Invitation verification: `node work/owner-invitations/model-check.cjs`; `node work/owner-invitations/browser-check.cjs --engine=chromium` (also webkit/firefox); `node work/owner-invitations/capture.cjs` for current invitation deliverables. Canonical `build.py` is the only build entry point.


## Later Owner Manager access phase

One Manager access row is added to Manager profiles only. Full-page current/choice/review/result flows use existing Team and invitation primitives; history is progressive disclosure. The source contract and boundaries are in `work/owner-manager-access/source-contract.md` and `brief.md`; exact evidence is recorded in `outputs/owner-manager-access-review.md`. `manager-access-store.js` owns independent scope revisions and original-command replay, with a small Team lifecycle listener for atomic promotion/reactivation and a distinct roleGeneration counter. Scope-only saves leave employee version, invitation validity and work eligibility unchanged. `manager-access.js` renders the screens, and `manager-access.css` scopes radio choices and enlarged-text wrapping. This simulation is not a live authorization layer.

Manager checks: `node work/owner-manager-access/model-check.cjs`, `node work/owner-manager-access/reset-regression.cjs`, and `node work/owner-manager-access/browser-check.cjs --engine=chromium` (also webkit/firefox). Capture with `node work/owner-manager-access/capture.cjs`. Team reset now uses an immutable original seed rather than the synchronized live directory, so completed core role changes do not survive Reset sample.


## Later Owner Clocker PIN phase

Clocker PIN now uses the same profile and More entry points, full-page setup/review/masked-entry/result flow, and source-supported Set/Reset only. Read the contract in `work/owner-clocker-pin/source-contract.md` and scope in `brief.md`; exact final evidence is `outputs/owner-clocker-pin-review.md`. `clocker-pin-store.js` models PIN metadata/version, local company-uniqueness comparison and fictional tablet-identity invalidation. Its private SHA256 checksums are only sample comparison data and are not authentication or production PIN storage. `clocker-pin.js` keeps digits out of retained UI state/public snapshots, clears fields before save, and requires a fresh read after uncertain/stale/unavailable outcomes. There is no operation UUID/replayable receipt/automatic retry, existing-PIN reveal, generation, send, revoke/delete, unlock or PIN history. Source also supports restricted Company-scope Managers; this mockup remains Owner-only.

Checks: `node work/owner-clocker-pin/model-check.cjs`, `node work/owner-clocker-pin/browser-check.cjs --engine=chromium` (also webkit/firefox). Capture with `node work/owner-clocker-pin/capture.cjs`. New masked fields use existing form roles; measured sticky-header clearance is scoped to this form. Account recovery and actual application integration remain separate work.


## Later Owner account recovery phase

One Account access row and the existing More/Team tools entry open the same stable-person flow: verify identity → review the full attestation and replacement consequence → issue an unmistakably invalid display sample → private handoff guidance. Account setup goes to invitations; active credentialed other people are eligible, including another Owner, while self is forbidden. Credential truth is shared with the fictional invitation model through a read-only local getter, not a new service endpoint.

`account-recovery-store.js` models issuance,15-minute expiry from each issuance, replacement and ambiguous outcomes only. `account-recovery.js` owns transient verification/code lifetime, generation guards, focus and navigation; `account-recovery.css` reuses the current form/identity/review roles. Hiding/preparing another code clears display but does not retire the prior proof. A successful fresh issue retires earlier unused proofs. There is no assisted status endpoint, operation identity, replay, receipt history, email delivery, clipboard write, password form or completion confirmation. Unknown outcomes require another identity check and an explicit fresh issue. Employee completion effects are explained but never performed here.

Source: `work/owner-account-recovery/source-contract.md`; scope: `brief.md`; final evidence: `outputs/owner-account-recovery-review.md`. Checks: `node work/owner-account-recovery/model-check.cjs`, `node work/owner-account-recovery/browser-check.cjs --engine=chromium` (also webkit/firefox). Captures: `node work/owner-account-recovery/capture.cjs`. Earlier reports and initial findings stay frozen. Real credentials, sessions, API/DB, delivery and production remain untouched.


## Owner Team audit and gap closure

Jose approved the source-backed Team coverage audit before Timecards. Current scope and outcome: `outputs/owner-team-audit.md`; checks: `outputs/owner-team-audit-checks.json`; current row-by-row coverage: `outputs/owner-team-audit-coverage.json`. Older coverage/review records remain historical.

The directory now includes the current Owner alongside employee records, folds accents with NFKD, bounds search to128 characters and shows immutable IDs when names are ambiguous. The shared PIN picker also disambiguates duplicates. Team Add/Edit measures sticky-header clearance for summaries and complete labels; Team search has one explicit clear action. Source catalog previews retain existing inactive qualifications/locations while withholding new inactive references. A person’s weekly-hour link opens their exact existing Schedule target section. Generic Profile→Schedule remains source-correct.

Per-employee `operational-rules-store.js`/`operational-rules.js`/`operational-rules.css` add the missing T-05 Owner review. All five settings save atomically with an independent CAS revision; Unknown/Reviewed not applicable/Configured and explicit minute/basis/window/paid/routing values follow the source contract. Existing settings are required: opening the review never inserts a settings row or weekly maximum. Unknown/conflict preserves submitted entries neutrally and requires a current read, with no operation receipt or automatic replay. This models the Team review interaction, not full scheduling enforcement or legal certification.

Qualifications save now uses the source’s version-only acknowledgement and has no invented operation ID/lookup. Core Add/Edit keeps its separate original-operation receipt. Unknown qualifications and rule entries never claim rollback; confirmed original core receipt clears its retained draft. New PIN/recovery requests are held while a core employee save is pending so completion cannot replace another task. A confirmed self-lifecycle change keeps its acknowledgement and then withholds further Team management.

Tests: `node work/owner-team-audit/rules-model-check.cjs` and `node work/owner-team-audit/browser-check.cjs --engine=chromium` (also webkit/firefox); capture with `node work/owner-team-audit/capture.cjs`. Source matrix/contracts, initial RED results and independent layered UI/UX evidence are retained under `work/owner-team-audit/` and `.omo/evidence/owner-team-audit-*/`. Actual app/auth/API/DB/message/device/production remain untouched. Attendance, weekly Team overview and saved Clocker clock-action receipt are explicitly adjacent future surfaces, not completed by this audit.

## Owner mobile Timecards P-01

Current bounded continuation: company-wide overview and full-page employee review inside More. Home also opens the task. Current/last/custom inclusive1–31day periods, same-length previous/next, source All/Need review/Approved predicates, accent-insensitive local name/ID search, complete recorded entries/breaks/corrections, captured historical revisions and context-preserving Back are implemented with fictional data. Current Owner and inactive people remain included. Dates and canonical Inbox `#timecard-<encodedId>` links follow the source contract; invalid initial dates fall back with an explicit notice. No-time grouping is an intentional mobile presentation adaptation, and matching searches/blocking exceptions stay directly visible.

Canonical additions: timecards-store.js, timecards.js, timecards.css. Source contract and staging: work/owner-timecards/. Checks: model-check.cjs, browser-check.cjs (--engine=chromium/webkit/firefox), final-checks.py. User handoff: outputs/owner-timecards-review.md. Each report carries its own artifact hash; earlier reports stay historical.

The local projection uses the fixed fictional America/Puerto_Rico workspace, millisecond-derived nanoseconds, elapsed clipping, separately reported breaks and source issue predicates. It is not the production arbitrary IANA/DST projection/DTO validator. Recorded time includes breaks and is not payroll hours. UI clears private visible time on leaving/background/offline/expiry/failure, resumes through a fresh local read and preserves reading context during normal refresh. These simulations do not establish real authorization or privacy enforcement.

Next bounded work is correction decisions and timecard approval/finalize/reopen review. None is a live command in P-01. Actual application remains read-only; no branch, commit, API/database integration, message, real time/pay mutation or deployment.

## Owner mobile correction review continuation

The next bounded slice implements Company-wide pending correction requests, three-way recorded/current/requested comparison, reason and bounded prior decisions, one-decision confirmation with an optional single-line note, known outcomes and same-command recovery. It reuses existing Team/Timecards controls and visual roles. Entry from Timecards uses correction request identity; Manager DTO employeeName is never a join key. The separate pending queue is not filtered by global location or selected Timecard period.

Canonical additions are corrections-store.js, corrections.js and corrections.css, with narrow app/Timecards integration. Timecards owns immutable raw facts and effective sample projection; the correction model owns pending requests, events and operation replay through a narrow correctionDomain bridge. Normal approve/decline updates fictional effective source/status only; raw punches and captured timecard history stay unchanged. Decline is permitted independently of approval-only stale/live/overlap/finalized checks. Corrected timecards still require separate review/approval.

The prior Dana pending example is now a source-valid missing morning shift, separate from her open afternoon entry. Baseline8h last-week clipping remains; approval adds4h while retaining her missing-clock-out issue. Alex supplies closed-entry and completed-break requests. These are fictional source relations, not actual employee IDs or operational commands. Model is fixed to the existing Puerto Rico sample zone, not a production DTO/Temporal/SQL/authorization implementation.

Privacy pause clears names, reason, intervals, note and private result. Only fixed nonidentifying saved/unknown feedback survives. An unresolved exact command remains in memory within the actor/session/scope partition; fresh ready authority permits explicit same-command POST simulation even after its request vanished. There is no receipt-lookup endpoint, automatic retry, durable storage, notification, Undo or Timecard approve/finalize/reopen command. Denied/replaced authority and Reset clear recovery.

Scope/contracts/runners/evidence: work/owner-corrections/. Checks: model-check.cjs, browser-check.cjs (--engine=chromium/webkit/firefox), final-checks.py; capture.cjs saves current actual screenshots under outputs/owner-corrections/. User handoff: outputs/owner-corrections-review.md and checks JSON. Prior reports/hashes stay historical. Global DESIGN.md/.impeccable/.21st design authority is preserved because no system change was requested. Next: actual Timecard approval/finalization/reopening review, then batching/export. Actual application remains read-only and no production action is pending.

### User-requested correction refinement

After functional verification, Jose requested cleaner, more premium presentation. The bounded refinement reuses19px clock/14px caption roles and the same native panels/disclosures. Comparisons show a shared workday once when all intervals have that day; overnight/different-day values retain full date context. Queue Clock times and For labels separate work date from oldest-request order. Confirmation reduces duplicate labels and tucks the optional note into the existing disclosure. Saved receipts use a quiet inline status with Phosphor check-circle. No new global design tokens/world or model behavior was introduced.

The native note disclosure synchronously captures its live open state before refresh replaces DOM, ignores detached toggle events, and preserves intentional collapse independently of note text. Blank/entered text, input/summary focus, validation auto-open and privacy resets have dedicated browser regressions. Before-refinement verified source/reports/images are preserved in work/owner-corrections/verified-before-refinement/. Current scoped report: outputs/owner-corrections-review.md. Latest model source is unchanged from that206-case verification; final38-case correction browser suite plus all Owner regressions runs on the current frozen artifact.


## Owner mobile section 1: timecard decisions

The approved four batches now extend existing Timecards: individual approval, separate finalization, reasoned reopening and reviewed batch approval/finalization. Canonical additions: timecard-actions-store.js (fictional command/authority/replay/partial-result model), timecard-actions.js (focused full-page selection/review/results), timecard-actions.css (incumbent roles). The existing Timecards store exposes a narrow lifecycle bridge, while corrections retain their own decision domain and original punches. build.py embeds these modules before timecards.js.

Read work/owner-timecard-decisions/brief.md, source-contract.md and plan.md; current report outputs/timecard-decisions/review.md. Verification: node work/owner-timecard-decisions/model-check.cjs; node work/owner-timecard-decisions/browser-check.cjs --engine=chromium (also webkit/firefox); regression runners under work/owner-timecard-decisions/regression/; python3 work/owner-timecard-decisions/final-checks.py. Capture: node work/owner-timecard-decisions/capture.cjs. Final checks require all current reports/captures first, and reject mismatched source hashes.

Batch browsing is separate from the ordinary list. Each person commits independently; first non-success stops remaining submissions. Unknown recovery sends only the original command after a fresh same-authority read. Reopen acknowledges a frozen finalized source even if live metadata changed, retains history and requires a new approval/finalization cycle. This is not a payroll or export action. Failed reads/Back cannot reveal earlier captured private reviews; denied/replaced authority clears recovery. Healthy refresh preserves reason/input focus and disclosed evidence.

The independent initial review found a HIGH private-view defect. Its original BLOCK report remains historical; the executor repaired the boundary and added denied/error regressions. No independent post-fix certification, actual API/database/session/permission enforcement, phone hardware testing, messages, money movement or deployment is claimed.

## Owner mobile section 2.1: attendance

Attendance now opens from Team Tools and the stable Home/Inbox missing-clock-in sample. New attendance-store.js/attendance.js/attendance.css separate Today published-shift missing clock-ins from recorded-time comparisons with saved historical schedule/break context. Details retain exact employee/record/date identity, company-wide corrections, phone-gated preview contact and meaningful origin/filter/location/focus return. The operational stores and global design system remain unchanged.

Read work/owner-attendance/brief.md, source-contract.md and plan.md; final report outputs/owner-attendance/review.md. Reproduce with model-check.cjs; browser-check.cjs --engine=chromium (also firefox/webkit); six regression/*-check.cjs runners in each engine; capture.cjs; then python3 work/owner-attendance/final-checks.py. The latter requires all final source-bound reports/captures, rejects mismatches, and regenerates source.diff.522 browser cases,20 attendance model cases and8 source checks passed on the report's final artifact.26 actual screenshots are retained with hashes.

The original reviewer found two MEDIUM URL/focus defects; executor repair and strengthened regressions pass all engines, without independent post-fix certification. Current observation lifetime is at most45s; privacy pause/access/expiry clears private evidence/contact previews, healthy refresh preserves meaningful context, and failed/partial data never becomes all-clear. No real call/text, clock/time write, API/DB integration or deployment occurs. Fixed Puerto Rico fixtures are not a production service implementation.

A-01/I-02 are bounded mockup-complete. Full Home/Inbox populations/counts and section2.2 Availability/weekly Team remain next work. Actual app checkout remains read-only; this prototype workspace has no Git branch/commit.

## Owner mobile section 2.2: Availability and weekly Team

Section2.2 supersedes the next-work note above. Team Tools and Inbox tools now open a complete weekly Availability review; Schedule tools/disclosure carry their selected week. Team overview exposes active all-role population, Employee/Lead submission denominator, planned company-wide hours/current targets and focused missing/outside-target filters. Stable profile/settings/Schedule handoffs preserve meaningful week/person/scope/filter/query/scroll/focus and reload behavior. No Manager/Employee UI or new availability/settings writer is introduced.

New canonical workforce-store.js/workforce.js/workforce.css consume existing Team identity and Schedule snapshot. Other changed implementation files are app.js/schedule.js/team.js/build.py only. Existing operational stores, styles and template remain unchanged. Rebuild with python3 work/owner-mobile/build.py. Scope/source contract/plan/ledger/runners and preserved failures are under work/owner-weekly-team/. Current user report outputs/owner-weekly-team/review.md; source-bound checks/provenance/diff are alongside it.

Commands: node work/owner-weekly-team/model-check.cjs; node work/owner-weekly-team/browser-check.cjs --engine=chromium (also firefox/webkit); seven regression/*-check.cjs runners for all3 engines; node work/owner-weekly-team/capture.cjs; python3 work/owner-weekly-team/final-checks.py. Final source bf5825e3bbdb168e62589fe19fef3671ae782dbe9f7252df43c398df1942491c:600 browser cases,20 model cases,8 source checks passed;28 actual captures. The final checker rejects source/image/report mismatches.

Original fresh reviewer WATCH found3MEDIUM unknown/route issues. Executor observed RED and repaired those plus related deadline/picker/Schedule-root paths in one combined batch; final regressions pass. Original report retained, no independent post-fix certification. Fixed-wait caution was addressed by observable waits and awaited in-flight reads. These simulations do not certify actual SQL/RSC/server authority, mobile devices or assistive technology.

H-04/R-01 are now bounded working mockup groups; coverage35 working/61 remaining-partial/4 excluded. Full Home/Inbox triage stays pending. Next is2.3 time-off decisions/decided-request history, not started. Actual app remains clean/read-only at46e202786863279302026ee03a0e225c359fa55c. No branch/commit, real delivery, customer-data operation, API/database integration or deployment occurred.

## Owner mobile section 2.3: time-off decisions and history

Section2.3 supersedes the next-work note above. Inbox Tools/More → Time off now has company-wide Waiting/Approved/Declined lists, stable search, full/partial-day detail, employee notes, exact scheduled-overlap disclosure, deliberate pending-only decisions, known results and read-only decision history. The represented Home/Inbox María sample routes to this domain; the legacy swap remains its separate preview. Full Home/Inbox populations/counts remain2.6.

New canonical timeoff-store.js/timeoff.js/timeoff.css consume Team identities and the existing Schedule snapshot. Narrow changes: app.js/build.py/schedule.js/team.js. Operational stores and existing styles/template remain unchanged. The actual writer's contract is requestId/status under current company authority, with one terminal transition; no invented operation ID, revision token, replay receipt endpoint, Undo, reviewer note, payroll/balance behavior or notification transport is added. Unknown outcomes require current reads, never automatic resubmission or false saved attribution.

Time-off approval does not mutate assignments. A narrow approved-interval callback constrains new Schedule assignments by actual full/partial interval and replaces pending María's contradictory legacy hardcoded approved day. Source-unavailable comparison is not zero overlaps. Employee/Schedule/deep-link/root returns preserve exact request/day/week/scope/filter/query/focus; direct origin intent survives reload. Profile-only return to Team directory does not reset stores or editing forms.

Read work/owner-timeoff/brief.md, source-contract.md, plan.md and ledger.md. User report outputs/owner-timeoff/review.md; final checks/provenance/diff alongside. Commands: node work/owner-timeoff/model-check.cjs; node work/owner-timeoff/browser-check.cjs --engine=chromium (also firefox/webkit); eight regression/*-check.cjs runners per engine; node work/owner-timeoff/capture.cjs; python3 work/owner-timeoff/final-checks.py. The checker rejects any report/capture source mismatch. Final report records696 browser cases,22 model cases,8 source checks and30 captures against df3c3ed2a27890ed807c4554b08d1bbc6a60efc87f88f26494fc1b9997660d42.

Original fresh reviewer WATCH found3MEDIUM recovery/scope/route issues, reproduced RED and repaired in one combined executor pass with expanded32-case focused suite. Original report and failures retained; no independent post-fix certification. This is a fixed-Oct26 Puerto Rico local simulation, not actual API/SQL/RSC/outbox/server-authority/mobile-device verification. Actual app checkout remains read-only/clean at46e202786863279302026ee03a0e225c359fa55c; no branch/commit, real message/customer-data operation, service spend, integration or deployment.

R-02/R-03 are bounded working mockup slices. Current coverage37 working/59 remaining-partial/4 Owner exclusions. Next2.4 shift swaps and coverage pickups has not begun.

## Section2.4 mobile Owner exchanges — completed Oct27

New exchanges-store.js/exchanges.js/exchanges.css; narrow app/build/Team/Schedule seams. Waiting/Done, original both-shift facts/accepted pickup, current simulated eligibility, revision-bound explicit approve/decline, synchronous local atomic assignment bridge, actor-scoped original-operation receipts, distinct changed/blocked/unavailable/unknown and known-save-with-failed-followup recovery. People links disclosed; exact profile/Schedule/origin/date/scope/filter/query/scroll/focus/reload return. Private state/acknowledgement clears on lifecycle/authority/expiry loss. No old generic swap Undo path is reachable.

Read work/owner-exchanges/{brief,source-contract,plan,ledger,handoff}.md. Report outputs/owner-exchanges/review.md; final774 browser/20model/8source checks/30captures at7de54c2bae8258320e12beb02357e058d997fd8d250850460238aa5cac85db80. Original independent ITERATE2P2 reproduced RED and executor-repaired in one pass; original report/resolution retained, no post-fix independent approval. Local evaluation response fixtures are not a full production rules engine. Only R-04/2.4 advanced; next2.5 callouts and closing coverage, then2.6 complete triage. Actual app clean/read-only, no data/messages/branch/commit/integration/deployment.

## Section2.5 mobile Owner callouts / coverage closure — completed Oct27

Unified Waiting/Open cover/Done extends exchanges-store/exchanges/exchanges.css. Narrow app parent-route serialization; Schedule exact material/assignment-episode release and replacement; weekly Team/timeoff projection excludes released work. Callout approve/decline, linked coverage, distinct voluntary/absence-preserving close, current/historical applicability, expiration and original-operation receipt/recovery. Note-only edits preserve approval; A→B→A cannot inherit it. Missing source blocks new commands after prior receipt lookup. Parent direct return survives relation/profile/Schedule/reload. No extra reason editor, reviewer note, Undo, actual notification or new root.

Read work/owner-callouts/{brief,source-contract,plan,ledger,handoff}.md; user report outputs/owner-callouts/review.md. Final846browser/44model/8source checks/31captures atbc7a9a2e15c84657e036b724b7077db0ced9b76084ca5bb4c4f9e584d864db70. Original independent ITERATE2P2 retained; one executor repair with RED→GREEN, no independent post-fix approval. Only R-05/R-06/2.5 advanced;40working/56remaining/4excluded. Next2.6 full Home/Inbox source populations/counts/handoffs. Actual source clean/read-only; no data/messages/branch/commit/integration/deployment.

## Section2.6 Home/Inbox and Daily Operations gate — completed Oct27

New triage-store.js/triage.js/triage.css aggregate existing sources, count current work, separate scheduled from clocked-in staffing, and connect exact reviews/returns. Narrow seams in app/build/Schedule/Attendance/workforce/timeoff/exchanges/timecards/corrections. Clear date and time is an unsaved deadline-field action; existing Save remains explicit. Other operational stores and template/global tokens stay unchanged.

Report outputs/owner-triage/review.md; spec/plan/ledger/runners under work/owner-triage. Build only with python3 work/owner-mobile/build.py. Final-source8checks,139models,942browser scenarios across3engines,26captures; sourced32fa1dd14a40c0e13b554eb0a784293e74891dbabef6caff18c98ea9aec53e6. Original fresh ITERATE and RED reports preserved; one executor repair, no independent post-fix certification. Section2 gate complete in local prototype;44working/52remaining/4excluded groups. Next3.1 Company details/settings navigation. Actual source read-only; no transport, integration or deployment.


## Section3.1 Company details and Settings navigation — completed Oct27

company-store.js/company.js/company.css extend the accepted mobile Owner system through the canonical build. More opens full-page Settings, grouped Company/Scheduling/conditionalPay; Company details has name/time-zone/Monday read/edit/save. Source-current lock and omitted-zone semantics; no invented expectedRevision or receipt contract. Later child editors remain truthful navigation previews. App/build seams add route, shell identity and central dirty/pending/unknown navigation protection.

Report outputs/owner-company/review.md; spec/source/plan/ledger/tests under work/owner-company. Final SHA 56826d5667d09bf2d42032e481438772e373a7bac802d40c554bde7facfc1a09;354 browser/18 model/8 source checks;27 captures. Original fresh BLOCK found6material defects; all reproduced/repaired/executor-rechecked in one pass, no post-fix independent certification. C01/C02/3.1 complete locally;46working/50remaining/4excluded. OverallSection3 in progress; next3.2Locations. Actual app read-only, no branch/commit/integration/deployment.


## Section3.2 Locations — completed Oct27

locations-store.js/locations.js/locations.css implement current directory/readiness, add/edit, timestamp CAS, protected permanent key, deliberate deactivate/reactivate and honest uncertain recovery. Narrow Company/app/Team/Schedule/Manager adapters use stable operational keys and mutable display labels. Settings counts active records; directory includes inactive. Related staffing context/draft/commit ownership is guarded; generated inactive work is preserved during active rebuild.

Evidence outputs/owner-locations/review.md; brief/source/plan/ledger/runners work/owner-locations. Finalbd5ae763be6493f3f5d08d101fad53e585f8188a36c93ec49ce98eb35ded2b97;501browser/40model/8source checks,34captures. Original fresh BLOCK retained; five blockers reproduced/repaired/executor-rechecked plus late detached-event correction, no second independent certification. C03/C04/C05/3.2 complete locally;49working/47remaining/4excluded. OverallSection3 in progress; next3.3Positions/break types. Actual app read-only; no real data/messages, branch/commit/integration/deployment.
