/* Owner-only device administration. The shared store owns every device mutation. */
function createOwnerClockerDevices(api,store) {
 const E=api.escapeHTML,I=api.icon,$=api.$,clone=v=>JSON.parse(JSON.stringify(v));
 const active=()=>api.page()==='clocker',setupStates=['UNREGISTERED','PENDING','EXPIRED'];
 const labels={ACTIVE:'Registered',PENDING:'Awaiting setup',EXPIRED:'Setup expired',UNREGISTERED:'Needs setup',REVOKED:'Revoked'};
 const button=(label,action,secondary=false,extra='')=>`<button type="button" class="btn${secondary?' secondary':''}" data-clocker-action="${action}" ${extra}>${label}</button>`;
 let payload=null,connection='loading',bound=null,expires=0,epoch=0,command=0,timer=null,busy=false;
 let view='list',selected=null,draft=null,baseline=null,errors={},guard=null,unknown=false,attempted=null,checked=false,conflict=false,reviewOperation=null,confirmed='';
 let setup=null,setupDevice=null,scenario='normal',query='',filter='active',scopeLocation='',listScroll=0;
 let origin={location:0,parent:'settings',query:'',feature:'clocker',scroll:0};
 const current=()=>payload?.devices.find(d=>d.id===selected),place=d=>payload?.locations.find(l=>l.id===d?.locationId);
 const dirty=()=>!!draft&&(view==='add'?!!draft.name||!!draft.locationId&&draft.locationId!==scopeLocation:draft.name!==(baseline?.name??''));
 const focusKey=e=>e?.id?'#'+CSS.escape(e.id):e?.dataset?.clockerAction?'[data-clocker-action="'+CSS.escape(e.dataset.clockerAction)+'"]':null;
 function focus(selector='h1') {
  const el=$('#home-content '+selector);if(!el)return;
  if(!el.matches('button,input,textarea,select'))el.tabIndex=-1;el.focus({preventScroll:true});
  const scroll=api.scroll();if(el.closest('.cd-nav')){scroll.scrollTop=0;return;}
  const field=el.closest('.form-field'),target=field||el,rect=target.getBoundingClientRect(),bounds=scroll.getBoundingClientRect(),header=$('.cd-nav')?.getBoundingClientRect().height||0,top=bounds.top+header+20,bottom=bounds.bottom-16;
  if(field||!el.matches('button,input,textarea,select')||rect.top<top)scroll.scrollTop+=rect.top-top;
  else if(rect.bottom>bottom)scroll.scrollTop+=rect.bottom-bottom;
 }
 function route() {
  const u=new URL(location.href);u.search='';u.hash='';
  const values={page:'clocker',location:origin.location,coq:origin.query,cofeature:origin.feature,coparent:origin.parent,cdview:view,cdid:selected||'',cdq:query,cdfilter:filter,cdloc:scopeLocation,cdscroll:origin.scroll||0};
  if(origin.locationReturn)values.cdreturn=JSON.stringify(origin.locationReturn);
  for(const [key,value]of Object.entries(values))u.searchParams.set(key,String(value));history.replaceState(null,'',u);
 }
 function clearCode(next) {setup=null;setupDevice=null;if(next&&['code','code-hidden','code-expired'].includes(view))view=next;}
 function clear() {payload=null;draft=null;baseline=null;errors={};guard=null;unknown=false;attempted=null;checked=false;conflict=false;reviewOperation=null;confirmed='';busy=false;clearCode();}
 function lose() {epoch++;command++;clearTimeout(timer);clear();bound=null;connection='denied';view='list';selected=null;query='';route();render();}
 function pause(state='paused') {
  epoch++;command++;clearTimeout(timer);if(busy)unknown=true;busy=false;payload=null;clearCode('code-hidden');connection=state;render();
 }
 function valid() {
  if(bound&&bound!==store.authority()||store.gate()==='denied'){lose();return false;}
  if(connection!=='ready'||!payload)return false;
  if(store.gate()!=='ready'){pause('unavailable');return false;}
  if(!navigator.onLine){pause('offline');return false;}
  if(store.now()>=expires){pause('expired');return false;}
  if(setup&&Date.parse(setup.expiresAt)<=store.now()){clearCode('code-expired');route();render();return false;}
  return true;
 }
 function measure() {
  if(!active())return;const head=$('.cd-nav');if(head)$('#home-content').style.setProperty('--cd-header-height',head.getBoundingClientRect().height+'px');
  for(const selector of ['#clocker-name','#clocker-setup-code']){const el=$(selector);if(el&&el.tagName==='TEXTAREA'){el.style.height='auto';el.style.height=Math.max(48,el.scrollHeight+2)+'px';}}
 }
 function frame(title,body,action='') {
  const parent=origin.locationReturn?'Location':origin.parent==='more'?'More':'Settings';
  const back=view==='list'?'Back to '+parent:['rename','rotate','revoke','conflict','code','code-hidden','code-expired'].includes(view)?'Back to device':'Back to devices';
  $('#home-content').innerHTML=`<div class="tm-page-nav tm-task-nav cd-nav"><button type="button" class="icon-button" data-clocker-action="back" aria-label="${back}" ${busy?'disabled':''}>${I('arrow-left')}</button><h1>${E(title)}</h1>${action}</div><div class="root-body tm-body cd-body" aria-busy="${connection==='loading'||busy}">${body}</div>`;
  api.header();measure();
 }
 const footer=()=>'<p class="co-footer">Sample Clocker devices · changes reset on reload</p>';
 const saved=()=>confirmed?`<section id="clocker-saved" class="co-saved" role="status">${I('check-circle')}<p>${E(confirmed)}</p></section>`:'';
 const errorSummary=()=>Object.keys(errors).length?`<section id="clocker-errors" class="tm-errors" role="alert" tabindex="-1"><h2>Check these details</h2>${Object.entries(errors).map(([field,text])=>`<p>${['name','locationId'].includes(field)?`<button type="button" class="cd-error-link" data-clocker-field="${field}">${E(text)}</button>`:E(text)}</p>`).join('')}</section>`:'';
 function unavailable() {
  const states={loading:['Loading Clocker devices','Checking current access and device details.'],paused:['Clocker devices paused','Private setup code was hidden. Refresh current details to continue.'],offline:['You’re offline','Private setup code was hidden. Reconnect, then refresh devices.'],expired:['Refresh device details','The previous observation is no longer current. Private setup code was hidden.'],denied:['Owner access ended','Only an active Owner with current access may manage Clocker devices.'],unavailable:['Devices unavailable','Current device details couldn’t be loaded. Refresh before making changes.']};
  const [heading,text]=states[connection]||states.unavailable;
  frame('Clocker devices',`${confirmed?'<section id="clocker-confirmed-unavailable" class="co-source" role="status"><h2>Update confirmed</h2><p>'+E(confirmed)+' Current details could not be loaded.</p></section>':''}<section id="clocker-state" class="empty cd-state" role="status"><h2>${heading}</h2><p>${text}</p>${connection==='loading'?'<div class="skeleton tall" aria-hidden="true"></div>':button('Refresh devices','refresh',true)}</section>${footer()}`);
 }
 function date(value) {if(!value)return 'Not used yet';return new Intl.DateTimeFormat('en-US',{timeZone:payload?.timeZone||'America/Puerto_Rico',month:'short',day:'numeric',hour:'numeric',minute:'2-digit'}).format(new Date(value));}
 function facts(device) {
  const location=place(device),state=labels[device.state]||'Unavailable';
  return `<dl class="tm-panel cd-facts"><div class="tm-detail"><dt>Device</dt><dd>${E(device.name)}</dd></div><div class="tm-detail"><dt>Location</dt><dd>${E(location?.name||'Location unavailable')}${location?.active===false?' · Inactive':''}</dd></div><div class="tm-detail"><dt>Status</dt><dd>${state}${device.state==='PENDING'&&device.enrollmentExpiresAt?' · code expires '+E(date(device.enrollmentExpiresAt)):''}</dd></div><div class="tm-detail"><dt>Last used</dt><dd>${E(date(device.lastSeenAt))}</dd></div><div class="tm-detail"><dt>Device ID</dt><dd class="cd-id">${E(device.id)}</dd></div></dl>`;
 }
 const checkedNotice=()=>checked?`<section id="clocker-checked" class="co-source" role="status"><h2>Current devices checked</h2><p>The earlier ${attempted?.operation==='REGISTER'?'addition':'update'} was not confirmed. Current details do not prove that it completed.${['REGISTER','ROTATE'].includes(attempted?.operation)?' Its private setup code cannot be recovered. Review the device before creating a new code.':''}</p></section>`:'';
 function directory() {
  const all=payload.devices,scoped=all.filter(d=>!scopeLocation||d.locationId===scopeLocation);
  const matches=d=>filter==='active'?d.state==='ACTIVE':filter==='setup'?setupStates.includes(d.state):d.state==='REVOKED';
  const rows=scoped.filter(d=>matches(d)&&`${d.name} ${place(d)?.name||''} ${d.id}`.toLocaleLowerCase().includes(query.trim().toLocaleLowerCase()));
  const counts={active:scoped.filter(d=>d.state==='ACTIVE').length,setup:scoped.filter(d=>setupStates.includes(d.state)).length,revoked:scoped.filter(d=>d.state==='REVOKED').length};
  const activeLocations=payload.locations.filter(l=>l.active);
  frame('Clocker devices',`${saved()}${checkedNotice()}<p class="cd-intro">Manage the shared tablets your team uses to clock in and out.</p>${!activeLocations.length?`<section class="co-source cd-state" id="clocker-no-location"><h2>No active location</h2><p>Add or reactivate a location before creating a tablet setup code.</p>${button('Go to Locations','go-locations',true)}</section>`:''}<label class="sr-only" for="clocker-search">Search devices</label><div class="search-field">${I('magnifying-glass')}<input type="search" id="clocker-search" placeholder="Device or location" autocomplete="off" value="${E(query)}"></div><div class="cd-filters"><div class="form-field"><label for="clocker-filter">Show devices</label><select id="clocker-filter">${[['active','Active'],['setup','Needs setup'],['revoked','Removed']].map(([key,label])=>`<option value="${key}" ${filter===key?'selected':''}>${label} · ${counts[key]}</option>`).join('')}</select></div><div class="form-field"><label for="clocker-location-filter">Location</label><select id="clocker-location-filter"><option value="">All locations</option>${payload.locations.map(l=>`<option value="${E(l.id)}" ${scopeLocation===l.id?'selected':''}>${E(l.name)}${!l.active?' · Inactive':''}</option>`).join('')}</select>${scopeLocation?'<p class="tm-help">'+E(payload.locations.find(l=>l.id===scopeLocation)?.name||'Location unavailable')+'</p>':''}</div></div><div id="clocker-results" aria-live="polite"><p class="cd-caption">${rows.length} ${rows.length===1?'device':'devices'} shown</p>${rows.length?`<div class="co-list">${rows.map(d=>`<button type="button" class="cd-row" id="clocker-row-${E(d.id)}" data-clocker-id="${E(d.id)}"><span><strong>${E(d.name)}</strong><small>${E(place(d)?.name||'Location unavailable')} · ${place(d)?.active===false?'Location inactive':labels[d.state]}${d.state==='ACTIVE'?' · '+E(date(d.lastSeenAt)):''}</small></span>${I('caret-right','chevron')}</button>`).join('')}</div>`:`<section class="empty cd-state"><h2>${!all.length?'No devices yet':query?'No matching devices':filter==='active'?'No active devices':filter==='setup'?'Nothing needs setup':'No removed devices'}</h2><p>${!all.length?'Add the shared tablet at each active location.':query?'Try another device name or location.':'Choose another status to see your other devices.'}</p>${query?button('Clear search','clear-search',true):!all.length?button('Add device','add',false,!activeLocations.length?'disabled':''):''}</section>`}</div>${checked&&draft&&attempted?.operation==='REGISTER'?button('Review retained addition','resume-add',true):''}${footer()}`,`<button type="button" class="btn secondary compact" data-clocker-action="add" ${!activeLocations.length?'disabled':''}>${I('plus')}<span>Add</span></button>`);
 }
 function missing() {frame('Clocker device',`<section class="empty cd-state"><h2>Device unavailable</h2><p>This device is no longer available in the current workspace.</p>${button('View devices','directory',true)}</section>${footer()}`);}
 function detail() {
  const device=current();if(!device)return missing();const location=place(device),rotateLabel=device.state==='ACTIVE'?'Replace tablet':device.state==='REVOKED'?'Reconnect tablet':'New setup code';
  frame('Clocker device',`${saved()}${checkedNotice()}${facts(device)}<section class="cd-section"><h2>Shared tablet access</h2><p>${device.state==='ACTIVE'?'This tablet is registered. Replacing it stops its current access immediately.':device.state==='REVOKED'?'This tablet has no current access. Reconnect it with a new setup code.':'A setup code does not mean the tablet is registered. Finish setup on the shared tablet.'}</p>${location?.active===false?'<p>This location is inactive. Rename and Revoke remain available; reactivate the location before creating a new code.</p>':''}</section><div class="tm-review-actions">${button(rotateLabel,'rotate',false,!location?.active?'disabled':'')}${device.state!=='REVOKED'?button('Revoke access','revoke',true):''}</div>${checked&&draft&&attempted?.operation==='RENAME'?button('Review retained name','resume-rename',true):''}${footer()}`,`<button type="button" class="btn secondary compact" data-clocker-action="rename">Rename</button>`);
 }
 function rename() {
  const device=current();if(!device)return missing();
  frame('Rename device',`${errorSummary()}${facts(device)}<form id="clocker-rename-form" novalidate><fieldset class="cd-fields" ${busy?'disabled':''}><div class="form-field"><label for="clocker-name">Device name</label><textarea id="clocker-name" name="name" rows="1" autocomplete="off" maxlength="160" aria-describedby="clocker-name-help${errors.name?' clocker-name-error':''}" ${errors.name?'aria-invalid="true"':''}>${E(draft?.name||'')}</textarea><p id="clocker-name-help" class="tm-help">Use 1–80 printable characters. The new name shows in this list only.</p>${errors.name?'<p id="clocker-name-error" class="co-field-error">'+E(errors.name)+'</p>':''}</div><div class="tm-review-actions"><button type="submit" class="btn" data-clocker-action="save-name" ${busy||!dirty()?'disabled':''}>${busy?'Saving…':'Save name'}</button>${button('Cancel','cancel',true,busy?'disabled':'')}</div></fieldset><p role="status" class="sr-only">${busy?'Saving name…':''}</p></form>${footer()}`);
 }
 function accessReview() {
  const device=current();if(!device)return missing();const revoking=view==='revoke';
  frame(revoking?'Revoke access?':'Create new code?',`${errorSummary()}${facts(device)}<section class="co-source cd-consequence"><h2>${revoking?'This tablet loses access right away':'Replace its current access'}</h2><p>${revoking?'This tablet loses access right away. Existing punches and time records are kept.':'Any old setup code and tablet access stop right away. This device’s identity, location and time records stay the same. The new code expires in ten minutes.'}</p></section><div class="tm-review-actions">${button(busy?'Saving…':revoking?'Revoke access':'Create new code',revoking?'confirm-revoke':'confirm-rotate',false,busy?'disabled':'')}${button('Cancel','cancel',true,busy?'disabled':'')}</div>${footer()}`);
 }
 function conflictView() {const device=current();frame('Device changed',`<section id="clocker-conflict" class="co-source" role="status"><h2>Review current details</h2><p>The earlier change was not saved. This device changed while you were reviewing.${draft?' Your entered name is kept.':''}</p></section>${device?facts(device):'<p>This device is no longer available.</p>'}${draft?'<section class="co-source"><h2>Retained name</h2><p>'+E(draft.name)+'</p></section>':''}<div class="tm-review-actions">${device?button('Review again','review-current'):''}${button('Use current details','use-current',true)}</div>${footer()}`);}
 function uncertainty() {frame('Check current devices',`<section id="clocker-unknown" class="co-source" role="status"><h2>Update not confirmed</h2><p>The earlier change may have completed. Refresh devices before making another change. Your ordinary entries are kept; a lost private code cannot be recovered.</p></section>${button('Check current devices','check')}${footer()}`);}
 function guardView() {frame('Unsaved changes',`<section id="clocker-leave" class="co-source"><h2>${unknown?'Update not confirmed':'Keep your entries?'}</h2><p>${unknown?'The earlier update may have completed. Leaving clears the retained entries in this preview.':'Your device entries have not been saved.'}</p></section><div class="tm-review-actions">${button('Keep editing','keep')}${button('Discard entries','discard',true)}</div>${footer()}`);}
 function enrollment() {
  const device=current(),result=renderOwnerClockerEnrollment({view,draft:draft||{},errors,device,setup,busy,locations:payload.locations,now:store.now(),escapeHTML:E,icon:I});
  frame(result.title,result.body+footer());return result.focus;
 }
 function render() {
  if(!active())return;if(bound&&bound!==store.authority())return lose();
  if(guard)return guardView();if(connection!=='ready'||!payload)return unavailable();
  if(unknown)return uncertainty();if(view==='conflict')return conflictView();
  if(view==='list')return directory();if(view==='detail')return detail();if(view==='rename')return rename();if(view==='rotate'||view==='revoke')return accessReview();
  if(['add','code','code-hidden','code-expired'].includes(view))return enrollment();return missing();
 }
 async function refresh({check=false}={}) {
  if(!active())return;if(bound&&bound!==store.authority())return lose();if(!navigator.onLine)return pause('offline');if(document.visibilityState==='hidden')return pause();
  const g=++epoch,key=store.authority(),oldFocus=focusKey(document.activeElement),scroll=api.scroll().scrollTop;
  clearCode('code-hidden');payload=null;connection='loading';render();await new Promise(resolve=>setTimeout(resolve,120));
  if(g!==epoch||!active())return;if(key!==store.authority())return lose();if(!navigator.onLine)return pause('offline');if(document.visibilityState==='hidden')return pause();
  const result=store.read();if(result.state==='denied')return lose();if(result.state!=='ready'){connection='unavailable';render();return;}
  payload=result;bound=key;connection='ready';expires=store.now()+result.validForMs;
  if(view==='add'&&!draft)draft={name:'',locationId:payload.locations.some(l=>l.id===scopeLocation&&l.active)?scopeLocation:''};
  if(check&&unknown){unknown=false;checked=true;conflict=false;baseline=null;view=attempted?.operation==='REGISTER'?'list':'detail';if(attempted?.operation==='REGISTER')filter='setup';route();}
  if(baseline&&current()&&current().version!==baseline.version&&['rename','rotate','revoke'].includes(view)){reviewOperation=view;view='conflict';conflict=true;route();}
  if(['code-hidden','code-expired'].includes(view)&&!current())view='detail';
  render();api.scroll().scrollTop=scroll;if(oldFocus&&$(oldFocus))$(oldFocus).focus({preventScroll:true});
  clearTimeout(timer);timer=setTimeout(tick,result.validForMs);
 }
 function renewObservation() {
  const key=bound,prior=payload,result=store.read();
  if(key!==store.authority()||result.state==='denied')return lose();
  if(result.state!=='ready')return pause('unavailable');
  const before=document.activeElement,selector=focusKey(before),selection=before&&'selectionStart'in before?[before.selectionStart,before.selectionEnd]:null,scroll=api.scroll().scrollTop;
  payload=result;expires=store.now()+result.validForMs;let changed=JSON.stringify([prior?.devices,prior?.locations,prior?.timeZone])!==JSON.stringify([result.devices,result.locations,result.timeZone]);
  if(setup){const device=result.devices.find(d=>d.id===setupDevice?.id),location=result.locations.find(l=>l.id===device?.locationId);if(!device||device.version!==setupDevice.version||device.state!=='PENDING'||device.enrollmentExpiresAt!==setup.expiresAt||!location?.active){clearCode('code-hidden');changed=true;}}
  if(baseline&&current()&&current().version!==baseline.version&&['rename','rotate','revoke'].includes(view)){reviewOperation=view;view='conflict';conflict=true;changed=true;}
  if(changed){route();render();api.scroll().scrollTop=scroll;if(view==='conflict')focus('#clocker-conflict');else if(selector&&$(selector)){const el=$(selector);el.focus({preventScroll:true});if(selection&&el.setSelectionRange)try{el.setSelectionRange(...selection);}catch{}}}
  clearTimeout(timer);timer=setTimeout(tick,result.validForMs);
 }
 function tick() {
  if(!active())return false;if(bound&&bound!==store.authority()||store.gate()==='denied'){lose();return false;}
  if(setup&&Date.parse(setup.expiresAt)<=store.now()){clearCode('code-expired');route();render();}
  if(payload&&store.gate()!=='ready'){pause('unavailable');return false;}
  if(payload&&!busy&&!guard&&!unknown&&navigator.onLine&&document.visibilityState==='visible'&&document.hasFocus()&&store.now()>=expires-15000)renewObservation();
  return valid();
 }
 function start(next,id=selected,{retained=false}={}) {
  if(!valid()||unknown||busy)return;clearCode();errors={};confirmed='';conflict=false;checked=false;
  selected=next==='add'?null:id;if(next!=='add'&&!current())return missing();view=next;baseline=next==='add'?null:clone(current());
  if(next==='add')draft=retained&&draft?draft:{name:'',locationId:payload.locations.some(l=>l.id===scopeLocation&&l.active)?scopeLocation:''};
  else if(next==='rename')draft=retained&&draft?draft:{name:baseline.name};else draft=null;
  route();render();focus(next==='add'||next==='rename'?'#clocker-name':next==='rotate'||next==='revoke'?'[data-clocker-action=cancel]':'h1');
 }
 async function save(operation) {
  if(busy||unknown||!valid()||conflict)return;
  const creating=operation==='REGISTER',input=creating?{operation,name:draft?.name||'',locationId:draft?.locationId||''}:{operation,deviceId:selected,expectedVersion:baseline?.version,...(operation==='RENAME'?{name:draft?.name||''}:{})};
  const checkedInput=store.validate(input);if(!checkedInput.ok){errors=checkedInput.errors;render();focus('#clocker-errors');return;}
  const key=bound,n=++command,mode=scenario;scenario='normal';attempted={...input};checked=false;busy=true;errors={};confirmed='';render();
  const result=store.execute(input,mode,key);await new Promise(resolve=>setTimeout(resolve,200));
  if(n!==command||!active())return;if(key!==store.authority())return lose();busy=false;
  if(result.state==='denied')return lose();
  if(result.state==='confirmed') {
   selected=result.device.id;draft=null;baseline=null;unknown=false;conflict=false;
   confirmed=operation==='RENAME'?'Device name updated.':operation==='REVOKE'?'Access revoked. Existing time records are kept.':'Setup code created. Finish on the shared tablet.';
   const fresh=store.read();payload=fresh.state==='ready'?fresh:null;connection=payload?'ready':'unavailable';expires=store.now()+45000;
   if(result.setup&&payload){setup={...result.setup};setupDevice=clone(result.device);view='code';}else{clearCode();view='detail';}
   route();render();focus(view==='code'?'#clocker-code-title':payload?'#clocker-saved':'#clocker-confirmed-unavailable');return;
  }
  if(result.state==='unconfirmed'){unknown=true;clearCode();route();render();focus('#clocker-unknown');return;}
  if(result.state==='conflict'){reviewOperation=view;conflict=true;view='conflict';await refresh();focus('#clocker-conflict');return;}
  if(result.state==='unavailable'){pause('unavailable');return;}
  errors=result.errors||{form:result.error||'This change was not saved. Your entries are kept.'};render();focus('#clocker-errors');
 }
 function backTarget() {return view==='list'?{kind:'parent'}:['add','detail'].includes(view)?{kind:'list'}:{kind:'detail',id:selected};}
 async function finish(target) {
  clearCode();draft=null;baseline=null;guard=null;errors={};checked=false;conflict=false;confirmed='';unknown=false;attempted=null;
  if(target.kind==='parent')return api.parent(origin);
  if(target.kind==='root'){if(api.root)return api.root(target.page);return api.navigate(target.page);}
  view=target.kind==='detail'?'detail':'list';if(target.id)selected=target.id;route();await refresh();
  if(view==='list'){api.scroll().scrollTop=listScroll;focus(selected&&$('#clocker-row-'+CSS.escape(selected))?'#clocker-row-'+CSS.escape(selected):'h1');}else focus('[data-clocker-action=rename]');
 }
 function leave(target) {if(busy)return;if(dirty()||unknown){clearCode('code-hidden');guard=target;render();focus();return;}void finish(target);}
 function open(context={}) {
  epoch++;command++;clearTimeout(timer);clear();origin={...api.origin(),...context};query=context.queryList||'';filter=['active','setup','revoked'].includes(context.filter)?context.filter:'active';scopeLocation=context.locationId||'';selected=context.id||null;
  view=['list','detail','rename','add','rotate','revoke'].includes(context.view)?context.view:'list';connection='loading';bound=null;api.navigate('clocker');route();void refresh().then(()=>{if(!active()||connection!=='ready')return;if(['rename','rotate','revoke'].includes(view)&&current()){baseline=clone(current());if(view==='rename')draft={name:baseline.name};render();}focus(view==='add'||view==='rename'?'#clocker-name':view==='rotate'||view==='revoke'?'[data-clocker-action=cancel]':'h1');});
 }
 async function copyCode() {
  if(!valid()||!setup||Date.parse(setup.expiresAt)<=store.now())return;const code=setup.code,key=bound,n=command;
  try{await navigator.clipboard.writeText(code);if(active()&&setup?.code===code&&key===store.authority()&&n===command){setup.copyMessage='Setup code copied.';render();focus('[data-clocker-action=copy-code]');}}
  catch{if(active()&&setup?.code===code&&key===store.authority()){setup.copyMessage='Select and copy the sample setup code.';render();focus('#clocker-setup-code');$('#clocker-setup-code')?.select();}}
 }
 function updateSaveButton(){const el=$('[data-clocker-action=save-name]');if(el)el.disabled=busy||!dirty();measure();}
 document.addEventListener('input',event=>{if(!active())return;const el=event.target;if(el.id==='clocker-search'){query=el.value;route();render();$('#clocker-search')?.focus({preventScroll:true});return;}if(el.id==='clocker-name'&&draft){draft.name=el.value;updateSaveButton();}});
 document.addEventListener('change',event=>{if(!active())return;const el=event.target;if(el.id==='clocker-location'&&draft){draft.locationId=el.value;const location=payload?.locations.find(l=>l.id===el.value),help=$('#clocker-location-help');if(help)help.textContent=(location?'Selected: '+location.name+'. ':'')+'The location stays with this device.';return;}if(el.id==='clocker-filter'||el.id==='clocker-location-filter'){if(unknown||!valid())return;if(el.id==='clocker-filter')filter=el.value;else scopeLocation=el.value;route();render();$('#'+el.id)?.focus({preventScroll:true});}});
 document.addEventListener('keydown',event=>{if(active()&&event.target.id==='clocker-name'&&event.key==='Enter'&&!event.isComposing){event.preventDefault();event.target.form?.requestSubmit();}},true);
 document.addEventListener('submit',event=>{if(!active()||!['clocker-add-form','clocker-rename-form'].includes(event.target.id))return;event.preventDefault();event.stopImmediatePropagation();void save(event.target.id==='clocker-add-form'?'REGISTER':'RENAME');},true);
 document.addEventListener('click',event=>{
  if(!active())return;const el=event.target.closest('button');if(!el||el.disabled)return;
  if(el.dataset.clockerField){event.preventDefault();event.stopImmediatePropagation();focus(el.dataset.clockerField==='name'?'#clocker-name':'#clocker-location');return;}
  if(!el.dataset.clockerAction&&!el.dataset.clockerId)return;const action=el.dataset.clockerAction;if(action==='save-name')return;
  event.preventDefault();event.stopImmediatePropagation();if(busy)return;
  if(el.dataset.clockerId){if(unknown)return;listScroll=api.scroll().scrollTop;return start('detail',el.dataset.clockerId);}
  if(action==='back'||action==='cancel'||action==='cancel-add')return leave(backTarget());
  if(action==='directory')return leave({kind:'list'});if(action==='back-device')return leave({kind:'detail',id:selected});
  if(action==='keep'){guard=null;render();focus(view==='add'||view==='rename'?'#clocker-name':'h1');return;}
  if(action==='discard')return void finish(guard);if(action==='refresh')return void refresh();if(action==='check')return void refresh({check:true});
  if(action==='hide-code'){clearCode('code-hidden');route();render();focus('#clocker-code-state');return;}
  if(action==='copy-code')return void copyCode();
  if(action==='go-locations'){if(!valid()||unknown)return;clearCode();return api.openLocations({...origin,clockerReturn:{view,id:selected,queryList:query,filter,locationId:scopeLocation}});}
  if(action==='clear-search'){query='';route();render();focus('#clocker-search');return;}
  if(unknown||!valid())return;
  if(action==='add')return start('add');if(action==='rename')return start('rename');if(action==='rotate')return start('rotate');if(action==='revoke')return start('revoke');
  if(action==='confirm-rotate')return void save('ROTATE');if(action==='confirm-revoke')return void save('REVOKE');
  if(action==='resume-add')return start('add',null,{retained:true});if(action==='resume-rename')return start('rename',selected,{retained:true});
  if(action==='use-current')return void finish({kind:'detail',id:selected});
  if(action==='review-current'){const next=reviewOperation||'detail';conflict=false;return start(next,selected,{retained:true});}
 },true);
 for(const event of ['blur','pagehide','offline'])window.addEventListener(event,e=>{if(active()&&e.target===window)pause(event==='offline'?'offline':'paused');});
 document.addEventListener('visibilitychange',()=>{if(active()&&document.visibilityState==='hidden')pause();});
 window.addEventListener('resize',measure);new ResizeObserver(measure).observe($('#home-content'));document.fonts?.ready.then(measure);
 setInterval(tick,500);
 return {open,render,refresh,store,previewScenario:value=>{scenario=value;},previewReadMode:value=>{store.previewReadMode(value);return refresh();},previewTick:tick,
  guardNavigation:page=>{if(!active()||page==='clocker')return false;if(bound&&bound!==store.authority()){lose();return false;}if(!dirty()&&!unknown&&!busy)return false;if(!busy)leave({kind:'root',page});return true;},
  onNavigate:page=>{if(page!=='clocker'){epoch++;command++;clearTimeout(timer);clear();bound=null;}},
  reset:()=>{epoch++;command++;clearTimeout(timer);clear();store.reset();view='list';selected=null;query='';filter='active';scopeLocation='';bound=null;},
  snapshot:()=>({connection,view,selected,query,filter,scopeLocation,busy,unknown,checked,conflict,hasDraft:!!draft,hasPrivateData:!!payload,hasSetupCode:!!setup,...store.snapshot()})};
}
