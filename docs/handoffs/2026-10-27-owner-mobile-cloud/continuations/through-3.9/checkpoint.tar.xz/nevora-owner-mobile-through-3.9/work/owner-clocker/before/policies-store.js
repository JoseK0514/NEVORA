/* Fictional, in-memory Owner policy revision stream. No operational API or persistence. */
function createOwnerPoliciesStore(api){
 const C=ownerPolicyContract,copy=v=>JSON.parse(JSON.stringify(v));let rows=[],mode='ready',session=0,writes=0;
 const rule={thresholdMinutes:7,comparison:'GT',effectiveFrom:'2026-10-01T12:00:37.123Z'};
 const gate=()=>api.gate()==='denied'||mode==='denied'?'denied':api.gate()!=='ready'||mode!=='ready'?'unavailable':'ready';
 const authority=()=>api.authority()+'|policy|'+session;
 const scope=(id,history=C.history(rows))=>history.scopes.find(s=>s.locationId===id)||{locationId:id,expectedRevision:0,state:'not_configured',selected:null};
 function reset(){session++;mode='ready';writes=0;rows=[{operationId:'11111111-1111-4111-8111-000000000001',revision:1,locationId:null,changedAt:'2026-10-01T12:00:00Z',changedKeys:['attendance.lateness'],settings:{version:1,attendance:{lateness:rule,earlyDeparture:null},labor:{compensation:{effectiveFrom:'2026-10-01T00:00:00Z',ruleReference:'Sample Owner compensation reference',breakTreatment:'INCLUDE_ALL_RECORDED_BREAKS',excludedBreakTypeIds:[]},rates:null,budgets:[],calculationMethod:{id:'sample-owner-method',revision:4}}}}];}
 function read(){const g=gate();if(g!=='ready')return {state:g};const context=api.context(),locations=api.locations();if(!context||!locations)return {state:'unavailable'};return {state:'ready',history:copy(C.history(rows)),locations:copy(locations),timeZone:context.timeZone,authority:authority(),observedAt:new Date(api.now()).toISOString(),validForMs:45000};}
 function save(input,scenario='normal',identity=authority()){
  if(identity!==authority()||gate()==='denied')return {state:'denied'};if(gate()!=='ready'||!api.context()||!api.locations())return {state:'unavailable'};
  let command;try{command=C.parseCommand(input);}catch{return {state:'invalid'};}
  const {locationId:id,settings}=command,locations=api.locations();if(id&&!locations.some(l=>l.id===id&&l.active))return {state:'denied'};
  const prior=rows.find(r=>r.operationId===command.operationId);
  if(prior)return JSON.stringify(prior.command||{operationId:prior.operationId,expectedRevision:prior.revision-1,locationId:prior.locationId,settings:prior.settings})===JSON.stringify(command)?{state:'saved',result:metadata(prior)}:{state:'conflict'};
  const validLocation=id=>id===null||locations.some(l=>l.id===id&&l.active);
  if((settings.labor?.rates||[]).some(r=>!api.employees().includes(r.employeeId)||!validLocation(r.locationId)||id&&r.locationId!==id)||(settings.labor?.budgets||[]).some(b=>!validLocation(b.locationId)||id&&b.locationId!==id)||(settings.labor?.compensation?.excludedBreakTypeIds||[]).some(b=>!api.breakTypes().includes(b)))return {state:'denied'};
  if(scope(id).expectedRevision!==command.expectedRevision)return {state:'conflict'};
  if(scenario==='invalid')return {state:'invalid'};if(scenario==='unknown-before'||scenario==='failure')return {state:'unknown'};
  const before=scope(id).selected?.settings||{version:1},changedKeys=[];
  for(const section of ['attendance','labor'])for(const field of new Set([...Object.keys(before[section]||{}),...Object.keys(settings[section]||{})]))if(JSON.stringify(before[section]?.[field])!==JSON.stringify(settings[section]?.[field]))changedKeys.push(section+'.'+field);
  const row={operationId:command.operationId,locationId:id,revision:command.expectedRevision+1,changedAt:new Date(api.now()).toISOString(),changedKeys:changedKeys.sort(),settings:copy(settings)};rows.push(row);writes++;
  return scenario==='unknown-after'?{state:'unknown'}:{state:'saved',result:metadata(row)};
 }
 const metadata=({operationId,locationId,revision,changedAt,changedKeys})=>({operationId,locationId,revision,changedAt,changedKeys});
 reset();return {read,save,gate,authority,scope,now:api.now,reset,previewReadMode:v=>{mode=v;},previewRows:v=>{rows=copy(v);},previewAppend:(id,settings)=>{rows.push({operationId:crypto.randomUUID(),locationId:id,revision:scope(id).expectedRevision+1,changedAt:new Date(api.now()).toISOString(),changedKeys:[],settings:copy(settings)});},snapshot:()=>({mode,writes})};
}
