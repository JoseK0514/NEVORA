# 3.6 Company/location policies and history

Continue accepted MOBILE OWNER only, C-08/C-09. Owner chooses whole company or stable location, understands six operational review alerts, edits one rule at a time, reviews the complete proposed scope, saves, sees a truthful result and returns to Settings/More with context. History, explicit conflict comparison, unavailable-current replacement, retained unknown command and authority/read failures belong to this batch. No pay authoring or automatic operational calculation, service, integration or deployment.

Baseline UI: 65f2a5d5cbb596f90a2d08adb2fca30c869e1142e8325e9d25f23326e70d1c64. Original canonical source copied to before/; artifact outputs/owner-policies/before.html. Arrival validator passed 9436 packaged +2170 reference files. Original manifests/evidence remain immutable.

Use existing task header, neutral notice, definition/list rows, native fields and 44/48px controls. No foundation/design restart. Scope list → focused rule → scope draft → whole review → save/result. History and private labor review use separate focused pages/disclosures. Preserve empty/unset/null/zero distinctions.
