/* Fictional resolved weekly availability and Schedule-backed planning review. Read only. */
function createOwnerWorkforceStore(team,schedule,clock){
 const copy=x=>JSON.parse(JSON.stringify(x)),base='2026-10-26',DAY=86400000;
 let submissions,mode,sources,session=1,nowOverride=null,reads=0;
 const now=()=>nowOverride===null?clock.now():Date.parse(nowOverride);
 const offset=d=>Math.round((Date.parse(d+'T12:00:00Z')-Date.parse(base+'T12:00:00Z'))/DAY);
 const date=(d,n)=>new Date(Date.parse(d+'T12:00:00Z')+n*DAY).toISOString().slice(0,10);
 const validWeek=d=>typeof d==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(d)&&Number.isFinite(Date.parse(d+'T12:00Z'))&&new Date(d+'T12:00Z').toISOString().slice(0,10)===d&&new Date(d+'T12:00Z').getUTCDay()===1;
 const minutes=t=>Number(t.split(':')[0])*60+Number(t.split(':')[1]);
 function reset(){mode='ready';sources={availability:'ready',hours:'ready'};nowOverride=null;reads=0;submissions={};for(const week of [base,date(base,7)])for(let n=1;n<=10;n++){
  let windows=[1,2,3,4,5].map(day=>({day,start:'09:00',end:'17:00'}));
  if(n===1)windows=[{day:1,start:'06:00',end:'10:00'},{day:1,start:'14:00',end:'18:00'},...windows.filter(w=>w.day!==1)];
  if(n===8)windows=[];
  if(n===10)windows=Array.from({length:7},(_,i)=>({day:(i+1)%7,start:'00:00',end:'24:00'}));
  const submitted=![3,9].includes(n),stamp=date(week,-4)+'T09:00:00-04:00';submissions[week+':person-'+n]={submitted,submittedAt:submitted?stamp:null,updatedAt:stamp,windows};
 }}reset();
 function authority(){const a=team.snapshot().actor;return JSON.stringify([a.id,a.active,a.accessRole,a.roleGeneration,session,'sample-company','weekly-review']);}
 function resolveWeek(value,kind){const settings=schedule.snapshot().deadlines,configured=Object.keys(settings).map(Number).filter(n=>n>0).sort((a,b)=>a-b),fallback=kind==='availability'?date(base,configured[0]??0):base;return {weekStart:validWeek(value)?value:fallback,invalidWeek:!!value&&!validWeek(value)};}
 function read({weekStart=base,location=null}={}){reads++;const actor=team.snapshot().actor;if(!team.isOwner()||mode==='denied'||mode==='signed-out'||Object.values(sources).includes('denied'))return {state:'unavailable',reason:'access_denied'};
  if(mode!=='ready'&&mode!=='empty')return {state:'unavailable',reason:({limit:'source_limit',schema:'schema_missing',invalid:'invalid_source'})[mode]||'read_failed'};
  if(!validWeek(weekStart))return {state:'unavailable',reason:'invalid_week'};
  const availability=sources.availability==='ready',hours=sources.hours==='ready';if(!availability&&!hours)return {state:'unavailable',reason:'read_failed'};
  try{const model=schedule.snapshot(),end=date(weekStart,6),people=(mode==='empty'?[]:team.directory()).filter(p=>p.active&&(!location||p.loc===location)).map(p=>{
   const eligible=['Employee','Lead'].includes(p.accessRole),sub=submissions[weekStart+':'+p.id]||{submitted:false,submittedAt:null,updatedAt:null,windows:[]};
   const windows=eligible&&availability&&sub.submitted?copy(sub.windows):[];
   for(const w of windows)if(!Number.isInteger(w.day)||w.day<0||w.day>6||!/^([01]\d|2[0-3]):[0-5]\d$/.test(w.start)||!/^(([01]\d|2[0-3]):[0-5]\d|24:00)$/.test(w.end)||minutes(w.end)<=minutes(w.start))throw Error('Invalid window');
   windows.sort((a,b)=>(a.day+6)%7-(b.day+6)%7||minutes(a.start)-minutes(b.start));
   let scheduledHours=null,target=null,maximum=null,hourStatus='unknown';if(hours){scheduledHours=Math.round(model.shifts.filter(s=>s.person===p.id&&!s.isCalloutApproved&&s.date>=weekStart&&s.date<=end).reduce((n,s)=>{const duration=minutes(s.end)-minutes(s.start);if(!Number.isFinite(duration)||duration===0)throw Error('Invalid shift');return n+(duration<0?duration+1440:duration)/60;},0)*100)/100;target=model.targets[p.id]??null;maximum=model.maximums[p.id]??null;if([target,maximum].some(v=>v!==null&&(!Number.isFinite(v)||v<0||v>168)))throw Error('Invalid hours');hourStatus=target===null?'unset':scheduledHours<target?'under':scheduledHours>target?'over':'on';}
   return {id:p.id,displayId:p.employeeId,name:p.name,initials:p.initials,tone:p.tone,role:p.accessRole,location:p.loc,eligible,submitted:availability&&eligible?!!sub.submitted:null,submittedAt:availability&&eligible?sub.submittedAt:null,updatedAt:availability&&eligible?sub.updatedAt:null,windows,availabilityStatus:!eligible?'not-required':!availability?'unknown':!sub.submitted?'missing':windows.length?'sent':'unavailable',scheduledHours,target,maximum,hourStatus};
  }).sort((a,b)=>a.name.localeCompare(b.name)||a.id.localeCompare(b.id));
  const eligible=people.filter(p=>p.eligible),deadline=model.deadlines[offset(weekStart)]?model.deadlines[offset(weekStart)]+':00-04:00':null;
  if(deadline&&!Number.isFinite(Date.parse(deadline)))throw Error('Invalid deadline');
  const publication=[...new Set(Object.entries(model.publications).filter(([k])=>Number(k.split(':')[0])===offset(weekStart)&&(!location||k.endsWith(':'+location))).map(([,v])=>v.status))];
  return {state:'ready',weekStart,endDate:end,people,activeCount:people.length,eligibleCount:eligible.length,sentCount:availability?eligible.filter(p=>p.submitted).length:null,missingCount:availability?eligible.filter(p=>!p.submitted).length:null,unavailableCount:availability?eligible.filter(p=>p.availabilityStatus==='unavailable').length:null,targetMissing:hours?people.filter(p=>p.hourStatus==='unset').length:null,outsideTarget:hours?people.filter(p=>['under','over'].includes(p.hourStatus)).length:null,deadline:availability?deadline:null,deadlinePassed:availability&&!!deadline&&now()>Date.parse(deadline),sources:{availability:availability?'ready':'unavailable',hours:hours?'ready':'unavailable'},publication:hours?(publication.length===1?publication[0]:publication.length?'Mixed draft/published':'Not planned'):null,observedAt:new Date(now()).toISOString(),validForMs:45000,authority:authority()};
  }catch{return {state:'unavailable',reason:'invalid_source'};}
 }
 return {read,resolveWeek,validWeek,authority,now,reset,addDays:date,offset,setReadMode:v=>{mode=v;},previewSource:(k,v)=>{sources[k]=v;},previewNow:v=>{nowOverride=v;},previewAuthority:()=>{session++;},previewSubmission:(week,id,patch)=>{submissions[week+':'+id]={...(submissions[week+':'+id]||{submitted:false,windows:[]}),...copy(patch)};},snapshot:()=>({reads,mode,sources:{...sources}})};
}
