/* Read-only fictional Clocker ledger projection; no punch, replay or persistence. */
function createOwnerClockerReceiptsStore(api){
 let mode='ready',reads=0;
 const ledger=[
  ['4a9c7ed1-9b42-4dc0-8847-324d7ade7832','CLOCK_IN','06:00'],
  ['bb8a042e-044c-4205-9aab-23a87511e789','START_BREAK','08:00'],
  ['c3773e70-b462-4c46-95ea-d5650a57e746','END_BREAK','08:30'],
  ['de542bbc-2d5a-44ea-90eb-b6ec3e20c134','CLOCK_OUT','10:00'],
 ].map(([commandId,action,time])=>({commandId,employeeId:'person-1',locationId:'location-1',deviceName:'Front counter tablet',action,performedAt:'2026-10-26T'+time+':00-04:00',timeEntryId:'sample-entry-6'}));
 const uuid=value=>typeof value==='string'&&/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/.test(value);
 const unavailable=reason=>({state:'unavailable',reason});
 function gate(){const shared=api.gate();return shared==='denied'||mode==='denied'?'denied':shared==='ready'&&['ready','empty'].includes(mode)?'ready':'unavailable';}
 function validateReference(value){const commandId=typeof value==='string'?value.trim().toLowerCase():'';return {ok:uuid(commandId),commandId,error:!commandId?'Enter the saved reference.':uuid(commandId)?'':'Use the full reference: 32 letters and numbers in five groups, with dashes.'};}
 function read(commandId){
  reads++;const access=gate();if(access!=='ready')return unavailable(access==='denied'?'access_denied':'read_failed');
  if(!uuid(commandId))return unavailable('invalid_reference');
  const authority=api.authority();
  try{
   const context=api.context?api.context():{timeZone:'America/Puerto_Rico'},timeZone=context?.timeZone;
   if(typeof timeZone!=='string')throw Error();
   new Intl.DateTimeFormat('en',{timeZone}).format(0);
   const locations=api.locations(),people=api.people();if(!Array.isArray(locations)||!Array.isArray(people))throw Error();
   const receipts=(mode==='empty'?[]:ledger.filter(r=>r.commandId===commandId)).map(row=>{
    const employee=people.find(p=>p.id===row.employeeId),location=locations.find(l=>l.id===row.locationId);
    if(!employee||!location||typeof employee.name!=='string'||typeof location.name!=='string')throw Error();
    const {employeeId,deviceName,action,performedAt,timeEntryId}=row;
    return {employeeId,employeeName:employee.name,deviceName,locationName:location.name,action,performedAt,timeEntryId};
   });
   if(gate()!=='ready'||authority!==api.authority())return unavailable('access_denied');
   return {state:'ready',commandId,receipts,timeZone,observedAt:new Date(api.now()).toISOString(),validForMs:15000,authority};
  }catch{return unavailable('read_failed');}
 }
 return {gate,authority:api.authority,now:api.now,read,validateReference,previewReadMode:value=>{mode=value;},reset:()=>{mode='ready';reads=0;},snapshot:()=>({mode,reads,writes:0})};
}
