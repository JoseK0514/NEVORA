/* Fictional Owner settings/profile source. No network, persistence or receipt protocol. */
function createOwnerCompanyStore({team,clock,locations,catalogCounts=()=>null}){
 let presentationSource=()=>({state:'ready',modules:{breaks:true},words:'standard'});
 const copy=x=>JSON.parse(JSON.stringify(x));let profile,mode,sources,capabilities,modules,session=1,reads=0,writes=0;
 const catalog=[
  ['company','Company details','Business name and time zone','Company'],['locations','Locations','Where your team works','Company'],['branding','Branding','Logo and workspace appearance','Company'],['features','Features and words','Enabled tools and terminology','Company'],['policies','Company policies','Operational rules and history','Company'],
  ['positions','Positions','Jobs used in scheduling','Scheduling'],['breaks','Break types','Breaks available on the Clocker','Scheduling'],['devices','Clocker devices','Shared tablets and setup','Scheduling'],['paysettings','Payroll settings','Pay setup and schedule','Pay']
 ].map(([id,title,description,group])=>({id,title,description,group}));
 function reset(){profile={name:'Friends',timeZone:'America/Puerto_Rico',locked:true,weekStart:'Monday',active:true};mode='ready';sources={profile:'ready',lock:'ready',locations:'ready',capabilities:'ready',modules:'ready'};capabilities={payroll:true,canConfigure:true};modules={breaks:true};session++;reads=0;writes=0;}reset();
 function authority(){const a=team.snapshot().actor;return JSON.stringify([a.id,a.active,a.accessRole,a.roleGeneration,session,mode==='denied'||mode==='signed-out','sample-company']);}
 const access=()=>!team.isOwner()||mode==='denied'?'access_denied':mode==='signed-out'?'authentication_required':null;
 function allowed(id){if(access()||mode!=='ready'||sources.modules!=='ready')return false;if(!catalog.some(r=>r.id===id))return false;if(id==='breaks'&&(!modules.breaks||presentationSource().state!=='ready'||!presentationSource().modules.breaks))return false;if(id==='paysettings'&&(sources.capabilities!=='ready'||!capabilities.payroll||!capabilities.canConfigure))return false;return true;}
 function validate(input){const errors={};if(!input||Object.keys(input).some(k=>!['name','timeZone'].includes(k)))return {ok:false,errors:{name:'Check the company details before saving.'}};
  const name=typeof input.name==='string'?input.name.trim():'';if(!name||[...name].length>160||/[\p{Cc}\p{Cf}]/u.test(name))errors.name='Enter a business name of 1–160 characters, without control characters.';
  const timeZone=Object.hasOwn(input,'timeZone')?input.timeZone:profile.timeZone;
  if(typeof timeZone!=='string'||!/^[A-Za-z_]+(?:\/[A-Za-z_+-]+)+$/.test(timeZone)||/^Etc\//i.test(timeZone))errors.timeZone='Enter a named time zone, such as America/Puerto_Rico.';else try{new Intl.DateTimeFormat('en',{timeZone}).format();}catch{errors.timeZone='Choose a valid named time zone.';}
  return {ok:!Object.keys(errors).length,errors,profile:{name,timeZone}};
 }
 function read(){reads++;const reason=access();if(reason)return {state:'unavailable',reason};if(mode!=='ready'||!profile.active)return {state:'unavailable',reason:'read_failed'};
  const state=Object.fromEntries(Object.entries(sources).map(([k,v])=>[k,v==='ready'?'ready':'unavailable'])),known=state.profile==='ready'&&state.lock==='ready';
  const destinations=state.modules==='ready'?catalog.filter(r=>allowed(r.id)).map(r=>({...r,title:r.id==='locations'&&presentationSource().state==='ready'?ownerPresentationData.wordPreset(presentationSource().words).en.locations:r.title,value:r.id==='locations'&&state.locations==='ready'&&Array.isArray(locations())?`${locations().length} active`:['positions','breaks'].includes(r.id)&&Array.isArray(catalogCounts(r.id))?`${catalogCounts(r.id).length} active`:null})):[];
  return {state:'ready',profile:known?copy(profile):null,sources:state,destinations,observedAt:new Date(clock.now()).toISOString(),validForMs:45000,authority:authority()};
 }
 function save(input,scenario='normal',key=authority()){
  if(access()||key!==authority()||mode!=='ready'||!profile.active||sources.profile!=='ready'||sources.lock!=='ready')return {state:'unavailable'};
  const v=validate(input);if(!v.ok)return {state:'invalid',errors:v.errors};if(profile.locked&&v.profile.timeZone!==profile.timeZone)return {state:'locked'};
  if(scenario==='failure')return {state:'error'};if(scenario==='unknown-before')return {state:'unconfirmed'};
  profile={...profile,...v.profile};writes++;return scenario==='unknown-after'?{state:'unconfirmed'}:{state:'confirmed',success:'Workspace updated.'};
 }
 return {setPresentationSource:fn=>{presentationSource=fn;},featureFacts:()=>{if(mode!=='ready'||access()||!profile.active||sources.profile!=='ready'||sources.modules!=='ready'||sources.capabilities!=='ready')return {state:'unavailable'};return {state:'ready',payrollEnabled:capabilities.payroll};},brandingContext:()=>mode==='ready'&&sources.profile==='ready'&&profile.active?{name:profile.name,timeZone:profile.timeZone}:null,catalogAccess:id=>{if(access()||!profile.active||id==='breaks'&&sources.modules==='ready'&&(!modules.breaks||presentationSource().state==='ready'&&!presentationSource().modules.breaks))return 'denied';if(mode!=='ready'||sources.profile!=='ready'||sources.modules!=='ready'||id==='breaks'&&presentationSource().state!=='ready')return 'unavailable';return 'ready';},read,save,validate,allowed,authority,now:clock.now,reset,publicName:()=>mode==='ready'&&sources.profile==='ready'&&profile.active?profile.name:null,catalog:copy(catalog),previewReadMode:v=>{mode=v;},previewSource:(key,value)=>{sources[key]=value;},previewProfile:patch=>{Object.assign(profile,copy(patch));},previewModules:patch=>{Object.assign(modules,copy(patch));},previewCapabilities:patch=>{Object.assign(capabilities,copy(patch));},previewAuthority:()=>{session++;},snapshot:()=>({mode,reads,writes,sources:{...sources}})};
}
