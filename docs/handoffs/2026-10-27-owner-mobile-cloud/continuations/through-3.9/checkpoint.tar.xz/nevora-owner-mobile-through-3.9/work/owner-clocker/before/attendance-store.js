/* Read-only fictional attendance sources. Fixed Puerto Rico fixture; no operational transport. */
function createOwnerAttendanceStore(team,clock,corrections){
 const copy=x=>JSON.parse(JSON.stringify(x)),Z='America/Puerto_Rico',minute=60000;
 let mode='ready',sourceModes={records:'ready',clockins:'ready'},session=1,nowOverride=null,contexts,targets,shifts,reads=0;
 const now=()=>nowOverride===null?clock.now():Date.parse(nowOverride);
 const at=(date,time)=>date+'T'+time+':00-04:00',day=value=>new Date(Date.parse(value)-4*3600000).toISOString().slice(0,10);
 const authority=()=>JSON.stringify([team.snapshot().actor.id,team.snapshot().actor.active,team.snapshot().actor.accessRole,team.snapshot().actor.roleGeneration,session,'sample-company','attendance']);
 const names={CLOCK_IN_AFTER_SCHEDULE_START:'Clock-in after scheduled start',CLOCK_OUT_BEFORE_SCHEDULE_END:'Clock-out before scheduled end',OPEN_AFTER_SCHEDULE_END:'No clock-out after scheduled end',BREAK_TARGET_EXCEEDED:'Break exceeded saved target',TIME_HISTORY_INCONSISTENT:'Time record needs review',SCHEDULE_UNMATCHED:'Schedule not matched',SCHEDULE_AMBIGUOUS:'Schedule match unclear'};
 const context=(date,start,end)=>({state:'matched',startAt:at(date,start),endAt:at(date,end),revisionId:'sample-captured-publication-1',publishedShiftId:'sample-captured-shift-'+date+'-'+start});
 function reset(){mode='ready';sourceModes={records:'ready',clockins:'ready'};nowOverride=null;session++;reads=0;
  contexts={'sample-entry-6':context('2026-10-26','05:45','10:15'),'sample-entry-7':context('2026-10-25','16:00','20:00'),'sample-entry-8':context('2026-10-26','07:00','15:00'),'sample-entry-9':context('2026-10-26','06:00','10:00'),'sample-entry-10':context('2026-10-26','07:30','11:00'),'sample-entry-15':{...context('2026-10-25','22:00','23:59'),endAt:at('2026-10-26','02:00')}};
  targets={'break-open':30};shifts=[{id:'sample-missing-running',employeeId:'person-5',locationId:'Rincón',startAt:at('2026-10-26','09:00'),endAt:at('2026-10-26','17:00'),positionName:'Team member'},{id:'sample-missing-ended',employeeId:'person-8',locationId:'Aguada',startAt:at('2026-10-26','05:00'),endAt:at('2026-10-26','08:00'),positionName:'Team member'}];
 }
 reset();
 function contact(id){const phone=team.get(id)?.phone?.trim().replace(/(?!^\+)[^\d]/g,'');return phone&&/^\+?\d{10,15}$/.test(phone)?phone:null;}
 function timecardPeriod(start,end,observed){const startDate=day(start),endDate=day(end||observed),latest=clock.addDays(endDate,-30),clipped=startDate<latest;return {startDate:clipped?latest:startDate,endDate,clipped};}
 function label(item){const p=team.get(item.employeeId);if(!p)throw Error('Missing employee label');return {...item,employeeName:p.name,employeeDisplayId:p.employeeId,locationName:item.locationId,tone:p.tone||'',initials:p.initials,phone:contact(p.id)};}
 function read(){reads++;const denied=!team.isOwner()||mode==='denied'||mode==='signed-out'||clock.snapshot().mode==='denied'||clock.snapshot().mode==='signed-out'||Object.values(sourceModes).includes('denied');if(denied)return {state:'unavailable',reason:'access_denied'};
  if(!['ready','empty'].includes(mode))return {state:'unavailable',reason:({limit:'source_limit',schema:'schema_missing',incomplete:'incomplete_source',invalid:'invalid_source'})[mode]||'read_failed'};
  if(Object.values(sourceModes).every(v=>v!=='ready'))return {state:'unavailable',reason:'read_failed'};
  const observedAt=new Date(now()).toISOString(),today=day(observedAt),dayStart=Date.parse(at(today,'00:00')),items=[],limitations=[],sources={records:sourceModes.records==='ready'?'ready':'unavailable',clockins:sourceModes.clockins==='ready'?'ready':'unavailable'};
  try{
   const raw=mode==='empty'?[]:clock.correctionDomain.read().entries.filter(e=>e.sourceKind!=='ADJUSTMENT');
   if(raw.length>1000||team.directory().length>300)return {state:'unavailable',reason:'source_limit'};
   if(raw.some(e=>!Number.isFinite(Date.parse(e.startAt))||e.endAt!==null&&!Number.isFinite(Date.parse(e.endAt))||!team.get(e.personId)||e.breaks.some(b=>!Number.isFinite(Date.parse(b.startAt))||b.endAt!==null&&!Number.isFinite(Date.parse(b.endAt)))))return {state:'unavailable',reason:'invalid_source'};
   if(sources.records==='ready')for(const e of raw){if(Date.parse(e.startAt)<dayStart&&e.endAt!==null&&Date.parse(e.endAt)<=dayStart)continue;
    const observations=[],saved=contexts[e.id],end=e.endAt?Date.parse(e.endAt):now(),overlap=raw.some(other=>other.id!==e.id&&other.personId===e.personId&&Date.parse(other.startAt)<end&&(other.endAt?Date.parse(other.endAt):now())>Date.parse(e.startAt));
    const inconsistent=end<=Date.parse(e.startAt)||e.endAt&&end>now()||overlap||e.breaks.some(b=>Date.parse(b.startAt)<Date.parse(e.startAt)||b.endAt&&Date.parse(b.endAt)<=Date.parse(b.startAt)||e.endAt&&(!b.endAt||Date.parse(b.endAt)>end));
    const add=(kind,evidence={})=>observations.push({kind,label:names[kind],...evidence});
    if(inconsistent){add('TIME_HISTORY_INCONSISTENT');limitations.push({entryId:e.id,reason:'time_history_inconsistent'});}
    else{
     if(!saved||saved.state==='not_evaluated')limitations.push({entryId:e.id,reason:'schedule_not_captured'});
     else if(saved.state==='unmatched')add('SCHEDULE_UNMATCHED');
     else if(saved.state==='ambiguous')add('SCHEDULE_AMBIGUOUS');
     else if(saved.state==='matched'&&(!Number.isFinite(Date.parse(saved.startAt))||!Number.isFinite(Date.parse(saved.endAt))||Date.parse(saved.endAt)<=Date.parse(saved.startAt)))limitations.push({entryId:e.id,reason:'schedule_context_invalid'});
     else if(saved.state==='matched'){
      if(Date.parse(e.startAt)>Date.parse(saved.startAt))add('CLOCK_IN_AFTER_SCHEDULE_START',{expectedAt:saved.startAt,recordedAt:e.startAt,differenceMinutes:Math.floor((Date.parse(e.startAt)-Date.parse(saved.startAt))/minute)});
      if(e.endAt&&Date.parse(e.endAt)<Date.parse(saved.endAt))add('CLOCK_OUT_BEFORE_SCHEDULE_END',{expectedAt:saved.endAt,recordedAt:e.endAt,differenceMinutes:Math.floor((Date.parse(saved.endAt)-Date.parse(e.endAt))/minute)});
      if(!e.endAt&&now()>Date.parse(saved.endAt))add('OPEN_AFTER_SCHEDULE_END',{expectedAt:saved.endAt,observedAt,differenceMinutes:Math.floor((now()-Date.parse(saved.endAt))/minute)});
     }
     for(const b of e.breaks){if(b.endAt!==null)continue;const target=targets[b.id];if(!Number.isInteger(target)||target<1||target>1440){limitations.push({entryId:e.id,breakId:b.id,reason:target==null?'break_target_not_captured':'break_target_invalid'});continue;}if(now()>Date.parse(b.startAt)+target*minute)add('BREAK_TARGET_EXCEEDED',{breakId:b.id,breakStart:b.startAt,targetMinutes:target,observedAt,differenceMinutes:Math.floor((now()-Date.parse(b.startAt)-target*minute)/minute)});}
    }
    if(observations.length)items.push(label({key:e.id,family:'records',employeeId:e.personId,locationId:e.locationId,workDate:day(e.startAt),recordedStart:e.startAt,recordedEnd:e.endAt,observations,savedContext:saved?.state==='matched'?copy(saved):null,timecardPeriod:timecardPeriod(e.startAt,e.endAt,observedAt)}));
   }
   if(sources.clockins==='ready'&&mode!=='empty')for(const shift of shifts){const start=Date.parse(shift.startAt),end=Date.parse(shift.endAt);if(!Number.isFinite(start)||!Number.isFinite(end)||end<=start)throw Error('Invalid published shift');if(day(shift.startAt)!==today&&end<=now())continue;
    const matched=raw.filter(e=>e.personId===shift.employeeId&&e.locationId===shift.locationId&&Date.parse(e.startAt)<end&&(e.endAt===null?now():Date.parse(e.endAt))>start-90*minute);
    if(matched.length||now()<start+5*minute&&now()<end)continue;
    const status=now()>=end?'no_punches':'not_clocked_in';items.push(label({key:'shift:'+shift.id,family:'clockins',employeeId:shift.employeeId,locationId:shift.locationId,workDate:day(shift.startAt),shift:copy(shift),status,recordedStart:null,recordedEnd:null,observations:[],sinceStartMinutes:Math.floor((now()-start)/minute),timecardPeriod:{startDate:day(shift.startAt),endDate:day(shift.startAt),clipped:false}}));
   }
   const priority=i=>i.family==='clockins'?(i.status==='not_clocked_in'?0:1):i.observations.some(o=>o.kind==='OPEN_AFTER_SCHEDULE_END')?2:i.observations.some(o=>o.kind==='TIME_HISTORY_INCONSISTENT')?3:4;
   items.sort((a,b)=>priority(a)-priority(b)||a.employeeName.localeCompare(b.employeeName)||a.key.localeCompare(b.key));
   const queue=corrections.read();return {state:'ready',authority:authority(),observedAt,today,timeZone:Z,validForMs:45000,sources,complete:sources.records==='ready'&&sources.clockins==='ready',limitations,items,pendingCorrectionCount:queue.state==='ready'?queue.requests.length:null,affectedEmployeeCount:new Set(items.map(i=>i.employeeId)).size,signalCount:items.reduce((n,i)=>n+(i.family==='clockins'?1:i.observations.length),0)};
  }catch{return {state:'unavailable',reason:'invalid_source'};}
 }
 return {read,authority,names,now,reset,contact,setReadMode:v=>{mode=v;},previewSource:(source,value)=>{sourceModes[source]=value;},previewNow:value=>{nowOverride=value;},previewContext:(id,value)=>{contexts[id]=value?copy(value):null;},previewBreakTarget:(id,value)=>{targets[id]=value;},previewShift:(id,patch)=>{const shift=shifts.find(s=>s.id===id);if(shift)Object.assign(shift,copy(patch));},previewAuthority:()=>{session++;},snapshot:()=>({mode,reads,sourceModes:{...sourceModes}})};
}
