## Task 1: Enforce the approved staging mail recipient

**Owner/files:** Codex; src/lib/auth/mail-transport.server.ts, its tests and existing onboarding/invitation delivery tests. Add a bounded test-environment recipient setting, shared by verification/invitation/recovery sends. Missing required staging recipient or a different recipient must fail before SMTP traffic. Preserve production and owned-loopback behavior and definite/unknown delivery semantics.

1. Reproduce remote staging transport accepting an unapproved destination using controlled mailer instrumentation, without a real send. Expected: regression fails before the fix.
2. Implement the smallest shared guard and configuration documentation. Expected: blocked sends never call SMTP; the approved recipient still works through the existing transport contract.
3. Run focused transport/invitation/registration tests, types and lint. Expected: all pass; no assertions weakened. Commit the bounded change.

