import {AsyncLocalStorage} from 'node:async_hooks';
// tsx can load the framework marker through both ESM and CJS entry paths.
const contextKey=Symbol.for('nevora.staging.request.context');
export const requestContext=globalThis[contextKey]??=new AsyncLocalStorage();
export async function cookies(){const c=requestContext.getStore();if(!c)throw Error('STAGING_REQUEST_CONTEXT_REQUIRED');return {get:name=>c.jar[name]===undefined?undefined:{name,value:c.jar[name]},getAll:name=>Object.entries(c.jar).filter(([n])=>!name||name===n).map(([name,value])=>({name,value})),set(name,value){if(typeof name==='object')c.jar[name.name]=name.value;else c.jar[name]=value;},delete(name){delete c.jar[name];}};}
export async function headers(){const c=requestContext.getStore();if(!c)throw Error('STAGING_REQUEST_CONTEXT_REQUIRED');return c.headers;}
export function redirect(path){const e=new Error('STAGING_REDIRECT');e.destination=path;throw e;}
export function notFound(){throw Error('STAGING_NOT_FOUND');}
