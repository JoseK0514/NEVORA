## Task 4: Resolve protected application and service connectivity

**Owner/interfaces:** Codex; existing app/commerce/private company endpoints, exact registered origins, current Owner/session authority and private entitlements.

1. Inspect actual service-to-service calls and SSO behavior. Expected: determine the precise blocked path without extracting browser auth or bypassing SSO.
2. Use existing supported authenticated paths if sufficient. Any additional narrowly scoped backend adapter must preserve current source/Owner/signature/role checks and receive only reviewed necessary credentials; document the concrete boundary before exposure. New persistent sensitive access through browser waits for action-time confirmation.
3. Verify correct/wrong host, revoked authority, cross-business access and unavailable source. Expected: only the original authorized business/Owner succeeds; failures do not grant access or trigger privileged work.

