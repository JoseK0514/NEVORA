import {readFileSync,writeFileSync,unlinkSync,existsSync} from 'node:fs';
import {Pool} from 'pg';
import Stripe from 'stripe';
const p='/Users/josek0514/.codex/tmp/nevora-neon-transfer/billing-fixture.json',d=JSON.parse(readFileSync(p,'utf8'));unlinkSync(p);
if(!['finish-provider-trial','cancel'].includes(d.action)||!/^rk_test_/.test(d.key)||Object.keys(d.companies).some(k=>!['a','b'].includes(k)))throw Error('BOUNDED_SANDBOX_FIXTURE_REQUIRED');
const url=new URL(d.catalog);if(url.pathname!=='/nevora_commerce_catalog'||decodeURIComponent(url.username)!=='nv_commerce_api_98fcf87026917d9d6b4b45de'||url.searchParams.get('sslmode')!=='verify-full')throw Error('STAGING_CATALOG_REQUIRED');
const stripe=new Stripe(d.key,{apiVersion:'2026-10-28.endive',maxNetworkRetries:0,timeout:10000}),pool=new Pool({connectionString:d.catalog,max:1,connectionTimeoutMillis:10000,statement_timeout:10000});pool.on('error',()=>{});
const receiptPath='.superpowers/sdd/2026-11-08-private-onboarding-staging-acceptance/stripe-owned-fixture-actions.json',receipts=existsSync(receiptPath)?JSON.parse(readFileSync(receiptPath,'utf8')):[];
try{
 if((await stripe.accounts.retrieveCurrent()).id!=='acct_1UZZK1HT1nhEuOJ2')throw Error('SANDBOX_ACCOUNT_MISMATCH');
 for(const[name,c]of Object.entries(d.companies) as [string,any][]){
  if(!['b7f07d3e-2255-474c-9a28-10c3185f5234','fe327544-3bd5-4b27-a19b-d1cb35d55300'].includes(c.workspaceId))throw Error('UNOWNED_FIXTURE');
  const row=(await pool.query('SELECT stripe_customer_id,stripe_subscription_id,trial_started_at,trial_ends_at FROM commerce.businesses WHERE id=$1',[c.workspaceId])).rows[0];if(!row?.stripe_subscription_id){console.log(JSON.stringify({name,state:'subscription_pending'}));continue;}
  const before=await stripe.subscriptions.retrieve(row.stripe_subscription_id);if(before.livemode||before.customer!==row.stripe_customer_id||before.metadata.nevora_business_id!==c.workspaceId||before.metadata.nevora_checkout_operation!==c.checkoutOperation)throw Error('OWNED_SUBSCRIPTION_REQUIRED');
  let after=before;
  if(d.action==='finish-provider-trial'&&before.status==='trialing')after=await stripe.subscriptions.update(before.id,{trial_end:'now',proration_behavior:'none'},{idempotencyKey:'nevora-staging-end-provider-trial:'+c.workspaceId+':'+before.id});
  if(d.action==='cancel'&&before.status!=='canceled')after=await stripe.subscriptions.cancel(before.id,{invoice_now:false,prorate:false});
  const actual=(await pool.query('SELECT trial_started_at,trial_ends_at FROM commerce.businesses WHERE id=$1',[c.workspaceId])).rows[0];if(actual.trial_started_at.getTime()!==row.trial_started_at.getTime()||actual.trial_ends_at.getTime()!==row.trial_ends_at.getTime())throw Error('APPLICATION_TRIAL_CHANGED');
  const receipt={at:new Date().toISOString(),name,action:d.action,subscriptionId:after.id,beforeStatus:before.status,status:after.status,beforeProviderTrialEnd:before.trial_end,providerTrialEnd:after.trial_end,applicationTrialUnchanged:true,livemode:false};receipts.push(receipt);writeFileSync(receiptPath,JSON.stringify(receipts,null,2));console.log(JSON.stringify(receipt));
 }
}catch{console.log(JSON.stringify({state:'fixture_action_unavailable',action:d.action,knownObjectsOnly:true}));process.exitCode=1;}finally{await pool.end();}
