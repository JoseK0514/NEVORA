import {readFileSync,writeFileSync,statSync} from 'node:fs';
import {randomBytes} from 'node:crypto';
import {Pool} from 'pg';
import {deploymentCapabilitiesAllowed,provisionerEnvironment} from '../../../services/hosted/neon/capabilities';
import {readProvisionerRuntime} from '../../../src/lib/onboarding/provisioning/runtime.server';
const path='/Users/josek0514/.codex/tmp/nevora-neon-transfer/provisioner-preflight.json';
let stage='private_input';
try{
 if((statSync(path).mode&0o777)!==0o600)throw Error();
 const env=JSON.parse(readFileSync(path,'utf8'));
 env.NEVORA_COMMERCE_WORKER_BINDING_KEY??=randomBytes(32).toString('base64url');
 stage='runtime_configuration';
 if(!deploymentCapabilitiesAllowed('provisioner',env))throw Error();
 const runtime=readProvisionerRuntime(provisionerEnvironment(env));
 if(!runtime||!runtime.commerce||runtime.policy.accountRef!=='org-twilight-term-01785349'||runtime.config.maxNewProjectsPerDay!==2||env.NEVORA_NEON_HOST_ENABLED!=='false')throw Error();
 const checks=[];
 for(const [kind,url,role] of [['control',runtime.config.controlDatabaseUrl,'nv_control_provision_a9ec007fb3935e41fd2a16ca'],['enrollment',runtime.commerce.databaseUrl,'nv_commerce_enroll_249bbb450f42c4c7cee82cd3']]){
  stage=kind+'_connection';const pool=new Pool({connectionString:url,max:1,connectionTimeoutMillis:10000,idleTimeoutMillis:1000,statement_timeout:5000});pool.on('error',()=>{});
  try{
   const client=await pool.connect();try{
    const tls=client.connection.stream;if(!tls.encrypted||!tls.authorized)throw Error();
    const row=(await client.query("SELECT current_database() AS database,current_user AS role,rolsuper,rolcreatedb,rolcreaterole,rolinherit,rolbypassrls,rolreplication,(SELECT count(*)::int FROM pg_auth_members WHERE member=pg_roles.oid) AS memberships,(SELECT count(*)::int FROM pg_class WHERE relowner=pg_roles.oid) AS owned_objects FROM pg_roles WHERE rolname=current_user")).rows[0];
    if(row.role!==role||['rolsuper','rolcreatedb','rolcreaterole','rolinherit','rolbypassrls','rolreplication'].some(k=>row[k])||row.memberships!==0||row.owned_objects!==0)throw Error();
    if(kind==='control'){
     stage='control_registry_capability';if(!(await client.query("SELECT has_table_privilege(current_user,'nevora_onboarding.workspace_registry','UPDATE') AS allowed")).rows[0].allowed)throw Error();
    }else{
     stage='enrollment_denials';for(const table of ['commerce.jobs','commerce.audit']){let denied=false;try{await client.query('SELECT 1 FROM '+table+' LIMIT 1');}catch(e){denied=(e as {code?:string}).code==='42501';}if(!denied)throw Error();}
    }
    checks.push({kind,...row,tlsVerified:true});
   }finally{client.release();}
  }finally{await pool.end();}
 }
 writeFileSync(path,JSON.stringify(env),{mode:0o600});
 const safe={configurationValid:true,positiveDeploymentPolicy:true,passwordlessAppIdentity:true,distinctEnrollmentKeys:true,providerOrganization:runtime.policy.accountRef,maximumNewProjects:runtime.config.maxNewProjectsPerDay,processingEnabled:false,checks};
 writeFileSync('.superpowers/sdd/2026-11-08-private-onboarding-staging-acceptance/provisioner-preflight.json',JSON.stringify(safe,null,2)+'\n');console.log(JSON.stringify(safe));
}catch{console.log(JSON.stringify({configurationValid:false,stage,processingEnabled:false}));process.exitCode=1;}
