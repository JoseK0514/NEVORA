## Task 3: Configure private provisioning with bounded resources

**Owner/interfaces:** Codex; existing private Neon provisioner, restricted control/enrollment roles, distinct crypto keys, reviewed resource policy and an organization-scoped provider key. Approval-dependent work waits for the pending exact browser confirmation; independent preparation continues.

1. Verify Free organization and key scope. Prefer the prepared isolated organization over an admin key covering existing native projects. Expected: no paid selection or existing-project access.
2. Store exact staging worker/control/enrollment configuration only in the provisioner; use a passwordless APP identity and required distinct keys. Expected: positive role-name preflight, named restricted DSNs, source/branch/account/region binding and actual denials.
3. Bound this run to two fictional companies, 0.25 CU, autosuspend and explicit provider quotas. Exercise a real queued provisioning operation, source validation, bootstrap, enrollment and initial-Owner state; preserve unknown-result recovery. Expected: exact identities and no unexpected project creations.

