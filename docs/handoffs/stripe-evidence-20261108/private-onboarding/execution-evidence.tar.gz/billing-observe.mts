import {readFileSync,writeFileSync,unlinkSync} from 'node:fs';
import {Pool} from 'pg';
import Stripe from 'stripe';
const p='/Users/josek0514/.codex/tmp/nevora-neon-transfer/billing-observe.json',d=JSON.parse(readFileSync(p,'utf8'));unlinkSync(p);
const url=new URL(d.catalog);if(decodeURIComponent(url.username)!=='nv_commerce_api_98fcf87026917d9d6b4b45de'||url.pathname!=='/nevora_commerce_catalog'||url.searchParams.get('sslmode')!=='verify-full'||!/^rk_test_/.test(d.key))throw Error('ISOLATED_BILLING_OBSERVATION_REQUIRED');
const pool=new Pool({connectionString:d.catalog,max:1,connectionTimeoutMillis:10000,statement_timeout:10000});pool.on('error',()=>{});
const stripe=new Stripe(d.key,{apiVersion:'2026-10-28.endive',timeout:10000,maxNetworkRetries:0});
try{
 const account=await stripe.accounts.retrieveCurrent();if(account.id!=='acct_1UZZK1HT1nhEuOJ2')throw Error('SANDBOX_ACCOUNT_MISMATCH');
 const companies=[];
 for(const[name,c]of Object.entries(d.companies) as [string,any][]){
  const row=(await pool.query('SELECT id,state,stripe_customer_id,stripe_subscription_id,subscription_status,trial_started_at,trial_ends_at,paid_through,past_due_since,plan_key,employee_count FROM commerce.businesses WHERE id=$1',[c.workspaceId])).rows[0];if(!row)throw Error('OWNED_BUSINESS_NOT_FOUND');
  const intent=(await pool.query('SELECT session_id FROM commerce.checkout_intents WHERE business_id=$1 AND operation=$2',[c.workspaceId,c.checkoutOperation])).rows[0];
  let checkout,subscription;
  if(intent?.session_id){const s=await stripe.checkout.sessions.retrieve(intent.session_id,{expand:['setup_intent']});if(s.livemode||s.metadata?.nevora_business_id!==c.workspaceId||s.customer!==row.stripe_customer_id)throw Error('OWNED_SESSION_MISMATCH');const setup=typeof s.setup_intent==='object'?s.setup_intent:null;checkout={status:s.status,mode:s.mode,amountTotal:s.amount_total,livemode:s.livemode,setupStatus:setup?.status??null};}
  if(row.stripe_subscription_id){const s=await stripe.subscriptions.retrieve(row.stripe_subscription_id,{expand:['latest_invoice']});if(s.livemode||s.metadata.nevora_business_id!==c.workspaceId||s.customer!==row.stripe_customer_id)throw Error('OWNED_SUBSCRIPTION_MISMATCH');const i=typeof s.latest_invoice==='object'?s.latest_invoice:null;subscription={id:s.id,status:s.status,trialEnd:s.trial_end,latestInvoice:i?{id:i.id,status:i.status,amountPaid:i.amount_paid,amountDue:i.amount_due,currency:i.currency,attemptCount:i.attempt_count}:null};}
  companies.push({name,...row,checkout,subscription});
 }
 const jobs=(await pool.query('SELECT state,count(*)::int AS count,sum(attempts)::int AS attempts,count(*) FILTER(WHERE last_error IS NOT NULL)::int AS withError FROM commerce.jobs GROUP BY state ORDER BY state')).rows;
 const webhookCount=(await pool.query('SELECT count(*)::int AS count FROM commerce.webhooks')).rows[0].count;
 const receipt={at:new Date().toISOString(),source:'actual Stripe sandbox API and restricted catalog principal',companies,jobs,webhookCount};
 writeFileSync('.superpowers/sdd/2026-11-08-private-onboarding-staging-acceptance/billing-observed-latest.json',JSON.stringify(receipt,null,2));console.log(JSON.stringify(receipt));
}catch{console.log(JSON.stringify({state:'observation_unavailable'}));process.exitCode=1;}finally{await pool.end();}
