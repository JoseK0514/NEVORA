import fs from 'node:fs';
import {spawnSync} from 'node:child_process';
const root='/Users/josek0514/.codex/tmp/nevora-neon-transfer/',input=root+'journey-chain.json';
const plan=JSON.parse(fs.readFileSync(input,'utf8'));fs.unlinkSync(input);let state=plan.state;
const persist=()=>fs.writeFileSync(root+'journey-chain-result.json',JSON.stringify(state),{mode:0o600});persist();
for(const [phase,name] of plan.phases){
 if(fs.existsSync(root+'journey-input.json')||fs.existsSync(root+'journey-output.json'))throw Error('ANOTHER_OWNED_PHASE_IS_RUNNING');
 fs.writeFileSync(root+'journey-input.json',JSON.stringify({env:plan.env,state}),{mode:0o600,flag:'wx'});
 const r=spawnSync(process.execPath,['--conditions=react-server','--import','./scripts/node-server-context.mjs','--import','tsx','.superpowers/sdd/2026-11-08-private-onboarding-staging-acceptance/hosted-journey.mts',phase,name],{encoding:'utf8',timeout:300000,maxBuffer:262144});
 if(fs.existsSync(root+'journey-output.json')){state=JSON.parse(fs.readFileSync(root+'journey-output.json','utf8'));fs.unlinkSync(root+'journey-output.json');persist();}
 // The child prints only explicit nonsecret receipt fields; never print stderr.
 for(const line of (r.stdout??'').trim().split('\n')){try{const o=JSON.parse(line);if(o.phase===phase&&o.name===name)console.log(JSON.stringify(o));}catch{}}
 if(r.status!==0){console.log(JSON.stringify({phase,name,state:'chain_stopped',childExit:r.status}));process.exit(r.status??1);}
}
console.log(JSON.stringify({state:'chain_complete',phases:plan.phases.length}));
