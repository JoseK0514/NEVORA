import {readFileSync,writeFileSync,unlinkSync,existsSync,statSync} from 'node:fs';
import {randomBytes} from 'node:crypto';
import {Pool} from 'pg';
const root='/Users/josek0514/.codex/tmp/nevora-neon-transfer/';
let stage='private_input';
try {
 const input=root+'authority-role-setup.json',output=root+'authority-role-result.json';
 if((statSync(input).mode&0o777)!==0o600||existsSync(output))throw Error();
 const {operator,stripe,existing}=JSON.parse(readFileSync(input,'utf8'));unlinkSync(input);
 const adminUrl=new URL(operator);adminUrl.searchParams.set('sslmode','verify-full');
 if(decodeURIComponent(adminUrl.username)!=='nevora_staging_operator'||adminUrl.pathname!=='/nevora_onboarding_control'||!adminUrl.hostname.endsWith('.neon.tech'))throw Error();
 const role=existing?.role??'nv_control_commerce_'+randomBytes(12).toString('hex'),password=randomBytes(36).toString('base64url');
 if(!/^nv_control_commerce_[a-f0-9]{24}$/.test(role))throw Error();
 const reader=existing?new URL(existing.readerUrl):new URL(adminUrl);if(!existing){reader.username=role;reader.password=password;}
 if(decodeURIComponent(reader.username)!==role||reader.hostname!==adminUrl.hostname||reader.pathname!==adminUrl.pathname)throw Error();
 const serviceKey=existing?.serviceKey??randomBytes(32).toString('base64url');
 // A durable private receipt precedes the sole role-create attempt.
 writeFileSync(output,JSON.stringify({role,readerUrl:reader.href,serviceKey,state:'attempting'}),{mode:0o600,flag:'wx'});
 const admin=new Pool({connectionString:adminUrl.href,max:1,connectionTimeoutMillis:10000});admin.on('error',()=>{});
 try {stage='create_reader';const c=await admin.connect();try {if(!c.connection.stream.authorized)throw Error();await c.query('BEGIN');if(!existing){await c.query(`CREATE ROLE "${role}" LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOINHERIT NOBYPASSRLS NOREPLICATION PASSWORD '${password}'`);await c.query(`GRANT CONNECT ON DATABASE nevora_onboarding_control TO "${role}"`);await c.query(`GRANT USAGE ON SCHEMA nevora_onboarding TO "${role}"`);await c.query(`GRANT SELECT ON nevora_onboarding.workspace_registry,nevora_onboarding.workspace_secrets TO "${role}"`);}await c.query('REVOKE TEMPORARY ON DATABASE nevora_onboarding_control FROM PUBLIC');await c.query(`ALTER ROLE "${role}" SET search_path=pg_catalog`);await c.query('COMMIT');}finally{c.release();}}finally{await admin.end();}
 const pool=new Pool({connectionString:reader.href,max:1,connectionTimeoutMillis:10000,statement_timeout:5000});pool.on('error',()=>{});
 let actual:Record<string,unknown>,denials:string[]=[];
 try {stage='reader_preflight';const c=await pool.connect();try {
  const tls=c.connection.stream;if(!tls.encrypted||!tls.authorized)throw Error();
  actual=(await c.query("SELECT current_user AS role,rolsuper,rolcreatedb,rolcreaterole,rolinherit,rolbypassrls,rolreplication,(SELECT count(*)::int FROM pg_auth_members WHERE member=pg_roles.oid) AS memberships,(SELECT count(*)::int FROM pg_class WHERE relowner=pg_roles.oid) AS owned_objects,has_database_privilege(current_user,current_database(),'CREATE') AS database_create,has_database_privilege(current_user,current_database(),'TEMPORARY') AS database_temp FROM pg_roles WHERE rolname=current_user")).rows[0];
  if(actual.role!==role||['rolsuper','rolcreatedb','rolcreaterole','rolinherit','rolbypassrls','rolreplication','database_create','database_temp'].some(k=>actual[k])||actual.memberships!==0||actual.owned_objects!==0)throw Error();
  await c.query('SELECT id FROM nevora_onboarding.workspace_registry LIMIT 1');await c.query('SELECT id FROM nevora_onboarding.workspace_secrets LIMIT 1');
  for(const [name,sql] of [
   ['registry_update',"UPDATE nevora_onboarding.workspace_registry SET lifecycle=lifecycle WHERE false"],
   ['registry_delete','DELETE FROM nevora_onboarding.workspace_registry WHERE false'],
   ['registry_insert','INSERT INTO nevora_onboarding.workspace_registry SELECT * FROM nevora_onboarding.workspace_registry WHERE false'],
   ['secrets_update','UPDATE nevora_onboarding.workspace_secrets SET active=active WHERE false'],
   ['registrations_read','SELECT 1 FROM nevora_onboarding.registrations LIMIT 1'],
   ['jobs_read','SELECT 1 FROM nevora_onboarding.provisioning_operations LIMIT 1'],
  ]){let denied=false;try{await c.query(sql);}catch(e){denied=(e as {code?:string}).code==='42501';}if(!denied)throw Error();denials.push(name);}
 }finally{c.release();}}finally{await pool.end();}
 stage='stripe_runtime_preflight';const stripeChecks=[];
 for(const [path,expected] of [['/v1/account',200],['/v1/prices/price_1UZb7JHT1nhEuOJ2MsMXV7Gf?expand[]=product',200],['/v1/balance',403]] as const){const r=await fetch('https://api.stripe.com'+path,{headers:{authorization:'Bearer '+stripe},signal:AbortSignal.timeout(10000)});const b=await r.json();if(r.status!==expected||(path==='/v1/account'&&b.id!=='acct_1UZZK1HT1nhEuOJ2')||(path.startsWith('/v1/prices/')&&b.livemode!==false))throw Error();stripeChecks.push({path,status:r.status});}
 writeFileSync(output,JSON.stringify({role,readerUrl:reader.href,serviceKey,state:'ready'}),{mode:0o600});
 const receipt={state:'ready',role,selectOnlyTables:['workspace_registry','workspace_secrets'],tlsVerified:true,actual:actual!,denials,stripeChecks};
 writeFileSync('.superpowers/sdd/2026-11-08-private-onboarding-staging-acceptance/authority-role-preflight.json',JSON.stringify(receipt,null,2));console.log(JSON.stringify(receipt));
}catch{console.log(JSON.stringify({state:'unavailable',stage,processingEnabled:false,privateRecoveryReceiptRetained:true}));process.exitCode=1;}
