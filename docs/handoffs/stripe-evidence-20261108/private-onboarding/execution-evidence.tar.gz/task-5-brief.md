## Task 5: Complete backend acceptance, review and Claude handoff

**Owner:** Codex. Run the complete signup/verification/provision/Owner activation/normal sign-in/setup/person/invitation/employee activation/billing journey through real backend interfaces for two fictional businesses. UI rendering is explicitly Claude's gate. Test duplicate/reordered/changed-replay, failure/recovery/cancellation and cross-business denials. Use Stripe sandbox only; retain uncertain receipts and retire only owned fixtures explicitly.

Run appropriate owned PostgreSQL, targeted, root, types, lint and clean-source build/artifact checks after implementation. Get one fresh whole-phase review, address Important/Critical findings with RED/GREEN and one fix pass, preserve independent gates. Deploy only exact reviewed staging source/configuration and verify actual hosted behavior. Restore bounded schedules/flags when finished. Update SCRUM-166/SCRUM-174 and durable docs with evidence, remaining failures, exact source/deployment state, rollback and Claude's exact integration contract. Do not label incomplete hosted or browser evidence complete.

## Review focus

Credential scope and custody; API/APP/WORKER/provisioner separation; SSO and company/Owner authority; sender-recipient restrictions and unknown SMTP results; concurrency/idempotency/partial provider outcomes; source/manifest/region/resource quotas; two real company database isolation; omitted configuration and safe rollback; evidence claims versus actual hosted scope.
