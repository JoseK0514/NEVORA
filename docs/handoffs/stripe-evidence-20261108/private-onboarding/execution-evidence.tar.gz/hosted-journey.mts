import {registerHooks} from 'node:module';
import {readFileSync,writeFileSync,unlinkSync,statSync} from 'node:fs';
import {randomUUID,randomBytes,createHash} from 'node:crypto';
import {Pool} from 'pg';
import {requestContext} from './request-adapter.mjs';
const privateRoot='/Users/josek0514/.codex/tmp/nevora-neon-transfer/';
const receiptRoot='.superpowers/sdd/2026-11-08-private-onboarding-staging-acceptance/';
const inputPath=privateRoot+'journey-input.json',outputPath=privateRoot+'journey-output.json';
const input=JSON.parse(readFileSync(inputPath,'utf8'));if((statSync(inputPath).mode&0o777)!==0o600)throw Error('PRIVATE_INPUT_MODE');unlinkSync(inputPath);
Object.assign(process.env,input.env);
const state=input.state??{companies:{},events:[]},phase=process.argv[2],name=process.argv[3]??'a';
const save=()=>writeFileSync(outputPath,JSON.stringify(state),{mode:0o600});
save();
const adapter=new URL('./request-adapter.mjs',import.meta.url).href;
registerHooks({resolve(specifier,context,next){if(['next/headers','next/navigation'].includes(specifier))return {url:adapter,shortCircuit:true};return next(specifier,context);}});
const {readOnboardingConfig}=await import('../../../src/lib/onboarding/config.server');
const {createControlStore}=await import('../../../src/lib/onboarding/control-store.server');
const {registrationHttpHandlers}=await import('../../../src/lib/onboarding/registration-http.server');
const {verificationDelivery}=await import('../../../src/lib/onboarding/verification-delivery.server');
const {provisioningHttpHandlers}=await import('../../../src/lib/onboarding/provisioning/http.server');
const {ownerActivationHttpHandlers}=await import('../../../src/lib/onboarding/owner-activation-http.server');
const config=readOnboardingConfig();if(!config.enabled||config.environment!=='test'||config.providerAccountRef!=='org-twilight-term-01785349'||config.maxNewProjectsPerDay!==2)throw Error('STAGING_CONFIG_REQUIRED');
const controlUrl=new URL(config.controlDatabaseUrl);if(decodeURIComponent(controlUrl.username)!=='nv_control_app_2c4c8695dbafd3b2282c36d6'||controlUrl.pathname!=='/nevora_onboarding_control'||controlUrl.searchParams.get('sslmode')!=='verify-full')throw Error('STAGING_APP_PRINCIPAL_REQUIRED');
const pool=new Pool({connectionString:config.controlDatabaseUrl,max:2,connectionTimeoutMillis:10000,statement_timeout:15000});pool.on('error',()=>{});const store=createControlStore(pool);
const ensure=(value:unknown,message:string)=>{if(!value)throw Error(message);};
const jsonRequest=(origin:string,path:string,body:unknown,cookie?:string)=>new Request(origin+path,{method:'POST',headers:{origin,host:new URL(origin).host,'content-type':'application/json','x-nevora-onboarding':'1',...(cookie?{cookie}:{})},body:JSON.stringify(body)});
const emit=(event:Record<string,unknown>)=>{state.events.push({phase,name,at:new Date().toISOString(),...event});save();writeFileSync(receiptRoot+'hosted-journey-events.json',JSON.stringify(state.events,null,2));console.log(JSON.stringify({phase,name,...event}));};
async function companyContext(c,action){
 const {resolveWorkspaceBinding}=await import('../../../src/lib/workspace-routing/resolver.server');
 const {withWorkspaceBinding}=await import('../../../src/lib/workspace-routing/context.server');
 const binding=await resolveWorkspaceBinding({origin:c.origin},store,{...config,tokenKey:config.workspaceTokenKey});
 return requestContext.run({jar:c.jar,headers:new Headers({host:new URL(c.origin).host,origin:c.origin,'x-forwarded-for':'127.0.0.1'})},()=>withWorkspaceBinding(binding,()=>action(binding)));
}
async function signIn(c,id,password){return companyContext(c,async binding=>{
 const {login}=await import('../../../src/app/login/actions'),{readSessionMutationProof}=await import('../../../src/lib/auth/session');
 for(const key of Object.keys(c.jar))delete c.jar[key];save();const form=new FormData();form.set('employeeId',id);form.set('password',password);let destination='';
 try{await login(form);}catch(error){if(error instanceof Error&&error.message==='STAGING_REDIRECT')destination=error.destination;else throw error;}
 ensure(destination==='/app','PASSWORD_SIGNIN_FAILED');const proof=await readSessionMutationProof();ensure(proof?.employee.id===id,'REAL_SESSION_REQUIRED');save();return proof;
});}
let stage='control_tls';
try {
 const client=await pool.connect();try{ensure(client.connection.stream.authorized,'TLS_REQUIRED');const r=(await client.query("SELECT current_user AS role,rolsuper,rolinherit,rolcreatedb,rolcreaterole,rolbypassrls,rolreplication,(SELECT count(*)::int FROM pg_auth_members WHERE member=pg_roles.oid) AS memberships FROM pg_roles WHERE rolname=current_user")).rows[0];ensure(r.memberships===0&&!['rolsuper','rolinherit','rolcreatedb','rolcreaterole','rolbypassrls','rolreplication'].some(k=>r[k]),'APP_ROLE_REQUIRED');}finally{client.release();}
 if(phase==='register'){
  stage='prepare_registration';ensure(!state.companies[name],'COMPANY_ALREADY_PREPARED');
  const c={registrationOperation:randomUUID(),verificationOperation:randomUUID(),workspaceOperation:randomUUID(),grantOperation:randomUUID(),activationOperation:randomUUID(),ownerPassword:'Fictional-'+randomBytes(24).toString('base64url')+'-123!',slug:'acceptance-'+name+'-20261108',jar:{}};state.companies[name]=c;save();
  const real=verificationDelivery(process.env,config);ensure(real,'REAL_SMTP_REQUIRED');
  const handlers=registrationHttpHandlers({config,store,delivery:{async send(m){ensure(m.email==='support@thevelani.com','UNAPPROVED_RECIPIENT');c.verificationProof=m.proof;save();const r=await real!.send(m);c.mailAccepted=true;save();return r;}}});
  const command={schemaVersion:1,operationId:c.registrationOperation,email:'support@thevelani.com',locale:'en',termsVersion:config.termsVersion,privacyVersion:config.privacyVersion};
  stage='real_verification_email';const first=await handlers.request(jsonRequest(config.signupOrigin,'/api/onboarding/registrations',command));ensure(first.status===202,'REGISTRATION_NOT_ACCEPTED');ensure(c.mailAccepted===true,'SMTP_NOT_ACCEPTED');
  const replay=await handlers.request(jsonRequest(config.signupOrigin,'/api/onboarding/registrations',command));ensure(replay.status===202,'REGISTRATION_REPLAY');
  const delivery=(await pool.query('SELECT delivery_state,attempts FROM nevora_onboarding.verification_deliveries WHERE operation_id=$1',[c.registrationOperation])).rows[0];ensure(delivery.delivery_state==='PROVIDER_ACCEPTED'&&delivery.attempts===1,'DELIVERY_RECEIPT');
  stage='verification_http';const verified=await handlers.verify(jsonRequest(config.signupOrigin,'/api/onboarding/verification',{schemaVersion:1,operationId:c.verificationOperation,proof:c.verificationProof}));const body=await verified.json();ensure(verified.status===200&&body.state==='verified','VERIFY_FAILED');const cookie=verified.headers.get('set-cookie')?.match(/^nevora_signup=([^;]+)/)?.[1];ensure(cookie,'SIGNUP_COOKIE_REQUIRED');c.signupCookie='nevora_signup='+cookie;c.snapshot=body.snapshot;delete c.verificationProof;save();
  emit({state:'verified',smtpProviderAccepted:true,smtpAttempts:1,registrationReplay:true,httpStatuses:[first.status,replay.status,verified.status]});
 }else{
  const c=state.companies[name];ensure(c,'COMPANY_MISSING');const handlers=provisioningHttpHandlers({config,store}),owner=ownerActivationHttpHandlers({config,store});
  if(phase==='reserve'){
   stage='workspace_reservation';c.workspaceCommand??={schemaVersion:1,operationId:c.workspaceOperation,expectedVersion:c.snapshot.version,payload:{businessName:'Fictional Acceptance '+name.toUpperCase(),timeZone:'America/Chicago',requestedSlug:c.slug,initialLocation:{name:'Fictional Main Studio',shortName:'Main',key:'main'},ownerProfile:{id:'OWNER-1',firstName:'Fictional',lastName:'Owner '+name.toUpperCase(),phone:'202-555-0101'}}};save();
   const call=body=>handlers.request(jsonRequest(config.signupOrigin,'/api/onboarding/workspaces',body,c.signupCookie));const first=await call(c.workspaceCommand),body=await first.json();ensure(first.status===202&&body.state==='pending','WORKSPACE_RESERVATION_FAILED');const repeat=await call(c.workspaceCommand);ensure(repeat.status===202,'RESERVE_REPLAY_FAILED');const changed=await call({...c.workspaceCommand,payload:{...c.workspaceCommand.payload,businessName:'Changed replay'}});ensure(changed.status===409,'CHANGED_REPLAY_NOT_DENIED');
   const row=(await pool.query('SELECT workspace_id,state,resource FROM nevora_onboarding.provisioning_operations WHERE operation_id=$1',[c.workspaceOperation])).rows[0];ensure(row,'RESERVATION_ROW_MISSING');c.workspaceId=row.workspace_id;c.origin='https://'+c.slug+'.'+config.portalBaseDomain;save();emit({state:'reserved',workspaceId:c.workspaceId,origin:c.origin,originalStatus:first.status,replayStatus:repeat.status,changedReplayStatus:changed.status});
  }else if(phase==='status'){
   stage='provisioning_status';const request=new Request(config.signupOrigin+'/api/onboarding/operations/'+c.workspaceOperation,{headers:{cookie:c.signupCookie}}),reply=await handlers.read(request,c.workspaceOperation),body=await reply.json();const row=(await pool.query('SELECT workspace_id,state,reason_code,resource FROM nevora_onboarding.provisioning_operations WHERE operation_id=$1',[c.workspaceOperation])).rows[0];c.provisioningState=row.state;if(row.resource)c.resource=row.resource;save();emit({state:row.state,reason:row.reason_code,httpStatus:reply.status,publicStage:body.stage,projectId:row.resource?.projectId??null});
  }else if(phase==='grant'){
   stage='owner_grant';const reply=await owner.grant(jsonRequest(config.signupOrigin,'/api/onboarding/bootstrap-grants',{schemaVersion:1,operationId:c.grantOperation},c.signupCookie)),body=await reply.json();ensure([200,202].includes(reply.status),'OWNER_GRANT_FAILED');if(body.state==='ready'){ensure(new URL(body.url).origin===c.origin,'OWNER_GRANT_ORIGIN');c.ownerGrantProof=new URLSearchParams(new URL(body.url).hash.slice(1)).get('proof');ensure(c.ownerGrantProof,'OWNER_GRANT_EMPTY');}save();emit({state:body.state,httpStatus:reply.status});
  }else if(phase==='activate'){
   stage='owner_activation';ensure(c.ownerGrantProof,'OWNER_GRANT_NOT_READY');const command={schemaVersion:1,operationId:c.activationOperation,proof:c.ownerGrantProof,password:c.ownerPassword};const r=await owner.activate(jsonRequest(c.origin,'/api/onboarding/owner-activation',command)),body=await r.json();c.activationFirstStatus=r.status;save();ensure(r.status===200&&body.state==='activated','OWNER_ACTIVATION_FAILED');c.ownerActivated=true;save();const repeat=await owner.activate(jsonRequest(c.origin,'/api/onboarding/owner-activation',command));c.activationReplayStatus=repeat.status;save();ensure(repeat.status===200,'OWNER_ACTIVATION_REPLAY_FAILED');emit({state:'activated',httpStatus:r.status,replayStatus:repeat.status});
  }else if(phase==='signin'){
   stage='normal_password_signin';const proof=await signIn(c,'OWNER-1',c.ownerPassword);c.ownerCookie=c.jar.fuel_session;ensure(c.ownerCookie,'OWNER_COOKIE_MISSING');save();emit({state:'signed_in',employeeId:proof.employee.id,role:proof.employee.role,passwordAction:true});
  }else if(phase==='setup'){
   stage='owner_setup';await companyContext(c,async binding=>{
    const {setupHttpHandlers}=await import('../../../src/lib/onboarding/owner-http.server');
    const handlers=setupHttpHandlers({config:{...config,tokenKey:config.workspaceTokenKey},store});
    const get=async()=>{const r=await handlers.read(new Request(c.origin+'/api/onboarding/state',{headers:{host:new URL(c.origin).host,origin:c.origin}}));ensure(r.status===200,'OWNER_SETUP_READ');return r.json();};
    let current=await get();c.setupCommands??=[];save();
    for(const payload of [{action:'STAFFING',staffingSettings:[{locationId:current.configuration.locations[0].id,minimumStaffPerShift:1,requiresDesignatedLead:false}],hourTargets:[]},{action:'COVERAGE_CREATE',locationId:current.configuration.locations[0].id,dayOfWeek:1,startTime:'09:00',endTime:'17:00',positionRequirements:[]}]){
     const i=c.setupCommands.length,command={schemaVersion:1,operationId:randomUUID(),expectedVersion:current.snapshot.version,payload};c.setupCommands.push(command);save();const r=await handlers.save(jsonRequest(c.origin,'/api/onboarding/steps/SCHEDULING',command),'SCHEDULING');const body=await r.json();ensure(r.status===200&&body.state==='saved','SETUP_SAVE_FAILED');const replay=await handlers.save(jsonRequest(c.origin,'/api/onboarding/steps/SCHEDULING',command),'SCHEDULING');ensure(replay.status===200,'SETUP_REPLAY_FAILED');current=await get();ensure(i<2,'SETUP_BOUND');
    }
    c.setup=current;save();emit({state:current.snapshot.registrationState,version:current.snapshot.version,canonicalReplay:true,locations:current.configuration.locations.length,coverage:current.configuration.coverage.length});
   });
  }else if(phase==='invite'){
   stage='employee_invitation';await companyContext(c,async binding=>{
    const {readSessionMutationProof}=await import('../../../src/lib/auth/session'),{getWorkspaceDb}=await import('../../../src/lib/workspace-routing/transport.server');
    const {readOnboardingSetup}=await import('../../../src/lib/onboarding/setup.server');
    const {saveEmployeeCoreAccessProfile}=await import('../../../src/lib/company-access/employee-profile.server');
    const {saveOnboardingPerson}=await import('../../../src/lib/onboarding/people.server');
    const {issueInvitationBatch,readInvitationBatch}=await import('../../../src/lib/onboarding/invitation-batch.server');
    const {invitationDelivery}=await import('../../../src/lib/auth/invitations/delivery.server'),{workspaceRuntimeEnvironment}=await import('../../../src/lib/workspace-routing/runtime-config.server');
    const proof=await readSessionMutationProof();ensure(proof?.employee.role==='OWNER','OWNER_REQUIRED');const ex=getWorkspaceDb(binding);let setup=await readOnboardingSetup(proof!,binding);const owner=setup.configuration.people.find(p=>p.id==='OWNER-1')!;
    // Only one real inbox is authorized. Clear the fictional Owner's contact
    // through the canonical profile command, leaving password/Owner identity intact.
    c.ownerContactCommand??={operationId:randomUUID(),employeeId:'OWNER-1',expectedEmployeeUpdatedAt:owner.updatedAt,profile:{firstName:owner.firstName,lastName:owner.lastName,phone:owner.phone,email:null,role:'OWNER',primaryLocationId:owner.primaryLocationId,active:true}};save();
    const contact=await saveEmployeeCoreAccessProfile(proof!,c.ownerContactCommand,ex);ensure(contact.state==='saved','FICTIONAL_OWNER_CONTACT_UPDATE');setup=await readOnboardingSetup(proof!,binding);ensure(setup.configuration.people.find(p=>p.id==='OWNER-1')?.email===null,'OWNER_CONTACT_NOT_CLEARED');
    c.employeeCommand??={schemaVersion:1,operationId:randomUUID(),expectedVersion:setup.snapshot.version,payload:{employee:{id:'EMP-1',firstName:'Fictional',lastName:'Employee '+name.toUpperCase(),phone:'202-555-0102',email:'support@thevelani.com',role:'EMPLOYEE',primaryLocationId:owner.primaryLocationId,eligibleLocationIds:[owner.primaryLocationId],positionIds:[]}}};save();const created=await saveOnboardingPerson(proof!,binding,c.employeeCommand);ensure(created.state==='saved','EMPLOYEE_CREATE');setup=await readOnboardingSetup(proof!,binding);const employee=setup.configuration.people.find(p=>p.id==='EMP-1')!;ensure(employee,'EMPLOYEE_MISSING');
    c.batchCommand??={schemaVersion:1,operationId:randomUUID(),expectedVersion:setup.snapshot.version,payload:{targets:[{employeeId:employee.id,expectedEmployeeVersion:employee.updatedAt,expectedInvitationRevision:0}]}};save();const real=invitationDelivery(await workspaceRuntimeEnvironment());ensure(real,'REAL_INVITATION_SMTP_REQUIRED');let sends=0;
    const delivery={async send(m){ensure(m.registeredEmail==='support@thevelani.com','UNAPPROVED_RECIPIENT');c.invitationInner=m.proof;c.invitationExpiry=m.expiresAt;save();const r=await real!.send(m);sends++;c.invitationAccepted=true;save();return r;}};
    await issueInvitationBatch(proof!,binding,c.batchCommand,delivery);const snapshot=await readInvitationBatch(proof!,binding,c.batchCommand.operationId);ensure(snapshot.state==='ready'&&snapshot.stage==='COMPLETE'&&c.invitationAccepted,'INVITATION_NOT_COMPLETE');await issueInvitationBatch(proof!,binding,c.batchCommand,delivery);ensure(sends===1,'DUPLICATE_INVITATION_SEND');save();emit({state:'invited',employeeId:'EMP-1',smtpProviderAccepted:true,smtpAttempts:1,batchStage:'COMPLETE',repeatDidNotSend:true,fictionalOwnerContactCleared:true});
   });
  }else if(phase==='employee-activate'){
   stage='employee_email_activation';ensure(c.invitationEmailEnvelope,'ACTUAL_EMAIL_PROOF_REQUIRED');await companyContext(c,async binding=>{
    const {openWorkspaceToken}=await import('../../../src/lib/workspace-routing/token-envelope.server');ensure(openWorkspaceToken(binding,'INVITATION',c.invitationEmailEnvelope)===c.invitationInner,'EMAIL_PROOF_BINDING');
    c.employeePassword??='Fictional-'+randomBytes(24).toString('base64url')+'-123!';save();const {POST}=await import('../../../src/app/api/auth/activate/route');const request=jsonRequest(c.origin,'/api/auth/activate',{proof:c.invitationEmailEnvelope,password:c.employeePassword});request.headers.set('x-nevora-activation','1');const r=await POST(request);ensure(r.status===200,'EMPLOYEE_ACTIVATION_FAILED');save();
   });const proof=await signIn(c,'EMP-1',c.employeePassword);ensure(proof.employee.role==='EMPLOYEE','EMPLOYEE_ROLE_REQUIRED');c.employeeCookie=c.jar.fuel_session;await companyContext(c,async binding=>{const {readOnboardingSetup}=await import('../../../src/lib/onboarding/setup.server');let denied=false;try{await readOnboardingSetup(proof,binding);}catch{denied=true;}ensure(denied,'EMPLOYEE_OWNER_SETUP_NOT_DENIED');});c.jar.fuel_session=c.ownerCookie;save();emit({state:'employee_activated',actualDeliveredEmailProof:true,passwordSignIn:true,ownerSetupDenied:true});
  }else if(phase==='billing-prepare'){
   stage='native_billing_authority';await companyContext(c,async()=>{
    const {currentCommerceConnection,readCommerceAuthority}=await import('../../../src/lib/commerce/access');
    const connection=await currentCommerceConnection();const started=Date.now();
    const first=await fetch(connection.origin+'/internal/access',{headers:{authorization:'Bearer '+connection.secret,'x-nevora-installation':connection.installationId},signal:AbortSignal.timeout(15000),redirect:'error'});const initial=await first.json();c.authorityPreflight={status:first.status,elapsedMs:Date.now()-started,state:initial.state};save();ensure(first.status===200&&initial.businessId===c.workspaceId&&initial.installationId===c.workspaceId&&initial.operational===true,'NATIVE_ENTITLEMENT_REQUIRED');
    const access=await readCommerceAuthority();ensure(access.operational&&access.state==='trial','ORIGINAL_ENTITLEMENT_CLIENT');
    stage='owner_billing_handoff';const {POST}=await import('../../../src/app/api/commerce/handoff/route');const reply=await POST(jsonRequest(c.origin,'/api/commerce/handoff',{})),body=await reply.json();c.handoffHttpStatus=reply.status;save();ensure(reply.status===200,'ORIGINAL_OWNER_HANDOFF_FAILED');const url=new URL(body.url);ensure(url.origin==='https://signup-staging.nevora.team'&&url.pathname==='/pages/plans','HANDOFF_ORIGIN_REQUIRED');const handoff=new URLSearchParams(url.hash.slice(1)).get('handoff');ensure(handoff,'HANDOFF_REQUIRED');
    const call=async(path,body?,bearer?,operation?)=>fetch(connection.origin+path,{method:body===undefined?'GET':'POST',headers:{origin:'https://signup-staging.nevora.team',...(body!==undefined?{'content-type':'application/json'}:{}),...(bearer?{authorization:'Bearer '+bearer}:{}),...(operation?{'idempotency-key':operation}:{})},...(body!==undefined?{body:JSON.stringify(body)}:{}),signal:AbortSignal.timeout(30000),redirect:'error'});
    const exchanged=await call('/v1/handoff/exchange',{token:handoff});ensure(exchanged.status===200,'HANDOFF_EXCHANGE_FAILED');const session=await exchanged.json();ensure(/^[A-Za-z0-9_-]{43}$/.test(session.accessToken),'BILLING_SESSION_REQUIRED');c.billingBearer=session.accessToken;save();const replay=await call('/v1/handoff/exchange',{token:handoff});ensure(replay.status===400,'HANDOFF_REPLAY_NOT_DENIED');
    const status=await call('/v1/status',undefined,c.billingBearer);c.billingStatus=await status.json();ensure(status.status===200&&c.billingStatus.businessId===c.workspaceId&&c.billingStatus.state==='trial','BILLING_STATUS_REQUIRED');
    stage='runtime_checkout';c.checkoutOperation??=randomUUID();save();const checkout=await call('/v1/checkout',{},c.billingBearer,c.checkoutOperation),result=await checkout.json();c.checkoutHttpStatus=checkout.status;c.checkoutErrorCode=result.error?.code;save();ensure(checkout.status===200,'RUNTIME_CHECKOUT_FAILED');const checkoutUrl=new URL(result.url);ensure(checkoutUrl.origin==='https://checkout.stripe.com'&&result.url.includes('cs_test_'),'SANDBOX_CHECKOUT_REQUIRED');c.checkoutUrl=result.url;save();const repeated=await call('/v1/checkout',{},c.billingBearer,c.checkoutOperation);ensure(repeated.status===200&&(await repeated.json()).url===c.checkoutUrl,'CHECKOUT_REPLAY_CHANGED');
    emit({state:'checkout_prepared',businessId:c.workspaceId,trial:c.billingStatus.state,activeEmployees:c.billingStatus.activeEmployees,handoffStatus:reply.status,handoffReplayDenied:true,checkoutStatus:checkout.status,checkoutReplaySame:true,authorityPreflight:c.authorityPreflight});
   });
  }else if(phase==='restore-owner-contact'){
   stage='canonical_fixture_contact_restoration';await companyContext(c,async binding=>{
    const{readSessionMutationProof}=await import('../../../src/lib/auth/session');const{readOnboardingSetup}=await import('../../../src/lib/onboarding/setup.server');const{getWorkspaceDb}=await import('../../../src/lib/workspace-routing/transport.server');const{saveEmployeeCoreAccessProfile}=await import('../../../src/lib/company-access/employee-profile.server');
    const proof=await readSessionMutationProof();ensure(proof?.employee.role==='OWNER','OWNER_REQUIRED');
    for(const[id,email]of [['EMP-1',null],['OWNER-1','support@thevelani.com']]){const setup=await readOnboardingSetup(proof!,binding),person=setup.configuration.people.find(x=>x.id===id)!;ensure(person,'FICTIONAL_PERSON_REQUIRED');if(person.email===email)continue;const command={operationId:randomUUID(),employeeId:id,expectedEmployeeUpdatedAt:person.updatedAt,profile:{firstName:person.firstName,lastName:person.lastName,phone:person.phone,email,role:person.role,primaryLocationId:person.primaryLocationId,active:true}};const result=await saveEmployeeCoreAccessProfile(proof!,command,getWorkspaceDb(binding));ensure(result.state==='saved','CANONICAL_CONTACT_RESTORE');}
    const final=await readOnboardingSetup(proof!,binding);ensure(final.configuration.people.find(p=>p.id==='OWNER-1')?.email==='support@thevelani.com'&&final.configuration.people.find(p=>p.id==='EMP-1')?.email===null,'FINAL_CONTACTS');
   });emit({state:'owner_contact_restored',canonicalCommands:true,approvedInboxOnly:true,noMailSent:true});
  }else if(phase==='employee-signin'){
   stage='current_employee_password_signin';const proof=await signIn(c,'EMP-1',c.employeePassword);ensure(proof.employee.role==='EMPLOYEE','CURRENT_EMPLOYEE_REQUIRED');c.employeeCookie=c.jar.fuel_session;c.jar.fuel_session=c.ownerCookie;save();emit({state:'employee_signed_in',currentPasswordAction:true,role:proof.employee.role});
  }else if(phase==='billing-smoke'){
   stage='rotated_billing_custody';await companyContext(c,async()=>{
    const{readCommerceAuthority}=await import('../../../src/lib/commerce/access');ensure((await readCommerceAuthority()).operational,'NEW_CUSTODY_ENTITLEMENT');const{POST}=await import('../../../src/app/api/commerce/handoff/route');const r=await POST(jsonRequest(c.origin,'/api/commerce/handoff',{}));ensure(r.status===200,'NEW_CUSTODY_OWNER_HANDOFF');const token=new URLSearchParams(new URL((await r.json()).url).hash.slice(1)).get('handoff'),api=process.env.NEVORA_COMMERCE_API_ORIGIN!;
    const exchange=await fetch(api+'/v1/handoff/exchange',{method:'POST',headers:{origin:'https://signup-staging.nevora.team','content-type':'application/json'},body:JSON.stringify({token}),signal:AbortSignal.timeout(20000),redirect:'error'});ensure(exchange.status===200,'NEW_CUSTODY_HANDOFF_EXCHANGE');c.billingBearer=(await exchange.json()).accessToken;save();const status=await fetch(api+'/v1/status',{headers:{origin:'https://signup-staging.nevora.team',authorization:'Bearer '+c.billingBearer},signal:AbortSignal.timeout(20000),redirect:'error'}),body=await status.json();ensure(status.status===200&&body.businessId===c.workspaceId&&body.operational===true,'NEW_CUSTODY_BILLING_STATUS');emit({state:'rotated_custody_operational',handoffStatus:r.status,exchangeStatus:exchange.status,status:status.status,accessState:body.state});
   });
  }else if(phase==='final-logout'){
   stage='close_all_test_owner_sessions';await companyContext(c,async()=>{const{destroySession,readSessionMutationProof}=await import('../../../src/lib/auth/session');await destroySession();ensure(await readSessionMutationProof()===null,'FINAL_LOGOUT');if(c.employeeCookie){c.jar.fuel_session=c.employeeCookie;await destroySession();ensure(await readSessionMutationProof()===null,'FINAL_EMPLOYEE_LOGOUT');}});const result=await fetch(process.env.NEVORA_COMMERCE_API_ORIGIN+'/v1/status',{headers:{origin:'https://signup-staging.nevora.team',authorization:'Bearer '+c.billingBearer},signal:AbortSignal.timeout(20000),redirect:'error'});ensure(result.status===401,'FINAL_BILLING_SESSION_REVOKED');emit({state:'closed',ownerSignedOut:true,billingStatus:result.status});
  }else if(phase==='transport-probes'){
   stage='actual_native_transport_boundary';ensure(/^[A-Za-z0-9_-]{43}$/.test(input.transportKey),'SERVICE_PROBE_KEY_REQUIRED');await companyContext(c,async()=>{
    const {currentCommerceConnection}=await import('../../../src/lib/commerce/access');const {readSessionMutationProof}=await import('../../../src/lib/auth/session');const {readBillingOwnerBinding}=await import('../../../src/lib/commerce/owner-binding');const {companyServiceSignature}=await import('../../../services/commerce/installation-transport');
    const connection=await currentCommerceConnection(),proof=await readSessionMutationProof();ensure(proof?.employee.role==='OWNER','OWNER_PROBE_REQUIRED');const owner=await readBillingOwnerBinding(proof!,connection);ensure(owner,'CURRENT_OWNER_BINDING_REQUIRED');const gateway='https://br-hidden-mud-bbnc2fxk-commerceauthority.compute.c-15.us-east-1.aws.neon.tech';
    const send=async(path,raw='',change={})=>{const method=path.endsWith('/facts')?'GET':'POST',origin=change.companyOrigin??c.origin,authorization='Bearer '+connection.secret,timestamp=String(Math.floor(Date.now()/1000)-(change.stale?31:0)),digest=createHash('sha256').update(raw).digest('hex'),signature=companyServiceSignature(input.transportKey,{timestamp,method,origin,path,authorization,bodySha256:digest});const headers={authorization,'x-nevora-company-origin':origin,'x-nevora-commerce-service-signature':'v1.'+timestamp+'.'+digest+'.'+(change.badHmac?'A'.repeat(43):signature),'content-type':'application/json'};return fetch((change.wrongHost?gateway.replace('-commerceauthority.compute','-unregisteredauthority.compute'):gateway)+path,{method,headers,...(method==='POST'?{body:change.altered?'{"changed":true}':raw}:{}),signal:AbortSignal.timeout(20000),redirect:'error'});};
    const positive=[];for(const[path,body]of [['/api/commerce/facts',''],['/api/commerce/policy',JSON.stringify({businessId:c.workspaceId,employeeLimit:15})],['/api/commerce/owner',JSON.stringify({businessId:c.workspaceId,installationId:c.workspaceId,incarnation:connection.incarnation,employeeId:proof!.employee.id,sessionTokenHash:proof!.sessionTokenHash,generation:owner.owner_generation})]]){const r=await send(path,body);ensure(r.status===200,'ORIGINAL_MACHINE_HANDLER_FAILED');positive.push({path,status:r.status});}
    const negative=[];for(const[requestClass,path,raw,patch,expected]of [['bad_service_hmac','/api/commerce/facts','',{badHmac:true},401],['altered_signed_body','/api/commerce/owner','{}',{altered:true},401],['oversized_authenticated_body','/api/commerce/owner','x'.repeat(2049),{},413],['expired_service_hmac','/api/commerce/facts','',{stale:true},401],['foreign_company_origin','/api/commerce/facts','',{companyOrigin:'https://foreign.invalid'},403]]){const r=await send(path,raw,patch);ensure(r.status===expected,'NATIVE_NEGATIVE_BOUNDARY_FAILED');negative.push({requestClass,status:r.status,layer:'application'});}
    try{const wrong=await send('/api/commerce/facts','',{wrongHost:true});ensure([400,401,403,404,421,503].includes(wrong.status),'WRONG_TARGET_HOST_ADMITTED');let code;try{const body=await wrong.json();if(typeof body.error?.code==='string'&&/^[a-z_]{1,50}$/.test(body.error.code))code=body.error.code;}catch{}negative.push({requestClass:'wrong_target_host',status:wrong.status,applicationCode:code??null,layer:code==='origin_denied'?'application':'platform routing; no application-handler acceptance claim'});}catch(e){if(e.message==='WRONG_TARGET_HOST_ADMITTED')throw e;negative.push({requestClass:'wrong_target_host',status:null,layer:'transport rejected; no application-handler acceptance claim'});}
    emit({state:'native_boundaries_verified',source:'a07bfcc17',browserEnvelopeKeyAbsentFromNativeInventory:true,positive,negative});
   });
  }else if(phase==='isolation'){
   stage='real_company_isolation';const a=state.companies.a,b=state.companies.b;
   const {readSessionMutationProof}=await import('../../../src/lib/auth/session');
   const {readOnboardingSetup}=await import('../../../src/lib/onboarding/setup.server');
   const {getWorkspaceDb}=await import('../../../src/lib/workspace-routing/transport.server');
   const {currentCommerceConnection}=await import('../../../src/lib/commerce/access');
   const {POST}=await import('../../../src/app/api/commerce/handoff/route');
   let aProof,connectionA;const identities=[];
   for(const x of [a,b])await companyContext(x,async binding=>{
    x.jar.fuel_session=x.ownerCookie;const proof=await readSessionMutationProof();ensure(proof?.employee.role==='OWNER','CURRENT_OWNER_REQUIRED');
    const rows=await getWorkspaceDb(binding).query({text:'SELECT current_database() AS database,workspace_id::text FROM public.onboarding_workspace_identity WHERE singleton',values:[]});ensure(rows.length===1&&rows[0].workspace_id===x.workspaceId,'COMPANY_DATABASE_IDENTITY');identities.push(rows[0]);
    if(x===a){aProof=proof;connectionA=await currentCommerceConnection();}
   });ensure(identities[0].workspace_id!==identities[1].workspace_id,'DATABASE_ISOLATION_REQUIRED');
   let crossCookieStatus,employeeStatus,crossProofDenied=false;
   const oldB=b.jar.fuel_session;b.jar.fuel_session=a.ownerCookie;
   try{await companyContext(b,async()=>{ensure(await readSessionMutationProof()===null,'CROSS_COMPANY_COOKIE_ADMITTED');crossCookieStatus=(await POST(jsonRequest(b.origin,'/api/commerce/handoff',{}))).status;ensure(crossCookieStatus===403,'CROSS_COMPANY_HANDOFF_ADMITTED');});}finally{b.jar.fuel_session=oldB;}
   await companyContext(b,async binding=>{try{await readOnboardingSetup(aProof,binding);}catch{crossProofDenied=true;}ensure(crossProofDenied,'CROSS_COMPANY_MUTATION_PROOF_ADMITTED');});
   const oldA=a.jar.fuel_session;a.jar.fuel_session=a.employeeCookie;
   try{await companyContext(a,async()=>{const proof=await readSessionMutationProof();ensure(proof?.employee.role==='EMPLOYEE','EMPLOYEE_REQUIRED');employeeStatus=(await POST(jsonRequest(a.origin,'/api/commerce/handoff',{}))).status;ensure(employeeStatus===403,'EMPLOYEE_BILLING_ADMITTED');});}finally{a.jar.fuel_session=oldA;}
   const cross=await fetch(connectionA.origin+'/internal/access',{headers:{authorization:'Bearer '+connectionA.secret,'x-nevora-installation':b.workspaceId},signal:AbortSignal.timeout(15000),redirect:'error'});ensure(cross.status===401,'CROSS_COMPANY_SECRET_ADMITTED');
   const wrong=await fetch(connectionA.origin+'/v1/status',{headers:{origin:'https://unapproved.example',authorization:'Bearer '+a.billingBearer},signal:AbortSignal.timeout(15000),redirect:'error'});ensure(wrong.status===403,'UNAPPROVED_UI_ORIGIN_ADMITTED');
   emit({state:'denied_as_expected',companyIdentities:identities,crossCookieStatus,crossProofDenied,employeeStatus,crossInstallationSecretStatus:cross.status,unapprovedUiStatus:wrong.status});
  }else if(phase==='source-unavailable'){
   stage='source_lifecycle_fail_closed';ensure(name==='b'&&input.sourceControl,'BOUNDED_SOURCE_PROBE_REQUIRED');
   const sourceUrl=new URL(input.sourceControl);ensure(decodeURIComponent(sourceUrl.username)==='nv_control_provision_a9ec007fb3935e41fd2a16ca'&&sourceUrl.pathname==='/nevora_onboarding_control'&&sourceUrl.searchParams.get('sslmode')==='verify-full','SOURCE_PROVISIONER_PRINCIPAL');
   const source=new Pool({connectionString:input.sourceControl,max:1,connectionTimeoutMillis:10000,statement_timeout:15000});source.on('error',()=>{});
   const {readCommerceAuthority,currentCommerceConnection}=await import('../../../src/lib/commerce/access');
   const {assertWorkspaceBindingCurrent}=await import('../../../src/lib/workspace-routing/resolver.server');let suspended=false,revision,denied=false,nativeStatus,unaffectedStatus;
   try{await companyContext(c,async binding=>{
    c.jar.fuel_session=c.ownerCookie;await readCommerceAuthority();const connection=await currentCommerceConnection();
    const current=(await source.query('SELECT revision::text,lifecycle FROM nevora_onboarding.workspace_registry WHERE id=$1 AND environment=$2',[c.workspaceId,'test'])).rows[0];ensure(current?.lifecycle==='ACTIVE','ACTIVE_FIXTURE_REQUIRED');revision=current.revision;
    const changed=await source.query("UPDATE nevora_onboarding.workspace_registry SET lifecycle='SUSPENDED',revision=revision+1 WHERE id=$1 AND environment='test' AND revision=$2 AND lifecycle='ACTIVE' RETURNING id",[c.workspaceId,revision]);ensure(changed.rowCount===1,'BOUNDED_SUSPENSION_FAILED');suspended=true;
    try{await readCommerceAuthority();}catch{denied=true;}ensure(denied,'CACHED_AUTHORITY_IGNORED_SOURCE_REVOCATION');
    let stale=false;try{await assertWorkspaceBindingCurrent(binding);}catch{stale=true;}ensure(stale,'STALE_BINDING_ADMITTED');
    const r=await fetch(connection.origin+'/v1/status',{headers:{origin:'https://signup-staging.nevora.team',authorization:'Bearer '+c.billingBearer},signal:AbortSignal.timeout(15000),redirect:'error'});nativeStatus=r.status;ensure(r.status>=400,'UNAVAILABLE_SOURCE_BILLING_ADMITTED');
    const other=await fetch(connection.origin+'/v1/status',{headers:{origin:'https://signup-staging.nevora.team',authorization:'Bearer '+state.companies.a.billingBearer},signal:AbortSignal.timeout(15000),redirect:'error'});unaffectedStatus=other.status;ensure(other.status===200,'UNRELATED_COMPANY_AFFECTED');
   });}finally{if(suspended){const restored=await source.query("UPDATE nevora_onboarding.workspace_registry SET lifecycle='ACTIVE',revision=revision+1 WHERE id=$1 AND environment='test' AND revision=$2::bigint+1 AND lifecycle='SUSPENDED' RETURNING revision::text",[c.workspaceId,revision]);ensure(restored.rowCount===1,'SOURCE_RESTORE_REQUIRED');c.restoredRevision=restored.rows[0].revision;save();}await source.end();}
   await companyContext(c,async()=>{const restored=await readCommerceAuthority();ensure(restored.operational,'SOURCE_RECOVERY_FAILED');});
   emit({state:'failed_closed_and_recovered',cachedAuthorityDenied:denied,nativeStatus,unaffectedStatus,monotonicRevision:true,restoredRevision:c.restoredRevision});
  }else if(phase==='revoke-billing'){
   stage='actual_owner_logout';const {POST}=await import('../../../src/app/api/commerce/handoff/route');
   const api=process.env.NEVORA_COMMERCE_API_ORIGIN!;
   const call=(path,body?,token?)=>fetch(api+path,{method:body===undefined?'GET':'POST',headers:{origin:'https://signup-staging.nevora.team',...(body===undefined?{}:{'content-type':'application/json'}),...(token?{authorization:'Bearer '+token}:{})},...(body===undefined?{}:{body:JSON.stringify(body)}),signal:AbortSignal.timeout(20000),redirect:'error'});
   c.revocationProbe??={};save();const probe=c.revocationProbe;
   await companyContext(c,async()=>{
    c.jar.fuel_session=c.ownerCookie;
    if(!probe.returnExchanged){const result=await call('/v1/handoff/exchange',{token:c.checkoutReturnProof});ensure(result.status===200,'ACTUAL_CHECKOUT_RETURN_EXCHANGE_FAILED');probe.returnBearer=(await result.json()).accessToken;probe.returnExchanged=true;save();}
    if(!probe.unspentHandoff){const r=await POST(jsonRequest(c.origin,'/api/commerce/handoff',{}));ensure(r.status===200,'REVOCATION_HANDOFF_PREPARE');probe.unspentHandoff=new URLSearchParams(new URL((await r.json()).url).hash.slice(1)).get('handoff');save();}
    const {destroySession,readSessionMutationProof}=await import('../../../src/lib/auth/session');await destroySession();ensure(await readSessionMutationProof()===null,'LOGOUT_COOKIE_STILL_ACTIVE');probe.ownerLoggedOut=true;save();
   });
   const statuses=[];for(const token of [c.billingBearer,probe.returnBearer]){const r=await call('/v1/status',undefined,token);ensure(r.status>=400,'REVOKED_OWNER_BILLING_ADMITTED');statuses.push(r.status);}
   const unspent=await call('/v1/handoff/exchange',{token:probe.unspentHandoff});ensure(unspent.status>=400,'REVOKED_OWNER_HANDOFF_ADMITTED');
   // An old browser cookie must fail independently of clearing the current jar.
   c.jar.fuel_session=c.ownerCookie;await companyContext(c,async()=>{const {readSessionMutationProof}=await import('../../../src/lib/auth/session');ensure(await readSessionMutationProof()===null,'OLD_OWNER_COOKIE_STILL_ACTIVE');const r=await POST(jsonRequest(c.origin,'/api/commerce/handoff',{}));ensure(r.status===403,'LOGGED_OUT_OWNER_HANDOFF_ADMITTED');});delete c.jar.fuel_session;
   emit({state:'owner_logout_revoked_billing',actualCheckoutReturnExchange:true,billingStatuses:statuses,unspentHandoffStatus:unspent.status,oldOwnerCookieDenied:true});
  }else if(phase==='billing-portal'){
   stage='native_customer_portal';c.portalOperation??=randomUUID();save();
   const api=process.env.NEVORA_COMMERCE_API_ORIGIN!;
   const r=await fetch(api+'/v1/portal',{method:'POST',headers:{origin:'https://signup-staging.nevora.team','content-type':'application/json',authorization:'Bearer '+c.billingBearer,'idempotency-key':c.portalOperation},body:'{}',signal:AbortSignal.timeout(30000),redirect:'error'});
   const body=await r.json();c.portalStatus=r.status;c.portalError=body.error?.code;save();ensure(r.status===200,'NATIVE_PORTAL_FAILED');ensure(new URL(body.url).origin==='https://billing.stripe.com','STRIPE_PORTAL_ORIGIN');c.portalUrl=body.url;save();emit({state:'portal_prepared',httpStatus:r.status,hostedStripe:true});
  }else throw Error('UNKNOWN_PHASE');
 }
}catch(error){save();console.log(JSON.stringify({phase,name,state:'unavailable',stage,code:error instanceof Error?error.message.replace(/[^A-Z0-9_]/g,'').slice(0,100):'UNKNOWN'}));process.exitCode=1;}finally{await pool.end();}
