## Task 2: Configure and verify application SMTP

**Owner/interfaces:** Codex; domain-scoped Resend sending-only key, dedicated Vercel staging Preview variables, existing application transport. Existing verified nevora.team domain; no unrelated production key reuse. Confirm official SMTP settings and key restrictions. Store sensitive SMTP password Preview-only, with other mail settings separately. Initially leave delivery flags off.

1. Inventory existing key names and Preview environment names; never decrypt unrelated values. Expected: no duplicate staging SMTP credential.
2. Create the domain-scoped sender credential and save securely to the approved staging destination. Expected: metadata confirms sensitive Preview-only, no temporary file remains.
3. Authenticate SMTP without sending, then use the real app registration/invitation paths with the approved inbox during bounded acceptance. Expected: exact envelope recipient, truthful provider acceptance/delivery, no new operation after uncertain outcomes.

