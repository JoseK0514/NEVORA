from pathlib import Path
import fcntl,gzip,hashlib,json,os,re,selectors,subprocess,tempfile,uuid
root=Path(__file__).resolve().parents[3]
rt=Path('/Users/josek0514/.codex/native-runtime/nevora-phases12-20261104-d791d75a')
sdk=Path.home()/'Library/Android/sdk'
env={k:v for k,v in os.environ.items() if k in ['HOME','PATH','TMPDIR','LANG','LC_ALL']}
env['JAVA_HOME']=str(Path.home()/'Library/Java/JavaVirtualMachines/temurin-21.jdk/Contents/Home');env['ANDROID_HOME']=str(sdk)
lock=(Path(tempfile.gettempdir())/'nevora-native-android-emulator-5560.lock').open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
a=[str(sdk/'platform-tools/adb'),'-s','emulator-5560']
def run(args,timeout=60,check=True):return subprocess.run(args,env=env,capture_output=True,text=True,check=check,timeout=timeout)
def device(*args,**kwargs):return run(a+list(args),**kwargs)
def user_state():
 text=device('shell','dumpsys','package','com.google.android.webview').stdout
 return next(line.strip() for line in text.splitlines() if 'User 0:' in line)
def source_hash():
 files=sorted(set(list((root/'native/android/app/src').rglob('*'))+list((root/'native/android').glob('*.gradle'))+[root/'native/ios/Fixtures/server.mjs',root/'src/lib/native-shell/security.ts']))
 digest=hashlib.sha256()
 for path in files:
  if path.is_file():digest.update(str(path.relative_to(root)).encode()+b'\0'+path.read_bytes())
 return digest.hexdigest()
assert device('emu','avd','name').stdout.splitlines()[0]=='NevoraPhase12_API32'
assert device('shell','getprop','ro.kernel.qemu').stdout.strip()=='1'
assert re.search(r'\benabled=0\b',user_state())
evidence=Path(tempfile.mkdtemp(prefix='nevora-missing-webview-'));key=uuid.uuid4().hex
report={'qualification':'diagnostic-missing-provider','serial':'emulator-5560','evidence':str(evidence),'passed':False,'sourceHash':source_hash(),'owner':key}
server=None;ports=[];disabled=False
try:
 build=rt/'runtime-baseline-build'
 command=[str(root/'native/android/gradlew'),'--no-daemon','--project-cache-dir',str(rt/'runtime-baseline-gradle-cache'),'-PnevoraBuildDirectory='+str(build),':app:assembleDebug',':app:assembleDebugAndroidTest']
 with (evidence/'build.log').open('w') as output:
  result=subprocess.run(command,cwd=root/'native/android',env=env,stdout=output,stderr=subprocess.STDOUT,timeout=300)
 assert result.returncode==0
 for apk in [build/'outputs/apk/debug/app-debug.apk',build/'outputs/apk/androidTest/debug/app-debug-androidTest.apk']:
  device('install','-r','-t',str(apk),timeout=90)
 server=subprocess.Popen(['node',str(root/'native/ios/Fixtures/server.mjs')],env=env,stdout=subprocess.PIPE,text=True)
 with selectors.DefaultSelector() as selector:
  selector.register(server.stdout,selectors.EVENT_READ);assert selector.select(timeout=5);addresses=json.loads(server.stdout.readline(4096))
 from urllib.parse import urlsplit
 for value in addresses.values():
  uri=urlsplit(value);assert uri.scheme=='http' and uri.hostname=='127.0.0.1' and uri.port and not uri.path and not uri.query and not uri.username
  ports.append(uri.port);device('reverse','tcp:'+str(uri.port),'tcp:'+str(uri.port))
 report['enabledStateBefore']=user_state();device('shell','pm','disable-user','--user','0','com.google.android.webview');disabled=True
 assert re.search(r'\benabled=3\b',user_state())
 state=device('shell','dumpsys','webviewupdate').stdout;(evidence/'provider-disabled.txt').write_text(state)
 assert 'Current WebView package (name, version):' not in state
 assert device('shell','test','-e','/data/local/tmp/webview-command-line',check=False).returncode==1
 result=device('shell','am','instrument','-w','-e','class','com.velani.nevora.development.ShellInstrumentedTest#j_missingWebViewStillShowsNativeUpdate','-e','fixtureOrigin',addresses['origin'],'-e','unavailableOrigin',addresses['unavailableOrigin'],'-e','nativeEvidenceKey',key,'com.velani.nevora.development.test/androidx.test.runner.AndroidJUnitRunner',timeout=90)
 output=result.stdout+result.stderr;(evidence/'instrumentation.log.gz').write_bytes(gzip.compress(output.encode(),mtime=0))
 (evidence/'android-runtime.log.gz').write_bytes(gzip.compress(device('logcat','-d','-v','brief','AndroidRuntime:E','*:S').stdout.encode(),mtime=0))
 assert source_hash()==report['sourceHash'];report['sourceVerified']=True
 assert re.search(r'\benabled=3\b',user_state());report['providerAbsentBeforeAfter']=True
 assert result.returncode==0 and re.findall(r'OK \((\d+) tests?\)',output)==['1'] and not any(x in output for x in ['FAILURES!!!','Process crashed','INSTRUMENTATION_FAILED']),output[-2000:]
 report['passed']=True
finally:
 errors=[]
 if disabled:
  try:
   assert re.search(r'\benabled=3\b',user_state());device('shell','pm','default-state','--user','0','com.google.android.webview');report['enabledStateAfter']=user_state();assert re.search(r'\benabled=0\b',report['enabledStateAfter']);report['providerStateRestored']=True
  except Exception as e:errors.append('provider:'+type(e).__name__)
 try:device('shell','am','force-stop','com.velani.nevora.development')
 except Exception as e:errors.append('app:'+type(e).__name__)
 for port in ports:
  try:device('reverse','--remove','tcp:'+str(port))
  except Exception as e:errors.append('reverse:'+type(e).__name__)
 if server:
  if server.poll() is None:server.terminate()
  try:server.wait(timeout=5)
  except subprocess.TimeoutExpired:server.kill();server.wait(timeout=5)
  server.stdout.close()
 if errors:report['passed']=False;report['cleanupErrors']=errors
 (evidence/'result.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
