import pathlib,json,gzip,hashlib,subprocess
root=pathlib.Path.cwd(); out=root/'docs/native/evidence/2026-11-04/runtime-baseline'
def read(name):return json.loads((out/name).read_text())
core=read('core.json');assert core['passed'] and core['jvm']=={'tests':26,'failures':0,'errors':0,'skipped':0} and core['apkMinimumSdk']==29 and core['debugAndTestAndUnsignedReleaseAndLint']
for name in ['supported-api32-matrix','supported-api37-matrix']:
 r=read(name+'/result.json');assert r['passed'] and r['instrumentationTests']==10 and r['coldInstrumentationTests']==1 and r['coldProcessRestart'] and r['fixtureOnly'] and not r['rendererObserver']; assert r['webView']=={'package':'com.google.android.webview','version':'149.0.7827.5','accessibilityMode':'platform-default','runtimeFlagsSha256':None}
r=read('backend-green/result.json');b=read('backend-green/backend-results.json');d=b['devices'][0];assert r['status']=='passed' and r['sourceVerified'] and r['ownershipClosed'] and b['status']=='passed' and b['ownershipClosed'];assert len(b['checks'])==18 and len({v['name'] for v in b['checks']})==18 and all(v['status']=='passed' for v in b['checks']);assert d['instrumentationTests']==3 and d['coldInstrumentationTests']==1 and d['qualification']=='full-backend' and not d['fixtureOnly'] and d['passed'] and not d['rendererObserver']
android=root/'native/android';files=sorted(set(list((android/'app/src').rglob('*'))+list(android.glob('*.gradle'))+list(android.glob('*.properties'))+list(android.glob('*.py'))+list((android/'gradle/wrapper').glob('*'))+[android/'app/build.gradle',android/'gradlew',root/'native/owned_artifacts.py',root/'native/ios/Fixtures/server.mjs',root/'src/lib/native-shell/security.ts']));digest=hashlib.sha256()
for p in files:
 if p.is_file():digest.update(str(p.relative_to(root)).encode()+b'\0'+p.read_bytes())
assert digest.hexdigest()==d['sourceHash']==read('supported-api37-matrix/result.json')['sourceHash']
assert not subprocess.check_output(['git','diff','79f2d9cbf746009add1be757858664cda0873780','--name-only','--','native','src','db','scripts','package.json','package-lock.json'],text=True).strip()
for a in read('qualification-artifacts.json'):
 data=(out/a['artifact']).read_bytes(); data=gzip.decompress(data) if a['gzip'] else data; assert len(data)==a['bytes'] and hashlib.sha256(data).hexdigest()==a['sha256']
assert read('source-continuity.json')['originalTenPendingFilesPreserved'] and not read('source-continuity.json')['changedPaths']
assert read('api32-google149-provider-owner.json')['restored'] and read('api32-google149-provider-owner.json')['restoredApkSha256']==read('api32-google149-provider-owner.json')['originalSha256'];assert read('api32-large-text-owner.json')['restored'] and read('api32-provider-disable-owner.json')['restored']
assert all(read(n)['stopped'] and read(n)['pid'] is None for n in ['api32-google149-owner.json','api37-owner.json'])
for n in ['outdated-provider-green','large-text-landscape-keyboard']:assert read(n+'/result.json')['passed'] and read(n+'/result.json')['instrumentationTests']==1
assert read('missing-provider-green/result.json')['passed'] and read('missing-provider-green/result.json')['providerStateRestored'] and read('missing-provider-green/result.json')['sourceVerified']
print(json.dumps({'passed':True,'candidate':r['checkpoint'],'jvm':26,'foundationEach':[10,1],'supportedTargets':['API32','API37.2'],'backendChecks':18,'nativeJourneys':3,'cold':1,'sourceVerified':True,'ownershipClosed':True,'evidenceHashesVerified':True,'restoredAndStopped':True}))
