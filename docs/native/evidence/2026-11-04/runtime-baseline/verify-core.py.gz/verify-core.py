from pathlib import Path
import os,subprocess,json,xml.etree.ElementTree as E
root=Path(__file__).resolve().parents[3]
rt=Path('/Users/josek0514/.codex/native-runtime/nevora-phases12-20261104-d791d75a')
env={k:v for k,v in os.environ.items() if k in ['HOME','PATH','TMPDIR','LANG','LC_ALL']};env['JAVA_HOME']=str(Path.home()/'Library/Java/JavaVirtualMachines/temurin-21.jdk/Contents/Home');env['ANDROID_HOME']=str(Path.home()/'Library/Android/sdk')
command=[str(root/'native/android/gradlew'),'--no-daemon','--project-cache-dir',str(rt/'runtime-baseline-gradle-cache'),'-PnevoraBuildDirectory='+str(rt/'runtime-baseline-build'),':app:testDebugUnitTest',':app:assembleDebug',':app:assembleDebugAndroidTest',':app:assembleRelease',':app:lint']
log=rt/'runtime-baseline-core.log'
with log.open('w') as output:result=subprocess.run(command,cwd=root/'native/android',env=env,stdout=output,stderr=subprocess.STDOUT,timeout=300)
assert result.returncode==0,log.read_text()[-2500:]
reports=list((rt/'runtime-baseline-build/test-results/testDebugUnitTest').glob('TEST-*.xml'));counts={'tests':0,'failures':0,'errors':0,'skipped':0}
for report in reports:
 tree=E.parse(report).getroot()
 for name in counts:counts[name]+=int(tree.attrib.get(name,0))
assert counts=={'tests':26,'failures':0,'errors':0,'skipped':0},counts
badging=subprocess.run([str(Path.home()/'Library/Android/sdk/build-tools/36.0.0/aapt'),'dump','badging',str(rt/'runtime-baseline-build/outputs/apk/debug/app-debug.apk')],env=env,capture_output=True,text=True,check=True).stdout
assert "sdkVersion:'29'" in badging
receipt={'passed':True,'command':command,'jvm':counts,'debugAndTestAndUnsignedReleaseAndLint':True,'apkMinimumSdk':29,'log':str(log)};(rt/'runtime-baseline-core.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
